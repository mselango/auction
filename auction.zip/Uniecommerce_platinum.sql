-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2013 at 04:50 PM
-- Server version: 5.1.69
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Uniecommerce_platinum`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE IF NOT EXISTS `ads` (
  `ads_id` int(5) NOT NULL AUTO_INCREMENT,
  `ads_title` varchar(100) NOT NULL,
  `ads_code` text NOT NULL,
  `ads_position` varchar(10) NOT NULL,
  `ad_pos` int(11) NOT NULL,
  `link` varchar(250) NOT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`ads_id`),
  KEY `add_id` (`ads_id`),
  KEY `add_id_2` (`ads_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`ads_id`, `ads_title`, `ads_code`, `ads_position`, `ad_pos`, `link`, `status`) VALUES
(1, 'soooooo', ' <a href="http://ad.zanox.com/ppc/?23935278C1360341802T"><img src="http://ad.zanox.com/ppv/?23935278C1360341802" align="bottom" width="160" height="200" border="0" hspace="1" alt="De beste deals bij Groupon!"></a>', 'bh', 6, 'http://www.kavin.com', 1),
(7, 'dsfsf', 'dsfdsfsdf', 'bh', 5, 'htpp://www.jj.com', 1),
(8, 'kavin', '', 'bh', 4, 'http://www.kavin.com', 1),
(11, 'dfdsf', '', 'bh', 4, 'http://www.kavin.com', 1),
(12, 'kvin', '', 'bh', 7, 'http://192.168.1.44:1430/Uniecommerce_platinum/trunk/products/category/main/computers.html', 1);

-- --------------------------------------------------------

--
-- Table structure for table `auction`
--

CREATE TABLE IF NOT EXISTS `auction` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `url_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `deal_key` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `deal_description` text COLLATE utf8_unicode_ci NOT NULL,
  `fineprints` text COLLATE utf8_unicode_ci NOT NULL,
  `highlights` text COLLATE utf8_unicode_ci NOT NULL,
  `terms_conditions` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` varchar(96) COLLATE utf8_unicode_ci NOT NULL,
  `deal_type` int(1) NOT NULL COMMENT '1-deals, 2-products, 3 - Auction',
  `merchant_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `product_value` double NOT NULL,
  `deal_value` double NOT NULL,
  `deal_price` double NOT NULL,
  `deal_savings` double NOT NULL,
  `user_limit_quantity` int(5) NOT NULL,
  `bid_increment` double NOT NULL,
  `bid_count` int(11) NOT NULL,
  `shipping_fee` double NOT NULL,
  `shipping_info` text COLLATE utf8_unicode_ci NOT NULL,
  `startdate` int(10) NOT NULL,
  `enddate` int(10) NOT NULL,
  `created_date` int(10) NOT NULL,
  `created_by` int(11) NOT NULL,
  `deal_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  `winner` int(11) NOT NULL,
  `auction_status` int(11) NOT NULL,
  PRIMARY KEY (`deal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `auction`
--

INSERT INTO `auction` (`deal_id`, `deal_title`, `url_title`, `deal_key`, `deal_description`, `fineprints`, `highlights`, `terms_conditions`, `meta_description`, `meta_keywords`, `category_id`, `sub_category_id`, `deal_type`, `merchant_id`, `shop_id`, `product_value`, `deal_value`, `deal_price`, `deal_savings`, `user_limit_quantity`, `bid_increment`, `bid_count`, `shipping_fee`, `shipping_info`, `startdate`, `enddate`, `created_date`, `created_by`, `deal_status`, `winner`, `auction_status`) VALUES
(1, ' 3D channel ', '3d-channel', '9CXaPukK', 'zxvzxv', 'zxvzx', 'vzxvxz', 'zxvzxv', 'vxzvxv', 'zxvzx', 78, '165', 0, 247, 1, 30, 25, 40, 5, 0, 5, 3, 6, 'xvzxv', 1369593000, 1369593120, 1369635589, 14, 1, 0, 1),
(2, 'Samsung LED TV online deal', 'samsung-led-tv-online-deal', 'FyLP2FEr', '<span style="color: rgb(17, 17, 17); font-family: arial; font-size: 20px; letter-spacing: -1px; background-color: rgb(255, 255, 255);">Samsung LED TV online deal</span><span style="color: rgb(17, 17, 17); font-family: arial; font-size: 20px; letter-spacing: -1px; background-color: rgb(255, 255, 255);">Samsung LED TV online deal</span>', '<span style="color: rgb(17, 17, 17); font-family: arial; font-size: 20px; letter-spacing: -1px; background-color: rgb(255, 255, 255);">Samsung LED TV online deal</span> ', '<span style="color: rgb(17, 17, 17); font-family: arial; font-size: 20px; letter-spacing: -1px; background-color: rgb(255, 255, 255);">Samsung LED TV online deal</span> ', '<span style="color: rgb(17, 17, 17); font-family: arial; font-size: 20px; letter-spacing: -1px; background-color: rgb(255, 255, 255);">Samsung LED TV online deal</span>', 'Samsung LED TV online deal', 'Samsung LED TV online deal', 119, '136', 0, 247, 1, 500, 300, 300, 200, 0, 5, 0, 0, 'xzzxvxzv', 1369679400, 1370025000, 1369719810, 14, 1, 0, 0),
(3, 'Proline Crew Neck Short Sleeves For Men', 'proline-crew-neck-short-sleeves-for-men', 'jhPL7RGH', '<span style="color: rgb(101, 101, 101); font-family: arial; background-color: rgb(255, 255, 255);">Proline is a brand for apparels and sportswear. Proline India was started by Rajesh and Rajiv Batra as a joint venture between Batra Group of Companies and Bombay Dyeing in 1983. Proline clothing line is aimed at the age group 18 to 35 years. The brand has a pan India presence and is well recognised by consumers. Started as a sports apparels company, it was endorsed by the likes of cricketers Ravi Shashtri and Vinod Kambli in its early days. Proline also exports to Middle East and Sri Lanka. Proline offers premium clothing with natural cotton fabric to offer the maximum comfort. The clothing is skilfully designed and apparels are made from high quality fabric. Proline aims to offer affordable clothing with trendiest designs. The brand mantra, in sync with modern generation, is Rock and Rule. The brand offers Proline t-shirts, Proline polo, Proline shorts, Proline trousers, trackpants, Proline accessories such as scarves, etc. Explore the latest collection from Proline at Jabong 24x7 online megastore. Get free shipping on all your orders and pay by Cash on Delivery.</span>', '<span style="color: rgb(101, 101, 101); font-family: arial; background-color: rgb(255, 255, 255);">Proline is a brand for apparels and sportswear. Proline India was started by Rajesh and Rajiv Batra as a joint venture between Batra Group of Companies and Bombay Dyeing in 1983. Proline clothing line is aimed at the age group 18 to 35 years. The brand has a pan India presence and is well recognised by consumers. Started as a sports apparels company, it was endorsed by the likes of cricketers Ravi Shashtri and Vinod Kambli in its early days. Proline also exports to Middle East and Sri Lanka. Proline offers premium clothing with natural cotton fabric to offer the maximum comfort. The clothing is skilfully designed and apparels are made from high quality fabric. Proline aims to offer affordable clothing with trendiest designs. The brand mantra, in sync with modern generation, is Rock and Rule. The brand offers Proline t-shirts, Proline polo, Proline shorts, Proline trousers, trackpants, Proline accessories such as scarves, etc. Explore the latest collection from Proline at Jabong 24x7 online megastore. Get free shipping on all your orders and pay by Cash on Delivery.</span> ', '<span style="color: rgb(101, 101, 101); font-family: arial; background-color: rgb(255, 255, 255);">Proline is a brand for apparels and sportswear. Proline India was started by Rajesh and Rajiv Batra as a joint venture between Batra Group of Companies and Bombay Dyeing in 1983. Proline clothing line is aimed at the age group 18 to 35 years. The brand has a pan India presence and is well recognised by consumers. Started as a sports apparels company, it was endorsed by the likes of cricketers Ravi Shashtri and Vinod Kambli in its early days. Proline also exports to Middle East and Sri Lanka. Proline offers premium clothing with natural cotton fabric to offer the maximum comfort. The clothing is skilfully designed and apparels are made from high quality fabric. Proline aims to offer affordable clothing with trendiest designs. The brand mantra, in sync with modern generation, is Rock and Rule. The brand offers Proline t-shirts, Proline polo, Proline shorts, Proline trousers, trackpants, Proline accessories such as scarves, etc. Explore the latest collection from Proline at Jabong 24x7 online megastore. Get free shipping on all your orders and pay by Cash on Delivery.</span> ', '<span style="color: rgb(101, 101, 101); font-family: arial; background-color: rgb(255, 255, 255);">Proline is a brand for apparels and sportswear. Proline India was started by Rajesh and Rajiv Batra as a joint venture between Batra Group of Companies and Bombay Dyeing in 1983. Proline clothing line is aimed at the age group 18 to 35 years. The brand has a pan India presence and is well recognised by consumers. Started as a sports apparels company, it was endorsed by the likes of cricketers Ravi Shashtri and Vinod Kambli in its early days. Proline also exports to Middle East and Sri Lanka. Proline offers premium clothing with natural cotton fabric to offer the maximum comfort. The clothing is skilfully designed and apparels are made from high quality fabric. Proline aims to offer affordable clothing with trendiest designs. The brand mantra, in sync with modern generation, is Rock and Rule. The brand offers Proline t-shirts, Proline polo, Proline shorts, Proline trousers, trackpants, Proline accessories such as scarves, etc. Explore the latest collection from Proline at Jabong 24x7 online megastore. Get free shipping on all your orders and pay by Cash on Delivery.</span>', 'xvzxv', 'zvz', 178, '181', 0, 247, 1, 100, 59, 74, 41, 0, 5, 3, 2, 'zxvzx', 1369679400, 1370543400, 1369720245, 14, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `auction_cod`
--

CREATE TABLE IF NOT EXISTS `auction_cod` (
  `auction_cod_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `shipping_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pin` bigint(10) NOT NULL,
  `fb_id` varchar(100) NOT NULL,
  `auction_id` int(10) NOT NULL,
  `datetime` bigint(20) NOT NULL,
  `amount` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`auction_cod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `auction_cod`
--

INSERT INTO `auction_cod` (`auction_cod_id`, `user_id`, `shipping_name`, `email`, `phone`, `address`, `city`, `state`, `country`, `pin`, `fb_id`, `auction_id`, `datetime`, `amount`, `quantity`, `status`) VALUES
(1, 278, 'elango', 'elangovan.s@ndot.in', 66346, 'erode', '1', 'TN', '22', 346346, 'xcnxnxcn', 1, 1369646691, 35, 1, 'Payment Done'),
(3, 278, 'vnccvncvn', 'cvncvn', 5745858, 'cvncvn', '1', 'cvncvn', '22', 0, 'nvnxcnx', 1, 1369648001, 35, 1, 'Payment Done'),
(4, 278, 'pradeep', 'pradeep@gmail.com', 346, 'zvxzxv', '1', 'xzvzxvxzv', '22', 5364346, 'xcnxcnx', 1, 1369650935, 35, 1, 'Payment Done');

-- --------------------------------------------------------

--
-- Table structure for table `banner_image`
--

CREATE TABLE IF NOT EXISTS `banner_image` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `image_title` varchar(256) NOT NULL,
  `redirect_url` text NOT NULL,
  `position` int(3) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1-Active,0-Deactive',
  PRIMARY KEY (`banner_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `banner_image`
--

INSERT INTO `banner_image` (`banner_id`, `image_title`, `redirect_url`, `position`, `status`) VALUES
(1, 'banner 1', 'http://192.168.1.35:1212/UniECommerce-v3/product/W9PNrqOF/ndot-social-commenting.html', 0, 1),
(2, 'banner 2', 'http://192.168.1.35:1212/UniECommerce-v3/product/u93AzwVQ/test-merchant-product.html', 0, 1),
(3, 'banner 3', 'http://192.168.1.35:1212/UniECommerce-v3/product/n1DcObgS/product-for-codproduct-for-codproduct-for-codproduct-for-codproduct-for-codproduct-for-cod.html', 0, 1),
(4, 'banner 4', 'http://192.168.1.35:1212/UniECommerce-v3/product/u93AzwVQ/test-merchant-product.html', 0, 1),
(5, 'banner 5', 'http://192.168.1.35:1212/UniECommerce-v3/', 0, 1),
(6, 'banner 6', 'http://192.168.1.35:1212/UniECommerce-v3/product/n1DcObgS/product-for-codproduct-for-codproduct-for-codproduct-for-codproduct-for-codproduct-for-cod.html', 0, 1),
(7, 'banner 7', 'http://192.168.1.35:1212/UniECommerce-v3/product/u93AzwVQ/test-merchant-product.html', 0, 1),
(8, 'banner 8', 'http://192.168.1.35:1212/UniECommerce-v3/', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bidding`
--

CREATE TABLE IF NOT EXISTS `bidding` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `auction_id` int(11) NOT NULL,
  `auction_title` varchar(264) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bid_amount` int(11) NOT NULL,
  `shipping_amount` int(11) NOT NULL,
  `bidding_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `winning_status` int(1) NOT NULL DEFAULT '0' COMMENT '0-Not win,1-Win,2-Action bought',
  `mail_alert` int(1) NOT NULL COMMENT '1-winng,2-1st-alert,3-2nd-alert',
  PRIMARY KEY (`bid_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `bidding`
--

INSERT INTO `bidding` (`bid_id`, `auction_id`, `auction_title`, `user_id`, `bid_amount`, `shipping_amount`, `bidding_time`, `end_time`, `winning_status`, `mail_alert`) VALUES
(1, 1, ' 3D channel ', 278, 25, 6, 1369635717, 1369679400, 0, 0),
(2, 1, ' 3D channel ', 278, 30, 6, 1369635733, 1369679400, 0, 0),
(3, 1, ' 3D channel ', 278, 35, 6, 1369635789, 1369679400, 1, 0),
(4, 3, 'Proline Crew Neck Short Sleeves For Men', 278, 60, 2, 1369720264, 1370543400, 0, 0),
(5, 3, 'Proline Crew Neck Short Sleeves For Men', 278, 65, 2, 1369722603, 1370543400, 0, 0),
(6, 3, 'Proline Crew Neck Short Sleeves For Men', 281, 80, 2, 1369815218, 1370543400, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_title` varchar(256) NOT NULL,
  `url_title` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blog_description` longtext NOT NULL,
  `category_id` int(11) NOT NULL,
  `meta_title` varchar(256) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `meta_keywords` varchar(256) NOT NULL,
  `tags` varchar(256) NOT NULL,
  `allow_comments` int(1) NOT NULL DEFAULT '1' COMMENT '1=>yes, 0=>no',
  `comments_count` int(11) NOT NULL,
  `blog_views` int(11) NOT NULL,
  `blog_date` int(11) NOT NULL,
  `publish_status` int(1) NOT NULL DEFAULT '1' COMMENT '1=> published, 2=>draft',
  `blog_status` int(1) NOT NULL DEFAULT '1' COMMENT '1=>active, 0=>deactive',
  PRIMARY KEY (`blog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE IF NOT EXISTS `blog_comments` (
  `comments_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `comments` varchar(250) NOT NULL,
  `blogg_id` int(11) NOT NULL,
  `approve_status` int(1) NOT NULL DEFAULT '0' COMMENT '1=>approved,0=>disapproved',
  `comments_date` int(11) NOT NULL,
  `notify_comments` int(1) NOT NULL DEFAULT '0' COMMENT '1=>yes,0=>no',
  `comments_status` int(1) NOT NULL DEFAULT '1' COMMENT '1=>active,0=>deactive',
  PRIMARY KEY (`comments_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blog_settings`
--

CREATE TABLE IF NOT EXISTS `blog_settings` (
  `blog_settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `allow_comment_posting` int(1) NOT NULL DEFAULT '1' COMMENT '1=>yes, 2=>no',
  `require_adminapproval_comments` int(1) NOT NULL DEFAULT '1' COMMENT '1=>yes, 2=>no',
  `posts_per_page` int(5) NOT NULL DEFAULT '4',
  PRIMARY KEY (`blog_settings_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `blog_settings`
--

INSERT INTO `blog_settings` (`blog_settings_id`, `allow_comment_posting`, `require_adminapproval_comments`, `posts_per_page`) VALUES
(1, 1, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(3) NOT NULL AUTO_INCREMENT,
  `main_category_id` int(11) NOT NULL,
  `category_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `category_url` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `category_mapping` text COLLATE utf8_unicode_ci NOT NULL,
  `category_status` int(1) NOT NULL DEFAULT '1',
  `deal` int(1) NOT NULL,
  `product` int(1) NOT NULL,
  `auction` int(1) NOT NULL,
  PRIMARY KEY (`category_id`),
  FULLTEXT KEY `subtypename` (`category_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=224 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `main_category_id`, `category_name`, `category_url`, `category_mapping`, `category_status`, `deal`, `product`, `auction`) VALUES
(176, 0, 'Televisions', 'televisions', '', 1, 1, 0, 0),
(139, 119, 'Digital Cameras', 'digital-cameras', '', 1, 0, 0, 0),
(78, 0, 'Jewellery', 'jewellery', '', 1, 1, 1, 1),
(154, 0, 'Home & Garden', 'home-garden', '', 1, 1, 0, 0),
(153, 152, 'Fine Art Listings', 'fine-art-listings', '', 0, 0, 0, 0),
(119, 0, 'Electronics', 'electronics', '', 1, 0, 1, 1),
(123, 118, 'Fish', 'fish', '', 1, 0, 0, 0),
(125, 118, 'Mutton', 'mutton', '', 1, 0, 0, 0),
(126, 118, 'chicken', 'chicken', '', 1, 0, 0, 0),
(127, 49, 'Dinner', 'dinner', '', 1, 0, 0, 0),
(128, 42, 'Birth Day', 'birth-day', '', 1, 0, 0, 0),
(129, 42, 'Marrige', 'marrige', '', 1, 0, 0, 0),
(130, 0, 'Collectibles', 'collectibles', '', 1, 1, 0, 0),
(131, 130, 'Coins', 'coins', '', 1, 0, 0, 0),
(132, 130, 'Heritage Memorabilia', 'heritage-memorabilia', '', 1, 0, 0, 0),
(133, 130, 'and Coins', 'and-coins', '', 1, 0, 0, 0),
(134, 130, 'MLBPAA Memorabilia', 'mlbpaa-memorabilia', '', 1, 0, 0, 0),
(135, 130, 'Other Collectibles', 'other-collectibles', '', 1, 0, 0, 0),
(136, 119, 'Camcorders', 'camcorders', '', 1, 0, 0, 0),
(137, 119, 'Car Electronics', 'car-electronics', '', 1, 0, 0, 0),
(138, 119, 'Cell Phones', 'cell-phones', '', 1, 0, 0, 0),
(140, 119, 'DVD Players', 'dvd-players', '', 1, 0, 0, 0),
(141, 119, 'GPS Systems', 'gps-systems', '', 1, 0, 0, 0),
(142, 119, 'Home Audio', 'home-audio', '', 1, 0, 0, 0),
(143, 119, 'iPod & MP3 Players', 'ipod-mp3-players', '', 1, 0, 0, 0),
(144, 119, 'Speakers', 'speakers', '', 1, 0, 0, 0),
(145, 119, 'Video Games', 'video-games', '', 1, 0, 0, 0),
(146, 119, 'Digital Picture Frames', 'digital-picture-frames', '', 1, 0, 0, 0),
(147, 119, 'Headphones', 'headphones', '', 1, 0, 0, 0),
(148, 119, 'Home Security', 'home-security', '', 1, 0, 0, 0),
(149, 119, 'Portable Electronics', 'portable-electronics', '', 1, 0, 0, 0),
(150, 119, 'Telephones', 'telephones', '', 1, 0, 0, 0),
(151, 119, 'Video Accessories', 'video-accessories', '', 1, 0, 0, 0),
(152, 0, 'Fine Art', 'fine-art', '', 0, 1, 1, 0),
(155, 154, 'Gardening & Plants', 'gardening-plants', '', 1, 0, 0, 0),
(156, 154, 'Home Decor', 'home-decor', '', 1, 0, 0, 0),
(157, 154, 'Housekeeping', 'housekeeping', '', 1, 0, 0, 0),
(158, 154, 'Kitchen & Dining', 'kitchen-dining', '', 1, 0, 0, 0),
(159, 154, 'Lawn & Patio', 'lawn-patio', '', 1, 0, 0, 0),
(160, 154, 'Tools & Accessories', 'tools-accessories', '', 1, 0, 0, 0),
(161, 154, 'Air Tools', 'air-tools', '', 1, 0, 0, 0),
(162, 154, 'Shop Equipment', 'shop-equipment', '', 1, 0, 0, 0),
(163, 154, 'Hand Tools', 'hand-tools', '', 1, 0, 0, 0),
(164, 154, 'Power Tools', 'power-tools', '', 1, 0, 0, 0),
(165, 78, 'Birthstones', 'birthstones', '', 1, 0, 0, 0),
(166, 78, 'Rings', 'rings', '', 1, 0, 0, 0),
(167, 78, 'Earrings', 'earrings', '', 1, 0, 0, 0),
(168, 78, 'Mens Jewelry', 'mens-jewelry', '', 1, 0, 0, 0),
(169, 78, 'Necklaces', 'necklaces', '', 1, 0, 0, 0),
(170, 78, 'Bracelets & Anklets', 'bracelets-anklets', '', 1, 0, 0, 0),
(171, 78, 'Pendants & Lockets', 'pendants-lockets', '', 1, 0, 0, 0),
(172, 78, 'Engagement Rings', 'engagement-rings', '', 1, 0, 0, 0),
(173, 78, 'Diamond Rings', 'diamond-rings', '', 1, 0, 0, 0),
(174, 78, 'Diamond Earrings', 'diamond-earrings', '', 1, 0, 0, 0),
(175, 78, 'Diamond Necklaces', 'diamond-necklaces', '', 1, 0, 0, 0),
(177, 176, 'LCD TV', 'lcd-tv', '', 1, 0, 0, 0),
(178, 0, 'Travel', 'travel', '', 1, 1, 1, 1),
(179, 178, 'Travel Bags', 'travel-bags', '', 1, 0, 0, 0),
(180, 178, 'Packages', 'packages', '', 1, 0, 0, 0),
(181, 178, 'Vouchers', 'vouchers', '', 1, 0, 0, 0),
(182, 178, 'Accessories', 'accessories', '', 1, 0, 0, 0),
(183, 0, 'Watches', 'watches', '', 1, 1, 1, 1),
(184, 183, 'View All Watches', 'view-all-watches', '', 1, 0, 0, 0),
(185, 183, 'Mens Watches', 'mens-watches', '', 1, 0, 0, 0),
(186, 183, 'Ladies Watches', 'ladies-watches', '', 1, 0, 0, 0),
(187, 0, 'EverythingElse', 'everythingelse', '', 1, 1, 0, 0),
(188, 187, 'Handbags', 'handbags', '', 1, 0, 0, 0),
(189, 187, 'Health & Beauty', 'health-beauty', '', 1, 0, 0, 0),
(190, 187, 'Luggage', 'luggage', '', 1, 0, 0, 0),
(191, 187, 'Mens Clothing', 'mens-clothing', '', 1, 0, 0, 0),
(192, 187, 'Mens Shoes & Accessories', 'mens-shoes-accessories', '', 1, 0, 0, 0),
(193, 187, 'Movies', 'movies', '', 1, 0, 0, 0),
(194, 187, 'Musical Instruments', 'musical-instruments', '', 1, 0, 0, 0),
(195, 187, 'Womens Clothing', 'womens-clothing', '', 1, 0, 0, 0),
(196, 187, 'Womens Shoes & Accessories', 'womens-shoes-accessories', '', 1, 0, 0, 0),
(197, 187, 'Binoculars & Telescopes', 'binoculars-telescopes', '', 1, 0, 0, 0),
(198, 187, 'Exercise & Fitness', 'exercise-fitness', '', 1, 0, 0, 0),
(199, 187, 'Sports Equipment', 'sports-equipment', '', 1, 0, 0, 0),
(200, 187, 'Toys & Games', 'toys-games', '', 1, 0, 0, 0),
(201, 0, 'Computers', 'computers', '', 1, 1, 1, 0),
(202, 201, 'Computers & Accessories', 'computers-accessories', '', 1, 0, 0, 0),
(203, 201, 'Components', 'components', '', 1, 0, 0, 0),
(204, 201, 'Desktop Computers', 'desktop-computers', '', 1, 0, 0, 0),
(205, 201, 'Drives', 'drives', '', 1, 0, 0, 0),
(206, 201, 'Laptop Computers', 'laptop-computers', '', 1, 0, 0, 0),
(207, 201, 'Monitors', 'monitors', '', 1, 0, 0, 0),
(208, 201, 'Netbooks', 'netbooks', '', 1, 0, 0, 0),
(209, 201, 'Networking', 'networking', '', 1, 0, 0, 0),
(210, 201, 'PDAs', 'pdas', '', 1, 0, 0, 0),
(211, 201, 'Printers & Scanners', 'printers-scanners', '', 1, 0, 0, 0),
(212, 201, 'Servers', 'servers', '', 1, 0, 0, 0),
(213, 201, 'Software', 'software', '', 1, 0, 0, 0),
(214, 201, 'Tablets', 'tablets', '', 1, 0, 0, 0),
(217, 201, 'test 1', 'test-1', '', 1, 0, 0, 0),
(218, 201, 'tset 2', 'tset-2', '', 1, 0, 0, 0),
(219, 201, 'tset 3', 'tset-3', '', 1, 0, 0, 0),
(220, 176, 'Sony Tv', 'sony-tv', '', 1, 0, 0, 0),
(221, 176, 'BPL', 'bpl', '', 1, 0, 0, 0),
(222, 130, 'kavin', 'kavin', '', 1, 0, 0, 0),
(223, 130, 'sameer', 'sameer', '', 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `category_mapping`
--

CREATE TABLE IF NOT EXISTS `category_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_map_deal_id` int(11) NOT NULL,
  `map_category_id` int(11) NOT NULL,
  `map_main_category_id` int(11) NOT NULL,
  `category_type` int(2) NOT NULL COMMENT '1-deal,2-product,3-auction',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2741 ;

--
-- Dumping data for table `category_mapping`
--

INSERT INTO `category_mapping` (`id`, `category_map_deal_id`, `map_category_id`, `map_main_category_id`, `category_type`) VALUES
(2510, 13, 135, 130, 1),
(2506, 75, 148, 119, 3),
(2505, 75, 136, 119, 3),
(2504, 11, 211, 201, 2),
(2503, 11, 203, 201, 2),
(2501, 74, 182, 178, 3),
(2502, 73, 136, 119, 3),
(2498, 72, 170, 78, 3),
(2489, 71, 136, 119, 3),
(2488, 70, 136, 119, 3),
(2487, 69, 136, 119, 3),
(2486, 68, 136, 119, 3),
(2485, 67, 136, 119, 3),
(2484, 66, 136, 119, 3),
(2483, 65, 141, 119, 3),
(2482, 65, 136, 119, 3),
(2481, 64, 141, 119, 3),
(2480, 64, 136, 119, 3),
(2479, 63, 141, 119, 3),
(2478, 63, 136, 119, 3),
(2492, 62, 186, 183, 3),
(2477, 61, 165, 78, 3),
(2467, 60, 186, 183, 3),
(2466, 59, 186, 183, 3),
(2465, 58, 186, 183, 3),
(2464, 57, 186, 183, 3),
(2463, 56, 186, 183, 3),
(2462, 55, 186, 183, 3),
(2461, 54, 186, 183, 3),
(2460, 53, 186, 183, 3),
(2459, 52, 186, 183, 3),
(2458, 51, 186, 183, 3),
(2457, 50, 186, 183, 3),
(2456, 49, 186, 183, 3),
(2455, 48, 186, 183, 3),
(2454, 47, 186, 183, 3),
(2453, 46, 186, 183, 3),
(2452, 45, 186, 183, 3),
(2451, 44, 186, 183, 3),
(2450, 43, 186, 183, 3),
(2449, 42, 186, 183, 3),
(2448, 41, 186, 183, 3),
(2447, 40, 186, 183, 3),
(2446, 39, 186, 183, 3),
(2445, 38, 186, 183, 3),
(2444, 37, 186, 183, 3),
(2443, 36, 186, 183, 3),
(2442, 35, 186, 183, 3),
(2441, 34, 186, 183, 3),
(2440, 33, 186, 183, 3),
(2439, 32, 186, 183, 3),
(2438, 31, 186, 183, 3),
(2437, 30, 186, 183, 3),
(2436, 29, 186, 183, 3),
(2435, 28, 186, 183, 3),
(2473, 27, 182, 178, 3),
(2431, 26, 136, 119, 3),
(2430, 25, 165, 78, 3),
(2428, 24, 182, 178, 3),
(2429, 23, 182, 178, 3),
(2594, 15, 136, 119, 2),
(2433, 12, 161, 154, 1),
(2404, 21, 138, 119, 3),
(2654, 11, 192, 187, 1),
(2653, 11, 191, 187, 1),
(2652, 11, 190, 187, 1),
(2651, 11, 189, 187, 1),
(2650, 11, 188, 187, 1),
(2649, 11, 198, 187, 1),
(2648, 11, 197, 187, 1),
(2671, 9, 204, 201, 2),
(2670, 9, 202, 201, 2),
(2669, 9, 203, 201, 2),
(2121, 8, 206, 201, 2),
(2120, 8, 205, 201, 2),
(2119, 8, 204, 201, 2),
(2118, 8, 202, 201, 2),
(2117, 8, 203, 201, 2),
(2126, 7, 206, 201, 2),
(2125, 7, 205, 201, 2),
(2124, 7, 204, 201, 2),
(2123, 7, 202, 201, 2),
(2122, 7, 203, 201, 2),
(2364, 20, 170, 78, 3),
(2363, 20, 165, 78, 3),
(1687, 19, 137, 119, 3),
(1686, 19, 136, 119, 3),
(2128, 6, 202, 201, 2),
(2127, 6, 203, 201, 2),
(2352, 18, 137, 119, 3),
(2351, 18, 136, 119, 3),
(2632, 10, 131, 130, 1),
(2631, 10, 133, 130, 1),
(2577, 15, 135, 130, 1),
(2576, 15, 133, 130, 1),
(2630, 9, 133, 130, 1),
(1685, 17, 147, 119, 3),
(1684, 17, 146, 119, 3),
(1683, 17, 136, 119, 3),
(2365, 16, 136, 119, 3),
(915, 15, 136, 119, 3),
(914, 14, 136, 119, 3),
(2350, 13, 136, 119, 3),
(1690, 12, 166, 78, 3),
(1689, 12, 172, 78, 3),
(1688, 12, 165, 78, 3),
(2162, 4, 196, 187, 1),
(2161, 4, 193, 187, 1),
(2160, 4, 189, 187, 1),
(2159, 4, 197, 187, 1),
(2130, 5, 214, 201, 2),
(2129, 5, 208, 201, 2),
(2628, 8, 135, 130, 1),
(2627, 8, 134, 130, 1),
(2626, 8, 133, 130, 1),
(881, 3, 166, 78, 3),
(880, 3, 172, 78, 3),
(879, 3, 165, 78, 3),
(2349, 4, 139, 119, 3),
(2348, 4, 136, 119, 3),
(1678, 11, 141, 119, 3),
(1677, 11, 138, 119, 3),
(1676, 11, 136, 119, 3),
(1675, 10, 167, 78, 3),
(1674, 10, 174, 78, 3),
(1673, 10, 165, 78, 3),
(2362, 9, 141, 119, 3),
(2361, 9, 136, 119, 3),
(2133, 4, 207, 201, 2),
(2495, 7, 131, 130, 1),
(2494, 7, 133, 130, 1),
(2183, 6, 131, 130, 1),
(2182, 6, 133, 130, 1),
(2201, 5, 198, 187, 1),
(2200, 5, 197, 187, 1),
(2132, 4, 204, 201, 2),
(2131, 4, 203, 201, 2),
(846, 4, 196, 187, 0),
(845, 4, 193, 187, 0),
(2633, 3, 165, 78, 1),
(2164, 2, 135, 130, 1),
(2736, 3, 184, 183, 1),
(2729, 2, 133, 130, 1),
(2138, 2, 139, 119, 2),
(2137, 2, 138, 119, 2),
(2136, 2, 137, 119, 2),
(2135, 2, 136, 119, 2),
(2142, 1, 205, 201, 2),
(2141, 1, 204, 201, 2),
(2140, 1, 202, 201, 2),
(2139, 1, 203, 201, 2),
(2347, 2, 147, 119, 3),
(2360, 8, 170, 78, 3),
(2359, 8, 165, 78, 3),
(2367, 7, 175, 78, 3),
(2366, 7, 165, 78, 3),
(928, 6, 141, 119, 3),
(927, 6, 139, 119, 3),
(2497, 10, 203, 201, 2),
(2358, 5, 137, 119, 3),
(2357, 5, 136, 119, 3),
(844, 4, 189, 187, 0),
(843, 4, 197, 187, 0),
(2735, 1, 165, 78, 3),
(2509, 13, 133, 130, 1),
(2545, 14, 135, 130, 1),
(2544, 14, 133, 130, 1),
(2568, 12, 148, 119, 2),
(2567, 12, 136, 119, 2),
(2558, 76, 185, 183, 3),
(2560, 16, 198, 187, 1),
(2593, 19, 153, 152, 1),
(2595, 15, 137, 119, 2),
(2656, 77, 136, 119, 3),
(2715, 1, 203, 201, 1),
(2673, 1, 203, 201, 2),
(2674, 1, 202, 201, 2),
(2675, 1, 204, 201, 2),
(2676, 1, 205, 201, 2),
(2677, 1, 206, 201, 2),
(2678, 1, 207, 201, 2),
(2679, 1, 208, 201, 2),
(2680, 1, 209, 201, 2),
(2681, 1, 210, 201, 2),
(2682, 1, 211, 201, 2),
(2683, 1, 212, 201, 2),
(2684, 1, 213, 201, 2),
(2685, 1, 214, 201, 2),
(2686, 2, 203, 201, 2),
(2687, 2, 202, 201, 2),
(2688, 2, 204, 201, 2),
(2689, 2, 205, 201, 2),
(2690, 2, 206, 201, 2),
(2691, 2, 207, 201, 2),
(2692, 2, 208, 201, 2),
(2693, 2, 209, 201, 2),
(2694, 2, 210, 201, 2),
(2695, 2, 211, 201, 2),
(2696, 2, 212, 201, 2),
(2697, 2, 213, 201, 2),
(2698, 2, 214, 201, 2),
(2728, 3, 214, 201, 2),
(2727, 3, 213, 201, 2),
(2726, 3, 212, 201, 2),
(2725, 3, 211, 201, 2),
(2724, 3, 210, 201, 2),
(2723, 3, 209, 201, 2),
(2722, 3, 208, 201, 2),
(2721, 3, 207, 201, 2),
(2720, 3, 206, 201, 2),
(2719, 3, 205, 201, 2),
(2718, 3, 204, 201, 2),
(2717, 3, 202, 201, 2),
(2716, 3, 203, 201, 2),
(2737, 4, 223, 130, 1),
(2738, 5, 223, 130, 1),
(2739, 2, 136, 119, 3),
(2740, 3, 181, 178, 3);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(5) NOT NULL AUTO_INCREMENT,
  `country_id` int(3) NOT NULL,
  `city_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `city_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `city_latitude` varchar(15) CHARACTER SET latin1 NOT NULL,
  `city_longitude` varchar(15) CHARACTER SET latin1 NOT NULL,
  `default` int(1) NOT NULL DEFAULT '0',
  `city_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active, 0-deactive',
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `country_id`, `city_name`, `city_url`, `city_latitude`, `city_longitude`, `default`, `city_status`) VALUES
(1, 3, 'California', 'california', '37.13405', '-119.81689', 1, 1),
(2, 2, 'Melbourne', 'melbourne', '-37.92687', '144.93164', 0, 1),
(3, 3, 'Los Angels', 'los-angels', '34.88593', '-117.59766', 0, 1),
(4, 3, 'Sydney', 'sydney', '-33.97981', '151.17188', 0, 1),
(6, 3, 'Mexico', 'mexico', '24.12670', '-102.83203', 0, 1),
(9, 3, 'Washington', 'washington', '47.26432', '-120.08057', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

CREATE TABLE IF NOT EXISTS `cms` (
  `cms_id` int(11) NOT NULL AUTO_INCREMENT,
  `cms_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `cms_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `cms_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `type` int(1) NOT NULL DEFAULT '0',
  `cms_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active, 0-deactive',
  PRIMARY KEY (`cms_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `cms`
--

INSERT INTO `cms` (`cms_id`, `cms_title`, `cms_url`, `cms_desc`, `type`, `cms_status`) VALUES
(4, 'Press Kit', 'press-kit', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and\n typesetting industry. Lorem Ipsum has been the industry''s standard \ndummy text ever since the 1500s, when an unknown printer took a galley \nof type and scrambled it to make a type specimen book. It has survived \nnot only five centuries, but also the leap into electronic typesetting, \nremaining essentially unchanged. It was popularised in the 1960s with \nthe release of Letraset sheets containing Lorem Ipsum passages, and more\n recently with desktop publishing software like Aldus PageMaker \nincluding versions .</p>\n<p>It is a long established fact that a reader will be distracted by the\n readable content of a page when looking at its layout. The point of \nusing Lorem Ipsum is that it has a more-or-less normal distribution of \nletters, as opposed to using ''Content here, content here'', making it \nlook like readable English. Many desktop publishing packages and web \npage editors now use Lorem Ipsum as their default model text, and a \nsearch for ''lorem ipsum'' will uncover many web sites still in their \ninfancy. Various versions have evolved over the years, sometimes by \naccident, sometimes on purpose (injected humour and the like).</p>', 0, 1),
(2, 'Privacy policy', 'privacy-policy', '<p><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p><p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p></p>', 0, 1),
(6, 'About Us', 'about-us', '<h1 class="entry-title"><font color="#3366ff">6 Tips for Creating an Effective About Page</font></h1><p style="text-align: center;"><img class="aligncenter" src="http://i55.tinypic.com/wbx99t.jpg" alt="wbx99t 6 Tips for Creating an Effective About Page" title="6 Tips for Creating an Effective About Page"></p>\n<p class="MsoNormal">In order to add credibility and personalization to \nan online business, a site should have a comprehensive “About Us” \nsection. The page needs to be clear, informative and easy to find. Don’t\n hide information about your business. Instead, give your visitors a \npage that you would be proud to have read. With a solid backbone behind \nyour online presence, visitors will be more likely to consider your site\n for a purchase.<strong> </strong></p>\n<p class="MsoNormal">Here are six things you should include on your “About Us” page.<strong><br>\n</strong></p>\n<h3><font color="#33ccff"><strong>1. What you do</strong></font></h3>\n<p>Before you begin writing, think about what you look for in a company.\n Provide information that would give customers insight as to why your \ncompany is credible and why they should buy from you. This is a great \nplace to list your Mission Statement. An example of an effective Mission\n Statement comes from Google, “Google’s mission is to organize the \nworld’s information and make it universally accessible and useful”. This\n statement tells you what they do, why they do it and in a way that is \nwritten well and to the point.</p>\n<h3><font color="#33ccff"><strong>2. Your story</strong></font></h3>\n<p>Reflect on the core roots of your business and how it all began. Not \nonly how, but why it began. If you are just starting out, think about \nwhat made you decide to start this particular type of business. This \ninformation can add a personal touch to your site.</p>\n<h3><font color="#33ccff"><strong>3. Why you’re different</strong></font></h3>\n<p>This can either be an extremely easy question to answer, or an \nextremely hard one. Think on this one for awhile. Your answer can range \nfrom offering free shipping on all items, to being a mom-and-pop shop. \nYou can also give some general information here that may boost you above\n the competition, such as listing items that are rare or giving \ncustomers reassuring statements- “If you aren’t satisfied with an item, \nyour money back guaranteed!”</p>\n<h3><font color="#33ccff"><strong>4. How long you’ve been around</strong></font></h3>\n<p>If you have a physical store, include the length of time it’s been \naround. If a customer sees that your brick and mortar store has been \naround for several years- whether your site is a week or a year old may \nmake no difference. Instead, the fact that you’ve been involved in \nselling these particular items for a length of time is substantial \nenough. Also mention how long your company has had its website. If your \nbusiness is a website in its entirety and it’s just starting out, don’t \nbe afraid to mention that. The truth is always the best answer in \ngenerating trust.</p>\n<h3><font color="#33ccff"><strong>5. How to reach you</strong></font></h3>\n<p>If you already have an easily seen “Contact Us” section, good job. \nThe “About Us” section is a great place to reiterate this information. \nIf you have a physical location, list the address here. Having an actual\n address and a phone number on the site is a major plus. In generating \nyour contact information, take it from a customer’s point of view. If a \nnumber and address aren’t listed, what is the reasoning behind such? \nDoes the company not want to be bothered? Are they hiding something? If I\n make a purchase and I’m not satisfied, what could I possibly do? Try to\n write your information in a way to make even the biggest pessimistic \nconsider your company for a purchase.</p>\n<h3><font color="#33ccff"><strong>6. Helpful tips</strong></font></h3>\n<p>Feel free to provide common information in this section as well, such\n as standard shipping and return procedures. The easier you make the \npurchase process, the better!</p>\n<p class="MsoNormal">Overall, the information provided in your “About \nUs” section should answer several questions a new customer may have, but\n most importantly in online selling it should answer the question- Why \nshould I trust purchasing from you? Providing easily accessible company \ninformation will show that you have nothing to hide and instead, you \nwant to educate your potential customers about your business. Providing \ninsight as to who you are and what you do adds a personal, trustworthy \ntouch that may make the difference between a visitor and a customer.</p>', 1, 1),
(8, 'Terms and conditions', 'terms-and-conditions', 'Visa, Master and American express Card payments are processed through an online payment gateway system. You need not worry about your card information falling into the wrong hands because your bank will authorize the card transaction directly without any information passing through us. In approximately 25-30 seconds (depending on your internet connection) your bank will issue, using the online payment gateway, an authorization code and confirmation of completion of transaction.<br>CartDeals, as a Verisign Certified Site, uses the latest 128 bit encryption technology and other sophisticated methods to protect your credit card information. You can book your product using SSL encryption (the internet standard for secure transactions). In fact, transacting online with a credit card at the Website is even safer than using a credit card at a restaurant because we do not retain your credit card information. You can be assured that CartDeals offers you the highest standards of security currently available on the internet so as to ensure that your shopping experience is private, safe and secure.<br>If the payment on the credit card is declined for some reason, alternate payment instructions must be received by CartDeals 72 hours prior to the time of departure; else, the order is liable to be cancelled.<br>CartDeals charges a service fee on all domestic airline bookings. In case of cancellation of booking, this fee is non-refundable.<br><br>Internet Banking<br><br>If you have an account with any of the below mentioned banks, then you can pay for your order through respective bank''s net banking options and the amount will be automatically debited from your account. "www.CartDealseals.com" processes the payments through an online gateway system which enables safe and secure transaction. Bank is not responsible for any inconvenience caused or non receipt of the tickets or passengers not allowed on the basis of E-tickets.<br>- Bank Of India<br>- CitiBank<br>- HDFC Bank<br>- IDBI Bank<br>- Indusind Bank<br>- Kotak Bank<br>- Punjab National Bank<br>- AXIS Bank<br>- Bank of Baroda - Retail NetBanking<br>- Bank of Baroda - Corporate NetBanking<br><br>', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE IF NOT EXISTS `color` (
  `color_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` int(11) NOT NULL,
  `color_name` varchar(128) NOT NULL,
  `color_code_name` varchar(64) NOT NULL,
  `color_code_id` int(11) NOT NULL,
  `color_status` int(1) NOT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `color_code`
--

CREATE TABLE IF NOT EXISTS `color_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color_code` varchar(64) NOT NULL,
  `color_name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `color_code`
--

INSERT INTO `color_code` (`id`, `color_code`, `color_name`) VALUES
(1, '6195ED', 'Cornflower Blue'),
(2, '00FF00', 'Green'),
(3, 'FFFF00', 'Yellow'),
(4, '0000FF', 'Blue'),
(5, '000000', 'Black'),
(7, '044022', 'Zuccini');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `message` varchar(256) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1-Active , 0- InActive',
  PRIMARY KEY (`contact_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `country_id` int(3) NOT NULL AUTO_INCREMENT,
  `country_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `country_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  `currency_symbol` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `currency_code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_url`, `country_name`, `country_code`, `country_status`, `currency_symbol`, `currency_code`) VALUES
(22, 'canadian', 'Canadian', 'CA', 1, 'C$', 'CAD'),
(3, 'us', 'US', 'US', 1, '$', 'USD'),
(21, 'singapore', 'Singapore', 'SG', 1, 's$', 'SGD'),
(24, 'india', 'India', 'IND', 1, '₹', 'INR'),
(23, 'new-zealand', 'NEW ZEALAND', 'NZ', 1, '$', 'NZD');

-- --------------------------------------------------------

--
-- Table structure for table `deals`
--

CREATE TABLE IF NOT EXISTS `deals` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `url_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `deal_key` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `deal_description` text COLLATE utf8_unicode_ci NOT NULL,
  `fineprints` text COLLATE utf8_unicode_ci NOT NULL,
  `highlights` text COLLATE utf8_unicode_ci NOT NULL,
  `terms_conditions` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` varchar(96) COLLATE utf8_unicode_ci NOT NULL,
  `deal_type` int(1) NOT NULL COMMENT '1-deals, 2-products, 3 - Auction',
  `merchant_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `deal_value` double NOT NULL,
  `deal_price` double NOT NULL,
  `deal_savings` double NOT NULL,
  `deal_percentage` float NOT NULL,
  `purchase_count` int(11) NOT NULL,
  `minimum_deals_limit` int(11) NOT NULL,
  `maximum_deals_limit` int(11) NOT NULL,
  `user_limit_quantity` int(5) NOT NULL,
  `bid_increment` double NOT NULL,
  `startdate` int(10) NOT NULL,
  `enddate` int(10) NOT NULL,
  `expirydate` int(10) NOT NULL,
  `created_date` int(10) NOT NULL,
  `created_by` int(11) NOT NULL,
  `deal_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  PRIMARY KEY (`deal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `deals`
--

INSERT INTO `deals` (`deal_id`, `deal_title`, `url_title`, `deal_key`, `deal_description`, `fineprints`, `highlights`, `terms_conditions`, `meta_description`, `meta_keywords`, `category_id`, `sub_category_id`, `deal_type`, `merchant_id`, `shop_id`, `deal_value`, `deal_price`, `deal_savings`, `deal_percentage`, `purchase_count`, `minimum_deals_limit`, `maximum_deals_limit`, `user_limit_quantity`, `bid_increment`, `startdate`, `enddate`, `expirydate`, `created_date`, `created_by`, `deal_status`) VALUES
(1, 'New Deals', 'new-deals', 'XiTMh4LB', 'dsfdsfdsfsdfdsfdsff', ' ', ' ', '', '', '', 201, '203', 0, 247, 1, 5, 5, 0, 0, 3, 1, 5, 4, 0, 1368642600, 1369679400, 1369938600, 1369044047, 14, 1);
INSERT INTO `deals` (`deal_id`, `deal_title`, `url_title`, `deal_key`, `deal_description`, `fineprints`, `highlights`, `terms_conditions`, `meta_description`, `meta_keywords`, `category_id`, `sub_category_id`, `deal_type`, `merchant_id`, `shop_id`, `deal_value`, `deal_price`, `deal_savings`, `deal_percentage`, `purchase_count`, `minimum_deals_limit`, `maximum_deals_limit`, `user_limit_quantity`, `bid_increment`, `startdate`, `enddate`, `expirydate`, `created_date`, `created_by`, `deal_status`) VALUES
(2, 'kavinnewtoday', 'kavinnewtoday', 'GZKjUy0v', '<h3 style="margin: 0px; padding: 0px; font-size: 14px; text-decoration: initial; font-weight: 400; color: rgb(81, 81, 81); font-family: verdana, Helvetica, Arial, sans-serif; font-style: normal; font-variant: normal; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">Specification of Samsung Galaxy S4 (16 GB, 3G, Black Mist)</h3><div class="item-desc" style="margin: 5px 0px; padding: 0px; outline: none 0px; color: rgb(81, 81, 81); font-family: verdana, Helvetica, Arial, sans-serif; font-size: 11px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 13px; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);"><b style="margin: 0px; padding: 0px; font-weight: 700;">Life companion</b><br style="margin: 0px; padding: 0px;">Make your life richer, simpler, and more fun. As a real life companion, the new Samsung GALAXY S4 helps bring us closer and captures those fun moments when we are together. Each feature was designed to simplify our daily lives. Furthermore, it cares enough to monitor our health and well-being. To put it simply, the Samsung GALAXY S4 is there for you.<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;">Captures all the fun</b><br style="margin: 0px; padding: 0px;">The Samsung GALAXY S4 captures all the action wherever you are. Don’t just look at your photos, hear what they have to say and relive those exciting memories. Take multiple exposure pictures and edit them together to add a special dramatic touch. Once done, spread the fun and instantly share your albums with friends and family.<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><ul style="margin: 0px; padding: 0px; line-height: 1.5em; list-style: none;"><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Dual Shot</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Sound &amp; ShotSound &amp; Shot</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Drama ShotDrama Shot</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Group PlayGroup Play</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Story AlbumStory Album</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Samsung HubSamsung Hub</li></ul><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;"><br style="margin: 0px; padding: 0px;">Brings everyone closer together</b><br style="margin: 0px; padding: 0px;">The Samsung GALAXY S4 is all about ‘togetherness’. It brings people together when they’re apart. You and your friends can share screens as well as explore each other’s favorite music, files and games. The Samsung GALAXY S4 not only overcomes barriers of distance but also breaks down language barriers.<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><ul style="margin: 0px; padding: 0px; line-height: 1.5em; list-style: none;"><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">S Translator</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">ChatONChatON</li></ul><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;">Simplifies everyday tasks</b><br style="margin: 0px; padding: 0px;">The ultimate productivity device – the Samsung GALAXY S4 is designed with the well-connected, multi-tasker in mind. Call a friend, answer the phone, preview emails and control videos without even touching the phone. When you connect your Samsung GALAXY S4 to your home entertainment system, it can suggest TV programs based on what you like. Access your personal HomeSync system from all devices and remotely share with friends and family.<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><ul style="margin: 0px; padding: 0px; line-height: 1.5em; list-style: none;"><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Smart Pause</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Air View / Air GestureAir View / Air Gesture</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Samsung WatchONSamsung</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">WatchON</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">HomeSyncHomeSync</li></ul><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;">Adjusts to you. Not the other way around.</b><br style="margin: 0px; padding: 0px;">The Samsung GALAXY S4 understands how important your health is. It can help you achieve your fitness goals by monitoring your fitness levels during workouts and throughout the day. It also cares for your general health with sensors that automatically adjust the display and volume – depending on how you are using the phone – to ensure the optimal experience.<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><ul style="margin: 0px; padding: 0px; line-height: 1.5em; list-style: none;"><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">S Health</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Adapt DisplayAdapt Display</li><li style="margin: 5px 0px 5px 20px; padding: 0px; line-height: 1.5em; list-style: disc;">Adapt SoundAdapt Sound</li></ul><br style="margin: 0px; padding: 0px;"><p style="margin: 0px; padding: 0px 0px 5px; line-height: 16px;"><b style="margin: 0px; padding: 0px; font-weight: 700;"><br style="margin: 0px; padding: 0px;"></b></p><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;">General</b><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">2G Network: GSM 850 / 900 / 1800 / 1900<br style="margin: 0px; padding: 0px;">3G Network: HSDPA 850 / 900 / 1900 / 2100<br style="margin: 0px; padding: 0px;">SIM: Micro-SIM<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;">Body<br style="margin: 0px; padding: 0px;"></b><br style="margin: 0px; padding: 0px;">Dimensions: 136.6 x 69.8 x 7.9 mm (5.38 x 2.75 x 0.31 in)<br style="margin: 0px; padding: 0px;">Weight: 130 g (4.59 oz)<br style="margin: 0px; padding: 0px;">Display: Type: Super AMOLED capacitive touchscreen, 16M colors<br style="margin: 0px; padding: 0px;">Size: 1080 x 1920 pixels, 5.0 inches (~441 ppi pixel density)<br style="margin: 0px; padding: 0px;">Multitouch: Yes<br style="margin: 0px; padding: 0px;">Protection: Corning Gorilla Glass 3<br style="margin: 0px; padding: 0px;">- TouchWiz UI<br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;"><br style="margin: 0px; padding: 0px;">Sound</b><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">Alert types: Vibration; MP3, WAV ringtones<br style="margin: 0px; padding: 0px;">Loudspeaker: Yes<br style="margin: 0px; padding: 0px;">3.5mm jack: Yes<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">Memory<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">Card slot: microSD, up to 64 GB<br style="margin: 0px; padding: 0px;">Internal: 16 GB storage, 2 GB RAM<br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;"><br style="margin: 0px; padding: 0px;">Data</b><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">GPRS: Yes<br style="margin: 0px; padding: 0px;">EDGE: Yes<br style="margin: 0px; padding: 0px;">Speed: HSDPA, 42.2 Mbps; HSUPA, 5.76 Mbps<br style="margin: 0px; padding: 0px;">WLAN: Wi-Fi 802.11 a/b/g/n/ac, dual-band, DLNA, Wi-Fi Direct, Wi-Fi hotspot<br style="margin: 0px; padding: 0px;">Bluetooth: Yes, v4.0 with A2DP, EDR, LE<br style="margin: 0px; padding: 0px;">NFC: Yes<br style="margin: 0px; padding: 0px;">Infrared port: Yes<br style="margin: 0px; padding: 0px;">USB: Yes, microUSB v2.0 (MHL 2), USB On-the-go, USB Host<br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;"><br style="margin: 0px; padding: 0px;">Camera</b><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">Primary: 13 MP, 4128 x 3096 pixels, autofocus, LED flash, check quality<br style="margin: 0px; padding: 0px;">Features: Dual Shot, Simultaneous HD video and image recording, geo-tagging, touch focus, face and smile detection, image stabilization, HDR<br style="margin: 0px; padding: 0px;">Video: Yes, 1080p@30fps, dual-video rec., check quality<br style="margin: 0px; padding: 0px;">Secondary: Yes, 2 MP,1080p@30fps, dual video call<br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;"><br style="margin: 0px; padding: 0px;">Features</b><br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">OS: Android OS, v4.2.2 (Jelly Bean)<br style="margin: 0px; padding: 0px;">Chipset: Exynos 5 Octa 5410<br style="margin: 0px; padding: 0px;">CPU: Quad-core 1.6 GHz Cortex-A15 &amp; quad-core 1.2 GHz Cortex-A7<br style="margin: 0px; padding: 0px;">GPU: PowerVR SGX 544MP3<br style="margin: 0px; padding: 0px;">Sensors: Accelerometer, gyro, proximity, compass, barometer, temperature, humidity, gesture<br style="margin: 0px; padding: 0px;">Messaging: SMS(threaded view), MMS, Email, Push Mail, IM, RSS<br style="margin: 0px; padding: 0px;">Browser: HTML5, Adobe Flash<br style="margin: 0px; padding: 0px;">Radio: No<br style="margin: 0px; padding: 0px;">GPS: Yes, with A-GPS support and GLONASS<br style="margin: 0px; padding: 0px;">Java: Yes, via Java MIDP emulator<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;">- Wireless charging (market dependent)<br style="margin: 0px; padding: 0px;">- S-Voice natural language commands and dictation<br style="margin: 0px; padding: 0px;">- Smart stay, Smart pause, Smart scroll<br style="margin: 0px; padding: 0px;">- Air gestures<br style="margin: 0px; padding: 0px;">- Dropbox (50 GB storage)<br style="margin: 0px; padding: 0px;">- Active noise cancellation with dedicated mic<br style="margin: 0px; padding: 0px;">- TV-out (via MHL 2 A/V link)<br style="margin: 0px; padding: 0px;">- SNS integration<br style="margin: 0px; padding: 0px;">- MP4/DivX/XviD/WMV/H.264/H.263 player<br style="margin: 0px; padding: 0px;">- MP3/WAV/eAAC /AC3/FLAC player<br style="margin: 0px; padding: 0px;">- Organizer<br style="margin: 0px; padding: 0px;">- Image/video editor<br style="margin: 0px; padding: 0px;">- Document viewer (Word, Excel, PowerPoint, PDF)<br style="margin: 0px; padding: 0px;">- Google Search, Maps, Gmail,<br style="margin: 0px; padding: 0px;">YouTube, Calendar, Google Talk, Picasa<br style="margin: 0px; padding: 0px;">- Voice memo/dial/commands<br style="margin: 0px; padding: 0px;">- Predictive text input (Swype)<br style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;"><b style="margin: 0px; padding: 0px; font-weight: 700;">Battery:</b><span class="Apple-converted-space"> </span>Li-Ion 2600 mAh battery<br style="margin: 0px; padding: 0px;"> </div><table id="detail-info" class="width-100p mart-5" style="margin: 5px 0px 0px; padding: 0px; border-collapse: collapse; border-spacing: 0px; font-size: 11px; width: 970px; color: rgb(81, 81, 81); font-family: verdana, Helvetica, Arial, sans-serif; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 13px; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);" cellpadding="0" cellspacing="0"><tbody style="margin: 0px; padding: 0px;"><tr style="margin: 0px; padding: 0px;"><td style="margin: 0px; padding: 0px;"><div class="product_text" style="margin: 0px 0px 15px; padding: 0px; outline: none 0px; overflow: hidden;"><table style="margin: 0px 0px 10px; padding: 0px; border-collapse: collapse; border-spacing: 0px; font-size: inherit; border: 1px solid rgb(242, 242, 242);" cellpadding="0" cellspacing="0"><tbody style="margin: 0px; padding: 0px;"><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><th colspan="2" style="margin: 0px; padding: 6px 10px; font-style: normal; font-weight: 700; text-align: left; width: 940px; background-color: rgb(242, 242, 242); font-size: 15px; color: rgb(51, 51, 51); background-position: initial initial; background-repeat: initial initial;">General</th></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Product Title:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><b style="margin: 0px; padding: 0px; font-weight: 700;">Samsung Galaxy S4 (16 GB, 3G, Black Mist)</b></td></tr><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Item EAN:</td><td style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">2724273436790</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Brand:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/samsung/a-7/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">Samsung Mobile Phones</a></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Memory Size:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/2/a-74/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">2</a></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Operating System:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/android/a-82/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">Android</a></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Package dimensions (W x D x H):</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">136.6 x 69.8 x 7.9 mm (5.38 x 2.75 x 0.31 in)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Display Resolution:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Super AMOLED capacitive touchscreen, 16M colors</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Product weight:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">130 g (4.59 oz)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Built-in speakers:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Storage Capacity:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/16-gb/a-257/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">16 GB</a></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Speakers:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Headphones:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Multimedia:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Google Search, Maps, Gmail, YouTube, Calendar, Google Talk, Picasa</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Processor Type:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Exynos 5 Octa 5410</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Wireless LAN:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Wi-Fi 802.11 a/b/g/n/ac, dual-band, DLNA, Wi-Fi Direct, Wi-Fi hotspot</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">CPU Speed:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Quad - core 1.6 GHz Cortex-A15 &amp; Quad - core 1.2 GHz Cortex-A7</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">FM Radio:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf4.souqcdn.com/static/ltr/en/images/icons/famfamfam/cross.png" title="No" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Dimensions:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">136.6 x 69.8 x 7.9 mm (5.38 x 2.75 x 0.31 in)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Technical Features:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Wireless charging, S-Voice natural language commands, dictation, Smart stay, Smart pause, Smart scroll, Air gestures, Active noise cancellation with dedicated mic, and Dropbox (50 GB storage)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">RAM Memory:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">2GB</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Camera sensitivity:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Dual Shot, Simultaneous HD video and image recording, geo-tagging, touch focus, face and smile detection, image stabilization, HDR</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Touchscreen:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">GPS Receivers:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, with A-GPS support and GLONASS</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Vibrating Alert:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">3G:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Phone camera:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">13 MP, 4128 x 3096 pixels, autofocus, LED flash, check quality</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Second camera:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, 2 MP,1080p@30fps, dual video call</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Supported network protocols:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">2G Network: GSM 850 / 900 / 1800 / 1900 3G Network: HSDPA 850 / 900 / 1900 / 2100</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Headphones:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Playback MP3:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">SIM:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">microSD, up to 64 GB</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Operating System:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Android OS, v4.2.2 (Jelly Bean)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Touch Panel:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, Multitouch</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Supported browsers:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">HTML5, Adobe Flash</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Product weight:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">130 g (4.59 oz)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Type:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/smartphones/a-1870/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">Smartphones</a></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Smartphone:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Java Technology:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, via Java MIDP emulator</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Speech recognition:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">CPU:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Quad-core 1.6 GHz Cortex-A15 &amp; quad-core 1.2 GHz Cortex-A7</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">JAVA:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, via Java MIDP emulator</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Alert Types:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Vibration; MP3, WAV ringtones</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Messaging:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">SMS(threaded view), MMS, Email, Push Mail, IM, RSS</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Operating System:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Android OS, v4.2.2 (Jelly Bean)</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Instant Messaging:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">HSDPA:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">42.2 Mbps; HSUPA, 5.76 Mbps</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Built-In Radio:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf4.souqcdn.com/static/ltr/en/images/icons/famfamfam/cross.png" title="No" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">DivX Playback:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">WAV Playback:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">AAC Playback:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">WMV Playback:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">MPEG 4 Playback:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Type of SD Card Interface:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">microSD</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">H.264 Playback:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider last" style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Player Type:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">MP3/WAV/eAAC /AC3/FLAC, MP4/DivX/XviD/WMV/H.264/H.263 player</td></tr></tbody></table></div><div class="product_text" style="margin: 0px 0px 15px; padding: 0px; outline: none 0px; overflow: hidden;"><table style="margin: 0px 0px 10px; padding: 0px; border-collapse: collapse; border-spacing: 0px; font-size: inherit; border: 1px solid rgb(242, 242, 242);" cellpadding="0" cellspacing="0"><tbody style="margin: 0px; padding: 0px;"><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><th colspan="2" style="margin: 0px; padding: 6px 10px; font-style: normal; font-weight: 700; text-align: left; width: 940px; background-color: rgb(242, 242, 242); font-size: 15px; color: rgb(51, 51, 51); background-position: initial initial; background-repeat: initial initial;">Image quality</th></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Megapixel:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/13mp/a-720/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">13MP</a></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Image quality:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">4128 x 3096 pixels</td></tr><tr class="columndivider last" style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Camera Resolution:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">13 MP, 4128 x 3096 pixels, autofocus, LED flash, check quality</td></tr><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><th colspan="2" style="margin: 0px; padding: 6px 10px; font-style: normal; font-weight: 700; text-align: left; width: 940px; background-color: rgb(242, 242, 242); font-size: 15px; color: rgb(51, 51, 51); background-position: initial initial; background-repeat: initial initial;">Video</th></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Video capture resolution:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">1080p@30fps</td></tr><tr class="columndivider last" style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Camera Video:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, 1080p@30fps, dual-video rec., check quality</td></tr><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><th colspan="2" style="margin: 0px; padding: 6px 10px; font-style: normal; font-weight: 700; text-align: left; width: 940px; background-color: rgb(242, 242, 242); font-size: 15px; color: rgb(51, 51, 51); background-position: initial initial; background-repeat: initial initial;">Display</th></tr><tr class="columndivider last" style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Screen Size:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/1080-x-1920-pixels,-5.0-inches-(~441-ppi-pixel-density)/a-340/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initial initial; background-repeat: initial initial;">1080 x 1920 pixels, 5.0 inches (~441 ppi pixel density)</a></td></tr><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><th colspan="2" style="margin: 0px; padding: 6px 10px; font-style: normal; font-weight: 700; text-align: left; width: 940px; background-color: rgb(242, 242, 242); font-size: 15px; color: rgb(51, 51, 51); background-position: initial initial; background-repeat: initial initial;">Connectivity</th></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Bluetooth version:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, v4.0 with A2DP, EDR, LE</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Bluetooth:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, v4.0 with A2DP, EDR</td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Infrared Interface:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">EDGE:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider " style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">GPRS:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><img src="http://cf2.souqcdn.com/static/ltr/en/images/icons/famfamfam/tick.png" title="Yes" style="margin: 0px; padding: 0px; border: 0px; font-size: 9px;"></td></tr><tr class="columndivider last" style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">USB Type:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Yes, microUSB v2.0 (MHL 2), USB On-the-go, USB Host</td></tr><tr style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><th colspan="2" style="margin: 0px; padding: 6px 10px; font-style: normal; font-weight: 700; text-align: left; width: 940px; background-color: rgb(242, 242, 242); font-size: 15px; color: rgb(51, 51, 51); background-position: initial initial; background-repeat: initial initial;">Color</th></tr><tr class="columndivider last" style="margin: 0px; padding: 0px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(242, 242, 242);"><td class="itemOne-attributeName  width-150" style="margin: 0px; padding: 6px 10px; width: 150px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);">Color:</td><td class="itemOne-attributeData" style="margin: 0px; padding: 6px 10px; vertical-align: top; text-align: left; border-right-width: 1px; border-right-style: solid; border-right-color: rgb(242, 242, 242);"><a href="http://uae.souq.com/ae-en/mobile-phone/16m-colors/a-54/l/" style="margin: 0px; padding: 0px; color: rgb(17, 87, 152); background-color: transparent; text-decoration: initial; outline: none; background-position: initi', 'test ', ' ', 'test', '', '', 130, '133', 0, 247, 1, 10, 10, 0, 0, 4, 1, 5, 3, 0, 1369161000, 1369593000, 1369852200, 1369204529, 14, 1);
INSERT INTO `deals` (`deal_id`, `deal_title`, `url_title`, `deal_key`, `deal_description`, `fineprints`, `highlights`, `terms_conditions`, `meta_description`, `meta_keywords`, `category_id`, `sub_category_id`, `deal_type`, `merchant_id`, `shop_id`, `deal_value`, `deal_price`, `deal_savings`, `deal_percentage`, `purchase_count`, `minimum_deals_limit`, `maximum_deals_limit`, `user_limit_quantity`, `bid_increment`, `startdate`, `enddate`, `expirydate`, `created_date`, `created_by`, `deal_status`) VALUES
(3, ' More Images     Wenger Men''s and Women''s Watches', 'more-images-wenger-mens-and-womens-watches', 'HXbhaD44', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">Wenger watches monitor the passage of time with Swiss quartz movements that keep the timepieces accurate to 1/10 of a second per day. Scratch-resistant mineral crystal protects the classic faces, and easy-to-read luminous hands glow in any level of light, allowing wearers to monitor how many hours they''ve been stuck in the chimney. Each watch arrives in a brushed-stainless-steel storage case that is engraved with the Wenger Swiss Military seal and the likeness of a Swiss Army knife. $69.99 for a Wenger Classic Field Swiss Military watch. Choose from the following styles: Men''s black dial and black leather strap (72925) Men''s black dial and black nylon strap (72915) Men''s black dial and brown leather strap (72917) Men''s ivory dial and olive nylon band (72901) Men''s white dial and brown leather strap (72900) Women''s white dial and brown leather strap (72920)</span>', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">Wenger watches monitor the passage of time with Swiss quartz movements that keep the timepieces accurate to 1/10 of a second per day. Scratch-resistant mineral crystal protects the classic faces, and easy-to-read luminous hands glow in any level of light, allowing wearers to monitor how many hours they''ve been stuck in the chimney. Each watch arrives in a brushed-stainless-steel storage case that is engraved with the Wenger Swiss Military seal and the likeness of a Swiss Army knife. $69.99 for a Wenger Classic Field Swiss Military watch. Choose from the following styles: Men''s black dial and black leather strap (72925) Men''s black dial and black nylon strap (72915) Men''s black dial and brown leather strap (72917) Men''s ivory dial and olive nylon band (72901) Men''s white dial and brown leather strap (72900) Women''s white dial and brown leather strap (72920)</span> ', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">Wenger watches monitor the passage of time with Swiss quartz movements that keep the timepieces accurate to 1/10 of a second per day. Scratch-resistant mineral crystal protects the classic faces, and easy-to-read luminous hands glow in any level of light, allowing wearers to monitor how many hours they''ve been stuck in the chimney. Each watch arrives in a brushed-stainless-steel storage case that is engraved with the Wenger Swiss Military seal and the likeness of a Swiss Army knife. $69.99 for a Wenger Classic Field Swiss Military watch. Choose from the following styles: Men''s black dial and black leather strap (72925) Men''s black dial and black nylon strap (72915) Men''s black dial and brown leather strap (72917) Men''s ivory dial and olive nylon band (72901) Men''s white dial and brown leather strap (72900) Women''s white dial and brown leather strap (72920)</span> ', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">Wenger watches monitor the passage of time with Swiss quartz movements that keep the timepieces accurate to 1/10 of a second per day. Scratch-resistant mineral crystal protects the classic faces, and easy-to-read luminous hands glow in any level of light, allowing wearers to monitor how many hours they''ve been stuck in the chimney. Each watch arrives in a brushed-stainless-steel storage case that is engraved with the Wenger Swiss Military seal and the likeness of a Swiss Army knife. $69.99 for a Wenger Classic Field Swiss Military watch. Choose from the following styles: Men''s black dial and black leather strap (72925) Men''s black dial and black nylon strap (72915) Men''s black dial and brown leather strap (72917) Men''s ivory dial and olive nylon band (72901) Men''s white dial and brown leather strap (72900) Women''s white dial and brown leather strap (72920)</span>', 'bzbzxb', 'zz', 183, '184', 0, 247, 1, 25, 100, 75, 75, 0, 1, 10, 5, 0, 1369679400, 1369852200, 1369938600, 1369719300, 14, 1),
(4, 'Rusty Wallace Racing Experience – Canadian Tire Motorsport Park', 'rusty-wallace-racing-experience-canadian-tire-motorsport-park', 'BLxICzX4', '<span style="color: rgb(101, 101, 101); font-family: open_sansregular; background-color: rgb(255, 255, 255);">usty Wallace Racing Experience engages adrenal glands with real-life rubber-burning packages that send speed demons around Canadian Tire Motorsport Park''s oval track. With the shotgun ride-along, need-for-speeders can hop into the passenger seat of a stock car and share three laps’ worth of in-the-action views with a professional driver. The Qualifier racing experience condenses the pro-racing experience into two hours of intense zooming. After classroom instruction familiarizes soon-to-be drivers with the course’s corners, students get to take the wheel for 10 invigorating laps, leaving their hair mussed, their eyes bulging, and their torsos coated in corporate sponsorships. Rusty Wallace Racing Experience After decades of winning the admiration of racing fans with his aggressive driving strategy and off-track charisma, Rusty Wallace now teaches his clients the tricks of the pro-racing trade with breathtaking ride-alongs and racing experiences. Guests buckle up and sit shotgun alongside a professional driver as they sends stock cars flying down straightaways and around curves, or they can get behind the wheel themselves, finally feeling what it''s like to be a professional driver. Each heart-pounding experience introduces participants to the intricacies and unique characteristics of some of the country''s most celebrated racetracks, from the versatile road courses and speedy main track of the Atlanta Motor Speedway to the </span>', '<span style="color: rgb(101, 101, 101); font-family: open_sansregular; background-color: rgb(255, 255, 255);">usty Wallace Racing Experience engages adrenal glands with real-life rubber-burning packages that send speed demons around Canadian Tire Motorsport Park''s oval track. With the shotgun ride-along, need-for-speeders can hop into the passenger seat of a stock car and share three laps’ worth of in-the-action views with a professional driver. The Qualifier racing experience condenses the pro-racing experience into two hours of intense zooming. After classroom instruction familiarizes soon-to-be drivers with the course’s corners, students get to take the wheel for 10 invigorating laps, leaving their hair mussed, their eyes bulging, and their torsos coated in corporate sponsorships. Rusty Wallace Racing Experience After decades of winning the admiration of racing fans with his aggressive driving strategy and off-track charisma, Rusty Wallace now teaches his clients the tricks of the pro-racing trade with breathtaking ride-alongs and racing experiences. Guests buckle up and sit shotgun alongside a professional driver as they sends stock cars flying down straightaways and around curves, or they can get behind the wheel themselves, finally feeling what it''s like to be a professional driver. Each heart-pounding experience introduces participants to the intricacies and unique characteristics of some of the country''s most celebrated racetracks, from the versatile road courses and speedy main track of the Atlanta Motor Speedway to the </span> ', '<span style="color: rgb(101, 101, 101); font-family: open_sansregular; background-color: rgb(255, 255, 255);">usty Wallace Racing Experience engages adrenal glands with real-life rubber-burning packages that send speed demons around Canadian Tire Motorsport Park''s oval track. With the shotgun ride-along, need-for-speeders can hop into the passenger seat of a stock car and share three laps’ worth of in-the-action views with a professional driver. The Qualifier racing experience condenses the pro-racing experience into two hours of intense zooming. After classroom instruction familiarizes soon-to-be drivers with the course’s corners, students get to take the wheel for 10 invigorating laps, leaving their hair mussed, their eyes bulging, and their torsos coated in corporate sponsorships. Rusty Wallace Racing Experience After decades of winning the admiration of racing fans with his aggressive driving strategy and off-track charisma, Rusty Wallace now teaches his clients the tricks of the pro-racing trade with breathtaking ride-alongs and racing experiences. Guests buckle up and sit shotgun alongside a professional driver as they sends stock cars flying down straightaways and around curves, or they can get behind the wheel themselves, finally feeling what it''s like to be a professional driver. Each heart-pounding experience introduces participants to the intricacies and unique characteristics of some of the country''s most celebrated racetracks, from the versatile road courses and speedy main track of the Atlanta Motor Speedway to the </span> ', '<span style="color: rgb(101, 101, 101); font-family: open_sansregular; background-color: rgb(255, 255, 255);">usty Wallace Racing Experience engages adrenal glands with real-life rubber-burning packages that send speed demons around Canadian Tire Motorsport Park''s oval track. With the shotgun ride-along, need-for-speeders can hop into the passenger seat of a stock car and share three laps’ worth of in-the-action views with a professional driver. The Qualifier racing experience condenses the pro-racing experience into two hours of intense zooming. After classroom instruction familiarizes soon-to-be drivers with the course’s corners, students get to take the wheel for 10 invigorating laps, leaving their hair mussed, their eyes bulging, and their torsos coated in corporate sponsorships. Rusty Wallace Racing Experience After decades of winning the admiration of racing fans with his aggressive driving strategy and off-track charisma, Rusty Wallace now teaches his clients the tricks of the pro-racing trade with breathtaking ride-alongs and racing experiences. Guests buckle up and sit shotgun alongside a professional driver as they sends stock cars flying down straightaways and around curves, or they can get behind the wheel themselves, finally feeling what it''s like to be a professional driver. Each heart-pounding experience introduces participants to the intricacies and unique characteristics of some of the country''s most celebrated racetracks, from the versatile road courses and speedy main track of the Atlanta Motor Speedway to the </span>', 'vzxv', 'xzvzx', 130, '223', 0, 247, 1, 25, 50, 25, 50, 2, 1, 100, 20, 0, 1369679400, 1369852200, 1369938600, 1369719381, 14, 1),
(5, 'Kasperskey Antivirus', 'kasperskey-antivirus', 'vtQ2qJxf', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">The resolution of a digital camera is often limited by the image sensor (typically a CCD or CMOS sensor chip) that turns light into discrete signals. The sensor is made up of millions of "buckets" that essentially count the number of photons that strike the sensor. The brighter the image at a given point on the sensor, the larger the value that is read for that pixel. Depending on the physical structure of the sensor, a color filter array may be used which requires a demosaicing/interpolation algorithm. The number of resulting pixels in the image determines its "pixel count". For example, a 640x480 image would have 307,200 pixels, or approximately 307 kilopixels; a 3872x2592 image would have 10,036,224 pixels, or approximately 10 megapixels. Image at left has a higher pixel count than the one to the right, but has lower spatial resolution.</span>', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">The resolution of a digital camera is often limited by the image sensor (typically a CCD or CMOS sensor chip) that turns light into discrete signals. The sensor is made up of millions of "buckets" that essentially count the number of photons that strike the sensor. The brighter the image at a given point on the sensor, the larger the value that is read for that pixel. Depending on the physical structure of the sensor, a color filter array may be used which requires a demosaicing/interpolation algorithm. The number of resulting pixels in the image determines its "pixel count". For example, a 640x480 image would have 307,200 pixels, or approximately 307 kilopixels; a 3872x2592 image would have 10,036,224 pixels, or approximately 10 megapixels. Image at left has a higher pixel count than the one to the right, but has lower spatial resolution.</span> ', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">The resolution of a digital camera is often limited by the image sensor (typically a CCD or CMOS sensor chip) that turns light into discrete signals. The sensor is made up of millions of "buckets" that essentially count the number of photons that strike the sensor. The brighter the image at a given point on the sensor, the larger the value that is read for that pixel. Depending on the physical structure of the sensor, a color filter array may be used which requires a demosaicing/interpolation algorithm. The number of resulting pixels in the image determines its "pixel count". For example, a 640x480 image would have 307,200 pixels, or approximately 307 kilopixels; a 3872x2592 image would have 10,036,224 pixels, or approximately 10 megapixels. Image at left has a higher pixel count than the one to the right, but has lower spatial resolution.</span> ', '<span style="color: rgb(101, 101, 101); font-family: arial; font-size: 12px; line-height: 18px; background-color: rgb(255, 255, 255);">The resolution of a digital camera is often limited by the image sensor (typically a CCD or CMOS sensor chip) that turns light into discrete signals. The sensor is made up of millions of "buckets" that essentially count the number of photons that strike the sensor. The brighter the image at a given point on the sensor, the larger the value that is read for that pixel. Depending on the physical structure of the sensor, a color filter array may be used which requires a demosaicing/interpolation algorithm. The number of resulting pixels in the image determines its "pixel count". For example, a 640x480 image would have 307,200 pixels, or approximately 307 kilopixels; a 3872x2592 image would have 10,036,224 pixels, or approximately 10 megapixels. Image at left has a higher pixel count than the one to the right, but has lower spatial resolution.</span>', 'zxvzx', 'xzxvzv', 130, '223', 0, 247, 1, 42, 52, 10, 19.2308, 2, 1, 100, 20, 0, 1369679400, 1371666600, 1372271400, 1369719541, 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `deal_cod`
--

CREATE TABLE IF NOT EXISTS `deal_cod` (
  `deal_cod_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `shipping_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pin` bigint(10) NOT NULL,
  `fb_id` varchar(100) NOT NULL,
  `deal_id` int(10) NOT NULL,
  `datetime` bigint(20) NOT NULL,
  `amount` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`deal_cod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `deal_cod`
--

INSERT INTO `deal_cod` (`deal_cod_id`, `user_id`, `shipping_name`, `email`, `phone`, `address`, `city`, `state`, `country`, `pin`, `fb_id`, `deal_id`, `datetime`, `amount`, `quantity`, `status`) VALUES
(1, 278, 'xcnxcnxc', '', 346346, 'nxcnxc', '1', 'nxcnxcn', '22', 36346, '', 2, 1369391865, 10, 1, 'Invalid'),
(2, 278, 'xnxnxnxcn', 'xcnxnxcnxcn', 457457, 'xcnxcn', '1', 'xcnxcn', '22', 45757, '', 2, 1369391934, 10, 1, 'Payment Done'),
(3, 278, 'cvncvmcv', 'cvmcvmcvm', 7457457, 'mcvmcvm', '1', 'cvmcmcvm', '22', 75745, '', 1, 1369393863, 5, 1, 'approved'),
(4, 278, 'xcnxcnxc', 'xcnxcn', 57457457, 'nxcnxncx', '1', 'xcnxcnxcn', '22', 457457, 'cvncvn', 1, 1369629589, 5, 1, 'Pending'),
(5, 278, 'xcnxcnxc', 'xcnxcn', 57457457, 'nxcnxncx', '1', 'xcnxcnxcn', '22', 457457, 'cvncvn', 1, 1369629598, 5, 1, 'approved'),
(6, 278, 'xcnxcnxc', 'xcnxcn', 57457457, 'nxcnxncx', '1', 'xcnxcnxcn', '22', 457457, 'cvncvn', 1, 1369629717, 5, 1, 'Invalid'),
(7, 278, 'xcvxcb', 'xcxcbbxcb', 235235, 'bxcbxcb', '1', 'xcbxcb', '22', 23235, 'sdvdsvg', 1, 1369631763, 5, 1, 'approved'),
(8, 279, 'magesh', 'maheswaran.k@ndot.in', 3432434, 'cbe', '1', 'tn', '24', 3443433, '', 1, 1369657383, 5, 1, 'approved'),
(9, 278, 'elango', 'elangovan.s@ndot.in', 235235, 'erode', '1', 'zxvzvxzv', '22', 35235, 'xbcxcbxc@gmail.com', 4, 1369719602, 25, 1, 'approved'),
(10, 278, 'kavin', 'kavinkumar.s@ndot.in', 9688814412, 'coimatore', '3', 'tamilnadu', '22', 54654654646, 'kavin.softeng', 5, 1369722135, 42, 1, 'Payment Done'),
(11, 278, 'kavin', 'kavinkumar.s@ndot.in', 9688814412, 'coimatore', '3', 'tamilnadu', '3', 54654654646, 'kavin.softeng', 5, 1369738748, 42, 1, 'Invalid'),
(12, 280, 'pradeep', 'pradep@ndot.in', 346346, 'erode', '1', 'erode', '22', 45364346, '', 5, 1369739872, 42, 1, 'approved'),
(13, 278, 'elango', 'elangovan.s@ndot.in', 9688814412, 'coimatore', '1', 'tamilnadu', '3', 54654654646, 'kavin.softeng', 5, 1369802730, 42, 1, 'Payment Done'),
(14, 281, 'sameer', 'sameer@synopsystechnology.com', 9688814412, 'testing address', '1', 'India', '24', 345345345345, 'kavin.softeng', 4, 1369814424, 25, 1, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `discussion`
--

CREATE TABLE IF NOT EXISTS `discussion` (
  `discussion_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `created_date` int(10) NOT NULL,
  `discussion_status` int(1) NOT NULL DEFAULT '1',
  `delete_status` int(2) NOT NULL DEFAULT '1' COMMENT '1-Active,0-Inactive',
  `type` int(1) NOT NULL COMMENT '1-deal,2-product,3-auction',
  PRIMARY KEY (`discussion_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `discussion_likes`
--

CREATE TABLE IF NOT EXISTS `discussion_likes` (
  `likes_id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1-deal,2-product,3-auction',
  PRIMARY KEY (`likes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `discussion_unlike`
--

CREATE TABLE IF NOT EXISTS `discussion_unlike` (
  `unlike_id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1-deal,2-product,3-auction',
  PRIMARY KEY (`unlike_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `email_settings`
--

CREATE TABLE IF NOT EXISTS `email_settings` (
  `settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `sendgrid_host` varchar(150) NOT NULL,
  `sendgrid_port` int(10) NOT NULL,
  `sendgrid_username` varchar(256) NOT NULL,
  `sendgrid_password` varchar(50) NOT NULL,
  `smtp_host` varchar(150) NOT NULL,
  `smtp_port` int(10) NOT NULL,
  `smtp_username` varchar(256) NOT NULL,
  `smtp_password` varchar(50) NOT NULL,
  `api_key` varchar(256) NOT NULL,
  `list_id` varchar(256) NOT NULL,
  `replay_to_mail` varchar(150) NOT NULL,
  `from_name` varchar(250) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`settings_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `email_settings`
--

INSERT INTO `email_settings` (`settings_id`, `sendgrid_host`, `sendgrid_port`, `sendgrid_username`, `sendgrid_password`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `api_key`, `list_id`, `replay_to_mail`, `from_name`, `status`) VALUES
(1, 'smtp.sendgrid.net', 587, 'engagedots', 'Whiter4~3NdOt', 'smtp.sendgrid.net', 587, 'engagedots', 'Whiter4~3NdOt', 'd3b197b0bcbafbf04f9d4710a885a4af-us6', 'd6e121b6da', 'contact-sales@ndot.in', 'uniecommerce', 1);

-- --------------------------------------------------------

--
-- Table structure for table `email_subscribe`
--

CREATE TABLE IF NOT EXISTS `email_subscribe` (
  `subscribe_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email_id` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `city_id` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `suscribe_city_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-Subscribe,0-Unsbscribe',
  `suscribe_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-subscribe,0-unsubscribe',
  `is_deleted` int(1) NOT NULL,
  PRIMARY KEY (`subscribe_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `email_subscribe`
--

INSERT INTO `email_subscribe` (`subscribe_id`, `user_id`, `email_id`, `country_id`, `city_id`, `category_id`, `suscribe_city_status`, `suscribe_status`, `is_deleted`) VALUES
(1, 248, 'kavin@gmail.com', '3', '1', '0', 1, 1, 0),
(3, 272, 'vinothkumar.r@ndot.in', '3', '4,4,4,3,3,3', '0', 1, 1, 0),
(4, 261, 'asdasd@asdasd.com', '3', '3,3', '0', 1, 1, 0),
(5, 262, 'ssss@sdad.hhh', '3', '3', '0', 1, 1, 0),
(6, 263, 'vinoth.scorpion@gmail.com', '3', '1', '0', 1, 1, 0),
(7, 264, 'vino@gmail.com', '3', '6', '0', 1, 1, 0),
(8, 267, 'adasdas@asdasd.com', '3', '3', '0', 1, 1, 0),
(11, 0, 'kavin.softeng@gmail.com', '', '1,4', '', 1, 1, 0),
(9, 0, 'dsfdsf@gmail.com', '', '1', '', 1, 1, 0),
(10, 0, 'fdsfd@gmail.com', '', '3', '', 1, 1, 0),
(12, 0, 'fgfdgdfg@gmail.com', '', '1', '', 1, 1, 0),
(13, 0, 'erewrewr@gmail.com', '', '1', '', 1, 1, 0),
(14, 0, 'hhhhhhhh@gmail.com', '', '1', '', 1, 1, 0),
(15, 0, 'dsfdsfdsfdsfdsf@gmail.com', '', '1', '', 1, 1, 0),
(16, 0, 'dfdsf@gmail.com', '', '1', '', 1, 1, 0),
(17, 276, 'selvam.r@ndot.in', '3', '1', '0', 1, 1, 0),
(18, 277, 'kavincheck@gmail.com', '3', '1', '0', 1, 1, 0),
(19, 278, 'elangovan.s@ndot.in', '3', '1', '0', 1, 1, 0),
(20, 279, 'maheswaran.k@ndot.in', '3', '1', '0', 1, 1, 0),
(21, 280, 'pradeep@ndot.in', '3', '3', '0', 1, 1, 0),
(22, 281, 'sameer@synopsystechnology.com', '3', '3', '0', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `faq_id` int(2) NOT NULL AUTO_INCREMENT,
  `question` varchar(164) NOT NULL,
  `answer` text NOT NULL,
  `faq_status` int(11) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive',
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `question`, `answer`, `faq_status`) VALUES
(5, 'How much does it cost to create check-in deals?', 'Check-in Deals are currently free to create. In the future, the product, product availability, and pricing are all subject to change.', 1),
(6, 'I found a deal I like - how do I buy it?', 'It''s simple. Just click the green "Get It" button for the deal you wish to purchase. You’ll then be directed to a third-party site to complete your purchase.', 1),
(7, 'Wait, why did I leave Metromix when I clicked “Get It”?', 'We aggregate deals from across the web to help you find the best and most exciting offers. When you click the “Get It” button from a deal that originated somewhere other than Metromix, you’ll be taken to that provider’s website to complete your purchase.', 1),
(8, 'What if I have an issue with the deal I purchased?', 'Any purchases you choose to make are from the deal sites themselves. If you have a question or concern, each site has a customer service phone number or email address so you can quickly address any issues. Please be sure to read and follow the terms and conditions of each site and offer.', 1),
(9, 'What is the new Deals section on Metromix?', 'Not only is Metromix your trusted resource for places to go and things to do, now, with Metromix Deals, you can also find extraordinary deals and specials available in your city.', 1),
(10, 'How can I feature my business on Metromix Deals?', 'To be considered for a listing on Metromix Deals, please complete our Deal Inquiry Form.', 1),
(11, 'How long does my Deal last?', 'Your Deal will remain available for consumers to purchase indefinitely unless you indicate a maximum number available or remove your Deal via biz.yelp.com.', 1),
(12, 'How are refunds handled?', 'If Yelp issues a refund to a customer, you owe Yelp your 70% share of the customer''s payment. Yelp will deduct this amount from future payments owed to you. In general, we believe that Yelp Deals should always be a great experience for the customer. So when a customer is unhappy or believes that a Deal was difficult to redeem at your business, we will refund their payment right away.', 1),
(13, 'I created my Deal, now what?', 'Watch this video to learn more about how your deal will appear on the Yelp web site and in mobile apps. Also learn how to redeem customer deals, and how to get paid.', 1),
(14, 'How do I track who purchased my Deal?', 'Once your Deal is created there will be a dedicated area within the "Yelp Deals" section where you will find a list of purchasers, as well as their unique redemption codes. When someone redeems their Deal you can electronically check them off by hitting "redeem" next to their name.', 1),
(20, 'Test Faq', 'adsfsdfsdffsdfsad\nsdfsdf\nsdf\nsd\nfsdaf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `image_resize`
--

CREATE TABLE IF NOT EXISTS `image_resize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_width` int(5) NOT NULL,
  `list_height` int(5) NOT NULL,
  `detail_width` int(5) NOT NULL,
  `detail_height` int(5) NOT NULL,
  `thumb_width` int(5) NOT NULL,
  `thumb_height` int(5) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `image_resize`
--

INSERT INTO `image_resize` (`id`, `list_width`, `list_height`, `detail_width`, `detail_height`, `thumb_width`, `thumb_height`, `type`) VALUES
(1, 160, 30, 15, 15, 23, 24, 1),
(2, 235, 250, 282, 352, 60, 75, 2),
(3, 167, 217, 282, 352, 60, 75, 3),
(4, 165, 185, 355, 400, 60, 75, 4),
(5, 228, 152, 455, 378, 100, 100, 5),
(6, 100, 100, 170, 165, 100, 100, 6);

-- --------------------------------------------------------

--
-- Table structure for table `module_settings`
--

CREATE TABLE IF NOT EXISTS `module_settings` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `is_deal` int(1) NOT NULL,
  `is_product` int(1) NOT NULL,
  `is_auction` int(1) NOT NULL,
  `is_blog` int(1) NOT NULL,
  `is_paypal` int(1) NOT NULL DEFAULT '1',
  `is_credit_card` int(1) NOT NULL DEFAULT '1',
  `is_authorize` int(1) NOT NULL DEFAULT '1',
  `is_cash_on_delivery` int(1) NOT NULL,
  `is_shipping` int(1) NOT NULL COMMENT '1- Free Shipping ,  2- Flat Shipping, 3- Per Product Shipping , 4- Per Item Shipping',
  `is_map` int(1) NOT NULL,
  `is_store_list` int(1) NOT NULL,
  `is_past_deal` int(1) NOT NULL,
  `is_faq` int(1) NOT NULL,
  `is_city` int(1) NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `module_settings`
--

INSERT INTO `module_settings` (`module_id`, `is_deal`, `is_product`, `is_auction`, `is_blog`, `is_paypal`, `is_credit_card`, `is_authorize`, `is_cash_on_delivery`, `is_shipping`, `is_map`, `is_store_list`, `is_past_deal`, `is_faq`, `is_city`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `url_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `deal_key` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `deal_description` text COLLATE utf8_unicode_ci NOT NULL,
  `fineprints` text COLLATE utf8_unicode_ci NOT NULL,
  `highlights` text COLLATE utf8_unicode_ci NOT NULL,
  `color` int(1) NOT NULL DEFAULT '0' COMMENT '0 - No , 1 - Yes',
  `size` int(1) NOT NULL,
  `shipping_amount` double NOT NULL,
  `terms_conditions` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` varchar(96) COLLATE utf8_unicode_ci NOT NULL,
  `deal_type` int(1) NOT NULL COMMENT '1-deals, 2-products, 3 - Auction',
  `merchant_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `deal_value` double NOT NULL,
  `deal_price` double NOT NULL,
  `deal_savings` double NOT NULL,
  `deal_percentage` float NOT NULL,
  `purchase_count` int(11) NOT NULL,
  `user_limit_quantity` int(5) NOT NULL,
  `created_date` int(10) NOT NULL,
  `created_by` int(11) NOT NULL,
  `deal_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  PRIMARY KEY (`deal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`deal_id`, `deal_title`, `url_title`, `deal_key`, `deal_description`, `fineprints`, `highlights`, `color`, `size`, `shipping_amount`, `terms_conditions`, `meta_description`, `meta_keywords`, `category_id`, `sub_category_id`, `deal_type`, `merchant_id`, `shop_id`, `deal_value`, `deal_price`, `deal_savings`, `deal_percentage`, `purchase_count`, `user_limit_quantity`, `created_date`, `created_by`, `deal_status`) VALUES
(1, 'test', 'test', 'ozEb3egA', 'test', '', '', 0, 1, 0, '', '', '', 201, '203,202,204,205,206,207,208,209,210,211,212,213,214', 2, 247, 1, 5, 10, 5, 50, 4, 10, 1368771623, 14, 1),
(2, 'test', 'test', '4jW8DuR5', 'test', '', '', 0, 1, 0, '', '', '', 201, '203,202,204,205,206,207,208,209,210,211,212,213,214', 2, 247, 1, 5, 10, 5, 50, 0, 10, 1368771705, 14, 1),
(3, 'test', 'test', 'IJHE6kkt', 'test', '', '', 0, 1, 0, '', '', '', 201, '203,202,204,205,206,207,208,209,210,211,212,213,214', 2, 247, 1, 5, 10, 5, 50, 1, 10, 1368771751, 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_size`
--

CREATE TABLE IF NOT EXISTS `product_size` (
  `product_size_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` int(11) NOT NULL,
  `size_name` varchar(256) NOT NULL,
  `quantity` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  PRIMARY KEY (`product_size_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `product_size`
--

INSERT INTO `product_size` (`product_size_id`, `deal_id`, `size_name`, `quantity`, `size_id`) VALUES
(1, 1, 'None', 10, 1),
(2, 2, 'None', 10, 1),
(4, 3, 'None', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` double NOT NULL,
  `type_id` int(11) NOT NULL,
  `module_id` int(1) NOT NULL COMMENT '1-deal,2-product,3-auction',
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`rate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `request_fund`
--

CREATE TABLE IF NOT EXISTS `request_fund` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL COMMENT '1-merchant request, 2-affiliate amount request',
  `user_id` int(11) NOT NULL,
  `payment_comments` text COLLATE utf8_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `date_time` int(10) NOT NULL,
  `request_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-pending, 2-approved, 3-Rejected',
  `payment_status` int(1) NOT NULL DEFAULT '0' COMMENT '1-success, 2-Failure',
  `transaction_date` int(10) NOT NULL,
  `transaction_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `error_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `error_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `error_message` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `theme` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `default_language` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'english',
  `contact_name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `contact_email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `webmaster_email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `noreply_email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `phone1` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `phone2` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `facebook_page` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_page` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `linkedin_page` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `facebook_fanpage` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `youtube_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `analytics_code` text COLLATE utf8_unicode_ci NOT NULL,
  `facebook_app_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `facebook_secret_key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_api_key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_secret_key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gmap_api_key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `paypal_payment_mode` int(1) NOT NULL COMMENT ' 0 - test account 1 - live account',
  `paypal_account_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `paypal_api_password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `paypal_api_signature` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `authorizenet_transaction_key` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `authorizenet_api_id` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `min_fund_request` double NOT NULL,
  `max_fund_request` double NOT NULL,
  `deal_commission` int(2) NOT NULL,
  `currency_symbol` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `currency_code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `country_code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `referral_amount` float NOT NULL,
  `site_mode` int(1) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '1',
  `latitude` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email_type` int(1) NOT NULL DEFAULT '1' COMMENT '1-Sendgrid,2-Smtp,3-Mailchimp',
  `flat_shipping` int(5) NOT NULL,
  `tax_percentage` int(3) NOT NULL,
  `auction_extend_day` int(3) NOT NULL,
  `auction_alert_day` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `meta_keywords`, `meta_description`, `title`, `theme`, `default_language`, `contact_name`, `contact_email`, `webmaster_email`, `noreply_email`, `phone1`, `phone2`, `facebook_page`, `twitter_page`, `linkedin_page`, `facebook_fanpage`, `youtube_url`, `analytics_code`, `facebook_app_id`, `facebook_secret_key`, `twitter_api_key`, `twitter_secret_key`, `gmap_api_key`, `paypal_payment_mode`, `paypal_account_id`, `paypal_api_password`, `paypal_api_signature`, `authorizenet_transaction_key`, `authorizenet_api_id`, `min_fund_request`, `max_fund_request`, `deal_commission`, `currency_symbol`, `currency_code`, `country_code`, `referral_amount`, `site_mode`, `status`, `latitude`, `longitude`, `email_type`, `flat_shipping`, `tax_percentage`, `auction_extend_day`, `auction_alert_day`) VALUES
(1, 'Uni-ecommerce', 'deals, daily deals, group deals,', 'sell services using multiple ways like group deals, coupons, and social media.', 'UniEcommerce Best deals and Products ', 'green', 'english', 'Nandha', 'contact-sales@ndot.in', 'admin@ndot.com', 'noreply@uniecommerce.com', '+91 960-098-8668', ' +91- 9595959595', 'http://www.facebook.com/uniecommerce', 'http://twitter.com/ndotindia', 'http://www.linkedin.com/company/269461', 'http://www.facebook.com/uniecommerce', 'http://www.youtube.com/watch?v=QhzrdsS5J9w', '<script type="text/javascript">\n  var _gaq = _gaq || [];\n  _gaq.push([''_setAccount'', ''UA-20025738-1'']);\n  _gaq.push([''_trackPageview'']);\n  (function() {\n    var ga = document.createElement(''script''); ga.type = ''text/javascript''; ga.async = true;\n    ga.src = (''https:'' == document.location.protocol ? ''https://ssl'' : ''http://www'') + ''.google-analytics.com/ga.js'';\n    var s = document.getElementsByTagName(''script'')[0]; s.parentNode.insertBefore(ga, s);\n  })();\n</script>                                                                                                  ', '401952489879906', '29a97afe6baedcc4028fd805600eea1b', '291719054236926', 'b24927947a1adc1cff504bd4cbb16968', 'b24927947a1adc1cff504bd4cbb16968', 0, 'haripr_1357394973_biz_api1.gmail.com', '1357395004', 'AVn.D2cvC.MsQAvZRc6lx0CJVtKGAIuUArsExV4UM81uJVNdHaQrEddJ', '8547YXL3eC7v6jZf', '5rBy75ZQDAk9', 12, 150, 0, '₹', 'INR', 'IND', 20, 1, 1, '11.02174', '76.91574', 1, 5, 12, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `shipping_info`
--

CREATE TABLE IF NOT EXISTS `shipping_info` (
  `shipping_id` int(11) NOT NULL AUTO_INCREMENT,
  `shipping_type` int(1) NOT NULL DEFAULT '1' COMMENT '1- product , 2 auction,3-deal',
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `adderss1` varchar(256) NOT NULL,
  `address2` varchar(256) NOT NULL,
  `city` int(11) NOT NULL,
  `state` varchar(256) NOT NULL,
  `country` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `postal_code` int(10) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `shipping_date` varchar(15) NOT NULL,
  `delivery_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shipping_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `shipping_info`
--

INSERT INTO `shipping_info` (`shipping_id`, `shipping_type`, `transaction_id`, `user_id`, `adderss1`, `address2`, `city`, `state`, `country`, `name`, `postal_code`, `phone`, `shipping_date`, `delivery_status`) VALUES
(1, 1, 1, 278, '12,kaikatty valasa', 'erode', 1, 'tamil nadu', 'Canadian', 'elango', 124234, '5235235', '1369375350', 0),
(2, 1, 2, 278, 'nxcnxcn', 'xcnxcn', 1, 'xcnxcn', 'India', 'xcbxcnxc', 346346, '346346', '1369375396', 0),
(3, 1, 3, 278, 'nxcnxcn', 'xcnxcn', 1, 'xcnxcn', 'India', 'xcbxcnxc', 346346, '346346', '1369375985', 0),
(4, 1, 4, 278, 'cvmcvm', 'cvncv', 1, 'cvmcvmcvm', 'Canadian', 'vncvncvn', 346346, '3436', '1369377485', 0),
(5, 1, 5, 278, 'bxcnxc', 'nxcnxc', 1, 'nxcnxc', 'Canadian', 'xcbxc', 46346, '34634', '1369378758', 0),
(6, 1, 6, 279, 'cbe', 'cbe', 1, 'tn', 'India', 'mahesh', 324324324, '234324324', '1369657295', 0);

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE IF NOT EXISTS `size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size_name` varchar(256) NOT NULL,
  PRIMARY KEY (`size_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`size_id`, `size_name`) VALUES
(10, '7'),
(2, '8'),
(3, '9'),
(1, 'None');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE IF NOT EXISTS `stores` (
  `store_id` int(11) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `store_url_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `store_key` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address1` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address2` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `city_id` int(5) NOT NULL,
  `country_id` int(5) NOT NULL,
  `phone_number` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `zipcode` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `store_type` int(1) NOT NULL COMMENT '1-Main, 2 - Branch',
  `merchant_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` int(10) NOT NULL,
  `store_status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`store_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`store_id`, `store_name`, `store_url_title`, `store_key`, `address1`, `address2`, `city_id`, `country_id`, `phone_number`, `zipcode`, `website`, `meta_keywords`, `meta_description`, `latitude`, `longitude`, `store_type`, `merchant_id`, `created_by`, `created_date`, `store_status`) VALUES
(1, 'kavinstore', 'kavinstore', 'temh4y5v', 'coimatore', 'coimatore', 1, 3, '9688814412', '5646465464', 'http://www.gmail.com', '', '', '-45.71037965341764', '137.765625', 1, 247, 14, 1368688838, 1),
(2, 'dsfdsf', 'dsfdsf', 'V2sGtH14', 'dsfdsf', 'dsfdsf', 1, 3, '9688814412', '5646465464', 'http://www.gmail.com', '', '', '11.00000', '78.00000', 1, 275, 14, 1368783828, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `tags_name` varchar(300) NOT NULL,
  `module_type` int(11) NOT NULL,
  `tags_count` varchar(300) NOT NULL DEFAULT '0',
  `tags_status` int(1) NOT NULL DEFAULT '1' COMMENT '1=>active, 0=>deactive',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `payer_id` varchar(25) NOT NULL,
  `payer_status` varchar(25) NOT NULL,
  `country_code` varchar(15) NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `transaction_date` int(10) NOT NULL,
  `correlation_id` varchar(50) NOT NULL,
  `acknowledgement` varchar(25) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `recipt_id` varchar(50) NOT NULL,
  `transaction_type` varchar(25) NOT NULL,
  `payment_type` varchar(25) NOT NULL,
  `order_date` int(10) NOT NULL,
  `amount` double NOT NULL,
  `referral_amount` double NOT NULL,
  `bid_amount` double NOT NULL,
  `shipping_amount` double NOT NULL,
  `tax_amount` float NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `pending_reason` varchar(100) NOT NULL,
  `reason_code` varchar(50) NOT NULL,
  `paypal_email` varchar(256) NOT NULL,
  `quantity` int(5) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1-CREDITCARD,2-PAYPAL, 3- REFER PAY, 4 - AUTHORIZE.NET',
  `captured` int(1) NOT NULL COMMENT '0-NO,1-YES',
  `captured_transaction_id` varchar(50) NOT NULL,
  `captured_date` int(10) NOT NULL,
  `captured_correlation_id` varchar(50) NOT NULL,
  `captured_ack` varchar(50) NOT NULL,
  `captured_payment_type` varchar(100) NOT NULL,
  `captured_payment_status` varchar(100) NOT NULL,
  `captured_pending_reason` text NOT NULL,
  `friend_gift_status` int(1) NOT NULL DEFAULT '0',
  `deal_merchant_commission` int(11) NOT NULL,
  `coupon_mail_sent` int(1) NOT NULL DEFAULT '0',
  `product_size` int(11) NOT NULL,
  `product_color` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `user_id`, `deal_id`, `product_id`, `auction_id`, `payer_id`, `payer_status`, `country_code`, `currency_code`, `transaction_date`, `correlation_id`, `acknowledgement`, `firstname`, `lastname`, `transaction_id`, `recipt_id`, `transaction_type`, `payment_type`, `order_date`, `amount`, `referral_amount`, `bid_amount`, `shipping_amount`, `tax_amount`, `payment_status`, `pending_reason`, `reason_code`, `paypal_email`, `quantity`, `type`, `captured`, `captured_transaction_id`, `captured_date`, `captured_correlation_id`, `captured_ack`, `captured_payment_type`, `captured_payment_status`, `captured_pending_reason`, `friend_gift_status`, `deal_merchant_commission`, `coupon_mail_sent`, `product_size`, `product_color`) VALUES
(1, 278, 1, 0, 0, '', '', '', '', 1369375350, '', '', 'elango', 'elango', '', '', '5', '', 1369375350, 5, 0, 0, 5, 0, 'Pending', 'Cash on delivery', '', '', 1, 5, 0, '', 0, '', '', '', '', '', 0, 0, 0, 0, 0),
(2, 278, 1, 0, 0, '', '', '', '', 1369375396, '', '', 'xcbxcnxc', 'xcbxcnxc', '', '', '5', '', 1369375396, 5, 0, 0, 5, 0, 'Pending', 'Cash on delivery', '', '', 1, 5, 0, '', 0, '', '', '', '', '', 0, 0, 0, 0, 0),
(3, 278, 1, 0, 0, '', '', '', '', 1369375985, '', '', 'xcbxcnxc', 'xcbxcnxc', '', '', '5', '', 1369375985, 5, 0, 0, 5, 0, 'Pending', 'Cash on delivery', '', '', 1, 5, 0, '', 0, '', '', '', '', '', 0, 0, 0, 0, 0),
(4, 278, 1, 0, 0, '', '', '', '', 1369377485, '', '', 'vncvncvn', 'vncvncvn', '', '', '5', '', 1369377485, 5, 0, 0, 5, 0, 'Pending', 'Cash on delivery', '', '', 2, 5, 0, '', 0, '', '', '', '', '', 0, 0, 0, 0, 0),
(5, 278, 1, 0, 0, '', '', '', '', 1369378758, '', '', 'xcbxc', 'xcbxc', '', '', '5', '', 1369378758, 10, 0, 0, 5, 0, 'Pending', 'Cash on delivery', '', '', 2, 5, 0, '', 0, '', '', '', '', '', 0, 0, 0, 0, 0),
(6, 279, 0, 3, 0, '', '', '', '', 1369657295, '', '', 'mahesh', 'mahesh', '', '', 'COD', '', 1369657295, 5, 0, 0, 0, 0.6, 'Pending', 'Cash on delivery', '', '', 1, 5, 0, '', 0, '', '', '', '', '', 0, 5, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_mapping`
--

CREATE TABLE IF NOT EXISTS `transaction_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `coupon_code` varchar(11) NOT NULL,
  `transaction_date` int(10) NOT NULL,
  `coupon_code_status` int(1) NOT NULL DEFAULT '1',
  `friend_name` varchar(64) NOT NULL,
  `friend_email` varchar(64) NOT NULL,
  `product_size` int(11) NOT NULL,
  `product_color` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `transaction_mapping`
--

INSERT INTO `transaction_mapping` (`id`, `deal_id`, `product_id`, `auction_id`, `user_id`, `transaction_id`, `coupon_code`, `transaction_date`, `coupon_code_status`, `friend_name`, `friend_email`, `product_size`, `product_color`) VALUES
(1, 0, 1, 0, 278, '1', 'XxhOlt8d', 1369375350, 1, 'xxxyyy', 'xxxyyy@zzz.com', 0, 0),
(2, 0, 1, 0, 278, '2', 'qu05UVkI', 1369375396, 1, 'xxxyyy', 'xxxyyy@zzz.com', 0, 0),
(3, 0, 1, 0, 278, '3', '6zhNKPkq', 1369375985, 1, 'xxxyyy', 'xxxyyy@zzz.com', 0, 0),
(4, 0, 1, 0, 278, '4', 'f5TzzNCC', 1369377485, 1, 'xxxyyy', 'xxxyyy@zzz.com', 0, 0),
(5, 0, 1, 0, 278, '5', 't07vVY9E', 1369378758, 1, 'xxxyyy', 'xxxyyy@zzz.com', 0, 0),
(6, 0, 3, 0, 279, '6', 'fb7AvEhr', 1369657295, 1, 'xxxyyy', 'xxxyyy@zzz.com', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fb_user_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fb_session_key` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_access_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_secret_token` int(100) NOT NULL,
  `address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `city_id` int(5) NOT NULL DEFAULT '0',
  `country_id` int(5) NOT NULL,
  `phone_number` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `my_favouites` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `payment_account_id` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_referral_balance` double NOT NULL,
  `merchant_account_balance` double NOT NULL,
  `merchant_commission` double NOT NULL COMMENT 'merchant commission',
  `referral_id` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `referred_user_id` int(11) NOT NULL,
  `deal_bought_count` int(5) NOT NULL,
  `created_by` int(11) NOT NULL,
  `user_type` int(1) NOT NULL DEFAULT '4' COMMENT '1-Website-Admin, 2-CityAdmin, 3-Merchant, 4-users',
  `user_status` int(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  `login_type` int(1) NOT NULL DEFAULT '1' COMMENT '1-direct, 2-admin, 3-facebook, 4-twitter',
  `joined_date` int(10) NOT NULL,
  `last_login` int(10) NOT NULL,
  `facebook_update` int(1) NOT NULL DEFAULT '0' COMMENT '1-active 0-Dactive',
  `rating` int(3) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=282 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `password`, `fb_user_id`, `fb_session_key`, `twitter_id`, `twitter_access_token`, `twitter_secret_token`, `address1`, `address2`, `city_id`, `country_id`, `phone_number`, `my_favouites`, `payment_account_id`, `user_referral_balance`, `merchant_account_balance`, `merchant_commission`, `referral_id`, `referred_user_id`, `deal_bought_count`, `created_by`, `user_type`, `user_status`, `login_type`, `joined_date`, `last_login`, `facebook_update`, `rating`) VALUES
(14, 'Adminn', '', 'admin@ndot.in', '21232f297a57a5a743894a0e4a801fc3', '0', '0', '', '', 0, 'Wajeda house, Gr. Floor', 'Gulmohar Cross Rd. No. 7', 3, 3, '+1 (323) 982-894', '', 'admin@ndot.in', 0, 2225.78, 0, '', 0, 0, 0, 1, 1, 0, 0, 0, 0, 0),
(247, 'kavin', 'soft', 'kavinkumar.s@ndot.in', 'fcb8adab4aded837916865d20a880e1c', '', '', '', '', 0, 'coimatore', 'coimatore', 1, 3, '9688814412', '', 'kavin@gmail.com', 0, 0, 5, '', 0, 0, 14, 3, 1, 2, 1368688838, 0, 0, 0),
(280, 'pradeep', '', 'pradeep@ndot.in', 'febc8f8ac083f5fc27e032c81e7b536a', '', '', '', '', 0, '', '', 3, 3, '', '', '', 0, 0, 0, 'CUoJQ3yC', 0, 0, 0, 4, 1, 1, 1369725659, 1369725659, 0, 0),
(279, 'mahesh', '', 'maheswaran.k@ndot.in', '49bb197bec17b7d20b2df6b1f3c3434a', '', '', '', '', 0, '', '', 1, 3, '', '', '', 0, 0, 0, '0Re76EPf', 0, 0, 0, 4, 1, 1, 1369657238, 1369657238, 0, 0),
(278, 'elango', '', 'elangovan.s@ndot.in', '34e8bc8aa3782126ee92302c4b0b1e4f', '', '', '', '', 0, '', '', 1, 3, '', '', '', 0, 0, 0, 'd93b4Mf2', 0, 6, 0, 4, 1, 1, 1369300862, 1369300862, 0, 0),
(277, 'kavincheck', '', 'kavincheck@gmail.com', 'fcb8adab4aded837916865d20a880e1c', '', '', '', '', 0, '', '', 1, 3, '', '', '', 0, 0, 0, 'xH7RfSvO', 0, 0, 0, 4, 1, 1, 1369205082, 1369205082, 0, 0),
(276, 'selvam', '', 'selvam.r@ndot.in', '238b45d33e6d918fb168ad9e4981a3ee', '', '', '', '', 0, '', '', 1, 3, '', '', '', 0, 0, 0, 'kI1FveB5', 0, 0, 0, 4, 1, 1, 1369121027, 1369121027, 0, 0),
(272, 'vinoth', '', 'vinothkumar.r@ndot.in', '7ed8e02e77441dd97e2496386ba3db39', '', '', '', '', 0, '', '', 3, 3, '', '', '', 0, 0, 0, 'vl7hcx3Z', 0, 0, 0, 4, 1, 1, 1368775056, 1368775056, 0, 0),
(274, 'kavin', '', 'kavin.softeng@gmail.com', 'fcb8adab4aded837916865d20a880e1c', '', '', '', '', 0, '', '', 1, 3, '', '', '', 0, 0, 0, 'n3HkkW27', 0, 0, 0, 4, 1, 1, 1368775353, 1368775353, 0, 0),
(275, 'dsfds', 'dsfds', 'kavinyyt@gmail.com', 'bc0b2aa76e85c2ca26d07f075cb42479', '', '', '', '', 0, 'dsfdsf', 'dsfdsfdsf', 1, 3, '9688814412', '', 'kavin@gmail.com', 0, 0, 9, '', 0, 0, 14, 3, 1, 2, 1368783828, 0, 0, 0),
(281, 'sameer', '', 'sameer@synopsystechnology.com', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', 0, '', '', 3, 3, '', '', '', 0, 0, 0, 'zqy7cGqY', 0, 0, 0, 4, 1, 1, 1369814279, 1369814279, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
