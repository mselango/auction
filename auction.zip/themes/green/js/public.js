// JavaScript Document
var scripts = document.getElementsByTagName("script"),
SrcPath = scripts[0].src;
Path = SrcPath.replace("js/jquery.js", "");

$(document).ready(function () {

	
	if($('#messagedisplay')){
		$('#messagedisplay').animate({opacity: 1.0}, 8000)
		$('#messagedisplay').fadeOut('slow');
	}
	if($('#error_messagedisplay')){
		$('#error_messagedisplay').animate({opacity: 1.0}, 8000)
		$('#error_messagedisplay').fadeOut('slow');
	}
	
	
	$('.cart_button').click(function() {
		var count=$("#item_count").html();
		var id=$(this).attr('id').replace('cart','');
		var id_name=$(this).attr('id_name').replace('cart','');
		if(id){ var url = Path+'payment_product/cart_items/'+count+"/"+id;  }
		
	                $.ajax(
	                {
		        type:'POST',
		        url:url,
		        cache:false,
		        async:true,
		        global:false,
		        dataType:"html",
		        success:function(check)
		        {   
		          window.location.href = Path+"cart.html" ;  
		          document.getElementById("item_count").innerHTML=check;
		        },
		        error:function()
		        {
			        alert('No data found.');
		        }
		
	                });
		});

	$('a.submit').click(function() { 



				
	
		var Pass= $("#password").val();
		var email= $("#email").val();



		var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                if (filter.test(email)) {

		if(email !='' && Pass !=''){ 
			
			$.post(Path+'users/login?email='+email+'&Pass='+Pass, { 


			}, function(response){ 	

						
			});
		}
		}else if(email=='') {
		$("#email_error").text("*Required");
		}
		else{
		$("#email_error").text("Invalid Email");
		}

		

		var req="* Required"; 

		if(Pass==''){
			$('#pass_error').text(req); }

		else if((Pass.length<5)||(Pass.length>20) && Pass!=''){
			$('#pass_error').text("The Password Should contain 5-20 Cahracters"); }
		
		else{ 
			$('#pass_error').empty();
			 }

														
	});

		$('a.profile_edit').live("click", function(e){	


				
			var UserID =  $(this).attr('id').replace('NEDIT-','');	
				$.post(Path+'users/edit_user_name?user_id='+UserID, { 
				}, function(response){ 	
					$('#user_name').css('display','none');
					$('#edit_hide').css('display','none');
					$('#Editprofile-'+UserID).css('display','');
					$("#e_followup-"+UserID).val(response);
					});											
		});
	/** Update profile **/
        	
	$('a.Upprofile').live("click", function(e){
										
		var getUID =  $(this).attr('id').replace('Upprofile-','');	
		var first_name = $("#fname-"+getUID).val(); 

		var last_name = $("#laneme-"+getUID).val(); 
		var ck_name = /^[A-Za-z0-9 ]{3,20}$/;

	if(first_name=='' || first_name==null){ 
			$("#fname_error_12").html('required');
			$('.Editprofile').css('display','');
	 }

	else if (ck_name.test(first_name)==true) { 
		
		e.preventDefault(); 		
			
			$.post(Path+'users/update_name?first_name='+first_name+'&last_name='+last_name +'&user_id='+getUID, { 

			}, function(response){ 
				$("#fname_error_12").html("");
				$('.Editprofile').css('display','none');
				$('#name_user').html(first_name+' '+last_name); 
				$('#user_name').show();
				$('#edit_hide').show();
				//$('#name_user').html(last_name);
	
					//$("body").append('<div class="modalOverlay"></div>');
			 		//new Messi('User name updated successfully');
					setTimeout(function() {
						$(".modalOverlay").fadeOut('slow');	
						$(".messi-box").fadeOut('slow');	
						
					}, 2000)
					
					return true;			
				
			});
		}
	else{
		$("#fname_error_12").html("In Valid Name");
		$('.Editprofile').css('display','');  
	 }
											
	});

	$('a.profile_edit_4').live("click", function(e){	
				
					$('#password_user').css('display','none');
					$('#password_ic').css('display','none');
					$('.Editprofile_4').css('display','');
															
		});

/** Update Password **/
        	
	$('a.Uppro_file_3').live("click", function(){
												
		var o_pass = $("#old_pass").val();  
		var n_pass = $("#new_pass").val();
		var c_pass = $("#confirm_pass").val();

		if(o_pass!='Enter Your Old Password*' && n_pass!='Enter Your New Password*' && c_pass!='Enter Your Confirm Password*'){
		
			if(n_pass!=c_pass){
							$('#pass_error_1').html("new password and confirm password doesn't match");
							$('#old_pass_error').html('');
							$('#new_pass_error').html('');
							$('.Editprofile_4').css('display','');
							$("#old_pass").val('');  
							$("#new_pass").val('');
							$("#confirm_pass").val('');
			}
			else{
				$.post(Path+'users/update_password?o_pass='+o_pass+'&n_pass='+n_pass+'&c_pass='+c_pass, { 

			}, function(response){ 
					if(response==-1){ 
						$('#old_pass_error').html("Old password doesn't match");
						$('#new_pass_error').html('');
						$('#pass_error_1').html('');
						$('.Editprofile_4').css('display','');
						$("#old_pass").val('');  
						$("#new_pass").val('');
						$("#confirm_pass").val('');
					}
					else{	
						$('.Editprofile_4').css('display','none');
						$('#password_ic').show();
						$('#password_user').show();
						$("#old_pass").val('');  
						$("#new_pass").val('');
						$("#confirm_pass").val('');
						$('#old_pass_error').html('');
						$('#new_pass_error').html('');
						$('#pass_error_1').html('');
						//$("body").append('<div class="modalOverlay"></div>');
						//new Messi('Password updated Successfully');

						//setTimeout(function() {
						//$(".modalOverlay").fadeOut('slow');	
						//$(".messi-box").fadeOut('slow');	
						
					//}, 2000)
						//return true;
					}
				
			});
	
		}
		
	}
		if(o_pass=='Enter Your Old Password*' || o_pass==''){
			$('#old_pass_error').html('required');
		}
		if(n_pass=='Enter Your New Password*'){
			$('#new_pass_error').html('required');
		}
		if(c_pass=='Enter Your Confirm Password*'){
				$('#pass_error_1').html('required');
		}
							
	});

		
	$('.profile_edit1').click(function(){ 
		$('.profile_edit1').hide();
		$('#show1').hide();
		$('#shw_lname').show();
		
	
	});
	$('a.Upprofile1').live("click", function(){

												
		var lname = $("#lname").val(); 
		var ck_name = /^[A-Za-z0-9 ]{3,20}$/;


		if (ck_name.test(lname)==true || lname=='') { 
			
			$.post(Path+'users/update_last_name?lname='+lname, { 

			}, function(response){ 
				$("#lname_error").html("");
				$('#show1').html(lname); 
				$('#shw_lname').hide();
				$('#show1').show();
				$('.profile_edit1').show();
				//$('#name_user').html(last_name);
	
			 		//new Messi('User name updated Success fully');			
				
			});
		}
	else{
		$("#lname_error").html("In Valid Name");
		return false;
	 }
											
	});




	$('a.profile_edit_2').click(function(){

		$('.profile_edit_2').hide();
		$('#show2').hide();
		$('#shw_phone').show();
	
	});
	$('a.Upprofile2').live("click", function(){

												
		var phone = $("#phone").val(); 
		var ck_name = /^[0-9 +-]{10,14}$/;

	
		if(ck_name.test(phone)==true || phone=='') { 
		
			
			$.post(Path+'users/update_phone?phone='+phone, { 

			}, function(response){ 
				$("#phone_error").html("");
				$('#show2').html(phone); 
				$('#shw_phone').hide();
				$('#show2').show();
				$('.profile_edit_2').show();
				//$('#name_user').html(last_name);
	
			 		//new Messi('User name updated Success fully');			
				
			});
		}
	else{
		$("#phone_error").html("In Valid Mobile number");
		return false;
	 }
											
	});


	      $('.sample_12').mouseover(function() {
			  
	         var getUID =  $(this).attr('id').replace('sample-','');

	    var url = Path+"welcome/show_category/?cate_id="+getUID;

	
		$.post(url,function(check){

		
			if(getUID!=""){


			$('#categeory1-'+getUID).html(check);
			$('#categeory1-'+getUID).show();
			
		
			}
	
			
			
			
		});

            });
	      $('.sample_123').mouseover(function() {
			  
	         var getUID =  $(this).attr('id').replace('sample123-','');

	    var url = Path+"deals/today_deals/?cate_id="+getUID;

	
		$.post(url,function(check){

		
			if(getUID!=""){


			$('#categeory123-'+getUID).html(check);
			$('#categeory123-'+getUID).show();
			
		
			}
	
			
			
			
		});

            });

                                        $('.sample32').mouseover(function() {
                                            var getUID =  $(this).attr('id').replace('sample32-','');
                                            var url = Path+"products/all_products/?cate_id="+getUID;

    	
                                            $.post(url,function(check){

    			
                                                if(getUID!=""){
    				
                                                    $('#categeory32-'+getUID).html(check);
    			
            
                                                    $('#categeory32-'+getUID).show();
              

                                                }
    	
    			
    			
    			
                                            });

                                        });

                                    $('.sample324').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample324-','');
                                        var url = Path+"deals/today_deals/?cate_id="+getUID;

    	
                                        $.post(url,function(check){

    			
                                            if(getUID!=""){
                                                $('#categeory324-'+getUID).html(check);
    		
                                                $('#categeory324-'+getUID).show();
                                 
    		
                                            }
    			
                                        });

                                    });

                                    $('.sample325').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample325-','');
                                        var url = Path+"auction/today_auction/?cate_id="+getUID;
    	
                                        $.post(url,function(check){
    			
                                            if(getUID!=""){
                                                $('#categeory325-'+getUID).html(check);

                                                $('#categeory325-'+getUID).show();
                                   

                                            }
                                        });
                                    });
	
	$('a.profile_edit_3').click(function(){
	
		$('.profile_edit_3').hide();
		$('#show3').hide();
		$('#shw_address').show();
	
	});
		
	$('.downarow').click(function(){
	 var getUID =  $(this).attr('id').replace('downarow-','');
	
		$('#categeory-'+getUID).hide();
		$('#downarow-'+getUID).hide();
			$('#sample_new-'+getUID).show();
		$('.arrow1-'+getUID).remove();
		$('.arrow-'+getUID).show();
		window.location.reload(true);
	
				
	
	});

	$('a.Upprofile3').live("click", function(){
												
		var address1 = $("#address1").val();
		var address2 = $("#address2").val();  
			$.post(Path+'users/update_address?address1='+address1+"&address2="+address2, { 

			}, function(response){ 
				
				$('#show3').html(address1+","+address2); 
				$('#shw_address').hide();
				$('#show3').show();
				$('.profile_edit_3').show();
		
						
				
			});
										
	});




	$('.profile_edit4').click(function(){
		$('.profile_edit4').hide();
		$('#show4').hide();
		$('#shw_city').show();
	
	});
	$('a.Upprofile4').live("click", function(){
												
		var city = $("#city").val(); 
			
			$.post(Path+'users/update_city?city='+city, { 

			}, function(response){ 
				$("#show4").html($('#city').find("option:selected").attr("title"));
				$('#shw_city').hide();
				$('#show4').show();
				$('.profile_edit4').show();
						
				
			});
										
	});

	$('.profile_edit5').click(function(){
		$('.profile_edit5').hide();
		$('#show5').hide();
		$('#shw_country').show();
	
	});
	$('a.Upprofile5').live("click", function(){
												
		var country = $("#country").val(); 

			
			$.post(Path+'users/update_country?country='+country, { 

			}, function(response){ 

				$("#show5").html($('#country').find("option:selected").attr("title"));
				$('#shw_country').hide();
				$('#show5').show();
				$('.profile_edit5').show();
						
				
			});
										
	});

	$('.profile_edit6').click(function(){
		$('.profile_edit6').hide();
		//$('#show5').hide();
		$('#shw_image').show();
	
	});




	$('a.Upprofile5').live("click", function(){
												
		var country = $("#country").val(); 
			
			$.post(Path+'users/update_country?country='+country, { 

			}, function(response){ 
				$("#show5").html($('#country').find("option:selected").attr("title"));
				$('#shw_country').hide();
				$('#show5').show();
				$('.profile_edit5').show();
						
				
			});
										
	});

	
		});
var win2;
function facebookconnect()
{ 
  win2 = window.open(Path+'facebook-connect.php',null,'width=750,location=0,status=0,height=500');

  checkChild();    
}

var win3;
function facebookconnect_share()
{ 

  win3 = window.open(Path+'facebook-connect-share.php',null,'width=750,location=0,status=0,height=500');

  checkChild();    
}
function checkChild() {
	  if (win2.closed) {
		window.location.reload(true);
	  } else setTimeout("checkChild()",1);
}

function closeerr(t)
{
	if(t=="err"){
		$("#error_messagedisplay").hide();
	}
	else{
		$("#messagedisplay").hide();
	}
}



/** Change City **/

function changecity(cityID, CityURL)
{

	window.location.href = Path+"changecity/"+cityID+"/"+CityURL+'.html';	
}


function filtercategory(category_url,type,cat_type)
{  

      if(category_url && type == "products"){
               
                  window.location.href = Path+"products/category/"+cat_type+"/"+category_url+'.html';        
      }
      else if(category_url && type == "deal"){
               window.location.href = Path+"deal/category/"+cat_type+"/"+category_url+'.html';        
      }
       else if(category_url && type == "auction"){ 
               window.location.href = Path+"auction-category/"+cat_type+"/"+category_url+'.html';        
      }
       return true;
}
function filtercolor(id)
{  

      if(id){

               
                  window.location.href = Path+"products/color_filter/"+id+'.html';        
      }

       return true;
}

function change_category()
		{

			$('#submit').click();
		}
function change_category1()
		{

			$('#submit_1').click();
		}

function change_sort()
		{
			$('#submit').click();
		}
/** SUBSCRIBE  UNSUBSCRIBE **/

function SubscribeUnsubscribe(id,type)
{

	if(id && type){
		window.location.href =Path+"users/"+type+"-select/"+id;
	}
	return;
}

function submitform()
        {
                if(document.forms["myform"].q.value==""){
                document.forms["myform"].q.placeholder="Search Value Empty";
                }
                else{
                document.forms["myform"].submit();
                }  
        }


function productaddtocart(id,key)
{
	if(id && key){
	
	        var url = Path+"product/addtocart/"+id+"/"+key;
		$.post(url,function(check){
		        alert(check); exit;
			window.location.href = Path+"cart.html" ;
		});
	       //window.location.href = Path+"product/addtocart/"+id+"/"+key;
	
	}
	return;
}
function show_popup()
{
	$('#fade').css({'visibility' : 'visible'});
	$('.popup_block5').css({'visibility' : 'visible'});
}

function showlogin()
{
	document.login.email.value='';
	document.login.password.value='';
	$('#email_error').html('');
	$('#password_error').html('');
	
	$('#fade').css({'visibility' : 'visible'});
	$('.popup_block').css({'visibility' : 'visible'});
	$('.popup_block1').css({'visibility' : 'hidden'});
	$('.popup_block2').css({'visibility' : 'hidden'});
}
function show_auction()
{

	$('#fade').css({'visibility' : 'visible'});
	$('.popup_auction').css({'visibility' : 'visible'});
}
function showforgotpassword()
{
	document.forget_password.email.value='';
	$('#femail_error').html('');
	
	
	$('#fade').css({'visibility' : 'visible'});
	$('.popup_block2').css({'visibility' : 'visible'});
	$('.popup_block').css({'visibility' : 'hidden'});
	$('.popup_block1').css({'visibility' : 'hidden'});
}

function showsignup()
{	
	document.signup.f_name.value='';
	document.signup.password.value='';
	document.signup.email.value='';
	document.signup.city.value='-99';
	$('#fname_error').html('');
	$('#emai_error').html('');
	$('#pass_error').html('');
	$('#city_error').html('');
	
	
	$('#fade').css({'visibility' : 'visible'});
	$('.popup_block').css({'visibility' : 'hidden'});
	$('.popup_block1').css({'visibility' : 'visible'});
	$('.popup_block2').css({'visibility' : 'hidden'});
	
}
	
function validateForms()
	{
		
		var email = document.login.email.value;		
		var password = document.login.password.value;
		var atpos=email.indexOf("@");
		var dotpos=email.lastIndexOf(".");
		if(email =='' || password == '' || (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length))
		{
			
			if(password == '')
			{
				$('#password_error').html('Required*');
			}
			else 
			{
				$('#password_error').html('');
			}
			if(email == '')
			{
				$('#email_error').html('Required*');

			}
			
			else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length)
			{
				$('#email_error').html('Invalid email');
				document.login.email.value = '';
				document.login.password.value = '';
			}
			else {
				$('#email_error').html('');
			}

		return false;	
		}
		
		else{
			
			var url= Path+'users/check_user_login/?email='+email+'&password='+password;
			$.post(url,function(check){
				if(check == -1)
				{
					$('#email_error').html('');
					$('#password_error').html("User name or password doesn't match");
					document.login.email.value = '';
					document.login.password.value = '';
					return false;
					
				}
			
				else if(check == 8){
					$('#email_error').html('User has been blocked ! contact admin');
					$('#password_error').html('');
					document.login.email.value = '';
					document.login.password.value = '';
					
				}
				
				else if(check == 1){ 
					document.login.submit();
				}
			});
			return false;	
		}

	
	}

	function check(){


		var filter = /^[0-9]+$/;
			var old_bid = $('#old_bid').val();
			var new_bid = $('#new_bid').val();
			var deal_id = $('input[name="bid_deal_id"]').val(); 
			
			if(parseFloat(new_bid)==""){
				$(".place_input").css('border','1px solid red');
					return false;
			}
			else if(filter.test(parseFloat(new_bid))==false){
				$(".place_input").css('border','1px solid red');
					$('#new_bid').val('');
					return false;
			}
			else if(parseFloat(old_bid) > parseFloat(new_bid)){ 
				$(".place_input").css('border','1px solid red');				
				return false;				
			}
			if(parseFloat(new_bid) >= parseFloat(old_bid)){ 
				$.post(Path+'auction/check_amount/'+new_bid+'/'+deal_id,function(check){ 
					if(check == 1) { 
						document.auction_bid.action = Path+"auction/bid_payment";
						document.auction_bid.submit();
						return true;	
					 }
					else {
						$(".place_input").css('border','1px solid red');				
						return false;	
					}
				});

				return false;			
			}
			
	}

function validatesignup()
{
		
	var fname = document.signup.f_name.value;	
	var email = document.signup.email.value;	
	var password = document.signup.password.value;
	var city = document.signup.city.value;
	
	var atpos=email.indexOf("@");
	var dotpos=email.lastIndexOf(".");
	if(fname == '' || email =='' || password == '' || (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) || city == '-99')
	{
		if(fname == ''){
			$('#fname_error').html('Required*');
		}
		else {
			$('#fname_error').html('');
		}
		if(password == '')
		{
			$('#pass_error').html('Required*');
		}
		else {
			$('#pass_error').html('');
		}
		if(city == '-99'){
			$('#city_error').html('Required*');
		
		}
		else {
			$('#city_error').html('');
		}
		if(email == '')
		{
			$('#emai_error').html('Required*');
		}
		else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length)
		{
			$('#emai_error').html('Invalid email');
			//$('#password_error').html('');
			document.signup.email.value = '';
			document.signup.password.value = '';
		}
		else {
			$('#emai_error').html('');
		}
		return false;
		
	}
	else{
		
		var url= Path+'users/check_user_signup/?email='+email;
		$.post(url,function(check){
			if(check == -1){
				$('#emai_error').html('User already exist');
				
				document.signup.email.value = '';
				document.signup.password.value = '';
				$('#city_error').html('');
				return false;
			}
			
			document.signup.submit();
		});
	}
	return false;
}


function validate_forget_password()
{
		
	var email = document.forget_password.email.value;	
	var atpos=email.indexOf("@");
	var dotpos=email.lastIndexOf(".");
	if(email =='' || (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length))
	{
		
		if(email == '')
		{
			$('#femail_error').html('Required*');
			return false;
		}
		
		if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length)
		{
			$('#femail_error').html('Invalid email');
			document.forget_password.email.value = '';
			return false;
		}
		
	return false;	
	}
	else{
		
		var url= Path+'users/check_user_signup/?email='+email;
		$.post(url,function(check){ 
			if(check == -1){
				document.forget_password.submit();
				//return true;
			}else{
				$('#femail_error').html('User not exist');
				return false;
			}
			
		});
		return false;
	}
	
}
/** SUBSCRIBE  UNSUBSCRIBE **/

function like1(d_id,u_id,dis_id,type)
{ 
    if(d_id  && u_id){
		var url = Path+"deals/like1?deal_id="+d_id+"&user_id="+u_id+"&dis_id="+dis_id+"&type="+type;
		$.post(url,function(check){ 
			$('#load_like_unlike_'+dis_id).html(check);
		});
	}
	return true;
}

function unlike1(d_id,u_id,dis_id,type)
{
    if(d_id  && u_id){
		var url = Path+"deals/unlike1?deal_id="+d_id+"&user_id="+u_id+"&dis_id="+dis_id+"&type="+type;
		$.post(url,function(check){
			$('#load_like_unlike_'+dis_id).html(check);
		});
	}
	return true;
}
function like(s_id,u_id,dis_id)
{
    if(s_id  && u_id){
		var url = Path+"stores/like?store_id="+s_id+"&user_id="+u_id+"&dis_id="+dis_id;
		$.post(url,function(check){
			$('#load_like_unlike_'+dis_id).html(check);
		});
	}
	return true;
}

function unlike(s_id,u_id,dis_id)
{
    if(s_id  && u_id){
		var url = Path+"stores/unlike?store_id="+s_id+"&user_id="+u_id+"&dis_id="+dis_id;
		$.post(url,function(check){
			$('#load_like_unlike_'+dis_id).html(check);
		});
	}
	return true;
}

function check_comment()
{ 
	var c = $("#comment_box").val();

	if(c=="Add a comment..."){
	$('#error').html('Required*');
	return false;

	}
	

	var d = $("#deal_id").val();
	var t = $("#type").val(); 
	var u_id = $('#user_id').val();
	if(u_id ==""){
		$("#comment_box").val('');
		$('#error').html('Please sign in to post comments');
		
		return false;
	}
	else{

	if(c == ""){
		$(".comment_box").css('border','1px solid red');
		return false;
	}
	else{
			var url = Path+'deals/comments/?comment='+c+"&deal_id="+d+"&type="+t;
			$.post(url,function(check){ 
					$('#show').html(check);
					$("#comment_box").val('');
			});
	}  

	}		
}

function check_comment1()

{ 
	var c = $("#comment_box").val();
	var d = $("#store_id").val(); 
	var u_id = $('#user_id').val();
	if(u_id ==""){
		$("#comment_box").val('');
		$('#error').html('Please sign in to post comments');
		
		return false;
	}
	
	if(c == ""){
		$(".comment_box").css('border','1px solid red');
		return false;
	}
	else{
			var url = Path+'stores/comments/?comment='+c+"&store_id="+d;
			$.post(url,function(check){ 
					
					$('#show_comment').html(check);
					$("#comment_box").val('');
			});
	}  
		
}

function filter_deals()
{

	var amount = $("#amount").val();
	var discount = $("#discount").val();

       var url = Path+"deals/ajax_post_deals/?amount="+amount+"&discount="+discount;

		$.post(url,function(check){

			$('#deal').html(check);
		});

}

function filter_products()
{

	var amount = $("#amount").val();



       var url = Path+"products/ajax_post_products/?amount="+amount;

		$.post(url,function(check){


			$('#product').html(check);
		});

}

function filter_auctions()
{

	var amount = $("#amount_1").val();


       var url = Path+"auction/ajax_post_auctions/?amount="+amount;


		$.post(url,function(check){


			$('.auction').html(check);
		});

}

function filter_color(color_id)
		{


	
       var url = Path+"products/ajax_post_color/?color="+color_id;


	

		$.post(url,function(check){

			$('#product').html(check);


			

		});

		

		}

function filter_size(size_id)
		{



       var url = Path+"products/ajax_post_size/?size="+size_id;
	
		$.post(url,function(check){

			$('#product').html(check);
			

		});

		

		}


