<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form method="get" class="admin_form" action="<?php echo PATH.'admin/manage-email-subscriber.html';?>">
            <table class="list_table1 fl clr">
	<?php if(($this->uri->last_segment()=="manage-email-subscriber.html") || ($this->uri->segment(3)=="page")) { ?>	
	 <?php if(count($this->users_list)>0){?>

	<a href="<?php echo PATH.'admin/manage-email-subscriber.html?id='.$this->Lang['SEARCH'].'&email='.$this->input->get('email').'&city='.$this->input->get('city'); ?>" title="<?php echo $this->Lang['EXP_SUB']; ?>"><span style="float:right;text-decoration: underline;"><img src="<?php echo PATH ?>images/csv.png" class="image" alt="Export Subscribers In CSV Format"/></span></a>
<?php }   }	 ?>	
                <?php 
	            if(isset($this->search_key)){
		            $s = $this->search_key;
	            }?>
                

			 <tr>
		<td><label><?php echo $this->Lang["CITY_NAME"]; ?></label></td>
                <td><label>:</label></td>
                <td><select name ="city">
                <?php if(isset($s->city)){ foreach($this->city_list as $c){ if($s->city == $c->city_id){ ?>
                <option value="<?php echo $c->city_id; ?>"><?php echo ucfirst($c->city_name); }}}?></option>
                <option value=""><?php echo $this->Lang["SEL_CITY"]; ?></option>
                <?php foreach($this->city_list as $c){ ?>
                <option value="<?php echo $c->city_id; ?>"><?php echo ucfirst($c->city_name); ?></option>  
                <?php }?>
                </select></td>
	
		<td><label><?php echo $this->Lang['EMAIL_F']; ?></label></td>
                <td><label>:</label></td>
                <td><input type = "text" name = "email" <?php if(isset($s->email)){?> value="<?php echo $s->email; ?>"<?php } ?>/></td>
		<td></td>

                <td><input type="submit" value="<?php echo $this->Lang['SEARCH']; ?>" class="fl"/></td>
            </tr>
            <tr>
            <td></td><td></td><td></td><td></td><td></td><td>
            </td>
            </tr>
        </table>
        </form>
    
    <?php if(count($this->users_list)>0){?>
        <table class="list_table fl clr mt15">
        	<tr>
        	<th align="left" ><?php echo $this->Lang['S_NO']; ?></th>

            	<th align="left" ><?php echo $this->Lang['EMAIL_F']; ?></th>
		<th align="left" >City</th>

		<th align="left" ><?php echo $this->Lang["B_UNB"]; ?></th>
		<th align="left" ><?php echo $this->Lang["DELETE"]; ?></th>
                
            </tr>
            <?php $i=0; $first_item = $this->pagination->current_first_item;
						
                foreach($this->users_list as $u){
					
					$city_ids = explode(',',$u->city_ids);
					$city_names = "";
					foreach($city_ids as $d){ 
						foreach($this->city_list as $s){
							if($s->city_id == $d){
								$city_names .= $s->city_name.',';
							}
						}

					}
				?>
                <tr>    
                        <td align="left"><?php echo $i+$first_item; ?></td>
       
                    

                        <td align="left"><?php echo $u->email_id; ?></td>		
                  
     			 <td align="left"><?php echo trim($city_names, ","); ?></td>
	

                        <td>
                    	<?php if($u->suscribe_status == 1){?>
                    	<a onclick="return blockunblocksubscriber('<?php echo $u->subscribe_id; ?>','block');" class="blockicon" title="<?php echo $this->Lang['BLO_USER']; ?>"></a>
                        <?php } else{  ?>
                        <a onclick="return blockunblocksubscriber('<?php echo $u->subscribe_id; ?>','unblock');" class="unblockicon" title="<?php echo $this->Lang['UNBLO_USER']; ?>"></a>
                        <?php } ?>
                    </td>
	 <td>
                    	<a onclick="return deletesubscriber('<?php echo $u->subscribe_id; ?>')" class="deleteicon" title="<?php echo $this->Lang['DELETE']; ?>" ></a>
                    </td>  
                    
                </tr>
            <?php $i++;} ?>   
        </table>
<?php } else{?><p class="nodata"><?php echo $this->Lang["NO_DATA"]; ?></p><?php }?>
     <?php echo $this->pagination; ?>    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
 
</div>
