<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="bread_crumb"><a href="<?php echo PATH."admin.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <table class="list_table fl clr">
        	<tr>
        	    <th width="5%"><?php echo $this->Lang['S_NO']; ?></th>
            	<th width="20%"><?php echo $this->Lang["COUNTRY"]; ?></th>
            	<th width="15%"><?php echo "Country Code"; ?></th>
            	<th width="20%"><?php echo $this->Lang["CUUR_SYM"]; ?></th>
            	<th width="20%"><?php echo $this->Lang["CUUR_CODE"]; ?></th>
                <th width="10%"><?php echo $this->Lang["EDIT"]; ?></th>
                <th width="10%"><?php echo $this->Lang["STATUS"]; ?></th>
                <th width="10%"><?php echo $this->Lang["DELETE"]; ?></th>
            </tr>
            <?php $i=1; foreach($this->countryDataList as $c){?>
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $c->country_name; ?></td>
                     <td><?php echo $c->country_code; ?></td>
                    <td><?php echo $c->currency_symbol; ?></td>
                    <td><?php echo $c->currency_code; ?></td>
                    <td>
                    	<a href="<?php echo PATH.'admin/edit-country/'. $c->country_url;?>.html" class="editicon" title="<?php echo $this->Lang['EDIT_COUNTRY']; ?>"></a>
                    </td>
                    <td>
                    	<?php if($c->country_status == 1){?>
                    	<a href="<?php echo PATH.'admin/block-country/'. $c->country_url;?>.html" class="blockicon" title="<?php echo $this->Lang['BLO_COUNT']; ?>"></a>
                        <?php } else{  ?>
                        <a href="<?php echo PATH.'admin/unblock-country/'. $c->country_url;?>.html" class="unblockicon" title="<?php echo $this->Lang['UNBLO_COUNT']; ?>"></a>
                        <?php } ?>
                    </td>
                    <td>
                    	<a href="<?php echo PATH.'admin/delete-country/'.$c->country_url;?>.html" 
                        onclick="return confirm('<?php echo $this->Lang['ARE_U_DEL']; ?>')" class="deleteicon" title="<?php echo $this->Lang['DEL_COUNT']; ?>"></a>
                    </td>
                </tr>
            <?php $i++; } ?>    
        </table>
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
