<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">

       <?php foreach($this->get_record as $ads){ ?>
        <form action="" method="post" class="admin_form" enctype="multipart/form-data">
            <table>
		<tr>
				<td><label><?php echo $this->Lang["ADD_TITLE"]; ?>:</label></td>
			<td><input type="text" name="ad_title" value="<?php echo $ads->ads_title; ?>"><em><?php if(isset($this->form_error["ad_title"])){ echo $this->form_error["ad_title"]; }?></em></td>
		</tr>

         <tr>
        	<td><label><?php echo $this->Lang["ADS_POSITION"]; ?> :</label></td>
            <td>
                <select name="ads_position">
                <?php
                $ads_position = Kohana::config('settings');
                foreach($ads_position["ads_position"] as $index => $position){
                if($ads->ads_position == $index){ ?>
                <option value="<?php echo $index; ?>"><?php echo $position;?></option>
                <?php }} foreach($ads_position["ads_position"] as $index => $position){ ?>
                <option value="<?php echo $index; ?>"><?php echo $position;?></option>
                <?php } ?>
                </select>
                <em><?php if(isset($this->form_error["ads_position"])){ echo $this->form_error["ads_position"]; }?></em>
            </td>
        </tr> 
        
        
        
				<tr>
				<td><label>Ad Position :</label><span>*</span></td>
				<td>
				<select name="ad_pos">
				<option value="<?php echo $ads->ad_pos; ?>"><?php echo $ads->ad_pos; ?></option>
				<?php $i=1; while($i <= $this->count_adds){ ?>
					<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
				<?php $i++; }	?>
				
				</select><em><?php if(isset($this->form_error["ad_pos"])){ echo $this->form_error["ad_pos"]; }?>
				</td>
				</tr>

        
         
	<?php /*	<tr>
			<td valign="top"><label><?php echo $this->Lang["ADD_CODE"]; ?>:</label></td>
			<td align="left"><textarea cols="20" rows="8" name="ad_code"><?php echo $ads->ads_code; ?></textarea><em><?php if(isset($this->form_error["ad_code"])){ echo $this->form_error["ad_code"]; }?></em></td>
			</tr> */ ?>
			
			  <tr>
                                <td valign="top"><label>Image:</label></td>
                                <td>
                                <input type="file" name="image"/>
                                <em><?php if(isset($this->form_error["image"])){ echo $this->form_error["image"]; }?></em>
                              <label>Image upload size <?php echo STORE_DETAIL_WIDTH; ?> X <?php echo STORE_DETAIL_HEIGHT; ?> </label>
                                </td>
                        </tr>
                        <input type="hidden" value="<?php echo $ads->ads_id; ?>" name="ads_id"/>
                          <tr>
                                <td></td>
                                <td></td>
                               <?php  if(file_exists(DOCROOT.'images/ads/'.$ads->ads_id.'.png'))       
	                        { ?>
                                <td><img border="0" src= "<?php echo PATH.'images/ads/'.$ads->ads_id.'.png';?>" alt="" width="100" /></td>
                                <?php } else { ?>
                                 <td><img border="0" src= "<?php echo PATH.'/images/no-images.png';?>" alt="" width="100" /></td>
                                <?php } ?>
                        </tr> 
                        
                        <tr>
				<td><label>Link:</label></td>
			<td><input type="text" name="link" value="<?php echo $ads->link; ?>"><em><?php if(isset($this->form_error["link"])){ echo $this->form_error["link"]; }?></em></td>
		</tr>
			
			
		<tr>
                <td></td>        <td><input type="submit" value="<?php echo $this->Lang['SUBMIT']; ?>" /><input type="button" value="<?php echo $this->Lang['CANCEL']; ?>" onclick="window.location.href='<?php echo PATH?>adds_mgmt/manage_adds.html'"/></td>
                </tr>
            </table>
        </form>
        <?php } ?>
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
