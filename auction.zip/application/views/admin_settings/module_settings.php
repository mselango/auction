<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="bread_crumb"><a href="<?php echo PATH."admin.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form action="" method="post" class="admin_form fl" >
<div class="mergent_det2">
	<fieldset>
		<legend>Modules <?php echo $this->Lang["SETTINGS"]; ?></legend> 
			<div class="paypal_mod">
            <table>
			<?php foreach($this->set_module as $u ){ ?>
            	<tr>	
			
			         <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/deal_module.png" class="image" alt="<?php echo $this->Lang['DL_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['DL_MDL']; ?>
                       <span><input type="checkbox" name="deal" <?php if($u->is_deal == 1){ ?> checked = "checked" <?php }  ?> value="1" ></span>
                      </p>
                       </div> <div class="dash_active_right">  </div> 
                    
                  
                </tr>
                

				<tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/product_module.png" class="image" alt="<?php echo $this->Lang['PRO_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['PRO_MDL']; ?>
                       <span><input type="checkbox" name="product" <?php if($u->is_product == 1){ ?> checked = "checked" <?php }  ?> value="1"></span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>
                <tr>
                    <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/auction_module.png" class="image" alt="<?php echo $this->Lang['ACT_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['ACT_MDL']; ?>
                       <span> <input type="checkbox" name="auction" <?php if($u->is_auction == 1){ ?> checked = "checked" <?php }  ?> value="1">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>

		        <tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/blog_module.png" class="image" alt="<?php echo $this->Lang['BLG_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['BLG_MDL']; ?>
                       <span><input type="checkbox" name="blog" <?php if($u->is_blog == 1){ ?> checked = "checked" <?php }  ?> value="1"></span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>
               
				<tr>	
			
			         <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/near_me_map_module.png" class="image" alt="<?php echo 'Near me map Module '; ?>"/>
                       </div>
                       
                       <p><?php echo 'Near me map Module'; ?>
                       <span><input type="checkbox" name="near_me_map" <?php if($u->is_map == 1){ ?> checked = "checked" <?php }  ?> value="1" ></span>
                      </p>
                       </div> <div class="dash_active_right">  </div> 
                    
                  
                </tr>
                

		<tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/store_list.png" class="image" alt="<?php echo 'Store list Module'; ?>"/>
                       </div>
                       
                       <p><?php echo 'Store list Module'; ?>
                       <span><input type="checkbox" name="store_list" <?php if($u->is_store_list == 1){ ?> checked = "checked" <?php }  ?> value="1"></span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>
                <tr>
                    <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/completed_deals.png" class="image" alt="<?php echo 'Past deals Module'; ?>"/>
                       </div>
                       
                       <p><?php echo 'Past deals'; ?>
                       <span> <input type="checkbox" name="past_deal" <?php if($u->is_past_deal == 1){ ?> checked = "checked" <?php }  ?> value="1">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>

		        <tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/faq_module.png" class="image" alt="<?php echo 'FAQ Module'; ?>"/>
                       </div>
                       
                       <p><?php echo 'FAQ Module'; ?>
                       <span><input type="checkbox" name="faq" <?php if($u->is_faq == 1){ ?> checked = "checked" <?php }  ?> value="1"></span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>
               
                
                
		 <?php } ?>
       </div>
            </table>
	</fieldset>
</div>
<div class="mergent_det2">
	<fieldset>
    	<legend> Payment type <?php echo $this->Lang["SETTINGS"]; ?></legend>  
    	<div class="paypal_mod">
				<table>
			<?php foreach($this->set_module as $u ){ ?>
            	<tr>	
			
			        <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/cash_on_delivery.png" class="image" alt="<?php echo 'Cash On Delivery'; ?>"/>
                       </div>
                       
                       <p>Cash On Delivery
                       <span> <input type="checkbox" name="cash_on_delivery" <?php if($u->is_cash_on_delivery == 1){ ?> checked = "checked" <?php }  ?> value="1" >
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                  
                </tr>
                
                
                <tr>	
			
			        <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/paypal_mod.png" class="image" alt="<?php echo $this->Lang['PAYPAL_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['PAYPAL_MDL']; ?>
                       <span> <input type="checkbox" name="paypal" <?php if($u->is_paypal == 1){ ?> checked = "checked" <?php }  ?> value="1" >
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                  
                </tr>

		<tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/credit_card_mod.png" class="image" alt="<?php echo $this->Lang['CRD_CARD_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['CRD_CARD_MDL']; ?>
                       <span> <input type="checkbox" name="credit_card" <?php if($u->is_credit_card == 1){ ?> checked = "checked" <?php }  ?> value="1">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                </tr>
                <tr>
                
                    <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/Authorizedotnet.png" class="image" alt="<?php echo $this->Lang['AUTH_MDL']; ?>"/>
                       </div>
                       
                       <p><?php echo $this->Lang['AUTH_MDL']; ?>
                       <span> <input type="checkbox" name="authorize" <?php if($u->is_authorize == 1){ ?> checked = "checked" <?php }  ?> value="1">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>

		 <?php } ?>         
                
            </table></div>
	</fieldset>
</div>


<div class="mergent_det2">
	<fieldset>
    	<legend>Shipping <?php echo $this->Lang["SETTINGS"]; ?></legend>  
    	<div class="paypal_mod">
				<table>
			<?php foreach($this->set_module as $u ){ ?>
            	<tr>	
			
			        <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/sign_free_red.png" class="image" alt="<?php echo 'Free Shipping'; ?>"/>
                       </div>
                       
                       <p>Free Shipping
                       <span> <input type="radio" name="shipping" <?php if($u->is_shipping == 1){ ?> checked = "checked" <?php }  ?> value="1" >
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                  
                </tr>

		<tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/flat_shipping.png" class="image" alt="<?php echo 'Flat Shipping'; ?>"/>
                       </div>
                       
                       <p>Flat Shipping
                       <span> <input type="radio" name="shipping" <?php if($u->is_shipping == 2){ ?> checked = "checked" <?php }  ?> value="2">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                </tr>
                <tr>
                
                    <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/product_shipping.png" class="image" alt="<?php echo 'Per Product Shipping'; ?>"/>
                       </div>
                       
                       <p>Per Product Shipping
                       <span> <input type="radio" name="shipping" <?php if($u->is_shipping == 3){ ?> checked = "checked" <?php }  ?> value="3">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>
                
                 <tr>
                
                    <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/item_shipping.png" class="image" alt="<?php echo 'Per Item Shipping'; ?>"/>
                       </div>
                       
                       <p>Per Item Shipping
                       <span> <input type="radio" name="shipping" <?php if($u->is_shipping == 4){ ?> checked = "checked" <?php }  ?> value="4">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                   
                </tr>

		 <?php } ?>         
                
            </table></div>
	</fieldset>
</div>
<?php /* CITY SETTINGS */ ?>
<div class="mergent_det2">
	<fieldset>
    	<legend>City <?php echo $this->Lang["SETTINGS"]; ?></legend>  
    	<div class="paypal_mod">
				<table>
			<?php foreach($this->set_module as $u ){ ?>
            	<tr>	
			
			        <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/with_city.png" class="image" alt="<?php echo 'With City'; ?>"/>
                       </div>
                       
                       <p>With City
                       <span> <input type="radio" name="city" <?php if($u->is_city == 1){ ?> checked = "checked" <?php }  ?> value="1" >
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                  
                </tr>

		<tr>
		            <div class="dash_active_left"> </div> 
                     <div class="dash_active_mid_mod">
                                          
                      <div class="dash_act_img">
                    
                      <img src="<?php echo PATH ?>images/with_out_city.png" class="image" alt="<?php echo 'Without city'; ?>"/>
                       </div>
                       
                       <p>Without City
                       <span> <input type="radio" name="city" <?php if($u->is_city == 0){ ?> checked = "checked" <?php }  ?> value="0">
                       </span> </p>
                      
                       </div> <div class="dash_active_right">  </div> 
                    
                </tr>
                             

		 <?php } ?>         
                
            </table></div>
	</fieldset>
</div>
		<table>
				<tr>
                   
                    <td style="padding:10px 0px 0px 193px;"><input type="submit" name="update" value="<?php echo $this->Lang['UPDATE']; ?>" title="<?php echo $this->Lang['UPDATE']; ?>" /><input type="button" title="<?php echo $this->Lang['CANCEL']; ?>"  value="<?php echo $this->Lang['CANCEL']; ?>" onclick="window.location.href='<?php echo PATH?>admin.html'"/></td>
                </tr>
            </table>
        </form>
	</div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
