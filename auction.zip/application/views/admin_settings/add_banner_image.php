<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="bread_crumb"><a href="<?php echo PATH."admin.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form action="" method="post" class="admin_form fl" enctype="multipart/form-data">
            <table>
                <tr>
                    <td><label><?php echo 'Image Title'; ?>*</label></td>
                    <td><label>:</label></td>
                    <td>
                    	<input type="text" name="title" value="<?php if(!isset($this->form_error['title']) && isset($this->userPost['title'])){ echo $this->userPost['title']; }?>" />
                    	<em><?php if(isset($this->form_error["title"])){ echo $this->form_error["title"]; }?></em>
                    </td>
                </tr>
                <tr>
                    <td><label><?php echo 'Upload Banner Image'; ?>*</label></td>
                    <td><label>:</label></td>
                    <td>
                    	<input type="file" name="image" />
                    	<em><?php if(isset($this->form_error["image"])){ echo $this->form_error["image"]; }?></em>
                    </td>
                </tr>
                <tr>
                    <td><label><?php echo 'Redirect URL '; ?>*</label></td>
                    <td><label>:</label></td>
                    <td>
                    	<input type="text" name="redirect_url" value="<?php if(!isset($this->form_error['redirect_url']) && isset($this->userPost['redirect_url'])){ echo $this->userPost['redirect_url']; }?>" />
                    	<em><?php if(isset($this->form_error["redirect_url"])){ echo $this->form_error["redirect_url"]; }?></em>
                    </td>
                </tr>
				<?php /* <tr>
                    <td><label><?php echo 'Position'; ?></label></td>
                    <td><label>:</label></td>
                    <td>
                    	<input type="text" name="position" value="<?php if(!isset($this->form_error['position']) && isset($this->userPost['position'])){ echo $this->userPost['position']; }?>" />
                    	<em><?php if(isset($this->form_error["position"])){ echo $this->form_error["position"]; }?></em>
                    </td>
                </tr> */ ?>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="<?php echo $this->Lang['SUBMIT']; ?>" title="<?php echo $this->Lang['SUBMIT']; ?>" /><input type="reset" value="<?php echo $this->Lang['RESET']; ?>" onclick="javascript:window.location='<?php echo PATH; ?>admin/add-banner-image.html'" title="<?php echo $this->Lang['RESET']; ?>" /> </td>
                </tr>

            </table>
        </form>
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
