<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="foot_out fl clr">
    	<div class="foot_in">
        <div class="login_footer">
   <?php /*?>     <ul>
            <li><a href="#" title="Privacy Policy">Privacy Policy</a></li><li>|</li>
            <li><a href="#" title="Affiliates">Affiliates</a></li><li>|</li>
            <li><a href="#" title="Contact Us">Contact Us</a></li><li>|</li>
            <li><a href="#" title="Links Page">Links Page</a></li><li>|</li>
            <li><a href="#" title="Tell a Friend">Tell a Friend</a></li><li>|</li>
            <li><a href="#" title="Site Map">Site Map</a></li>
        </ul><?php */?>
        <p> <?php echo $this->Lang["FOOTER_COPYRIGHT"]."&nbsp;".SITENAME.".&nbsp;".$this->Lang["FOOTER_ALLRIGHT"]; ?></p>

        </div>
        </div>
</div>

