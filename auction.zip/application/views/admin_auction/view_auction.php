<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="Home"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
    <div class="mergent_det">
    <fieldset>
    <legend>Auction Product Details</legend>
        <table class="list_table fl clr show_details_table">
            <?php foreach( $this->deal_deatils as $d){
				$symbol = CURRENCY_SYMBOL;
		
			?>
  	
                <tr>
                         <th valign="top" align="left" width="20%"><?php echo "Auction Title"; ?></th><th valign="top">:</th><td align="left"><?php echo ucfirst($d->deal_title); ?></td>
                </tr>

                
                <tr>
                         <th valign="top" align="left" width="20%"><?php echo $this->Lang["CATEGORY"]; ?></th><th valign="top">:</th><td align="left"><?php foreach($this->category_list as $c){ if($c->category_id==$d->category_id){ echo ucfirst($c->category_name); } } ?></td>
                </tr>
					
				<tr>
                         <th valign="top" align="left" width="20%"><?php echo $this->Lang["SUB_CATEGORY"]; ?></th><th valign="top">:</th><td align="left"><?php $cat_ids = explode(',',$d->sub_category_id); foreach($this->category_list as $c){ 
							foreach($cat_ids as $cat){ if($c->category_id==$cat){ echo ucfirst($c->category_name)."<br>"; } } } ?></td>
                </tr>
				
                <tr>
                   <th valign="top" align="left"><?php echo "Auction Description"; ?></th><th valign="top">:</th><td align="left"><?php echo nl2br($d->deal_description);?></td>
                </tr>
              
 				<tr>
                        
                
                   <th align="left" >Auction Original Price</th><th>:</th><td align="left"><?php echo $symbol." ".$d->product_value; ?></td>
                </tr>
                
                   <th align="left" >Auction Price</th><th>:</th><td align="left"><?php echo $symbol." ".$d->deal_value; ?></td>
                </tr>
			
                <tr>
                        <th align="left">Bid Increment</th><th>:</th><td align="left"><?php echo $symbol." ".$d->bid_increment; ?></td>
                </tr>
                
                <tr>
                        <th align="left">Bid Count</th><th>:</th><td align="left"><?php echo $d->bid_count; ?></td>
                </tr>
                
                <tr>
                        <th align="left">Shipping Fee</th><th>:</th><td align="left"><?php echo $symbol." ".$d->shipping_fee; ?></td>
                </tr>
                
                <tr>
                        <th align="left">Shipping Information</th><th>:</th><td align="left"><?php echo $d->shipping_info; ?></td>
                </tr>
                
                <tr>
                        <th align="left" ><?php echo $this->Lang["START_DATE"]; ?></th><th>:</th><td align="left"><?php echo date("d-M-Y h:i:s A", $d->startdate); ?></td>
                </tr>

                <tr>
                        <th align="left" ><?php echo $this->Lang["END_DATE"]; ?></th><th>:</th><td align="left"><?php echo date("d-M-Y h:i:s A", $d->enddate); ?></td>
                </tr>

				<tr>
                         <th valign="top" align="left" width="20%"><?php echo $this->Lang["MERCHANT_NAME"]; ?></th><th valign="top">:</th><td align="left"><?php echo ucfirst($d->firstname); ?></td>
                </tr>

                <tr>
                         <th valign="top" align="left" width="20%"><?php echo $this->Lang["COUNTRY"]; ?></th><th valign="top">:</th><td align="left"><?php echo ucfirst($d->country_name); ?></td>
                </tr>

                <tr>
                         <th valign="top" align="left" width="20%"><?php echo $this->Lang["CITY"]; ?></th><th valign="top">:</th><td align="left"><?php echo ucfirst($d->city_name); ?></td>
                </tr>

                 <tr>
                         <th valign="top" align="left" width="20%"><?php echo $this->Lang["SHOP_NAME"]; ?></th><th valign="top">:</th><td align="left"><?php echo ucfirst($d->store_name); ?></td>
                 </tr>

                <tr>
                <th valign="top" align="left" ><?php echo "Auction Image"; ?></th><th valign="top">:</th>
                <?php $con=0; 
                        for($i=1; $i<=5; $i++){ 
                                if(file_exists(DOCROOT.'images/auction/466_347/'.$d->deal_key.'_'.$i.'.png')) { 
                                        $con=$con+1; 
                                } 
                } ?>
                <?php  if(file_exists(DOCROOT.'images/auction/466_347/'.$d->deal_key.'_1'.'.png'))  { ?>
                
                <td align="left">
                <?php for($i=1; $i<=$con; $i++){ ?>
                       
                        <img border="0" src= "<?php echo PATH.'images/auction/466_347/'.$d->deal_key.'_'.$i.'.png';?>" alt="" width="100" />
                <?php } ?>
                </td>
                
                <?php } else { ?>
                
                <td><img border="0" src= "<?php echo PATH.'/images/no-images.png';?>" alt="" width="100" /></td>
                
                <?php } }?>                            
                </tr>  
                </table>
                </fieldset>
                </div>
                
                <div class="mergent_det2">
      <fieldset>
		 <legend > <?php echo "BIDING DETAILS" ?></legend>
      
     			<?php if($this->uri->segment(2) != "view-user"){ 
			if(count($this->bidding_list) > 0){ ?>
        <table class="list_table fl clr mt20">
        	<tr>
				<th align="left" width="5">S.no</th>
				<th align="left" width="20%"><?php echo 'Auction Name'; ?></th>
				<th align="left" width="12%"><?php echo 'User name'; ?></th>			
				<th align="left" width="15%">Starting Bid <?php echo '('.CURRENCY_SYMBOL.')';?></th>
				<th align="left" width="15%">Bid amount <?php echo '('.CURRENCY_SYMBOL.')';?></th>
				<th align="left" width="15%">Bid time</th> 
			
            </tr>
            
            <?php $i=1; 
			
			foreach($this->bidding_list as $u){ 
				?>
                <tr>    
                        <td align="left"><?php echo $i; ?></td>
                        <td align="left"><?php echo $u->deal_title; ?> </td>
						<td align="left"><?php echo $u->firstname; ?></td>
                        <td align="left"><?php echo $u->deal_value; ?></td>
                        <td align="left"><?php echo $u->bid_amount; ?></td>
                        <td align="left"><?php echo date("d-M-Y h:i:s A", $u->bidding_time); ?></td>
				</tr>
				<?php if($this->highest_bid[0]->bid_id == $u->bid_id) { ?>
						<?php if($u->winner!=0) { ?>
				<div class="value_total_in_bid">
           <div class="value_amount"><p align="left">Winner </p><b>:</b><span align="center" class="blink" > <?php echo  ucfirst($u->firstname); ?> </span></div>
           
           <div class="value_amount"><p align="left">Amount </p><b>:</b><span align="center" class="blink" > <?php echo  CURRENCY_SYMBOL.($u->bid_amount); ?> </span></div></div>
					<?php } else { ?>
					<div class="value_total_in_bid">
           <div class="value_amount"><p align="left">Highest Bidder </p><b>:</b><span align="center" class="blink" > <?php echo  ucfirst($u->firstname); ?> </span></div>
           
           <div class="value_amount"><p align="left">Highest Bidder Amount </p><b>:</b><span align="center" class="blink" > <?php echo  CURRENCY_SYMBOL.($u->bid_amount); ?> </span></div></div>
				<?php } ?>
			<?php } ?>
			<?php $i++; }  ?>

			</table>
		<?php }  } ?>

               <table> 
                <tr> 
                <td colspan="3"> <?php if(count($this->bidding_list)==0){ ?><?php echo new View("payment/biding_transaction_list"); ?><?php } else {?><p class="nodata"> </p><?php } ?></td>
                </tr> 
      
                <tr><td colspan="3"><a href="javascript:history.back();" class="back_btn"><?php echo $this->Lang["BACK"]; ?></a></td></tr>  
        </table>
        </fieldset>
        </div>
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>



