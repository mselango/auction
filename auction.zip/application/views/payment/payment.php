<?php defined('SYSPATH') OR die("No direct access allowed."); ?>

<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="<?php echo $this->Lang["HOME"]; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a>
<?php if(isset($s->title)){?>
<a href="<?php echo PATH.$this->url; ?>" title="<?php echo $this->template->title; ?>">&nbsp;<?php echo $this->template->title; ?>&nbsp;<span class="fwn">&#155;&#155;</span>
<?php } else{ ?>
<p><?php echo $this->template->title; ?></p>
<?php } ?></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
	<form method="get" class="admin_form" action="">
			<?php if(count($this->fund_request_list)>0){?>

	<a style="float:right;text-decoration: underline; cursor: pointer;position:relative; z-index:2;" href="<?php echo $this->sort_url.'id='.$this->Lang['SEARCH'].'&name='.$this->input->get('name'); ?>" title="Export Product COD Transactions In CSV Format"><img src="<?php echo PATH ?>images/csv.png" class="image" alt="Export Product COD Transactions In CSV Format"/></a>
	<?php }  ?>	 
            <table class="list_table1 fl clr">
                <?php 
	            if(isset($this->search_key)){        
	            }?>

		    <td><input type = "text" name = "name" <?php if(isset($this->search_key)){?> value="<?php echo $this->search_key; ?>"<?php } ?>/>
		    <input type="submit" style=" height:32px;background:#1D95D0; color:#fff;" value="<?php echo $this->Lang['SEARCH']; ?>" class="fl"/>
		    </td>
		    <td><label><?php echo $this->Lang["FUND_TYPE"]; ?></label></td>
		        <td><label>:</label></td> 
		        <td>
		        
		        <select  onchange="window.open(this.options[this.selectedIndex].value,'_top')">
		        
		         <option value="<?php echo PATH.'admin/all-fund-request.html';?>" <?php if($this->uri->last_segment() == "all-fund-request.html"){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["WITH_DRAW_ALL"]; ?></option>
		         
		        <option value="<?php echo PATH.'admin/approved-fund-request.html';?>" <?php if(($this->uri->last_segment() == "approved-fund-request.html")||($this->uri->segment(2) == "approved-fund-request")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["WITH_DRAW_APP"]; ?></option>
		        
		        <option value="<?php echo PATH.'admin/reject-fund-request.html';?>" <?php if(($this->uri->last_segment() == "reject-fund-request.html")||($this->uri->segment(2) == "reject-fund-request")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["WITH_DRAW_REG"]; ?></option>
		        
		        <option value="<?php echo PATH.'admin/success-fund-request.html';?>" <?php if(($this->uri->last_segment() == "success-fund-request.html")||($this->uri->segment(2) == "success-fund-request")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["WITH_DRAW_SUCC"]; ?></option>
		        
		         <option value="<?php echo PATH.'admin/failed-fund-request.html';?>" <?php if(($this->uri->last_segment() == "failed-fund-request.html")||($this->uri->segment(2) == "failed-fund-request")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["WITH_DRAW_FAIL"]; ?></option> 
		        </select>
		        </td>
		    <td></td>
 
        </table>
       ( <label><?php echo $this->Lang['USER_NAME']; ?>, <?php echo $this->Lang['EMAIL']; ?></label> )  
        </form>
		<?php $tot_amt_success = "0";
			$tot_amt_fail = "0";
			$tot_amt_reje = "0"; 
			$tot_amt_pending = "0"; ?>
        <?php if(count($this->fund_request_list) > 0){ ?>
        <table class="list_table fl clr mt20">
        	<tr>
			<th align="left" width="8%"><span class="align3"><?php echo $this->Lang["S_NO"]; ?></span></th>
			<th align="left" width="12%"><?php echo $this->Lang["MERCHANT_NAME"]; ?></th>
			<th align="left" width="12%"><span class="align1"><?php echo $this->Lang["EMAIL"] ; ?></span></th>
			<th align="left" width="13%"><?php echo $this->Lang["REQUEST_AMOUNT"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></th>			
			<th align="left" width="12%"><span class="align3"><?php echo $this->Lang["DATE"]; ?></span></th>
			<?php if($this->more_action == 'require') { ?>
			<th align="left" width="12%"><?php echo $this->Lang["STATUS"]; ?></th> 
			<?php } ?>
			
			<?php if($this->more_action == 'message') { ?>
			<th align="left" width="12%"><?php echo $this->Lang["STATUS"]; ?></th> 
			<?php } ?>

                </tr>
            
                <?php $i = 0;  $first_item = $this->pagination->current_first_item;
		
			foreach($this->fund_request_list as $u){?>

                <tr>    
         	    <td align="left"><span class="align4"><?php echo $i+$first_item; ?></span></td>	
		    <td align="left"><?php echo $u->firstname; ?></td>
		    <td align="left"><?php echo $u->email; ?></td>
		    <td ><span class="align"><?php echo $u->amount; ?></span></td>		
                    <td align="left"><?php echo date('d-M-Y',$u->date_time); ?></td>
                    
                    
                    <?php  if($this->more_action == 'require') { ?>
 		   <td align="left"  >
		    <?php if($u->request_status == 1){?>
                   <select  style="height:29px;" onchange="return updatefundrequest_status('<?php echo $u->request_id; ?>','<?php echo $u->user_id; ?>',this.value)">
                        <option value=""><?php echo $this->Lang['PENDING']; ?></option>
                        <option  value="2"><?php echo $this->Lang['APPROVED']; ?></option>
	                <option value="3" ><?php echo $this->Lang['REJECTED']; ?></option>
                   </select>
                 <?php 
			$tot_amt_pending+=$u->amount;
		} elseif($u->payment_status == 1){
                   echo '<span class="clor">'. $this->Lang['SUCCESS'].'</span>'; $tot_amt_success+=$u->amount; }

                  elseif($u->payment_status == 2){
                   	echo '<span class="clor2">'.$this->Lang['FAILURE'].'</span>'; $tot_amt_fail+=$u->amount;
		   } 
		
		 elseif($u->request_status == 3){  ?>
			<span class="clor3"><?php echo $this->Lang['REJECTED']; ?></span>  <?php $tot_amt_reje+=$u->amount;
		 }?> 
                </td>
               
                <?php } ?>

                <?php  if($this->more_action == 'message') { ?>
 		   <td align="left"  >
		    <?php if($u->payment_status == 2){?>
                   <select style="height:29px;"  onchange="return updatefundrequest_status('<?php echo $u->request_id; ?>','<?php echo $u->user_id; ?>',this.value)">
                        <option value=""><?php echo $this->Lang['FAILURE']; ?></option>
                        <option  value="2"><?php echo $this->Lang['APPROVED']; ?></option>
                         <option value="3" ><?php echo $this->Lang['REJECTED']; ?></option>
	                <option value="4" ><?php echo $this->Lang['REASON']; ?></option>
                   </select>
                   
                   <?php } elseif($u->payment_status == 1){
                   echo '<span class="clor">'. $this->Lang['SUCCESS'] .'</span>';} ?>
                 
                </td>
                <?php  }  ?>
                </tr>
	
            <?php  $i++;} ?> 
        </table> 
	<?php if(($this->uri->last_segment() == "all-fund-request.html")||($this->uri->segment(2) == "all-fund-request")){  ?>
	<table class="list_table fl clr mt20">            
           <th align="left" >
           <fieldset>  
    		<legend><?php echo $this->Lang['FUND_REQ_DET']; ?></legend>  
         <div class="value_total_in">
           
     <div class="value_amount"><p align="left"><?php echo $this->Lang["PEN_REQ"]; ?> </p><b>:</b><span align="center"> <?php echo CURRENCY_SYMBOL.$tot_amt_pending; ?> </span></div>
	 <div class="value_amount"><p align="left"><?php echo $this->Lang["SUCC_REQ"]; ?> </p><b>:</b><span align="center"> <?php echo CURRENCY_SYMBOL.$tot_amt_success; ?> </span></div>
	 <div class="value_amount"><p align="left"><?php echo $this->Lang["REG_REQ"]; ?> </p><b>:</b><span align="center"> <?php echo CURRENCY_SYMBOL.$tot_amt_reje; ?> </span></div>
	<div class="value_amount"><p align="left"><?php echo  $this->Lang["FAIL_REQ"]; ?> </p><b>:</b><span align="center"> <?php echo CURRENCY_SYMBOL.$tot_amt_fail; ?> </span></div>
           </th>       
             
            </div> 
           </fieldset>
            </table> 
<?php } ?>	
  <?php } else {?><p class="nodata"><?php echo $this->Lang["NO_DATA"]; ?></p><?php }?>
	
     </div>

    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
 <span class="pagination"> <?php echo $this->pagination; ?> </span>
