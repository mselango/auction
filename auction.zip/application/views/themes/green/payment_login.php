<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript"> 
        $(document).ready(function(){  
        $('.cancel_login').hide();
        $('.what_happens').hide();
        $('.what_buygift').hide();
        $('.can_change').hide();
        $('#down1').hide();
        $('#down2').hide();
        $('#down3').hide();
        });
</script>

<script type="text/javascript"> 
        function WhatHappens() {
                $('.what_happens').slideToggle(300);
                $('#down1').slideToggle(300);
                $('#right1').slideToggle(300);
                
        }
        function Whatbuygift() {
                 $('.what_buygift').slideToggle(300);
                 $('#down2').slideToggle(300);
                $('#right2').slideToggle(300);
        }
        function CanChange() {
                $('.can_change').slideToggle(300);
                $('#down3').slideToggle(300);
                $('#right3').slideToggle(300);
        }
</script>      
  </div>
            </div>
        </div>
 <div class="contianer_outer">
            <div class="contianer_inner">
                <div class="contianer">




                    <!--content start-->
                    <div class="content">
                        <!--Blog content starts-->
    <div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            <li><p><?php echo $this->Lang["ORDER_DETAILS"]; ?></p></li>
                        </ul>
                    </div>
                        <div class="blog_left">
     
                            <div class="blog_left_inner">
                                  <div class="pro_top">
                                <h2><?php echo $this->Lang["ORDER_DETAILS"]; ?></h2>
                                  </div>
                                <div class="table-heading-text1">
                                    <div class="table-heading-text-left1">
                                        <div class="tb-desc1"><?php echo $this->Lang["DESC"]; ?></div>
                                    </div>
                                    <div class="table-heading-text-right1">
                                        <div class="tb-qty1"><?php echo $this->Lang["QUAN"]; ?></div>
                                        <div class="tb-price1"><?php echo $this->Lang["PRI"]; ?></div>						
                                        <div class="tb-total1"><?php echo $this->Lang["TOTAL"]; ?></div>
                                    </div>
                                </div>
					<?php  foreach($this->deals_payment_deatils as $payment) {  ?>
                                <div class="table-content-text1">
                                    <div class="table-content-text-left1">
                                        <div class="tb-desc-content1"><?php echo $payment->deal_title; ?></div>
                                    </div>
                                    <div class="table-content-text-right1">
                                        <div class="tb-qty-content1">
                                            <div class="lessthen">
                                                <a class="less_min" style="cursor:pointer;" id="QtyDown" onclick="DownTotal()" title=""></a>
                                            </div>
                                            <div class="lessthen1">
                                               <input name="QTY" id="QTY" value="1" readonly="readonly" type="text" rel="20">
                                            </div>
                                            <div class="greaterthen">
                                                <a class="plus" style="cursor:pointer;" id="QtyUp" onclick="UpTotal()" title=""></a>
                                            </div>

                                        </div>
                                        <div class="tb-x-mark1">X</div>
							<script>
        function UpTotal()
        {
                if($('#QTY').val()!=<?php echo $payment->user_limit_quantity; ?>) {
                        var plus_amount = parseInt($('#QTY').val()) + 1;
                        $('#QTY').val(plus_amount); 
                        var total_amount = <?php echo $payment->deal_value; ?>*plus_amount;
                        if(total_amount!="0") {
                                $('#amount').text(total_amount);
                                $('#oldamount').text(total_amount);
                        }
                        else {
                                if(val!="") {
                                $('#amount').text(1*<?php echo $payment->deal_value; ?>);
                                $('#oldamount').text(1*<?php echo $payment->deal_value; ?>);
                                } else {
                                        $('#amount').text('0');
                                        $('#oldamount').text('0');
                                }
                        }
                }
                
        }
        
        function DownTotal()
        {
                if($('#QTY').val()!=1) {
                        var plus_amount = parseInt($('#QTY').val()) - 1;
                        $('#QTY').val(plus_amount); 
                        var total_amount = <?php echo $payment->deal_value; ?>*plus_amount;
                        if(total_amount!="0") {
                                $('#amount').text(total_amount);
                                $('#oldamount').text(total_amount);
                        }
                        else {
                                if(val!="") {
                                $('#amount').text(1*<?php echo $payment->deal_value; ?>);
                                $('#oldamount').text(1*<?php echo $payment->deal_value; ?>);
                                } else {
                                        $('#amount').text('0');
                                        $('#oldamount').text('0');
                                }
                        }
                }
        }
        
        </script>

                                        <div class="tb-price-content1"><?php echo CURRENCY_SYMBOL.$payment->deal_value; ?></div>
                                        <div class="tb-equals-mark1">=</div>							
                                        <div class="tb-total-content1"><?php echo CURRENCY_SYMBOL; ?><span id="amount"><?php echo $payment->deal_value; ?></span></div>
                                    </div>
                                </div>
                                <div class="table-myprice1">
                                    <div class="myprice-text1">Total to Pay</div>
                                    <div class="myprice-num1" id="balance">
                                      <span><?php echo CURRENCY_SYMBOL; ?></span><span id="oldamount"><?php echo $payment->deal_value; ?></span>
                                    </div>
                                </div>
	<?php }?>

				<div class="account-info-panel1">
						<p class="acc-info-heading1"><?php echo $this->Lang["ACC_INFO"]; ?></p>
						<div class="acc-login-panel">
							<div class="acc-login-panel-left">
							</div>
							<div class="acc-login-panel-mid1">
							<div class="befor_login" style=" margin: 30px 0 0 0;">
                                <div class="be_log_left mt20">
                                <h3 class="acc-info-heading1"><?php echo $this->Lang['ALREADY_ACC'];?></h3>
                                <p><?php echo $this->Lang['PURCHACED_GR'];?></p><br>
                                </div>
                                
								
								
								<div class="ld-login-button2">
                                                                    <div class="button_right_cont">
								
                             <div class="but_lft">
                                  <div class="but_rgt">
                                       <div class="but_mid">
                                <a  style="cursor:pointer;" onclick="return SimilarDeals();" id="SimilarDeals"  ><?php echo $this->Lang['LOGIN'];?></a>
                                </div>
                                  </div>
                             </div>
                                                                    </div>
                               
                               
                         
								
								</div>
							
                            </div>
							    <div class="cancel_login">
								 <form method="post" action="<?php echo PATH;?>payment/login">
									<div class="acc-login-form1">
									    <?php  foreach($this->deals_payment_deatils as $payment) {  ?>
                                          <input name="dealid" type="hidden" value="<?php echo $payment->deal_key; ?>" />
                                          <input name="url" type="hidden" value="<?php echo $payment->url_title; ?>"/>
                                          <?php } ?>
										<div class="login_form1">
										<ul>
											<li>
												<label><?php echo $this->Lang["EMAIL_F"]; ?>:<span class="form_star">*</span></label>
												<div class="fullname"> <input name="email" placeholder="<?php echo $this->Lang['ENTER_EMAIL']; ?>" type="text"  /></div>
											</li>
										</ul>
										</div>
										<div class="login_form_pass1">
										<ul>
											<li>
												<label><?php echo $this->Lang['PASSWORD']; ?>:<span class="form_star">*</span></label>
												<div class="fullname"><input name="password"  placeholder="<?php echo $this->Lang['ENTER_PASS']; ?>" type="password" /></div>
												<label class="acc-login-forgot-pass-text1"><a onclick="showforgotpassword();" style="cursor:pointer;" title="<?php echo $this->Lang['FORGOT_PASS']; ?>"><?php echo $this->Lang['FORGOT_PASS']; ?></a></label>
											</li>
										</ul>
										</div>
										
									


										
										<div class="sign_up_submit_outer1">
											<div class="button1">
												    <div class="but_lft">
                                                                                                         <div class="but_rgt">
                                                                                                             	<div class="but_mid">
													<input class="bnone" name="Submit" type="submit" value="<?php echo $this->Lang['LOGIN']; ?>" />
												</div>
                                                                                                         </div>
                                                                                                    </div>
											
												
											</div>
									  <div class="cancel">
                                                            <div class="sub_lft1">
                                                                	<div class="sub_rgt1">
                                                                            
												<div class="sub_mid1">
													<a  style="cursor:pointer;" class="cancle" onclick="return SimilarProducts();"  id="SimilarProducts"  ><?php echo $this->Lang['CANCEL']; ?></a>
												</div>
												</div>
                                                            </div>
											
											
											</div>
										
										</div>


										
									
									</div>
								</form>
							</div></div>
							<div class="acc-login-panel-right">
							</div>
						</div>
					</div>
					





                                <div class="personal-info-panel1">


                                    <p class="per-info-heading1">Personal Information</p>
                                    <div class="per-info-section1">
			<form method="post" id="commentForm_deals12" action="<?php echo PATH;?>payment/signup">
                                        <div class="personal-info-left1">
			      <?php  foreach($this->deals_payment_deatils as $payment) {  ?>
                                  <input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" size="40"/>
                                  <input name="url_title" type="hidden" value="<?php echo $payment->url_title; ?>" size="40"/>
                                  <?php } ?>
                                            <div class="contact_form_2">
                                                <ul>
											<li>
												<label><?php echo $this->Lang["NAME"]; ?>:<span class="form_star">*</span></label>
												<div class="fullname"><input name="f_name" size="40" placeholder="<?php echo $this->Lang['ENTER_NAME']; ?>" type="text" value="<?php if(!isset($this->form_error['f_name']) && isset($this->userPost['f_name'])){ echo $this->userPost['f_name']; } ?>" class="required" /></div><em>
                <?php if(isset($this->form_error['f_name'])){ echo $this->form_error["f_name"]; }?>
                </em>
											</li>
											<li>
												<label><?php echo $this->Lang['EMAIL_F']; ?>:<span class="form_star">*</span></label>
												<div class="fullname"><input name="email" placeholder="<?php echo $this->Lang['ENTER_EMAIL']; ?>" type="text" value="<?php if(!isset($this->form_error['email']) && isset($this->userPost['email'])){echo $this->userPost['email'];} else if(isset($this->email)){ echo $this->email; }?>" size="40" class="required email"  /></div>
												<em>
                <?php if(isset($this->form_error['email'])){ echo $this->form_error["email"]; }?>
                </em>
											</li>
											<li>
												<label><?php echo $this->Lang['PASSWORD'];?>:<span class="form_star">*</span></label>
												<div class="fullname"><input name="password"  placeholder="<?php echo $this->Lang['ENTER_PASS']; ?>" type="password" class="required"  value="<?php if(!isset($this->form_error['password']) && isset($this->userPost['password'])){ echo $this->userPost['password']; } ?>" size="40"/></div>
<em>
                <?php if(isset($this->form_error['password'])){ echo $this->form_error["password"]; }?>
                </em>
																	</li>
                                            
                                            <li>
												<label><?php echo $this->Lang['SEL_CITY']; ?>:</label>
												<div class="fullname">
														 <select name="city">
                    <?php $cityid = $this->city_id;
				if(isset($this->current_cityid)){ $cityid = $this->current_cityid;}
				$cityURL = "";
				foreach($this->all_city_list as $CData){ if($CData->city_id == $cityid){ $cityURL = $CData->city_url.".html";?>
                    <option value="<?php echo $CData->city_id; ?>"><?php echo ucfirst($CData->city_name); ?></option>
                    <?php 	}
					}
					foreach($this->all_city_list as $CityL){ ?>
                    <option <?php if($CityL->city_url==$this->input->get('city')){ echo 'Selected="true"'; } ?> value="<?php echo $CityL->city_id; ?>"><?php echo ucfirst($CityL->city_name); ?></option>
                    <?php } ?>
                  </select>
												</div>
											</li>
										</ul>
                                                <div class="complete-order-button">
                                                    <div class="new_submit_1">
                                                        <div class="ora_left">
                                                              <div class="ora_right">
                                                                   <div class="ora_mid2"><input class="bnone" name="Submit" type="submit" value="<?php echo $this->Lang['COMP_ODR']; ?>" /></div>
                                                              </div>	
                                                        </div>
                                                       
                                                      												
                                                    </div>
                                                </div>
</form>
                                                <div class="payment_terms_outer">
                                                    <p  id="terms1" class="terms-conditons-text">
                                                        <span class="fl font_myriad_pro"><?php echo $this->Lang['BY_CLICK']; ?> </span>
     <a class="font_myriad_pro mt5" title="<?php echo $this->Lang['TERMS_COND']; ?>" href="<?php echo PATH;?>terms-and-conditions.php"><?php echo $this->Lang['TERMS_COND']; ?>.</a>
                                                    </p>
                                                </div>
                                            </div>

                                        </div>



                                    </div>


                                </div>




                            </div>
                        </div>
			<div class="payment-login-deals-right">
			
				<div class="payment-faq-container">
					<p class="faq-heading-text"><?php echo $this->Lang['PAY_MEN']; ?></p>				
			<div class="faq-content2">
						<div class="faq-content-heading" onclick="return WhatHappens();">
													
							<div class="faq-content-heading-left cursor" id="right1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
							<div class="faq-content-heading-left1 cursor" id="down1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
						</div>
					     <div class="what_happens">
						<div class="faq-content-text">
						    
							<p><?php echo $this->Lang['WHILE_BUY_A_PRODUCT']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content2">
						<div class="faq-content-heading" onclick="return Whatbuygift();">
							
							<div class="faq-content-heading-left cursor" id="right2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
							<div class="faq-content-heading-left1 cursor" id="down2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
						</div>
						  <div class="what_buygift">  
						<div class="faq-content-text">
							<p><?php echo $this->Lang['ITS_QUITE_OPTIONAL']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content3">
						<div class="faq-content-heading" onclick="return CanChange();">
							<div class="faq-content-heading-left cursor" id="right3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
							<div class="faq-content-heading-left1 cursor" id="down3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
						</div>
						<div class="can_change">
						<div class="faq-content-text">
							<p><?php echo $this->Lang['OBVIOUSLY_YES']; ?></p>
						</div>
						</div>
					</div>
				</div>
			</div>
          </div>
        </div>
                      
                    <!--Blog content ends-->
                </div>
            </div>
        </div>
<script>
$(document).ready(function(){
 
$("#commentForm_deals12").validate();
});
</script>

