<?php if(count($this->store_details) > 0){ ?>	
	<?php  foreach( $this->store_details as $stores){?>	
	 <div class="feture_deal_listing_1">
                                    <div class="feture_top"></div>
                                    <div class="feture_mid_1">
                                        <div class="fetur_img">  
                                        <?php  if(file_exists(DOCROOT.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png')){ ?>
          <a href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" ><img src="<?php echo PATH.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png';?>"   alt="<?php echo $stores->store_name; ?>" title="<?php echo $stores->store_name; ?>"></a>

          <?php } else { ?>
          <a href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" ><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_stores_list.png"   alt="<?php echo $stores->store_name; ?>" title="<?php echo $stores->store_name; ?>"  ></a>

          <?php }?>                                                 
                                                                                             
                                        </div>
                                        <div class="feture_bot_det">
                                        <a class="bot_square" href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" title="<?php echo $stores->store_name; ?>"><?php echo substr(ucfirst($stores->store_name),0,30);?></a>
                                           
                                            <p class="bot_square_text"><?php echo $stores->address1; ?></p>
                                           <p class="bot_square_text"><?php echo $stores->address2; ?> , <?php echo $stores->zipcode; ?></p>
                                              <?php /**<p class="bot_square_text"><?php echo $this->Lang['PHONE']; ?>: <?php echo $stores->phone_number; ?></p> **/?>
                                                <div class="bot_store_view">
                                                        <div class="store_view_deal">
                                                            <a class="view_product" href="" title="">&nbsp;</a>
                                                        </div>
                                                        <div class="store_view_produ">
                                                            <div class="view_lft">
                                                                <div class="view_rgt">
                                                                    <div class="view_mid">
                                                                        <a class="view_product" href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" title="VIEW DETAILS">VIEW DETAILS</a> 
                                                                    </div>
                                                                </div>
                                                            </div>
                                                           
                                                        </div>
                                                    </div>

                                        </div>
                                    </div>
                                    <div class="feture_bot"></div>
                                </div> 
	

	
				
				<?php  } ?>
				<?php  } else {?>
      <p class="nodata"><?php echo $this->Lang["NO_DATA"]; ?></p>
      <?php }?>
