<div class="bid_his_heading_status">
							<p style=" text-align: center; font:  bold 12px arial; color:#333;"><?php echo count($this->transaction_details); ?> bids total</p>
						</div>
						<div class="bid_his_heading bg_white">
							<p>Current Winning Bidder(s)</p>
						</div>
						<div class="bidders_list" >	
						<?php foreach ($this->transaction_details as $tran) { ?>
							<div class="list1">
								<div class="list1_left">
									<p><?php echo $tran->firstname; ?> <?php echo $tran->lastname; ?></p>
									<span><?php echo date("d-m-Y h:i:s A", $tran->transaction_date); ?></span>
								</div>
								<div class="list1_right">
									<p><?php echo CURRENCY_SYMBOL . " " . $tran->bid_amount; ?></p>											
								</div>
							</div>
						<?php } ?>
					</div>
