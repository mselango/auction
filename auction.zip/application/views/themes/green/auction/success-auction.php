<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
		$('#fade').css({'filter' : 'alpha(opacity=100)'}).fadeIn();
		$('#fade').css({'visibility' : 'visible'});
		$("body").kkCountDown({
		colorText:'black',
		addClass : 'shadow'
		});
		
	});
</script>
<style>
#fade { background: #000; position: fixed; left: 0; top: 0; width: 100%; height: 100%; opacity: 1.0; z-index: 9999; }
.success_auction { float: left;position: fixed; width:75%;  z-index: 99999; background: white;clear:both;top:42px;  left: 199px; padding: 10px;}
</style>

 <body>

<div class="success_auction">
        <!--QTY header start-->
        <div class="header_outer">
            <div class="qty_header_top_inner">
                <div class="logo">
                    <h1>
                       <a href="<?php echo PATH;?>" title="logo"><img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png" /></a>
                    </h1>
                </div>
            </div>
        </div> 
        <!--QTY header end-->

        <!--QTY CONTENT start-->
        <div class="contianer_outer1">
            <div class="contianer_inner">
                <div class="contianer">
                    <div class="qty_content_outer">
                        <div class="qty_heading">
                            <h3>Congratulations!<span>Your bid was placed successfully.</span></h3>
                           <?php /* <label>You’ll receive an email confirmation shortly</label> */?>
                        </div>
                        <div class="qty_content">
                            <div class="qty_content_left1">
									<?php if(file_exists(DOCROOT.'images/auction/220_160/'.$this->deal_key.'_1'.'.png')) {
										$image = PATH.'images/auction/220_160/'.$this->deal_key.'_1'.'.png';
									} else {
										$image = PATH."themes/".THEME_NAME."/images/noimage_deals_details.png";
									} ?>
                                <a href="#" title="bid_image">
                                    <img src= "<?php echo $image; ?>" alt="bid_image"/>
                                </a>
                            </div>
                            <div class="qty_content_right">
                                <div class="qty_top_box_1">
                                    <div class="qty_box_commom">
                                        <ul>
                                            <li class="amount_bid">
                                                <label>Your Bid Amount :</label>
                                                <span><?php echo CURRENCY_SYMBOL.$this->current_bid_value; ?></span>
                                            </li>
                                            <li class="amount_bid1">
                                                <label>Estimated Shipping Charge :</label>
                                                <span><?php echo CURRENCY_SYMBOL.$this->shipping_amount; ?></span>
                                            </li>
                                            <li>
                                                <p><span time="<?php echo $this->end_time; ?>" class="kkcount-down" ></p>
                                            </li>
                                            <li>
                                                <h5>auction time remaining</h5>
                                            </li>
                                            <li>
                                                <div class="bs_row_right_1">
                                                    <div class="gren_left">
                                                        <div class="gren_right">
                                                            <div class="gren_mid"><input type="button" value="Close window" onclick="javascript:window.location='<?php echo PATH; ?>auction/<?php echo $this->deal_key ; ?>/<?php echo $this->url_title; ?>.html'" ></div> 
                                                        </div>
                                                    </div>


                                                </div>
                                            </li>
                                            <li>
                                                <a  href="#" title="View Additional Noise Canceling Headphones">View Additional Noise Canceling Headphones</a>
                                            </li>
                                        </ul>
                                    </div>


                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="qty_footer_list">
                        <ul>
                            <li>If no alternative information is provided within 24 hours of the auction closing the winning bidder's default credit card and billing address will be used to ship the winnings.</li>
                            <li>Your credit card will NOT be charged until the auction ends and we will only charge the minimum amount needed to win.</li>
                            <li>A 3% transaction fee with $1.99 minimum and a $9.99 maximum will be added per order if you win.</li>
                            <li>If your order is cancelled due to a credit card decline, a $25 fee will be assessed.</li>
                            <li>Applicable sales tax will be added to Illinois &amp; Tennessee orders.</li>
                            <li>By bidding I agree with the User Agreement, Privacy Policy, Return Policy &amp; Bidding Rules.</li>
                        </ul>  

                    </div>

                </div>
            </div>
        </div>
        <!--QTY CONTENT ends-->
</div>

    </body>

