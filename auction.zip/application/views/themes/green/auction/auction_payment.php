

<script type="text/javascript"> 
    $(document).ready(function(){  
		
<?php if ($this->paypal_setting) { ?> 
                   $('.cancel_login').hide();
                   $('.cod_show').hide();
 <?php } else { ?>
                    $('.befor_login').hide();
                    $('.cancel_login').show();
                    $('.cod_show').hide();
<?php } ?>
                $('.AuthorizeNet_pay').hide();
                $('.no_paypal').hide();
                $('.cod_show').hide();
        
            });
</script>
<script type="text/javascript"> 
    $('.cancel_login').hide();
     $('.cod_show').hide();
    function SimilarDeals() {
        $('.cancel_login').show();
        $('.befor_login').hide();
        $('.AuthorizeNet_pay').hide();
         $('.cod_show').hide();
    }
    function SimilarProducts() {
        $('.befor_login').show();
        $('.cancel_login').hide();
        $('.AuthorizeNet_pay').hide();
         $('.cod_show').hide();
    }
    function Authorize() {
        $('.befor_login').hide();
        $('.cancel_login').hide();
        $('.AuthorizeNet_pay').show();
         $('.cod_show').hide();
    }
    
        function SimilarCod() {
			    $('.cod_show').show();
                $('.cancel_login').hide();
					$('#order_hide').hide();
		
                $('.befor_login').hide();
                $('.AuthorizeNet_pay').hide();
                $('.complete-order-button').show();
		
        }
        
       
</script>
<SCRIPT language=Javascript>
    function isNumberKey(evt)
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    }
</SCRIPT>
			<div class="bread_crumb">
				<ul>
					<li><p><a title="<?php echo $this->Lang['HOME1']; ?>" href="<?php echo PATH; ?>" ><?php echo $this->Lang['HOME1']; ?></a></p></li>
					<li><p><?php echo $this->Lang['YOUR_PUR']; ?></p></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--end-->
<div class="contianer_outer1">
    <div class="contianer_inner">
        <div class="contianer">
            <!--content start-->
            <div class="content_abouts"  id="payment_credit_card">
                <div class="content_auction_top">
                    <h2><?php echo $this->Lang['TYPE_PAY']; ?></h2>
                    <div class="payment_select"> 
                        <?php if ($this->paypal_setting) { ?>
                            <div class="payment_sel_lft"><a onclick="return SimilarProducts();" id="SimilarProducts"  > <input id="paypal_radio" type="radio" name="name" checked/></a>  <p class="fl width60 color333333"><?php echo $this->Lang['PAYPAL']; ?></p></div>
                        <?php } ?>
                        <?php if ($this->credit_card_setting) { ?>
                            <div class="payment_sel_lft1"><a onclick="return SimilarDeals();" id="SimilarDeals"  > <input type="radio" name="name"  <?php if ($this->paypal_setting) {
                        } else { ?> checked <?php } ?> /></a> <p class="fl width220"><?php echo $this->Lang['PAYPAL_CREDIT']; ?></p></div>
                        <?php } ?>
                        <?php if ($this->authorize_setting) { ?>
                            <div class="payment_sel_lft1"> <a onclick="return Authorize();" id="Authorize"  > <input type="radio" name="name"  /></a> <p class="fl width220">Authorize.net</p></div>
						<?php } ?>
						     <a onclick="return SimilarCod();" id="Cod"  >   <div class="payment_sel_lft1"> <input type="radio" name="name"  /></a> <p class="fl width220">COD</p>
                    </div>
                </div>
				<?php $referral_balance = "0"; ?>
                <?php foreach ($this->deals_payment_deatils as $payment) { ?>
                    <div class="content_auction_mid">
                        <div class="cont_auc_lft">
                            <?php if (file_exists(DOCROOT . 'images/deals/220_160/' . $payment->deal_key . '_1' . '.png')) { ?>
                                <a href="<?php echo PATH . 'deals/' . $payment->deal_key . '/' . $payment->url_title . '.html'; ?>" title="<?php echo $payment->deal_title; ?>"><img src="<?php echo PATH . 'images/deals/220_160/' . $payment->deal_key . '_1' . '.png'; ?>"  alt="<?php echo $payment->deal_title; ?>" title="<?php echo $payment->deal_title; ?>" >&nbsp;</a>
                            <?php } else { ?>
                                <a href="<?php echo PATH . 'deals/' . $payment->deal_key . '/' . $payment->url_title . '.html'; ?>" title="<?php echo $payment->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png"  alt="<?php echo $payment->deal_title; ?>" title="<?php echo $payment->deal_title; ?>" >&nbsp;</a>  
							<?php } ?> 
                        </div>
                        <div class="cont_auc_rgt">
                            <ul>
                                <li>
                                    <label><?php echo $this->Lang['DESC']; ?>   </label>
                                    <b>:</b>
                                    <span><?php echo $payment->deal_title; ?></span>
                                </li>
                                <li>
                                    <label>Shipping Fee   </label>
                                    <b>:</b>
                                    <p><?php echo CURRENCY_SYMBOL . $payment->shipping_fee; ?> </p>
                                </li>
                                <li>
                                    <label>Bid Amount    </label>
                                    <b>:</b>
                                    <p><?php echo CURRENCY_SYMBOL . $this->current_bid_value; ?> </p>
                                </li>
                                <li>
                                    <label>Total     </label>
                                    <b>:</b>
                                    <span id="amount"><?php echo CURRENCY_SYMBOL; ?><?php echo $this->current_bid_value + $payment->shipping_fee; ?></span>
                                    <INPUT TYPE="hidden"  id="ref_deal_id"  value="<?php echo $payment->deal_id; ?>">
                                </li>
                            </ul>
                        </div>
                        <div style="display:none" id="oldamount"><?php echo $this->current_bid_value; ?></div>
                    </div>
                    <?php } ?>
                <div class="befor_login">
					<?php echo new View("themes/" . THEME_NAME . "/paypal/auction_paypal"); ?>
                </div>
                <div class="cancel_login">
					<?php echo new View("themes/" . THEME_NAME . "/paypal/auction_dodirect_creditcard"); ?>
                </div>
           </div>
           <div class="AuthorizeNet_pay">
				<?php echo new View("themes/" . THEME_NAME . "/paypal/auction_Authorize"); ?>
           </div>
                    
                    
                    <div class="cod_show">
			 <?php echo new View("themes/".THEME_NAME."/paypal/auction_cod"); ?>     
        
        </div>  
        
            <script>
                $(document).ready(function(){
                    $("#commentForm_ref").validate();
                });
            </script>
            <div class="no_paypal">
                <form name="payment" method="POST" id="commentForm_ref" action="<?php echo PATH; ?>payment/referral_payment">
                    <input name="P_QTY" id="PCR_QTY_VAL" value="1" type="hidden" >
                    <input name="deal_id"  type="hidden" value="<?php echo $payment->deal_id; ?>" >
                    <input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" >
                    <input name="deal_value" type="hidden" value="<?php echo $this->current_bid_value; ?>" >
                    <input name="amount" id="PCR_AMOUNT"  type="hidden" value="<?php echo $this->current_bid_value; ?>" >
                    <input name="p_referral_amount" id="PCR_REFERRAL" value="0" type="hidden">
					<?php if ($this->uri->segment(2) == "payment_details_friend") { ?>
                        <div class="pop_up_1">
                            <label><?php echo $this->Lang['FRI_NAME']; ?></label>
                            <div class="text_box_2">
                                <div class="pur_txt_box">
                                    <input type="text" value="" name="friend_name" class="required" onkeyup="Referralfriend(this.value)"/>
                                </div>
                                <em>
									<?php if (isset($this->form_error['friend_name'])) {
										echo $this->form_error["friend_name"];
									} ?>
                                </em> 
                            </div>
                        </div>
                        <div class="pop_up_1">
                            <label><?php echo $this->Lang['FRI_EMAIL']; ?></label>
                            <div class="text_box_2">
                                <div class="pur_txt_box">
                                    <input type="text" value="" name="friend_email" class="required email" onkeyup="Referralfriend(this.value)"/>
                                </div>
                                <em>
									<?php if (isset($this->form_error['friend_email'])) {
										echo $this->form_error["friend_email"];
									} ?>
								</em> 
                            </div>
                        </div>
                        <input name="friend_gift"  value="1" type="hidden">
					<?php } else { ?>
                        <input name="friend_name"  type="hidden" value="xxxyyy" >
                        <input name="friend_email"   type="hidden" value="xxxyyy@zzz.com" >
                        <input name="friend_gift"  value="0" type="hidden">
					<?php } ?>
                    <div class="blog_right1" id="blog_rgt_2">
                        <div class="payment-faq-container" id="payment-faq-container_2">
                            <p class="faq-heading-text">Payment Faq</p>
                            <div class="faq-content1">
                                <div class="faq-content-heading">
                                    <div class="faq-content-heading-left">
                                        <a href="#" title="">  What happens after I buy?</a>
                                    </div>
                                </div>
                                <div class="faq-content-text">
                                    <p>Once the purchase has been accomplished, you'll recieve an email confirming that the process has been completed.During exceptional network traffic circumstances,please allow full 24 hours to recieve the reciept through e mail.This e mail will.</p>
                                </div>
                            </div>
                            <div class="faq-content2">
                                <div class="faq-content-heading">
                                    <div class="faq-content-heading-left1">
                                        <a href="#" title="">  What if I buy as a gift?</a>
                                    </div>
                                </div>
                            </div>
                            <div class="faq-content3">
                                <div class="faq-content-heading">
                                    <div class="faq-content-heading-left1">
                                        <a href="#" title=""> How may I get referral amount? </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
            <!--end-->
        </div>
    </div>
</div>

