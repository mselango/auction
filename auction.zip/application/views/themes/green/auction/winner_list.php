<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
		<?php if(count($this->winner_list)>0){ ?>
						<?php  $deal_offset = $this->input->get('offset'); foreach($this->winner_list as $deals){ ?>
                            <div class="winer_listing">
                                <div class="winner_inner">
                                    <div class="winner_inner_common">
                                        <div class="act_img_top"></div>
                                        <div class="act_img_mid">
                                            <div class="winner_images">
                                                <?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
												<a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png';?>" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>
												<?php } else { ?>
												<a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" style="width:163px; height:185px;" ></a>
												<?php }?>
                                            </div>
                                        </div>
                                        <div class="act_img_bot"></div>
                                        <div class="winner_over_all">
                                            <div class="winner_over_all_listing">
                                                <p>Winner  : </p>
                                                <label><?php echo ucfirst($deals->firstname); ?></label>
                                                <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo substr($deals->deal_title,0,40)."..";?>"><?php echo substr(ucfirst($deals->deal_title),0,40)."..";?></a>
                                            </div>
                                            <div class="winner_over_all_listing_prize">
                                                <p>Retail Price : </p>
                                                <label> <?php echo CURRENCY_SYMBOL.$deals->product_value; ?></label>

                                            </div>
                                            <div class="winner_over_all_listing_prize">
                                                <p>Auction Price :  </p>
                                                <label> <?php echo CURRENCY_SYMBOL.$deals->deal_value; ?></label>

                                            </div>
                                            <div class="winner_over_all_listing_prize">
                                                <p>Bid Amount :  </p>
                                                <label> <?php echo CURRENCY_SYMBOL." ".$deals->bid_amount; ?></label>

                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                            
					   <?php } $deal_offset++; ?>
					<?php }else {?>
<p>Nodata Found</p>
<?php } ?>
