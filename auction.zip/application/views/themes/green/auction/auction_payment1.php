<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php if(!$this->UserID) { ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
		$('#fade').css({'filter' : 'alpha(opacity=100)'}).fadeIn();
		$('#fade').css({'visibility' : 'visible'});
		
	});
</script>
<style>
#fade { background: #000; position: fixed; left: 0; top: 0; width: 100%; height: 100%; opacity: 1.0; z-index: 9999; }
.auction_login { float: left; font-size: 1.2em; position: fixed; top: 10%; left: 35%;right:35%; z-index: 99999; clear:both;}
</style>
<div class="auction_login">
	<div class="login_inner">
		<div class="login">
			<div class="login_top"></div>
			<div class="login_mid">
				<a class="close" title="close" id="close" style="cursor:pointer;">&nbsp;</a>
				<div class="login_det">
					<div class="login_top_det">
						<div class="log_logo"><a href="<?php echo PATH; ?>" title="<?php echo SITENAME ; ?>"><img alt="logo" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/></a></div>
							<h1><?php echo $this->Lang['USER_LOG']; ?></h1>
							<form id="login" name="login1" method="post" action="" autocomplete="off">
								<ul>
									<li>
										<label><?php echo $this->Lang['EMAIL']; ?>:<span class="form_star"></span> </label>
										<div class="full"><input type="text" value="" name="email" placeholder="Enter your Email here" autocomplete="off"></div>
									</li>
									<li><em id="email_error1"></em></li>
									<li>
										<label><?php echo $this->Lang['PASSWORD']; ?>:<span class="form_star"></span> </label>
										<div class="full"><input type="password" placeholder="Enter your Password here" value="" name="password" autocomplete="off"></div>
									</li><li><em id="password_error1"></em></li>
									<?php /*<li>
										<label ><a class="forgot" href="javascript:showforgotpassword();" title="<?php echo $this->Lang['FORGOT_PASS']; ?>?"><?php echo $this->Lang['FORGOT_PASS']; ?>?</a></label>
									</li> */ ?>
									<li>
									<div class="login_submit_outer">
										<div class="submit">
											<div class="sub_lft"></div>
											<div class="sub_mid"><input type="button" value="LOGIN" onclick="return validate_login();"></div>
											<div class="sub_rgt"></div>
										</div>
										</div>
									</li>
								</ul>
							</form>
						</div>
					</div>
				</div>
				<div class="login_bot"></div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
	$(document).ready(function(){
	$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
	$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); //Fade in the fade layer 				   		   
	//Close Popups and Fade Layer
	$('#close').live('click', function() { //When clicking on the close or fade layer...
		//$('#popup1').css({'visibility' : 'hidden'});
			$('.auction_login').css({'visibility' : 'hidden'});
			$('#fade').css({'visibility' : 'hidden'});
		
		
		return false;
	});
			$(document).keyup(function(e) { 
			if (e.keyCode == 27) { // esc keycode
				//$('#popup1').css({'visibility' : 'hidden'});
				$('.popup1').css({'visibility' : 'hidden'});
				$('#fade').css({'visibility' : 'hidden'});
			
			return false;
			}
		});
	});
	function validate_login()
		{

			var email = document.login1.email.value;	
			var password = document.login1.password.value;
			var atpos=email.indexOf("@");
			var dotpos=email.lastIndexOf(".");
			if(email =='' || password == '' || (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length))
			{
				if(email == '')
				{
					$('#email_error1').html('required');
				}
				if(password == '')
				{
					$('#password_error1').html('required');
				
					return false;
				}
				if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length)
				{
					$('#email_error1').html('Invalid Email');
					$('#password_error1').html('');
					document.login1.email.value = '';
					document.login1.password.value = '';
				}
				
			}
			else{
				
				var url= Path+'users/check_user_login/?email='+email+'&password='+password;
				$.post(url,function(check){
					if(check == -1)
					{
						$('#email_error1').html('');
						$('#password_error1').html("User name or Password doesn't match");
						document.login1.email.value = '';
						document.login1.password.value = '';
					}
				
					else if(check == 8){
						$('#email_error1').html('User Has been Blocked ! Contact Admin');
						$('#password_error1').html('');
						document.login1.email.value = '';
						document.login1.password.value = '';
					}
					
					else if(check == 1){ 
						document.login1.submit();
					}
				});
			}
		
		}
		
	</script>

<?php } elseif($this->UserID == $this->auction_user){ ?>

<?php echo new View("themes/".THEME_NAME."/auction/auction_payment"); ?>

<?php } else { ?>
	<form method="post" >
		<h1> Sorry you are not a correct user for buy this auction </h1>
			<input type="button" value="Click It" onclick="window.location.href='<?php echo PATH; ?>auction.html'" >
	</form>
<?php } ?>
