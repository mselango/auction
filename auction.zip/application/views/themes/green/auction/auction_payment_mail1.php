<?php defined('SYSPATH') OR die('No direct access allowed.');?>
<?php foreach($this->transaction_details as $tran){
	if(file_exists(DOCROOT.'images/auction/220_160/'.$tran->deal_key.'_1'.'.png')) {
		$image = PATH.'images/auction/220_160/'.$tran->deal_key.'_1'.'.png';
	} else {
		$image = PATH."themes/".THEME_NAME."/images/noimage_deals_details.png";
	}
	$end_time = $tran->end_time+(AUCTION_ALERT_DAY*24*60*60);
	$message = "<p style='color:red;'>Congratulations,".$tran->firstname."!</p><p style='color:red;'>You've won the auction for:</p><p><img border='0' src='$image' height='160px' width='160px'/></p><p>Auction title : $tran->auction_title</p><p>Bid amount: ".CURRENCY_SYMBOL.$tran->bid_amount."</p><p>Auction close :".date('M d Y, h:i A', $auction->enddate)."</p><p>Payment must be made on or before : ".date('M d Y, h:i A', $end_time)."</p><p><a href='".PATH.'auction/buy_auction/'.base64_encode($auction->deal_id).'/'.base64_encode($tran->user_id).'/'.base64_encode($tran->bid_amount).'/'.base64_encode($tran->bid_id)."' style='decoration:none;'><input type='button' value='pay now'></p></a>";  ?>
<!DOCTYPE html>
<html lang="en" class="demo-1">
    <head>
        <meta charset="UTF-8" />
        <title>Acution Buy Mail Template</title>
    </head>
    <body>
        <table cellspacing="0" cellpadding="0" border="0" width="700" style=" background:#fff; width:700px; border:  1px solid #ccc;">
            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0" style=" width:680px; margin:0 0 0 9px;">
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" >
                                    <tr>				
                                        <td style=" width:544px;margin:0px; padding:0px; height:2px;">
                                            <div style="width:116px; margin:0px; padding:0px;  height:2px;">&nbsp;</div>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0">
                                    <tr style="height:16px;"></tr>
                                    <tr>
                                        <td style="margin:0px; padding:0px; width: 497px; vertical-align: top; ">
                                            <a href="#" title=""><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png" border="0" alt="" /></a>
                                        </td>
                                        <td style="vertical-align: top; width: 183px;">
                                            <table>
                                                <tr>
                                                    <td style=" vertical-align: top;  width: 183px; text-align: right;font:  normal 12px arial; color: #333; padding: 0px; margin: 0px;"><?php echo date('F d,Y l');?></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="#" title="Facebook" style=" padding: 0 0 0 83px;"><img src="images/facebook.png"  border="0" alt="Facebook"/></a>
                                                        <a href="#" title="Twitter"><img src="images/twitter.png"  border="0" alt="twitter"/></a>
                                                        <a href="#" title="linked In"><img src="images/linked_in.png"  border="0" alt="linked_in"/></a>
                                                        <a href="#" title="Google+"><img src="images/goog1.png"  border="0" alt="Google+"/></a>
                                                        <a href="#" title="Rss"><img src="images/rss.png"  border="0" alt="Rss"/></a>
                                                    </td>
                                                </tr>
                                                <tr height="10"></tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0"  style="width:680px;    border: 1px solid #ECE9E4; background:#fff;">
                                    <tr height="10"></tr>
                                    <tr height="5"></tr>
                                    <td width="8"></td>
                                    <td>
                                        <table>
                                            <tr>
                                                <td style="width: 401px; vertical-align: top;">
                                                    <table>
                                                        <tr>
                                                            <td style="vertical-align: top;"> <p style=" font:  bold 23px/25px arial; color: #0099cc; margin: 0px; padding: 0px;">Congratulations, <?php echo $tran->firstname; ?></p>
                                                                <p style="font:  normal 18px arial; color: #0099cc; margin: 0px; padding: 0px;"> You've won the auction for</p>
                                                            </td>                   
                                                        </tr>
                                                        <tr>
                                                            <td> 
                                                                <table>
                                                                    <tr height="10"></tr>
                                                                    <tr>
                                                                        <td  style="width:282px">
                                                                            <img src="<?php echo $image; ?>" style="width:282px; height:195px; float:left; border:1px solid #ECE9E4;" border="0" alt="View This Deals" />
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td  style=" vertical-align: top;">
                                                                            <table cellpadding="0" cellspacing="0" border="0">
                                                                                <tr>
                                                                                    <td style="width:195px;">
                                                                                        <p style=" font:  bold 16px/19px arial; color: #666; margin: 0px; padding: 0px;"><?php echo $tran->auction_title; ?></p>
                                                                                    </td>
                                                                                    <td>
                                                                                        <a style=" font:  bold 12px arial; background: #82BF40;  color: #fff; margin: 0px; margin-left:10px;padding:4px 11px 5px 12px; text-decoration: none;" href="<?php echo PATH.'auction/buy_auction/'.base64_encode($tran->auction_id).'/'.base64_encode($tran->user_id).'/'.base64_encode($tran->bid_amount).'/'.base64_encode($tran->bid_id); ?>" title="Buy Now">Buy Now</a>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>                   
                                                        </tr>
                                                    </table>
                                                </td>
                                                <td width="15"></td>
                                                <td style="width: 236px; vertical-align: top;">
                                                    <table>
                                                        <tr>
                                                            <td style="width: 230px;  vertical-align: top;">
                                                                <a href="#" title="You're a Winner" style=" width:100%;font:  bold 24px/23px arial; color: #fff; background: #0099cc; margin: 0px; padding: 6px 24px 8px 20px; text-align: center; text-decoration: none;">You're a Winner</a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 224px; vertical-align: top;">
                                                                <p  style=" font:  bold 14px/18px arial;  padding-top: 10px;color: #666;  margin: 0px;  text-align: center; text-decoration: none;">Payment must be made on or before</p>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 224px; vertical-align: top;">
                                                                <p  style=" font:  bold 16px arial;  padding-top: 10px;color: #99cc33;  margin: 0px;  text-align: center; text-decoration: none;"><?php echo date('M d Y, h:i A', $end_time); ?></p>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 224px; vertical-align: top;">
                                                                <p  style=" font:  bold 13px/17px arial;  padding-top: 10px;color: #666;  margin: 0px;  text-align: center; text-decoration: none;">or this order automatically cancels                                                                    and the product is placed back
                                                                    <br/>into inventory</p>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 224px; vertical-align: top;">
                                                                <p  style=" font:  normal 12px arial;  padding-top: 10px;color: #666;  margin: 0px;  text-align: center; text-decoration: none;">Non-payment of auctions you have won on
                                                                    <?php echo SITENAME; ?> also cancels out any other
                                                                    current bids you may have placed
                                                                    <br/>into inventory</p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr height="15"></tr>
                                        </table>
                                    </td>
                                    <td width="7"></td>
								</tr>
								<tr>
									<td width="8"></td>
									<td>
										<table>
											<tr>
												<td style=" width: 314px; border:  1px solid #ccc; padding: 3px;">
													<table>
														<tr>
															<td style=" vertical-align: top; font: bold 13px arial; color: #0099cc;">Auction Details</td>
														</tr>
														<tr>
															<td style=" vertical-align: top; ">
																<table>
																	<tr>
																		<td style=" vertical-align: top; font: bold 15px arial; color: #666;">Winning Bid Price  :  </td>
																		<td style=" vertical-align: top; font: bold 15px arial; color: #666;"> <?php echo CURRENCY_SYMBOL.$tran->bid_amount; ?></td>
																	</tr>
																	<tr height="2"></tr>
																	<tr>
																		<td style=" vertical-align: top; font: bold 15px arial; color: #666;">Auction Close  :         </td>
																		<td style=" vertical-align: top; font: bold 15px arial; color: #666;">  <?php echo date('M d Y, h:i A', $auction->enddate); ?></td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
												<td width="7"></td>
											</tr>
										</table>
									</td>
									<td width="7"></td>
								</tr>
								<tr height="7"></tr>
								<tr>
									<td width="8"></td>
									<td style=" vertical-align: top; text-align: right; padding-bottom: 10px; padding-top: 6px;">
										<table>
											<tr>
												<td width="10"></td>
												<td>
													<p style="font: normal 12px arial; text-align: center; color: #666; margin: 0px; ">You have won this auction and committed to pay the winning bid amount. Once payment is received, your 
														product will be shipped and you receive a shipping confirmation email. </p>   
												</td>
												<td width="10"></td> 
											</tr>
											<tr height="7"></tr>
											<tr>
												<td width="10"></td>
												<td>
													<p style="font: normal 12px arial; text-align: center; color: #666;margin: 0px;  ">To review your shipping information, log into yourM <a style="font: bold 12px arial; text-align: center; color: #000; " href="<?php echo PATH;?>users/my-coupons.html" title="My page"> My page.</a> </p>   
												</td>
												<td width="10"></td> 
											</tr>
											<tr height="7"></tr>
										</table>
									</td>
									<td width="7"></td>
								</tr>
							</table>
						</td>
					</tr>

				</td>
			</tr>
			<tr>
				<td>
					<p  style="width:660px; margin:0px; padding: 21px 0 0 0px; font: normal 12px arial;  color:#333; text-align:center;">You are receiving this message because you signed up with the email address<a  style=" color: #0066cc;" href="" title="<?php echo $tran->email; ?>"> <?php echo $tran->email; ?></a>
						<br/>Please add <a  style=" color: #007bd9;"href="#" title="mail@unicommerce.com">mail@unicommerce.com</a> to your safe senders list so your WagJag messages don't end up in your 
						Junk box.
					</p>
				</td>
			</tr>
			<tr height="20"></tr>
			<tr>
				<td>
					<p style=" font:  normal 13px arial; color: #007bd9; text-align: center; padding:0; margin:0;"> Unsubscribe form Daily Deals  | <a  style=" color: #0066cc;"href="#" title="Privacy Police">Privacy Police</a></p>
				</td>
			</tr>
			<tr height="20"></tr>
			<tr>
				<td>
					<p style=" font:  normal 13px arial; color: #333; text-align: center; padding:0; margin:0; "> Copyright lojgodvdfi,2013 | 590 King St W | Coimbatore , NO | M5V1M3</p>
				</td>
			</tr>
			<tr>
				<td>
					<table cellspacing="0" cellpadding="0" border="0">
						<tr style="height:14px;"></tr>

					</table>
				</td>
			</tr>
		</table>
		<tr style=" height:30px"></tr>	
	</table>
	<tr>
		<td width="20"></td>
		<td width="660">

		</td>
		<td width="20"></td>

	</tr>
</body>
</html>
<?php } ?>
