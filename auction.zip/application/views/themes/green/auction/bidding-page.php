<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
		$('#fade').css({'filter' : 'alpha(opacity=100)'}).fadeIn();
		$('#fade').css({'visibility' : 'visible'});
	});
</script>
<style>
#fade { background: #000; position: fixed; left: 0; top: 0; width: 100%; height: 100%; opacity: 1.0; z-index: 9999; }
.bidding_auction { float: left;position: fixed; width:75%;  z-index: 99999; background: white;clear:both;top:42px; left:155px; padding: 12px; }
</style>
<div class="bidding_auction" >
	<!--QTY header start-->
        <div class="header_outer">
            <div class="qty_header_top_inner">
                <div class="logo">
                    <h1>
                        <a href="<?php echo PATH;?>" title="logo"><img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png" /></a>
                    </h1>
                </div>
            </div>
        </div> 
	<!--QTY header end-->
<!--QTY CONTENT start-->
	<form method="post" name="success" action="<?php echo PATH;?>auction/success_bidding" >
        <div class="contianer_outer1">
            <div class="contianer_inner">
                <div class="contianer">
                    <div class="qty_content_outer">
                        <div class="qty_heading">
							<input type="hidden" id="new_bid" name="bid_value" value="<?php echo $this->current_bid_value; ?>" >
							<input type="hidden"  name="bid_deal_id" value="<?php echo $this->deal_id; ?>" >
							<input type="hidden"  name="bid_deal_key" value="<?php echo $this->deal_key; ?>" >
							<input type="hidden"  name="bid_title" value="<?php echo $this->bid_title; ?>" >
							<input type="hidden"  name="bid_url_title" value="<?php echo $this->url_title; ?>" >
							<input type="hidden" name="shipping_amount" value="<?php echo $this->shipping_amount; ?>" >
							<input type="hidden" name="end_time" value="<?php echo $this->end_time; ?>" >
                            <h2><?php echo $this->bid_title; ?></h2>
                            <p>Bid Amount: <?php echo CURRENCY_SYMBOL.$this->current_bid_value; ?></p>
                        </div>
                        <div class="qty_content">
                            <div class="qty_content_left">
									<?php if(file_exists(DOCROOT.'images/auction/220_160/'.$this->deal_key.'_1'.'.png')) {
								$image = PATH.'images/auction/220_160/'.$this->deal_key.'_1'.'.png';
							} else {
								$image = PATH."themes/".THEME_NAME."/images/noimage_deals_details.png";
							} ?>
                                <a href="" title="bid_image">
                                    <img src="<?php echo $image; ?>" alt="bid_image"/>
                                </a>
                            </div>
                            <div class="qty_content_right">
                                <div class="qty_top_box">
                                    <h3>Bid Summary</h3>
                                    <ul>
                                       <?php /* <li>
                                            <div class="bs_row">
                                                <div class="bs_row_left">
                                                    <p>Auction Amount:</p>
                                                </div>
                                                <div class="bs_row_right">
                                                    <p>2@$45/ea.</p>
                                                </div>
                                            </div>
                                        </li> */ ?>
                                        <li>
                                            <div class="bs_row">
                                                <div class="bs_row_left">
                                                    <p>Your Bid Amount:</p>
                                                </div>
                                                <div class="bs_row_right">
                                                    <p><?php echo CURRENCY_SYMBOL.$this->current_bid_value; ?></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="bs_row">
                                                <div class="bs_row_left">
                                                    <p>Shipping Amount:</p>
                                                </div>
                                                <div class="bs_row_right">
                                                    <p><?php echo CURRENCY_SYMBOL.$this->shipping_amount; ?></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="bs_row">
                                                <div class="bs_row_left">
                                                    <b>Total:</b>
                                                </div>
                                                <div class="bs_row_right">
                                                    <p class="row_price"><?php echo CURRENCY_SYMBOL.($this->current_bid_value + $this->shipping_amount); ?></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="bs_row_gren_now">
                                            <div class="bs_row_2">
                                                <div class="bs_row_right">
                                                     <div class="gren_left">
                                                           <div class="gren_right">
                                                                 <div class="gren_mid"><input type="submit" value="place a bid"></div> 
                                                           </div>
                                                    </div>		
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="qty_footer_list">
                        <ul>
                            <li>If no alternative information is provided within 24 hours of the auction closing the winning bidder's default credit card and billing address will be used to ship the winnings.</li>
                            <li>Your credit card will NOT be charged until the auction ends and we will only charge the minimum amount needed to win.</li>
                            <li>A 3% transaction fee with $1.99 minimum and a $9.99 maximum will be added per order if you win.</li>
                            <li>If your order is cancelled due to a credit card decline, a $25 fee will be assessed.</li>
                            <li>Applicable sales tax will be added to Illinois &amp; Tennessee orders.</li>
                            <li>By bidding I agree with the User Agreement, Privacy Policy, Return Policy &amp; Bidding Rules.</li>
                        </ul>  
                    </div>
                </div>
            </div>
        </div>
	</form>
<!--QTY CONTENT ends-->
</div>


