<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('a.cart_button_1').live("click", function(e){
            var offset  = 0;
            offset = document.getElementById('offset').value;
            var record = document.getElementById('record').value;
            var record1 = document.getElementById('record1').value;
	    
            var url = Path+'auction/today_auction_1?offset='+offset+'&record='+record;

            $.post(url,function(check){ 


                if(check){ 
				  
                    $('.auction').append(check);
                    $('#loading').show();
                    offset = parseInt(offset)+4;

                    $("#offset").val(offset);

                    if(offset >= record1 ) {

                        $('#loading').hide();

                    }

                }
            });     
        
        });
    });

</script>
</div>
</div>
</div>
<!--end-->
<div class="contianer_outer">
    <div class="contianer_inner">
        <div class="bread_crumb">
            <ul>
				<li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
				<li><p>
						<?php if (($this->uri->last_segment() != "auction.html") && ($this->uri->last_segment() != "search.html")) { ?>
							<a href="<?php echo PATH; ?>auction.html" title="<?php echo $this->Lang['AUCTION']; ?>"><?php echo $this->Lang["AUCTION"]; ?></a>
					</p>
						<?php } else {
								echo $this->Lang['AUCTION'];
							} ?>
				</li>
				<?php if (($this->uri->last_segment() != "auction.html") && ($this->uri->segment(2) != "page")) { ?>
						<li class="bread_crum_about">
							<?php if(isset($this->sub_cat)) { ?>
								<p><a href="<?php echo PATH; ?>auction-category/main/<?php echo strtolower($this->category_name);?>.html"><?php echo $this->category_name; ?></a>&nbsp;&nbsp;&nbsp;<?php echo $this->sub_cat; ?></p>
							<?php } else { ?>
								<p>  <?php echo $this->category_name; ?></p>
							<?php } ?>
						</li>
					<?php } ?>
            </ul>
        </div>
        <?php if (count($this->all_deals_list) > 0) { ?>                     
            <div class="contianer">
                <!--content start-->
                <div class="content">
                        <!--sidebar start-->
                        <div class="conntent_left">
                            <div class="cat_outer1">
                                <div class="category2">
                                    <form action="" method="get" name="form1"  >
                                    <h1>Categories</h1>
                                    <ul>
                                        <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
                                        $cat1 = array_unique($cat);		?>
										<?php foreach ($this->category_list as $d) {
											if ($d->auction == 1) { ?>
												<li>
													<span class="cate_check">
													<?php $type="auction"; $categories=$d->category_url; ?>
													<a style="cursor:pointer;" class="sample" id="sample-<?php echo $d->category_id; ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>">
														<?php echo ucfirst($d->category_name); ?>
													</a>
													<div class="sub_menu_top1">	
														<span class="white">&nbsp; </span>
														<ul>
															<a style="cursor:pointer;">
																<div id="categeory-<?php echo $d->category_id; ?>">
																	<?php echo new View("themes/" . THEME_NAME . "/auction/sub_categorey_list"); ?>
																</div>
															</a>
														</ul>
													</div>
                                                </li>
											<?php }	
											} ?>
                                    </ul>
									</form>
                                </div>
                                <input type="submit" value="submit" id="submit" style="display:none;">
                                </form>
                            </div>
                            <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample-','');
                                        var url = Path+"auction/today_auction/?cate_id="+getUID;
    	
                                        $.post(url,function(check){
    			
                                            if(getUID!=""){
                                                $('#categeory-'+getUID).html(check);
    				
                                                $('#sample_new-'+getUID).show();
                                                $('#categeory-'+getUID).show();
                                                $('.arrow1-'+getUID).show();
                                                $('#downarow-'+getUID).show();
                                                $('.arrow-'+getUID).hide();

                                            }
                                        });
                                    });
                                });  
                            </script>
                            <div class="cat_outer2" id="s1000">
                                <div class="category" id="f200" style="padding-bottom:10px;">	
                                    <h1>Price</h1>
                                    <div class="catogory_content2 fl clr" id="f300">
                                        <p style="padding-top:4px;font:normal 12px arial; color: 656565;" class="p1">Price bracket</p>
                                        <div id="slider-range"></div></br>
                                        <input type="text" style="float:left;  height:25px;font:normal 12px/25px arial;color:#787878; border:none; background: #fff; text-align: center; border:1px solid #d4d4d4; margin-left: 23px; margin-top:6px;" id="amount_1"  readonly="readonly" name="amount"/>
                                    </div>
                                    <div class="bot_ha">&nbsp;</div>
                                    <div class="catogory_list2 fl clr"></div>
                                </div>
                            </div>
							<div class="ad_bot_rft12">
                                <div class="ora_left_12">
                                    <div class="ora_right_12">
                                        <div class="ora_mid2_312">
											<a href="<?php echo PATH; ?>auction/winner.html" title="<?php echo $this->Lang['SHOP_NW']; ?>"><input type="button" value="winners list" title="winners list" /></a>
										</div>
									</div>
								</div>
							</div>
                            <!--scroll filter start-->
                            <input type="hidden" name="offset" id="offset" value="4">
                            <input type="hidden" name="record" id="record" value="4">
                            <input type="hidden" name="record" id="record1" value="<?php echo $this->all_deals_count; ?>">
                            <!--price and discount script-->
                            <link rel="stylesheet" href="http://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css" />
                            <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
                            <script>
                                $(function() {
                                    $( "#slider-range" ).slider({
                                        range: true,
                                        min: <?php echo $this->deal_min; ?>,
                                        max: <?php echo $this->deal_max; ?>,
                                        values: [ <?php echo $this->deal_min; ?>,<?php echo $this->deal_max; ?> ],
                                        slide: function( event, ui ) {
                                          $( "#amount_1" ).val("<?php echo CURRENCY_SYMBOL; ?>"+ui.values[ 0 ] + " - " +"<?php echo CURRENCY_SYMBOL; ?>"+ ui.values[ 1 ] );
                                            var amount = $("#amount_1").val();
                                            var url = Path+"auction/ajax_post_auctions/?amount="+amount;

                                            $.post(url,function(check){
                                                $('.auction').html(check);
												$('div#loading').hide();
                                            });
                                        },
                                    });
								   $( "#amount_1" ).val("<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 0 ) +
											" - " +"<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 1 ) );
																});
							</script>
                        </div>
                        <!--sidebar end-->
                        <div class="content_right">
                            <!--action deal list-->
                            <div class="product_details_list">
                                <div class="pro_top">
                                    <div class="pro_title"><h2>AUCTION</h2></div>
                                    <!--a class="view_more" href="#" title="VIEW MORE ">VIEW MORE</a-->
                                </div>
                                <div class="pro_mid">
                                    <div class="auction">
										<?php echo new View("themes/" . THEME_NAME . "/auction/listing"); ?>
                                    </div>
									<?php if (($this->uri->last_segment() == "auction.html") && ($this->all_deals_count > 1)) { ?>
                                        <div id="loading">
											<?php if (($this->pagination) != "") { ?> 
                                                <div class="feature_viewmore">
                                                    <div class="fea_view_more">
                                                        <div class="view_more_inne">
                                                            <div class="viewmore_lft"></div>
                                                            <div class="viewmore_midd">
                                                                <a  style="cursor:pointer;" class="cart_button_1" title="See More Auction">-------See More Auction-------</a>
                                                            </div>
                                                            <div class="viewmore_rgt"></div>
                                                        </div>
                                                    </div>
                                                </div>
											<?php } ?>
                                        </div>
									<?php } ?>
                                </div>
                            </div>
                        </div>
					</div>
                <!--end-->
					<?php } else { ?>
						<?php echo new View("themes/" . THEME_NAME . "/subscribe");
					} ?>
			</div>
    </div>
</div>


