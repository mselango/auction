<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript">
	$(document).ready(function(){
	$("body").kkCountDown({
	colorText:'#ED7E2C',
	colorTextDay:'#ED7E2C',
	addClass : 'shadow'
	});
	});
</script>
<script type="text/javascript"> 
        $(document).ready(function(){ 
        $('.auction_listing_gallery').hide();
        $('.auction_listing_listview').hide();  
        });
</script>
<script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery.anythingzoomer.js"></script>
<script type="text/javascript"> 
        function AuctionListing() {
                $('.auction_listing').show();
                $('.auction_listing_gallery').hide();
                $('.auction_listing_listview').hide();
        }
        function AuctionListingGallery() {
                $('.auction_listing').hide();
                $('.auction_listing_gallery').show();
                $('.auction_listing_listview').hide();
        }
        function AuctionListingListview() {
                $('.auction_listing').hide();
                $('.auction_listing_gallery').hide();
                $('.auction_listing_listview').show();
        }
        
        $(function() {
		$(".zoom").anythingZoomer({
			overlay : true,
			edit: true,

			offsetX : 0,
			offsetY : 0
		});

		$('.president')
		.bind('click', function(){
			return false;
		})
		.bind('mouseover click', function(){
			var loc = $(this).attr('rel');
			if (loc && loc.indexOf(',') > 0) {
				loc = loc.split(',');
				$('.zoom').anythingZoomer( loc[0], loc[1] );
			}
			return false;
		});

	});
       
</script>
       <?php if(count($this->all_deals_list)>0){ ?>    
                    <?php foreach( $this->all_deals_list as $deals){ 
                    $symbol = CURRENCY_SYMBOL; 
                    $time = ($deals->enddate-time());
                    ?>
                    <?php if(888483 > $time ) { $closetime = $time*1000; ?>
                    <script type="text/javascript">     
                    $(document).ready(function(){                        
                        setTimeout(function() {
                        $('#deallisting<?php echo $deals->deal_id; ?>').fadeOut('fast');
                        }, parseInt(<?php echo $closetime; ?>) );  
                        setTimeout(function() {
                        $('#deallistinggallery<?php echo $deals->deal_id; ?>').fadeOut('fast');
                        }, parseInt(<?php echo $closetime; ?>) ); 
                        setTimeout(function() {
                        $('#deallistinglistview<?php echo $deals->deal_id; ?>').fadeOut('fast');
                        }, parseInt(<?php echo $closetime; ?>) ); 
                        
                        setTimeout(callback, parseInt(<?php echo $closetime; ?>));
                        function callback()
                        {
                        }                                                
                    });
                    </script>
                    <?php } ?>      
<div class="auction_list">
	<div class="action_img">
		<div class="act_img_top"></div>
			<div class="act_img_mid">
				<?php if($this->session->get('cate')!="") { ?> <?php $url=$this->session->get('cate'); ?> <?php } else { ?> <?php $url=$deals->category_url; ?>  <?php } ?>
					<?php if(file_exists(DOCROOT.'images/category/icon/'.$url.'.png')){ ?>
						<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH.'images/category/icon/'.$url.'.png'; ?>" title="<?php echo $url; ?>"></span>
					<?php } else { ?>
						<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png" title="<?php echo $url; ?>"/></span>
					<?php } ?>
					<?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
						<a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png';?>"  alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" border="0" /></a>
					<?php } else { ?>
						<a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_auctions_list.png"  alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" border="0" /></a>
					<?php }?>
                         </div>
                                            <div class="act_img_bot"></div>

                                        </div>
                                        <div class="action_rgt">
                                            <p><a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title;?>"><?php echo substr(ucfirst($deals->deal_title),0,25).'...';?></a></p>
                                                
                                            <div class="bid_cont">
											                                           
							                       <?php $q=0; foreach($this->all_payment_list as $payment){ ?>
													<?php if($payment->auction_id==$deals->deal_id){ 
															$firstname = $payment->firstname;
															$transaction_time = $payment->transaction_date;
															$q=1;
													}     } ?>
												  <?php if($q==1){ ?>
														
                                                <div class="bid_value">					
												  <label>  Last Bidder :</label>
													 <span><?php echo substr(ucfirst($firstname),0,10).'...'; ?></span>
												   </div>
												 <div class="bid_value">					
													<label> Bid:</label>
														<span> <?php echo date("d-m-Y ",$transaction_time); ?> 
														
													</div>
													
                    
                    <?php } ?>
                      <?php if($q==0){ ?>
                     <div class="bid_value">  
                 
                    

                <label>  Last Bidder :</label>
                 <span> Not Yet Bid</span>
                 </div>
                <div class="bid_value">    
                <label>  Close Time:</label>
                     <span><?php echo date("d-m-Y",$deals->enddate); ?></span>
                    </div>	
                    <?php } ?>
												<div class="bid_value3">
													<label>Time Left  :</label>
                                                    <span time="<?php echo $deals->enddate; ?>" class="kkcount-down">
                                                     
                                                        </span>
                                                </div>
                                           

                                            </div>

                                            <div class="act_bid_values">                                        
                                                <div class="view_deals">
                                                <div class="view_lft">
                                                    <div class="view_rgt">
                                                        <div class="view_mid">
                                                            <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                             </div>
                                        </div>
                                    </div>
<?php }?>
        <?php }else { ?>

 
<p>Nodata Found</p>
<?php } ?>

      
        

