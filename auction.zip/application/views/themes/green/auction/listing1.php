<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="auction_listing">   
                    <?php if(count($this->all_deals_list)>0){ ?>
                    <div class="all_deals_rgt_action">                    
                    <div class="deals_list_new">
                    <?php foreach( $this->all_deals_list as $deals){
                    $symbol = CURRENCY_SYMBOL; 
                    ?>
                    <div class="deal_list_action">
                    <div class="deal_list_top_action"><p><?php echo $deals->deal_title; ?></p></div>
                    <div class="deal_list_mid_action">
                    <div class="list_top_det_rolli">
                    <?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
                    <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png';?>" width="220" height="160" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>
                    <?php } else { ?>
                    <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" width="220" height="160" alt="<?php echo $deals->deal_title; ?>"   title="<?php echo $deals->deal_title; ?>" width="165px" height="114px" ></a>

                    <?php }?> 
                    <div class="deal_offer2">
                    <div class="buttons">
                    <a class="buy_now" href="#" title="buy now">Bid NOW</a>
                    <span class="cost ml10"><?php echo $symbol." ".$deals->deal_value; ?></span>
                    </div>
                    </div>
                    <div class="bid_me_cont">
                    <div class="bid_me_inner">
                    <span class="right">Highest Bidder</span><span class="dot2">:</span>
                    <span class="contr">Nandhakumar</span>
                    </div>
                    <div class="bid_me_inner2">
                    <span class="right">Bids</span><span class="dot3">:</span>
                    <span class="contr">$0.1</span>
                    </div>
                    </div>	
                    </div>
                    </div>
                    <div class="deal_list_bot_action">
                    <div class="bid_me_inner_aero">
                    <a href="#" title="More Info"> More Info</a>
                    <label><a href="#" title="More Info"> +  Add to Wishlist</a></label>
                    </div>
                    <div class="time_left_1">
                    <h4><?php echo $this->Lang['TIME_LEFT']; ?></h4>
                    <span time="<?php echo $deals->enddate; ?>" class="kkcount-down" ></span>
                    </div>
                    </div>
                    </div>
                    <?php }   ?>
                    </div>                    
                    </div>
                    <?php }   ?>
                    </div>
                   </div>  
              <div class="auction_listing_gallery" style="display:none">           
            <?php if(count($this->all_deals_list)>0){ ?>
            <div class="all_deals_rgt">
            <div class="listing_imagess_in_top">
            <?php foreach( $this->all_deals_list as $deals){
            $symbol = CURRENCY_SYMBOL; ?>
            <div class="img_common_left">
            <div class="img_top_1"></div>
            <div class="img_mid">
            <div class="immgaes_over_top ">
            <div class="hover_link_top">
            <div class="test5">
            <p><?php echo $deals->deal_title; ?></p>
            <label><?php echo substr($deals->deal_description,0,150)."..";?></label>
            </div>
            <div class="new_buttons_3">
            <div class="new_buy_now"><a href="#" title="buy now">Buy NOW</a></div>
            <div class="new_cost"><?php echo $symbol." ".$deals->deal_value; ?></div>
            </div>
            </div>
            <?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
            <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png';?>" width="220" height="160" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>
            <?php } else { ?>
            <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" width="220" height="160" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" width="165px" height="114px" ></a>
            <?php }?> 
            </div>
            </div>
            <div class="img_bot"></div>
            </div>
            <?php }   ?>
            </div>
            </div>
            <?php }   ?>
            </div>   
              
            <div class="auction_listing_listview" style="display:none">   
            <?php if(count($this->all_deals_list)>0){ ?>
            <div class="all_deals_rgt">			
            <div class="deal_list_view">				
            <?php foreach( $this->all_deals_list as $deals){
            $symbol = CURRENCY_SYMBOL; ?>
            <div class="deal_list_view_top"></div>
            <div class="deal_list_view_mid">
            <div class="new_deal_image">
            <?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
            <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png';?>" width="220" height="160" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>
            <?php } else { ?>
            <a href="<?php echo PATH.'auction/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" width="220" height="160" alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" width="165px" height="114px" ></a>
            <?php }?> 
            </div>
            <div class="new_deal_rgt_det">
            <div class="new_deal_offer_1">
            <div class="new_deal_detail_1">
            <a href="#" title="<?php echo $deals->deal_title; ?>"><?php echo $deals->deal_title; ?></a>
            <p><?php echo substr($deals->deal_description,0,350)."..";?></p>
            </div>
            <div class="new_buttons_1">
            <div class="new_buy_now"><a href="#" title="buy now">Buy NOW</a></div>
            <div class="new_cost"><?php echo $symbol." ".$deals->deal_value; ?></div>
            </div>
            </div>
            <div class="new_list_bot_det">
            <div class="new_bidder_list">
            <div class="bidder_section">
            <span class="bidder_high">Highest Bidder </span>
            <span class="fl">:</span>
            <span class="bidder_name">Nandhakumar</span>
            </div>
            <div>
            <span class="bidder_high">Bids</span>
            <span class="fl">:</span>
            <span class="bidder_name">$0.1</span>
            </div>
            </div>
            <div class="time_left_1">
            <h4><?php echo $this->Lang['TIME_LEFT']; ?></h4>
            <span time="<?php echo $deals->enddate; ?>" class="kkcount-down" ></span>
            </div>
            </div>
            </div>
            </div>
            <div class="deal_list_view_bot"></div>	
            <?php }   ?>
            </div>
            </div>
            <?php }   ?>
            
            
		     
		   </div>   
