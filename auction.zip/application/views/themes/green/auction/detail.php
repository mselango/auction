<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/zoom.css" media="all">
<script type="text/javascript"> 
	$(document).ready(function() { 
		Rocket.SizeChart.rows = [{"CHEST (INCH)":"38","SHOULDER(INCH)":"16","LENGTH(INCH)":"27"},{"CHEST (INCH)":"40","SHOULDER(INCH)":"17","LENGTH(INCH)":"28"},{"CHEST (INCH)":"42.5","SHOULDER(INCH)":"18","LENGTH(INCH)":"29"},{"CHEST (INCH)":"45","SHOULDER(INCH)":"19","LENGTH(INCH)":"30"},{"CHEST (INCH)":"47","SHOULDER(INCH)":"19","LENGTH(INCH)":"31"},{"CHEST (INCH)":"49","SHOULDER(INCH)":"20","LENGTH(INCH)":"32"}];
		Rocket.SizeChart.columns = ["CHEST (INCH)","SHOULDER(INCH)","LENGTH(INCH)"];
		Rocket.SizeChart.conversionHoverActive = false;
		Rocket.SizeChart.preparePopup(false);
		// stop highlight animation if user overs list item
		$('#listProductSizes > li').bind('mouseover', function() {
			$(this).stop(false, true);
		});
		$(document).bind("Quicklist.productRemoved", function (e, sku) {
			//We are on the detail page of the product we just removed from quicklist
			//Enable the add to quicklist link
			if ($('#configSku').val() == sku) {
				$('#qlPrdAdded').hide();
				$('#qlPrdAdd').show();
			}
		});$('.tool-tip').hover(function() {
			var tipId = $(this).attr('label');
			var pos = $(this).position();
			$('#' + tipId).css({'top':(pos.top + 10), 'left': (pos.left + 10)});
			$('#' + tipId + ' span').css('background-color', '#fff' );
			$("#" + tipId).fadeIn(200);
		}, function() {
			var tipId = $(this).attr('label');
			$("#" + tipId).fadeOut(200);
		});

		globalConfig.product = globalConfig.product || {};
		globalConfig.product.rDetails = {"sku":"UN573MA91PPSINDFAS","chain":"3270|3328|3329|3330","brand":"United Colors of Benetton","brandId":"573","price":799,"sessionId":"qonohdq1sn843pl0afp0biklg3","userId":"","catId":"3270","cat":"Clothing","brickId":"3330","brick":"Crew Neck T-Shirts"};

		Jabong.image.initSetImage();
		$( '#prdZoomImgPrev' ).live( 'click', function() { Jabong.image.imgNavigate( 'prev' ) } );
		$( '#prdZoomImgNext' ).live( 'click', function() { Jabong.image.imgNavigate( 'next' ) } );

		if(window.location.hash == "#productReviews") {
			$("#productReviewsTab").trigger('click');
		}

		$('#recommSliderSolr').bxSlider({
			mode: 'vertical',
			auto: false,
			displaySlideQty: 3,
			moveSlideQty: 1,
			speed: 250
		});

		Rocket.QuickList.loadList([], []);
	});
</script>
	<script type="text/javascript">$('.prd-more-images-slider').jCarouselLite({
	btnNext: ".next",
	btnPrev: ".prev",
	circular: false,
	visible: 5
	});        $('#prd-imageBox-container').bind('mouseenter', function() {
	$('.prd-zoom-info').hide();
	});
	$('#prd-imageBox-container').bind('mouseleave', function() {
	$('.prd-zoom-info').show();
	});
	var reviewFieldMsg = "You must fill the empty field(s) highlighted above.";
	var reviewSuccessMsg = "Thank you. Your review will start appearing soon.";
	var reviewErrorMsg = "There has been an error saving your rating. Please try again.";
	//<![CDATA[
	jQuery.ajax({
	type: "GET",
	url: "//ndot.in",
	success: function(data){
		new RecommendationView(data, 4);
	}
	});
	//]]></script>  
	<script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jquery-1.5.js"></script> 
	<script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jquery.jcarousel.min.js "></script> 
	<script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/easySlider1.7.js"></script> 
	<script src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/zoom.js" type="text/javascript"></script>
	<script type="text/javascript"> 
		var aliceImageHost = 'http://ndot.in';
		var globalConfig = {};     
	</script>	
<?php
foreach ($this->deals_deatils as $deals) {
    $symbol = CURRENCY_SYMBOL;
    ?>

					<script>
						setInterval(function()
						{ 
							var url ="<?php echo PATH; ?>auction/bid_history/<?php echo $deals->deal_id; ?>";
							$.post(url,function(check){ 
									 $("div#show_bid_history").html(check);								  
							});
							}, 1000);//time in milliseconds 
					</script>
					<script>
						setInterval(function()
						{ 
							var url ="<?php echo PATH; ?>auction/bid_history_amount/<?php echo $deals->deal_key; ?>/<?php echo $deals->url_title; ?>";
							$.post(url,function(check){ 
									var check1=check.split('--'); 
									 $('input[name="bid_deal_value"]').val(check1[0]);		
									 $('span.bidamountval').html(check1[0]);	
									 $('span.bidamountval1').html("( <?php echo $symbol." ";?> "+check1[0]+" or More )");
									if(check1[1]==0){
									$("p a#auction").removeAttr("href");
									$("p a#auction").text('Sold Out');
									}
							});
							}, 1000);//time in milliseconds 
					</script>
    </div> <!--for header -->
</div>
</div>
<div class="contianer_outer1">
	<div class="contianer_inner">
		<div class="bread_crumb">
			<ul>
				 <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
				 <li><p><a href="<?php echo PATH; ?>auction.html" title="Auction"><?php echo 'Auction'; ?></a></p></li>
				 <li><p><?php echo ucfirst($deals->deal_title); ?></p></li>
			</ul>
		</div>
		<div class="contianer">
         <!--content start-->
			<div class="content_abouts">
				<div class="ad_left">
					<div class="all_deal_top_left" style="padding:0px; margin:0px; width:365px;">
						<div id="prdMedia" class="prd-media">
							<?php if (file_exists(DOCROOT . 'images/auction/1000_700/' . $deals->deal_key . '_1' . '.png')) { ?>
								<div id="productZoom" style="background-image: url(&quot;<?php echo PATH . 'images/auction/1000_800/' . $deals->deal_key . '_1.png'; ?>&quot;); background-position: 0px -499.56px; opacity: 1; display: none;background-repeat:no-repeat;height:400px; width:620px;" data-zoom-image="<?php echo PATH . 'images/auction/1000_800/' . $deals->deal_key . '_1.png'; ?>"></div>
									<div id="prd-imageBox-container" class="prd-imageBoxLayout ">
                                        <a href="" class="prd-imageBox" id="prdZoomBox">
											<?php if ($deals->winner != 0 && $deals->auction_status = 1) { ?>
                                                <div class="should_out_images">
                                                    &nbsp;
                                                </div>
											<?php } ?>
                                            <span rel="foaf:depiction">
                                                <img class="prd-image" id="prdImage" data-js-function="setPlaceholderOnError" title="<?php echo $deals->deal_title; ?>" alt="<?php echo $deals->deal_title; ?>" src="<?php echo PATH . 'images/auction/1000_700/' . $deals->deal_key . '_1.png'; ?>"  width="355">
                                            </span>
                                            <div style="top: 181px; left: 0px; display: none;" id="magnifier"></div>
                                        </a>
                                    </div>
									<?php } else { ?>
                                    <div id="productZoom" style="background-image: url(&quot;<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png&quot;); background-position: 0px -499.56px; opacity: 1; display: none;background-repeat:no-repeat;height:400px; width:355px;" data-zoom-image="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png"></div>
									<div id="prd-imageBox-container" class="prd-imageBoxLayout ">
                                        <a href="" class="prd-imageBox" id="prdZoomBox">
											 <?php if ($deals->winner != 0 && $deals->auction_status = 1) { ?>
                                                <div class="should_out_images">
                                                    &nbsp;
                                                </div>
											<?php } ?>
                                            <span rel="foaf:depiction">
                                                <img class="prd-image" id="prdImage" data-js-function="setPlaceholderOnError" title="<?php echo $deals->deal_title; ?>" alt="<?php echo $deals->deal_title; ?>" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png" height="380" width="355">
                                            </span>
                                            <div style="top: 181px; left: 0px; display: none;" id="magnifier"></div>
                                        </a>
									</div>
									<?php } ?>
									<h2 class="s-visuallyhidden">More Images</h2>
									<div class="prd-more-images-slider-container">
                                    <div class="prd-more-images-slider lfloat">
                                        <ul id="productMoreImagesList" class="prd-moreImagesList ui-listItemBorder ui-listLight clearfix">
											<?php for ($i = 1; $i <= 5; $i++) { ?>
												<?php if (file_exists(DOCROOT . 'images/auction/1000_700/' . $deals->deal_key . '_'.$i . '.png')) { ?>
                                                    <li class="lfloat ui-border selected"
                                                        data-js-function="setImage"
                                                        data-image-product="<?php echo PATH . 'images/auction/1000_700/' . $deals->deal_key . '_' . $i . '.png'; ?>"
                                                        data-image-big="<?php echo PATH . 'images/auction/1000_800/' . $deals->deal_key . '_' . $i . '.png'; ?>">
                                                        <img data-js-function="setPlaceholderOnError"
                                                             data-placeholder="<?php echo PATH . 'images/auction/1000_800/' . $deals->deal_key . '_' . $i . '.png'; ?>"
                                                             id="gal<?php echo $i; ?>"
                                                             width="37"
                                                             height="54"
                                                             src="<?php echo PATH . 'images/auction/1000_800/' . $deals->deal_key . '_' . $i . '.png'; ?>"
                                                             alt="zoom" />
                                                    </li>
												<?php } else { ?>
											<?php  } ?>  
										<?php } ?>
									</ul>
								</div>
							</div>
						</div>
                        <div class="ad_left_2">
                        <!--ZOMM SLIDER HERE-->
                        </div>
					</div>
					<div class="ad_left_content">
						<div class="bid_his_heading">
							<p>Bid Histories</p>
						</div>
					<script>
						setInterval(function()
						{ 
							var url ="<?php echo PATH; ?>auction/bid_history/<?php echo $deals->deal_id; ?>";
							$.post(url,function(check){ 
									 $("div#show_bid_history").html(check);								  
							});
							}, 1000);//time in milliseconds 
					</script>
						<div id="show_bid_history" > <?php echo new View("themes/".THEME_NAME."/auction/bid_history"); ?></div>
				</div>
			</div>
			<div class="ad_right">
				<div class="detail_page_top_right">
					<div class="hb_bg_mid">
						<ul>
						<?php if (count($this->transaction_details)) { ?>
                            <?php $i = 0;
								$saving = 0;
								foreach ($this->transaction_details as $tran) { ?>
									<?php if ($i == 0) { ?>
										<li><p><?php echo $deals->deal_title; ?></p></li>	
                                        <li><p><span>Lead Bidder :</span> <?php echo ucfirst($tran->firstname); ?> <span style="color:#360"></span></p></li>
									<?php } $i++;
								}
						} else { ?>
                                        <li><p><span>Last Bidder  :</span> Not Yet Bid</p></li>
						<?php } ?>
                                    <li><h3><span time="<?php echo $deals->enddate; ?>" class="kkcount-down" ></span>
                                            <span>Auction Close Time: <?php echo date('d-m-Y h:i:s A', $deals->enddate); ?></span>
                                        </h3>
                                    </li>	
                                    <li>
                                        <div class="hb_buy_now_left">
                                            <div class="hb_place_bid">
                                                <p>Starting Bid<span><?php echo $symbol . " " . $deals->deal_value; ?></span></p>
											</div>
										</div>
                                        <div class="hb_buy_now_right">
                                            <div class="hb_place_bid_button">
                                                <div class="hb_place_bid_button_left">
                                                    <div class="hb_place_bid_button_right">
                                                        <div class="hb_place_bid_button_mid">
															<?php if ($deals->winner != 0 && $deals->auction_status = 1) { ?>
                                                                <p><a id="sold" title="Sold Out" style="cursor:default;">Sold Out</a></p>
															<?php } else { ?>
                                                                <p><a id="auction"  href="javascript:show_auction();"  title="Place my Bid">Place my Bid</a></p>
															<?php } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="enter_more_button">
                                            <div class="view_lft_3">
                                                <div class="view_rgt_3">
                                                    <div class="view_mid_3">
                                                        <a style="text-decoration:none; cursor:default;" title="TO BID ENTER <?php echo $symbol . ' ' . $deals->deal_price; ?>">TO BID ENTER <?php echo $symbol." ";?><span class="bidamountval"><?php echo $deals->deal_price; ?></span> OR MORE.</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    
                                    <li class="hb_li_padding_bottom_none">
                                        <div class="hb_buy_now_left">
                                            <p class="hb_font_weight_normal">Bid Increment</p>
                                        </div>
                                        <div class="hb_buy_now_right">
                                            <p class="hb_font_size_small" style="width:120px;"><?php echo $symbol . " " . $deals->bid_increment; ?></p>
                                        </div>
                                    </li>
                                    <li class="hb_li_padding_bottom_none">
                                        <div class="hb_buy_now_left">
                                            <p class="hb_font_weight_normal">Retail Price</p>
                                        </div>
                                        <div class="hb_buy_now_right">
                                            <p class="hb_font_size_small" style="width:120px;"><?php echo $symbol . " " . $deals->product_value; ?></p>
                                        </div>
                                    </li>
                                    <?php /* <li class="hb_li_padding_bottom_none">
                                      <div class="hb_buy_now_left">
                                      <p class="hb_font_weight_normal">Price Paid</p>
                                      </div>
                                      <div class="hb_buy_now_right">
                                      <p class="hb_font_size_small" style="width:120px;">$12.00</p>
                                      </div>
                                      </li> */ ?>
                                    <li class="border_none">
                                        <div class="li_shareleft">
                                            <p class="save_over_text">Save Over <span><?php $saving = $deals->product_value - $deals->deal_value;
                                    if ($saving < 0) {
                                        echo $symbol . " " . "0";
                                    } else echo $symbol . " " . $saving; ?></span></p>
                                            <h6>For the normal retail price!</h6>
                                        </div>
                                        <div class="li_share_right">
                                            <link href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/jRating.jquery.css" rel="stylesheet" type="text/css"/>
                                            <script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jRating.jquery.js"></script>
                                            <script type="text/javascript">
                                                $(document).ready(function(){
                                                    $(".basic<?php echo $deals->deal_id; ?>").jRating({
                                                        bigStarsPath : '<?php echo PATH; ?>/images/stars_detail.png', // path of the icon stars.png
                                                        smallStarsPath : '<?php echo PATH; ?>/images/small.png', // path of the icon small.png
                                                        phpPath : '<?php echo PATH; ?>auction-rating.html', // path of the php file jRating.php
                                                        length:5,
                                                        rateMax : 10,
                                                        decimalLength:1,
                                                        showRateInfo: false,
											<?php if ((!$this->UserID) || ($deals->enddate < time())) { ?>	
												isDisabled : true			
											<?php } ?>
                                                 });
											});
                                            </script>
                                            <div class="inner_top_over1">
                                                <label>Rating :</label>
                                                <div class="basic<?php echo $deals->deal_id; ?>" id="<?php echo $this->avg_rating; ?>"></div>
                                            </div>
                                            <div class="ad_fb">
                                                <span>Share :</span>
                                                <iframe src="http://www.facebook.com/plugins/like.php?href=<?php echo PATH . 'auction/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?> &amp;layout=button_count&amp;show_faces=true&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden;  height:21px; width:105px;" allowTransparency="true"></iframe>
                                            </div>
                                            <div class="ad_tw">
                                                <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
                                                <a href="http://twitter.com/share" class="twitter-share-button" data-url="<?php echo PATH . 'auction/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" data-count="horizontal"><?php echo $this->Lang['Tweet']; ?></a>
                                            </div>
                                        </div>
                                    </li>	
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="all_deals_bottom">
                    <div class="top_tab">
                        <ul>
                            <li><a title="Auction Details">Auction Details</a></li>
                        </ul>
                    </div>
                    <div class="bot_mid_det">
                        <h2><?php echo $deals->deal_title; ?></h2>
                        <p><?php echo $deals->deal_description; ?></p>
                    </div>
                </div>
                <div class="ad_content2 deal_ad_content2">
					<?php if(strip_tags($deals->highlights) != "") { ?>
                        <div class="ad_content2_left branch_detail1 pro_top">
                            <h2>HIGHLIGHTS</h2>
                            <ul>
                                <li><p><?php echo $deals->highlights; ?></p></li>
                            </ul>
                        </div>
					<?php } ?>
					<?php if(strip_tags($deals->fineprints) != "") { ?>
                        <div class="ad_content2_left_1 branch_detail1 pro_top">
                            <h2>FINE PRINTS</h2>
                            <ul>
                                <li><p><?php echo $deals->fineprints; ?></p></li>
                            </ul>
                        </div>
					<?php } ?>
                </div>
                <div class="ad_content2">
                    <div class="branch_detail1 pro_top ad_details">
                        <h2>PRICE DETAILS</h2>
                        <ul>
                            <li>
                                <div class="ad_detail1">
                                    <p class="ad_detail1_label">Starting Bid From:</p>
                                    <p class="ad_detail1_value"><?php echo $symbol . " " . $deals->deal_value; ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="ad_detail1">
                                    <p class="ad_detail1_label">Auction type(s):</p>
                                    <p class="ad_detail1_value">Reserve Auction</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="branch_detail1 pro_top ad_details">
                        <h2>AUCTION DETAILS</h2>
                        <ul>
                            <li>
                                <div class="ad_detail1">
                                    <p class="ad_detail1_label">Start Time :</p>
                                    <p class="ad_detail1_value"><?php echo date('M d, h:i A', $deals->startdate); ?></p>
                                </div>
                            </li>
							<?php /* <li>
							  <div class="ad_detail1">
							  <p class="ad_detail1_label">Start Time:</p>
							  <p class="ad_detail1_value">Feb 15, 02:16 PM</p>
							  </div>
							  </li> */ ?>
                            <li>
                                <div class="ad_detail1">
                                    <p class="ad_detail1_label">End Time:</p>
                                    <p class="ad_detail1_value"><?php echo date('M d, h:i A', $deals->enddate); ?></p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="branch_detail1 pro_top ad_details border_none">
                        <h2>SHIPPING DETAILS</h2>
                        <ul>
                            <li>
                                <div class="ad_detail1">
                                    <p class="ad_detail1_label">Shipping Fee:</p>
                                    <p class="ad_detail1_value"><?php echo $symbol . " " . $deals->shipping_fee; ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="ad_detail1">
                                    <p class="ad_detail1_label">Shipping Information:</p>
                                    <p class="ad_detail1_value"><?php echo $deals->shipping_info; ?></p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
				<?php /*     * * AUCTION DETAIL POPUP  ** */ ?>

                <form method="POST" name="auction_bid"  onsubmit="return check();"> 
                    <div class="popup_auction" >
                        <div class="place_sign_up">
                            <div class="place_sign_top">
                                <div class="place_sign_bott">
                                    <div class="place_sign_midd">
                                        <a class="place_close_but" href="" id="auction_close" style="cursor:pointer;" title="close"></a>
                                        <div class="place_midd_top">
                                            <a href="<?php echo PATH; ?>" title="Uniecommerce"><img alt="logo" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/logo.png" /></a>
                                        </div>
							<?php if($deals->startdate < time()){ ?>
										<?php if ($this->UserID) { //if($count_user==0){  ?>
                                            <div class="place_midd_bott">
                                                <div class="place_bott_top">
                                                    <h3>Your bid amount is no longer enough to win.</h3>
                                                    <p>Please re-enter your bid.</p>
                                                </div>
                                                <div class="place_bott_mid">
                                                    <div class="place_bot_left">
                                                        <p>New Max Bid :</p>
                                                    </div>
                                                    <div class="place_bot_center">
                                                        <label><?php echo $symbol; ?></label>
                                                        <div class="place_input">
                                                            <input id="new_bid" name="bid_deal_current_value" type="text" AUTOCOMPLETE="OFF" value=""/>
                                                        </div>
                                                        <input type="hidden" id="old_bid" name="bid_deal_value" value="<?php echo $deals->deal_price; ?>" >
                                                        <input type="hidden"  name="bid_deal_id" id="bid_deal_id" value="<?php echo $deals->deal_id; ?>" >
                                                        <input type="hidden"  name="bid_deal_key" value="<?php echo $deals->deal_key; ?>" >
                                                        <input type="hidden"  name="bid_title" value="<?php echo $deals->deal_title; ?>" >
                                                        <input type="hidden"  name="bid_url_title" value="<?php echo $deals->url_title; ?>" >
                                                        <input type="hidden" name="shipping_amount" value="<?php echo $deals->shipping_fee; ?>" >
                                                        <input type="hidden" name="end_time" value="<?php echo $deals->enddate; ?>" >
                                                        <p>.00/ea</p>
                                                        <span class="bidamountval1">(<?php echo $symbol." ";?><?php echo $deals->deal_price; ?> or More)</span>
                                                    </div>
                                                    <div class="place_bot_rgt">
                                                        <div class="gren_left">
                                                            <div class="gren_right">
                                                                <div class="gren_mid_2"><input id="update" type="submit" value="Update" title="Update"/></div>   
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
											<?php } else { ?>
                                            <div class="place_midd_bott">
                                                <div class="place_bott_top">
                                                    <h3>Please Login And Place your bid.</h3>
                                                </div>
                                            </div>
										<?php } } else { ?>
										<div class="place_midd_bott" >
                                                <div class="place_bott_top">
                                                    <h3>This is a Future auction so you can't bid!.</h3>
													
													<p><span>Auction start Time: <?php echo date('d-m-Y h:i:s A', $deals->startdate); ?></span></p>
                                                </div>
                                            </div>
									<?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="branch_detail branch_detail1 pro_top">
                    <h2>FEATURED AUCTIONS</h2>
                    <div class="content_store_list">
                        <div class="slider_wrap">
                            <ul <?php if (count($this->all_deals_list) > 4) { ?>  id="mycarousel6" class="jcarousel-skin-tango4"<?php } else { ?> <?php } ?>>
                                <?php if (count($this->all_deals_list) > 0) { ?>
									<?php
										foreach ($this->all_deals_list as $deals1) {
											$symbol = CURRENCY_SYMBOL;
                                            ?>			
                                        <li>
                                            <div class="auction_list">
                                                <div class="action_img">
                                                    <div class="act_img_top"></div>
                                                    <div class="act_img_mid">
                                                        <?php if (file_exists(DOCROOT . 'images/category/icon/' . $deals1->category_url . '.png')) { ?>
                                                            <span class="cat_icon1"><img alt="category icon" src="<?php echo PATH . 'images/category/icon/' . $deals1->category_url . '.png'; ?>"></span>
														<?php } else { ?>
                                                            <span class="cat_icon1"><img alt="category icon" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png"/></span>
														<?php } ?>
														<?php if (file_exists(DOCROOT . 'images/auction/220_160/' . $deals1->deal_key . '_1' . '.png')) { ?>
                                                            <a href="<?php echo PATH . 'auction/' . $deals1->deal_key . '/' . $deals1->url_title . '.html'; ?>" title="<?php echo $deals1->deal_title; ?>"><img src="<?php echo PATH . 'images/auction/220_160/' . $deals1->deal_key . '_1' . '.png'; ?>"  alt="<?php echo $deals1->deal_title; ?>" title="<?php echo $deals1->deal_title; ?>" border="0" /></a>
                                                        <?php } else { ?>
                                                            <a href="<?php echo PATH . 'auction/' . $deals1->deal_key . '/' . $deals1->url_title . '.html'; ?>" title="<?php echo $deals1->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png"  alt="<?php echo $deals1->deal_title; ?>" title="<?php echo $deals1->deal_title; ?>" border="0" width="165px" height="185px"/></a>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="act_img_bot"></div>
                                                </div>
                                                <div class="action_rgt">
                                                    <p><a href="<?php echo PATH . 'auction/' . $deals1->deal_key . '/' . $deals1->url_title . '.html'; ?>" title="<?php echo $deals1->deal_title; ?>"><?php echo substr(ucfirst($deals1->deal_title),0,25).'...'; ?></a></p>
                                                    <div class="bid_cont">
														<?php $q = 0;
														foreach ($this->all_payment_list as $payment) { ?>
															<?php
															if ($payment->auction_id == $deals1->deal_id) {
																$firstname = $payment->firstname;
																$transaction_time = $payment->transaction_date;
																$q = 1;
															}
														}
														?>
														<?php if ($q == 1) { ?>
                                                            <div class="bid_value">					
                                                                <label>  Last Bidder :</label>
                                                                <span><?php echo substr(ucfirst($firstname),0,10).'..'; ?></span>
                                                            </div>
                                                            <div class="bid_value">					
                                                                <label> Bid:</label>
                                                                <span> <?php echo date("d-m-Y ", $transaction_time); ?> 
																<?php echo date("h:i A", $transaction_time); ?></span>
                                                            </div>
														<?php } ?>
														<?php if ($q == 0) { ?>
                                                            <div class="bid_value">  
                                                                <label>  Last Bidder :</label>
                                                                <span> Not Yet Bid</span>
                                                            </div>
                                                            <div class="bid_value">    
                                                                <label>  Close Time:</label>
                                                                <span><?php echo date("d-m-Y", $deals1->enddate); ?><br/><?php echo date("h:i A", $deals1->enddate); ?></span>
                                                            </div>	
														<?php } ?>
                                                        <div class="bid_value3">
                                                            <label>Time Left  :</label>
                                                            <span time="<?php echo $deals1->enddate; ?>" class="kkcount-down" >
                                                                <br/>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="act_bid_values">                                        
                                                        <div class="view_deals">
                                                            <div class="view_lft">
                                                                <div class="view_rgt">
                                                                    <div class="view_mid">
                                                                        <a href="<?php echo PATH . 'auction/' . $deals1->deal_key . '/' . $deals1->url_title . '.html'; ?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div> 
                                        </li>
									<?php }
									} else { ?>
																	Nodata Found
									<?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="some_of_otheritems">
                    <div class="pro_top">
                    </div>
                    <div class="addres_common">
                        <div class="addres_left_cont">
                            <div class="map_page3">
                                <div class="pro_title3 branch_detail1 pro_top">
                                <h2>address</h2>
                            </div>
                                <div class="map_page">
                                    <div id="map_main" style="width:448px; height:308px;"></div>
                                    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
                                    <script type="text/javascript">
                                        var latlng = new google.maps.LatLng(<?php echo $deals->latitude; ?>,<?php echo $deals->longitude; ?>);
                                        var myOptions = {
                                            zoom: 12,
                                            center: latlng,
                                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                                            navigationControl: true,
                                            mapTypeControl: true,
                                            scaleControl: true
                                        };

                                        var map = new google.maps.Map(document.getElementById("map_main"), myOptions);
                                        var marker = new google.maps.Marker({
                                            position: latlng,
                                            animation: google.maps.Animation.BOUNCE
                                        });
    										
                                        var infowindow = new google.maps.InfoWindow({
                                            content: '<b><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $deals->store_name); ?></b><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $deals->address1); ?></p><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $deals->address2); ?></p><p><?php echo $deals->city_name; ?>,<?php echo $deals->country_name; ?></p>'
                                        });

                                        google.maps.event.addListener(marker, 'click', function() { 
                                            infowindow.open(map, marker);
                                        });
                                        marker.setMap(map);
    									   
                                    </script>
                                </div>
                                <div class="common_all">
                                    <div class="addres_left_right">
                                        <h3><?php echo $deals->address1; ?>,</h3>
                                        <p><?php echo $deals->address2; ?>,  </p>                                    
                                        <p><?php echo $deals->city_name; ?>, <?php echo $deals->city_name; ?>. </p>                  
                                        <p><?php echo $this->Lang['MOBILE']; ?>: <?php echo $deals->phone_number; ?> </p>
                                        <p>Head Office: +91 422-434-2519. </p>
                                        <p><?php echo $this->Lang['WEBSITE']; ?>: <a target="blank" href="<?php echo $deals->website; ?>" class="color007BD9"> <?php echo $deals->website; ?></a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="cotent_face_right">
                                <div class="pro_title3 branch_detail1 pro_top">
                                    <h2>Comments</h2>
                                    <div class="face_commont">
                                        <div class="face_comm_top">
                                            <div class="face_top_left">
										<?php if (($this->session->get("UserID")) && file_exists(DOCROOT . 'images/user/150_115/' . $this->session->get("UserID") . '.png')) { ?> <img src="<?php echo PATH . 'images/user/150_115/' . $this->session->get("UserID") . '.png'; ?>"  alt="side_vdeio"  style="width:50px; height:50px;" />
										<?php } else { ?>
											<img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/comm_user.png"  alt="side_vdeio" border="0"  style="width:50px; height:50px;" />
										<?php } ?>
									</div>
										<form method="post" >
											<div class="face_top_textarea">
												<?php $Url = "home";
												if ($this->uri->segment(1) == "deals") {
													$Url = "deals";
												} ?>
                                                    <input type="hidden" name="deal_key" value="<?php echo $deals->deal_key; ?>" />
                                                    <input type="hidden" name="deal_id" id="deal_id"  value="<?php echo $deals->deal_id; ?>" />
                                                    <input type="hidden" name="url_title" value="<?php echo $deals->url_title; ?>" />
                                                    <input type="hidden" name="last_url" value="<?php echo $Url; ?>" />
                                                    <input type="hidden" name="type" id="type" value="3" />
                                                    <input type="hidden" name="user" id="user_id" value="<?php echo $this->session->get('UserID'); ?>" />
                                                    <textarea name ="comments" placeholder="Add a comment..."  id="comment_box" class="comment_box"></textarea>
                                                    <em id="error"></em>
                                                </div>
                                                <div class="post_button">
                                                    <div class="button1">
                                                        <div class="gren_left_3">
                                                            <div class="gren_right_3">
                                                                <div class="gren_mid_3" ><input type="button" title="POST" value="POST" onclick="check_comment();" /></div> 
                                                            </div>
                                                        </div>		
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div id="show"> <?php echo new View("themes/" . THEME_NAME . "/deals/comment"); ?> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end-->
            </div>
        </div>
    </div>
<?php } ?>


	<script type="text/javascript">
		$(document).ready(function(){
		 
			$("body").kkCountDown({
				colorText:'#CC0000',
				addClass : 'shadow'
			});
			
			$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
			$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); //Fade in the fade layer 				   		   
			//Close Popups and Fade Layer
			$('#auction_close').live('click', function() { //When clicking on the close or fade layer...
				$('.popup_auction').css({'visibility' : 'hidden'});
				$('#fade').css({'visibility' : 'hidden'});
				return false;
			});
		
			$(document).keyup(function(e) { 
				if (e.keyCode == 27) { // esc keycode
					$('.popup_auction').css({'visibility' : 'hidden'});
					$('#fade').css({'visibility' : 'hidden'});
					$('#new_bid').val('')
			
					return false;
				}
			});
		});
		
	</script>

	<script type="text/javascript"> $(document).ready(function() { 
		Rocket.SizeChart.rows = [{"CHEST (INCH)":"38","SHOULDER(INCH)":"16","LENGTH(INCH)":"27"},{"CHEST (INCH)":"40","SHOULDER(INCH)":"17","LENGTH(INCH)":"28"},{"CHEST (INCH)":"42.5","SHOULDER(INCH)":"18","LENGTH(INCH)":"29"},{"CHEST (INCH)":"45","SHOULDER(INCH)":"19","LENGTH(INCH)":"30"},{"CHEST (INCH)":"47","SHOULDER(INCH)":"19","LENGTH(INCH)":"31"},{"CHEST (INCH)":"49","SHOULDER(INCH)":"20","LENGTH(INCH)":"32"}];
		Rocket.SizeChart.columns = ["CHEST (INCH)","SHOULDER(INCH)","LENGTH(INCH)"];
		Rocket.SizeChart.conversionHoverActive = false;

		Rocket.SizeChart.preparePopup(false);

		// stop highlight animation if user overs list item
		$('#listProductSizes > li').bind('mouseover', function() {
			$(this).stop(false, true);
		});
		$(document).bind("Quicklist.productRemoved", function (e, sku) {
			//We are on the detail page of the product we just removed from quicklist
			//Enable the add to quicklist link
			if ($('#configSku').val() == sku) {
				$('#qlPrdAdded').hide();
				$('#qlPrdAdd').show();
			}
		});$('.tool-tip').hover(function() {
			var tipId = $(this).attr('label');
			var pos = $(this).position();
			$('#' + tipId).css({'top':(pos.top + 10), 'left': (pos.left + 10)});
			$('#' + tipId + ' span').css('background-color', '#fff' );
			$("#" + tipId).fadeIn(200);
		}, function() {
			var tipId = $(this).attr('label');
			$("#" + tipId).fadeOut(200);
		});

		globalConfig.product = globalConfig.product || {};
		globalConfig.product.rDetails = {"sku":"UN573MA91PPSINDFAS","chain":"3270|3328|3329|3330","brand":"United Colors of Benetton","brandId":"573","price":799,"sessionId":"qonohdq1sn843pl0afp0biklg3","userId":"","catId":"3270","cat":"Clothing","brickId":"3330","brick":"Crew Neck T-Shirts"};

		Jabong.image.initSetImage();
		$( '#prdZoomImgPrev' ).live( 'click', function() { Jabong.image.imgNavigate( 'prev' ) } );
		$( '#prdZoomImgNext' ).live( 'click', function() { Jabong.image.imgNavigate( 'next' ) } );

		if(window.location.hash == "#productReviews") {
			$("#productReviewsTab").trigger('click');
		}

		$('#recommSliderSolr').bxSlider({
			mode: 'vertical',
			auto: false,
			displaySlideQty: 3,
			moveSlideQty: 1,
			speed: 250
		});

		Rocket.QuickList.loadList([], []);
	});</script>

	<script type="text/javascript">$('.prd-more-images-slider').jCarouselLite({
	btnNext: ".next",
	btnPrev: ".prev",
	circular: false,
				
	visible: 5
	});        $('#prd-imageBox-container').bind('mouseenter', function() {
	$('.prd-zoom-info').hide();
	});
	$('#prd-imageBox-container').bind('mouseleave', function() {
	$('.prd-zoom-info').show();
	});
	var reviewFieldMsg = "You must fill the empty field(s) highlighted above.";
	var reviewSuccessMsg = "Thank you. Your review will start appearing soon.";
	var reviewErrorMsg = "There has been an error saving your rating. Please try again.";
	//<![CDATA[
	jQuery.ajax({
	type: "GET",
	url: "//ndot.in",
	success: function(data){
		new RecommendationView(data, 4);
	}
	});
	//]]></script>  

