<title> <?php echo SITENAME; ?> </title>

<link href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/popup.css" rel="stylesheet" type="text/css"/>
<?php
if (isset($this->is_product)) {
    $type = "products";
} else if (isset($this->is_auction)) {
    $type = "auction";
} else {
    $type = "deal";
}
?>

<?php  if(($this->uri->last_segment()=="near-map.html")||($this->uri->last_segment()=="nearmap.html")) { ?>
<?php  ?>
<!--header start-->
<div class="header_top_outer fullwidth_header">
    <div class="header_top_inner">
       <!-- <div class="header_top">-->
            <div class="header_top_left">
                <ul>
                    <li><a style="color:#675B58" title="HELP" href="<?php echo PATH; ?>contactus.html">HELP</a></li>
                    <li>|</li>
                    <li>CUSTOMER SUPPORT ( 24x7 ) <?php if (PHONE1) {
    echo PHONE1;
} else {
    
} ?></li>
                </ul> 
            </div>
            <div class="header_top_rgt header_right_top">
				
                <a class="refer_friend" href="<?php echo PATH ?>refer-friends.html" title="<?php echo $this->Lang['REFER_FRIENDS'] . ' ' . CURRENCY_SYMBOL . '' . REFERRAL_AMOUNT . '*'; ?>">
                    <?php echo $this->Lang['REFER_FRIENDS'] . ' ' . CURRENCY_SYMBOL . '' . REFERRAL_AMOUNT . '*'; ?></a>
                    
                    
							
                    
                <ul>
                    <li>
                        <a style="margin-right:5px;" title="F Connect" onclick="facebookconnect();" style="cursor:pointer;">
							<img alt="f_connect" src="<?php echo PATH;?>/themes/green/images/f_connect.png">
							</a>
                    </li>  
                   
<?php if ($this->session->get('UserID')) { ?>
						
                        <li><a title="MY ACCOUNT"><?php echo $this->Lang['WELCOME']; ?> <?php echo $this->session->get('UserName'); ?></a> </li>
                        <li>|</li>
                        <li><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a> </li>
                        <li>|</li>

                        <li><a href="<?php echo PATH; ?>logout.html" title="<?php echo $this->Lang['LOGOUT']; ?>"><?php echo $this->Lang['LOGOUT']; ?></a> </li>
<?php } else { ?>

                        <li class="cur"><div class="fb_connect" title="<?php echo $this->Lang['FB']; ?>"><a onClick="facebookconnect();">

                                </a></div> </li>
                    <?php } ?>

                    <?php if (FB_PAGE) { ?>
                        <li><a class="faceb" href="<?php echo FB_PAGE; ?>" target="blank" title="<?php echo $this->Lang['FB']; ?>">&nbsp;</a></li>
                    <?php }if (TWITTER_PAGE) { ?> 
                        <li><a class="twitt" href="<?php echo TWITTER_PAGE; ?>" target="blank" title="<?php echo $this->Lang['TW']; ?>">&nbsp;</a></li>
                    <?php }if (LINKEDIN_PAGE) { ?> 
                        <li><a class="linked" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="<?php echo $this->Lang['LINK']; ?>">&nbsp;</a></li>
                    <?php } if ($this->city_id) { ?> 
    <?php foreach ($this->all_city_list as $CX) {
        if ($this->city_id == $CX->city_id) { ?>
                                <li><a class="rss" href="<?php echo PATH . 'deals/rss/' . $this->city_id . '/' . $CX->city_url; ?>" target="blank" title="">&nbsp;</a></li>

        <?php }
    }
} ?>
           <?php /*         <li><a class="google" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="google">&nbsp;</a></li> */ ?>

                </ul>
            <!--</div>-->
        </div>
    </div>
</div>
<div class="header_outer fullwidth_header">

    <div class="header_top_inner">
        <div class="header">
            <div class="header_bottom">
                <div class="logo common_logo_right">
                    <h1>
                        <a href="<?php echo PATH; ?>" title="Uniecommerce">
                            <img alt="logo" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/>
                        </a>
                    </h1>
                </div>
                <div class="header_top_rgt2">
                
                    
                <ul>
          

<?php if ($this->session->get('UserID')) { ?>
                        <li><a title="MY ACCOUNT"><?php echo $this->Lang['WELCOME']; ?> <?php echo $this->session->get('UserName'); ?></a> </li>
                        <li>|</li>
                        <li><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a> </li>
                        <li>|</li>

                        <li><a href="<?php echo PATH; ?>logout.html" title="<?php echo $this->Lang['LOGOUT']; ?>"><?php echo $this->Lang['LOGOUT']; ?></a> </li>
<?php } else { ?>

                        <li><a id="login" href="javascript:showlogin();" title="<?php echo $this->Lang['LOGIN']; ?>"><?php echo $this->Lang['LOGIN']; ?></a></li>
                        <li>|</li>
                        <li><a href="javascript:showsignup();" title="<?php echo $this->Lang['SIGN_UP']; ?>"><?php echo $this->Lang['SIGN_UP']; ?></a> </li>
 <li>|</li>
                        <li><a href="javascript:showsignup();" title="<?php echo $this->Lang['SIGN_UP']; ?>">Contact Us</a> </li>
 <li>|</li>
                        <li class="cur"><div class="fb_connect" title="<?php echo $this->Lang['FB']; ?>"><a onClick="facebookconnect();">

                                </a></div> </li>
                    <?php } ?>

                    <?php if (FB_PAGE) { ?>
                        
                    <?php }if (TWITTER_PAGE) { ?> 
                        
                    <?php }if (LINKEDIN_PAGE) { ?> 
                       
                    <?php } if ($this->city_id) { ?> 
    <?php foreach ($this->all_city_list as $CX) {
        if ($this->city_id == $CX->city_id) { ?>
                               

        <?php }
    }
} ?>
<?php /*                    <li><a class="google" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="google">&nbsp;</a></li> */ ?>

                </ul>
            <!--</div>-->
        </div>
                <div class="city_cat">
                                            <ul>
                                                <li>
    <?php
    $city_name = "";
    foreach ($this->all_city_list as $c) {
        if ($c->city_id == $this->session->get('CityID')) {
            $city_name = $c->city_name;
        }
    }
    ?>
                                                    <a style="cursor:pointer;" title="<?php echo ucfirst($city_name); ?>"><?php echo ucfirst($city_name); ?></a>

                                                    <div class="drop_down1">

                                                        <ul>
                                    <?php foreach ($this->all_country_list as $country) { ?>	  
                                                                <li>
                                                                    <div class="drop_down_sub">
                                                                    <ul>
                                        <?php foreach ($this->all_city_list as $city) {
                                            if ($country->country_id == $city->country_id) { ?>
                                                                                <span>
                                                                                    <li>
                                                                                        <a style="cursor:pointer;" onClick="return changecity('<?php echo $city->city_id; ?>','<?php echo $city->city_url; ?>');" title="<?php echo ucfirst($city->city_name); ?>" ><?php echo $city->city_name; ?>  </a>
                                                                                    </li>
                                                                                </span>
                                            <?php }
                                        } ?>
                                                                    </ul>
                                                                    </div>
                                                                </li>
                                    <?php } ?>

                                                        </ul>
                                                    </div>

                                                </li>
                                            </ul>
                                        </div>
                                
                                </div>
            
            
            
            <div class="blue_header">
                 <div class="cities_common_right">
              <div class="cities_common">
                                <ul>
                                    <li><a href="<?php echo PATH; ?>all-categories.html">Shop All Categories</a>
                                    </li>
                                </ul>

                            </div>
                 </div>
                <div class="common_search">
                        <?php if (isset($this->is_product)) { ?>
                        <form id="myform" action="<?php echo PATH; ?>products/search.html">
                            <?php } elseif (isset($this->is_store)) {
                                ?>
                            <form id="myform" action="<?php echo PATH; ?>stores/search.html">
                                <?php } else if (isset($this->is_deals)) {
                                    ?>
                                <form id="myform" action="<?php echo PATH; ?>deals/search.html">
                                    <?php } else if(isset($this->is_auction)){
                                        ?>
                                    <form id="myform" action="<?php echo PATH; ?>auction/search.html">
				    <?php } else {  ?>   

	 			 <form id="myform" action="<?php echo PATH; ?>">

				   <?php } ?>
                                      <div class="sub"><input type="submit" value="" title="Search"/></div>  
                                    <div class="t_box">
			<?php $search = $this->input->get('q'); ?>


                                        <input type="text" size="12"  name="q" class="search_tbox textbg"  <?php if (isset($search)) { ?> value="<?php echo $search; ?>" <?php } else { ?> <?php if(isset($this->is_home)) { ?> placeholder="Search for&nbsp;<?php if($this->product_setting == 1) echo 'Products,' ; ?> <?php if($this->deal_setting ==1) echo 'Deals,' ; ?> <?php if($this->auction_setting == 1) echo 'Auction,'; ?>Stores etc.." <?php } else if(isset($this->is_product)) { ?> placeholder="Search for Products.." <?php } else if(isset($this->is_todaydeals)){ ?> placeholder="Search for Deals.."   <?php } else if(isset($this->is_auction)) { ?> placeholder="Search for Auction.." <?php } else if(isset($this->is_store)){ ?> placeholder="Search for  Stores..."  <?php } else {   ?>placeholder="Search for Products, Deals, Auction, Stores etc.." <?php } ?><?php }  ?> />

                                    </div>
                                   <?php /* <div class="cities">
                                        <ul>
                                            <li><a href="#">All Categories</a>

                                                <div class="drop_down">
                                                    <ul>
                                                            <?php foreach ($this->category_list as $d) {
                                                                $cat = ($type == "products") ? 'product' : (($type == "auction") ? 'auction' : 'deal'); ?>

                                                            <li><a href="javascript:filtercategory('<?php echo $d->category_url; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>" ><b><?php echo ucfirst($d->category_name); ?></b></a>



                                                            </li>
<?php } ?>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>

                                    </div> */?>
                                    <div class="sub2"><input type="submit" value="Search" title="Search" /></div>
                                </form> 
                                </div>
                <?php if ($this->product_setting) { ?>
                                    <div class="add_cart">
                                        <a href="<?php echo PATH; ?>cart.html" title="MY CART(<?php if ($this->session->get('count') != '') {
                                    echo $this->session->get('count');
                                } else {
                                    echo '0';
                                } ?>)">MY CART(<?php if ($this->session->get('count') != "") {
                                    echo $this->session->get('count');
                                } else {
                                    echo "0";
                                } ?>)</a>
                                    </div>
                                                        <?php } ?>
            </div>


                                <div class="menu">
                                    <div class="menu_left">
                                        <ul>
                                            <li <?php if (isset($this->is_home)) {
                                                            echo "class='active'";
                                                        } ?>>
                                                
                                                <a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>">
                                                      <span class="aerro_right_common1"> <?php echo $this->Lang['HOME1']; ?></span>
                                                       <span class="aerro_right_common">&nbsp;</span>
                                                </a>
                                         
                                                <div class="sub_menu1">
                                                    <b>Shop By Category</b>
                                                    
                                                    <ul>
                                                        
                                                        <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
                                                        $cat1 = array_unique($cat);
                                                        ?>

                                            <?php foreach ($this->category_list as $d) { ?>
                                                            <li>
															<?php $type="deal"; $categories=$d->category_url; ?>
                                                                                                                               
                                                               <a style="cursor:pointer;" class="sample_123" id="sample123-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');">
    <?php echo ucfirst($d->category_name); ?>
                                                                </a>
                                                                <div class="sub_menu2">
                                                                    <span class="white">&nbsp;</span>
                                                                    <ul>
                                                                     
                                                                            <a style="cursor:pointer;"><div id="categeory123-<?php echo $d->category_id; ?>"><?php echo new View("themes/" . THEME_NAME . "/deals/subcategory_list"); ?>
                                                                                </div>
                                                                            </a>
                                                                        

                                                                    </ul>
                                                                </div>
                                                            </li>
                                                       <?php } ?>

                                                    </ul>
                                                </div>
                                             
                                            </li>

<?php if ($this->product_setting) { ?>

                                                <li <?php if (isset($this->is_product)) {
        echo "class='active'";
    } ?>> <a href="<?php echo PATH; ?>products.html" title="PRODUCTS">
                                                        
                                                        <span class="aerro_right_common1">PRODUCTS</span>
                                                        <span class="aerro_right_common">&nbsp; </span>
                                                    </a>
                                                    <div class="sub_menu1">
                                                        <b>Shop By Category</b>
                                                        <ul>
    <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
    $cat1 = array_unique($cat);
    ?>

    <?php foreach ($this->category_list as $d) {
        if ($d->product == 1) {
            ?>
                                                                    <li>
																		<?php $type="products"; $categories=$d->category_url; ?>
																		<a style="cursor:pointer;" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" class="sample32" id="sample32-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>">
																		<?php echo ucfirst($d->category_name); ?>
                                                                        </a>
                                                                        <div class="sub_menu2">
                                                                            <span class="white">&nbsp;</span>
                                                                            <ul>
                                                                                <a style="cursor:pointer;"> <div id="categeory32-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/products/sub_categorey_list"); ?>

                                                                                        </div></a>

                                                                            </ul>
                                                                        </div>
                                                                    </li>
                                                                <?php }
                                                            } ?>

                                                        </ul>
                                                    </div></li>



                                                </li>
                                                                                <?php } ?>
<?php if ($this->deal_setting) { ?>
                                                <li <?php if (isset($this->is_todaydeals)) {
        echo "class='active'";
    } ?>><a href="<?php echo PATH; ?>today-deals.html" title="DEALS">
                                                        <span class="aerro_right_common1">DEALS</span>
                                                        <span class="aerro_right_common"> &nbsp;</span>
                                                        
                                                    </a>

                                                    <div class="sub_menu1">
                                                        <b>Shop By Category</b>
                                                        <ul>
    <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
    $cat1 = array_unique($cat);
    ?>

    <?php foreach ($this->category_list as $d) {
        if ($d->deal == 1) {
            ?>
                                                                    <li>
																<?php $type="deal"; $categories=$d->category_url; ?>

                                                                        <a style="cursor:pointer;" class="sample324" id="sample324-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" >
                                                                    <?php echo ucfirst($d->category_name); ?>
                                                                        </a>
                                                                        <div class="sub_menu2">
                                                                            <span class="white">&nbsp;</span>
                                                                            <ul>
                                                                               <a style="cursor:pointer;"> <div id="categeory324-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/deals/subcategory_list"); ?>
                                                                                        </div></a>

                                                                            </ul>
                                                                        </div>
                                                                    </li>
        <?php }
    } ?>

                                                        </ul>
                                                    </div></li>

                                                </li>
                                                        <?php } ?>
<?php if ($this->auction_setting) { ?>
                                            <li <?php if (isset($this->is_auction)) {
                                                            echo "class='active'";
                                                        } ?>><a href="<?php echo PATH; ?>auction.html" title="AUCTION">
                                                    
                                                   <span class="aerro_right_common1"> AUCTION</span>
                                                   <span class="aerro_right_common">&nbsp; </span>
                                                </a>
                                                <div class="sub_menu1">
                                                    <b>Shop By Category</b>
                                                    <ul>
<?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
$cat1 = array_unique($cat);
?>

                                            <?php foreach ($this->category_list as $d) {
                                                if ($d->auction == 1) {
                                                    ?>
                                                                <li>
																	<?php $type="auction"; $categories=$d->category_url; ?>
                                                                    <a style="cursor:pointer;" class="sample325" id="sample325-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>"onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');">
																		<?php echo ucfirst($d->category_name); ?>
                                                                    </a>
                                                                    <div class="sub_menu2">
                                                                        <span class="white">&nbsp;</span>
                                                                        <ul>
                                                                            
                                                                            <a style="cursor:pointer;"><div id="categeory325-<?php echo $d->category_id; ?>">
                                                    <?php echo new View("themes/" . THEME_NAME . "/auction/sub_categorey_list"); ?>
                                                                                    </div></a>

                                                                        </ul>
                                                                    </div>
                                                                </li>
    <?php }
} ?>

                                                    </ul>
                                                </div></li></li>
   <?php } ?>
                                    <?php if ($this->past_deal_setting) { ?>

                                                <li <?php if (isset($this->is_soldout)) {
                                            echo "class='active'";
                                        } ?>>
                                                    <a   class="aerrnone" href="<?php echo PATH; ?>soldout.html" title="SOLD OUT">
                                                              <span class="aerro_right_common1">  SOLD OUT</span>
                                                  
                                                       
                                                    </a>

                                                </li> 
                                                <?php } ?>

<?php if ($this->store_setting) { ?>
                                                <li <?php if (isset($this->is_store)) {
        echo "class='active'";
    } ?>><a  class="aerrnone" href="<?php echo PATH; ?>stores.html" title="STORES">
                                                           <span class="aerro_right_common1">    STORES</span>
                                                      </a></li>
                                                        <?php } ?>

<?php if(($this->deal_setting ==1 || $this->product_setting ==1 || $this->auction_setting ==1 ) && $this->map_setting) { ?>
                                                <li <?php if (isset($this->is_map)) {
        echo "class='active'";
    } ?>>

                                                    <a   class="aerrnone"href="<?php echo PATH; ?>near-map.html" title="<?php echo $this->Lang['NEAR_MAP']; ?>"><?php echo $this->Lang['NEAR_MAP']; ?></a>

                                                </li>
                                                                <?php } ?>

<?php if ($this->blog_setting) { ?>
                                                <li <?php if (isset($this->is_blog)) {
        echo "class='active'";
    } ?>>


                                                    <a  class="aerrnone" href="<?php echo PATH; ?>blog" title="<?php echo $this->Lang['BLO']; ?>">
                                                        <span class="aerro_right_common1">        <?php echo $this->Lang['BLO']; ?></span>
                                                        
                                                    </a>

                                                </li>
                                    <?php } ?>

                                        </ul>
                                    </div>
<?php if (CITY_SETTING) { ?>

                                        
                                <?php }  else {?>

 				<div class="city_cat12">
                                      
                                        </div>

				<?php } ?>


                                </div>


                                <!--end-->
                                <div class='popup_block'><?php echo new View("themes/" . THEME_NAME . '/users/login_popup'); ?></div>
                                <div class='popup_block1'><?php echo new View("themes/" . THEME_NAME . '/users/sign_up_popup'); ?></div> 
                                <div class='popup_block2'><?php echo new View("themes/" . THEME_NAME . '/users/forget_popup'); ?></div> 


                                <script>
                                    $(document).ready(function () {
                                        $(".show1").click(function() {
                                            $(".arro").toggle("slow", "linear");
                                            $(".drop_down").toggle("slow", "linear");
                                        });
                                    });
                                </script>

                               
        </div>
    </div>
</div>

<?php }  else { ?>
<!--header start-->
<div class="header_top_outer">
    <div class="header_top_inner">
        <!--<div class="header_top">-->
            <div class="header_top_left">
                <ul>
                    <li><a style="color:#675B58" title="HELP" href="<?php echo PATH; ?>contactus.html">HELP</a></li>
                    <li>|</li>
                    <li>CUSTOMER SUPPORT ( 24x7 ) <?php if (PHONE1) {
    echo PHONE1;
} else {
    
} ?></li>
                </ul> 
            </div>
            <div class="header_top_rgt">
                <a class="refer_friend" href="<?php echo PATH ?>refer-friends.html" title="<?php echo $this->Lang['REFER_FRIENDS'] . ' ' . CURRENCY_SYMBOL . '' . REFERRAL_AMOUNT . '*'; ?>">
                    <?php echo $this->Lang['REFER_FRIENDS'] . ' ' . CURRENCY_SYMBOL . '' . REFERRAL_AMOUNT . '*'; ?></a>
                
                
                <ul>
                         <li>
                        <a style="margin-right:5px;" title="F Connect" onclick="facebookconnect();" style="cursor:pointer;">
							<img alt="f_connect" src="<?php echo PATH;?>/themes/green/images/f_connect.png">
							</a>
                    </li>  
<?php if ($this->session->get('UserID')) { ?>
                 
<?php } else { ?>
                    
                
                    <?php } ?>

                    <?php if (FB_PAGE) { ?>
                        <li><a class="faceb" href="<?php echo FB_PAGE; ?>" target="blank" title="<?php echo $this->Lang['FB']; ?>">&nbsp;</a></li>
                    <?php }if (TWITTER_PAGE) { ?> 
                        <li><a class="twitt" href="<?php echo TWITTER_PAGE; ?>" target="blank" title="<?php echo $this->Lang['TW']; ?>">&nbsp;</a></li>
                    <?php }if (LINKEDIN_PAGE) { ?> 
                        <li><a class="linked" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="<?php echo $this->Lang['LINK']; ?>">&nbsp;</a></li>
                    <?php } if ($this->city_id) { ?> 
    <?php foreach ($this->all_city_list as $CX) {
        if ($this->city_id == $CX->city_id) { ?>
                                <li><a class="rss" href="<?php echo PATH . 'deals/rss/' . $this->city_id . '/' . $CX->city_url; ?>" target="blank" title="">&nbsp;</a></li>

        <?php }
    }
} ?>
<?php /*                    <li><a class="google" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="google">&nbsp;</a></li> */ ?>

                </ul>
            <!--</div>-->
        </div>
    </div>
</div>
<div class="header_outer">

    <div class="header_top_inner">
        <div class="header">
            <div class="header_bottom">
                <div class="logo">
                    <h1>
                        <a href="<?php echo PATH; ?>" title="Uniecommerce"><img alt="logo" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/></a>
                    </h1>
                </div>
    <div class="left_top_commen_red">
                          <a  ><img alt="logo" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/homepage1_03.png"/></a>  
                        </div>
                <div class="header_top_rgt2">

                <ul>
          

<?php if ($this->session->get('UserID')) { ?>
                        <li><a title="MY ACCOUNT"><?php echo $this->Lang['WELCOME']; ?> <?php echo $this->session->get('UserName'); ?></a> </li>
                        <li>|</li>
                        <li><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a> </li>
                        <li>|</li>

                        <li><a href="<?php echo PATH; ?>logout.html" title="<?php echo $this->Lang['LOGOUT']; ?>"><?php echo $this->Lang['LOGOUT']; ?></a> </li>
                        <li>|</li>
<?php } else { ?>

                        <li><a id="login" href="javascript:showlogin();" title="<?php echo $this->Lang['LOGIN']; ?>"><?php echo $this->Lang['LOGIN']; ?></a></li>
                        <li>|</li>
                        <li><a href="javascript:showsignup();" title="<?php echo $this->Lang['SIGN_UP']; ?>"><?php echo $this->Lang['SIGN_UP']; ?></a> </li>
 <li>|</li>
                        <li><a href="<?php echo PATH; ?>contactus.html" title="<?php echo $this->Lang['SIGN_UP']; ?>">Contact Us</a> </li>
 <li>|</li>
                        <li class="cur"><div class="fb_connect" title="<?php echo $this->Lang['FB']; ?>"><a onClick="facebookconnect();">

                                </a></div> </li>
                    <?php } ?>

                    <?php if (FB_PAGE) { ?>
                        
                    <?php }if (TWITTER_PAGE) { ?> 
                        
                    <?php }if (LINKEDIN_PAGE) { ?> 
                       
                    <?php } if ($this->city_id) { ?> 
    <?php foreach ($this->all_city_list as $CX) {
        if ($this->city_id == $CX->city_id) { ?>
                               

        <?php }
    }
} ?>
<?php /*                    <li><a class="google" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="google">&nbsp;</a></li> */ ?>

                </ul>
            <!--</div>-->
        </div>
                        <div class="city_cat">
                                            <ul>
                                                <li>
    <?php
    $city_name = "";
    foreach ($this->all_city_list as $c) {
        if ($c->city_id == $this->session->get('CityID')) {
            $city_name = $c->city_name;
        }
    }
    ?>
                                                    <a style="cursor:pointer;" title="<?php echo ucfirst($city_name); ?>"><?php echo ucfirst($city_name); ?></a>

                                                    <div class="drop_down1">

                                                        <ul>
                                    <?php foreach ($this->all_country_list as $country) { ?>	  
                                                                <li>

                                                                    <ul>
                                        <?php foreach ($this->all_city_list as $city) {
                                            if ($country->country_id == $city->country_id) { ?>
                                                                                <span>
                                                                                    <li>
                                                                                        <a style="cursor:pointer;" onClick="return changecity('<?php echo $city->city_id; ?>','<?php echo $city->city_url; ?>');" title="<?php echo ucfirst($city->city_name); ?>" ><?php echo $city->city_name; ?>  </a>
                                                                                    </li>
                                                                                </span>
                                            <?php }
                                        } ?>
                                                                    </ul>
                                                                </li>
                                    <?php } ?>

                                                        </ul>
                                                    </div>

                                                </li>
                                            </ul>
                                        </div>
                

                    


                                
            
            <div class="blue_header">
                        <div class="cities_common">
                                <ul>
                                    <li><a href="<?php echo PATH; ?>all-categories.html">Shop All Categories</a>
                                    </li>
                                </ul>

                            </div>
                <div class="common_search">
                        <?php if (isset($this->is_product)) { ?>
                        <form id="myform" action="<?php echo PATH; ?>products/search.html">
                            <?php } elseif (isset($this->is_store)) {
                                ?>
                            <form id="myform" action="<?php echo PATH; ?>stores/search.html">
                                <?php } else if (isset($this->is_deals)) {
                                    ?>
                                <form id="myform" action="<?php echo PATH; ?>deals/search.html">
                                    <?php } else if(isset($this->is_auction)){
                                        ?>
                                    <form id="myform" action="<?php echo PATH; ?>auction/search.html">
				    <?php } else {  ?>   

	 			 <form id="myform" action="<?php echo PATH; ?>">

				   <?php } ?>
                                      <div class="sub"><input type="submit" value="" title="Search"/></div>  
                                    <div class="t_box">
			<?php $search = $this->input->get('q'); ?>


                                        <input type="text" size="12"  name="q" class="search_tbox textbg"  <?php if (isset($search)) { ?> value="<?php echo $search; ?>" <?php } else { ?> <?php if(isset($this->is_home)) { ?> placeholder="Search for&nbsp;<?php if($this->product_setting == 1) echo 'Products,' ; ?> <?php if($this->deal_setting ==1) echo 'Deals,' ; ?> <?php if($this->auction_setting == 1) echo 'Auction,'; ?>Stores etc.." <?php } else if(isset($this->is_product)) { ?> placeholder="Search for Products.." <?php } else if(isset($this->is_todaydeals)){ ?> placeholder="Search for Deals.."   <?php } else if(isset($this->is_auction)) { ?> placeholder="Search for Auction.." <?php } else if(isset($this->is_store)){ ?> placeholder="Search for  Stores..."  <?php } else {   ?>placeholder="Search for Products, Deals, Auction, Stores etc.." <?php } ?><?php }  ?> />

                                    </div>
                                   <?php /* <div class="cities">
                                        <ul>
                                            <li><a href="#">All Categories</a>

                                                <div class="drop_down">
                                                    <ul>
                                                            <?php foreach ($this->category_list as $d) {
                                                                $cat = ($type == "products") ? 'product' : (($type == "auction") ? 'auction' : 'deal'); ?>

                                                            <li><a href="javascript:filtercategory('<?php echo $d->category_url; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>" ><b><?php echo ucfirst($d->category_name); ?></b></a>



                                                            </li>
<?php } ?>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>

                                    </div> */?>
                                    <div class="sub2"><input type="submit" value="Search" title="Search" /></div>
                                </form> 
                                </div>
                <?php if ($this->product_setting) { ?>
                                    <div class="add_cart">
                                        <a href="<?php echo PATH; ?>cart.html" title="MY CART(<?php if ($this->session->get('count') != '') {
                                    echo $this->session->get('count');
                                } else {
                                    echo '0';

                                } ?>)">My Cart(<?php if ($this->session->get('count') != "") {
                                    echo $this->session->get('count');
                                } else {
                                    echo "0";
                                } ?>)</a>
                                    </div>
                                                        <?php } ?>
                                </div>
            </div>


                                <div class="menu">
                                    <div class="menu_left">
					
                                        <ul>
                                            <li <?php if (isset($this->is_home)) {
                                                            echo "class='active'";
                                                        } ?>>
                                                
                                                <a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>">
                                                      <span class="aerro_right_common1"> <?php echo $this->Lang['HOME1']; ?></span>
                                                       <span class="aerro_right_common">&nbsp;</span>
                                                </a>
                                               
                                            </li>

<?php if ($this->product_setting) { ?>

                                                <li <?php if (isset($this->is_product)) {
        echo "class='active'";
    } ?>> <a href="<?php echo PATH; ?>products.html" title="PRODUCTS">
                                                        
                                                        <span class="aerro_right_common1">PRODUCTS</span>
                                                        <span class="aerro_right_common">&nbsp; </span>
                                                    </a>
                                                    <div class="sub_menu1">
                                                        <b>Shop By Category</b>
                                                        <ul>
    <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
    $cat1 = array_unique($cat);
    ?>

    <?php foreach ($this->category_list as $d) {
        if ($d->product == 1) {
            ?>
                                                                    <li>
																		<?php $type="products"; $categories=$d->category_url; ?>
																		<a style="cursor:pointer;" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" class="sample32" id="sample32-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>">
                                                                            <?php echo ucfirst($d->category_name); ?>
                                                                        </a>
                                                                        <div class="sub_menu2">
                                                                            <span class="white">&nbsp;</span>
                                                                            <ul>
                                                                                <a style="cursor:pointer;"> <div id="categeory32-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/products/sub_categorey_list"); ?>

                                                                                        </div></a>

                                                                            </ul>
                                                                        </div>
                                                                    </li>
                                                                <?php }
                                                            } ?>

                                                        </ul>
                                                    </div></li>



                                                </li>
                                                                                <?php } ?>
<?php if ($this->deal_setting) { ?>
                                                <li <?php if (isset($this->is_todaydeals)) {
        echo "class='active'";
    } ?>><a href="<?php echo PATH; ?>today-deals.html" title="DEALS">
                                                        
          <span class="aerro_right_common1">DEALS</span>
          <span class="aerro_right_common">&nbsp; </span> 
                                                    </a>

                                                    <div class="sub_menu1">
                                                        <b>Shop By Category</b>
                                                        <ul>
    <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
    $cat1 = array_unique($cat);
    ?>

    <?php foreach ($this->category_list as $d) {
        if ($d->deal == 1) {
            ?>
                                                                    <li>
																		<?php $type="deal"; $categories=$d->category_url; ?>
                                                                        <a style="cursor:pointer;" class="sample324" id="sample324-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" >
                                                                        
                                                                    <?php echo ucfirst($d->category_name); ?>
                                                                        </a>
                                                                        <div class="sub_menu2">
                                                                            <span class="white">&nbsp;</span>
                                                                            <ul>
                                                                               <a style="cursor:pointer;"> <div id="categeory324-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/deals/subcategory_list"); ?>
                                                                                        </div></a>

                                                                            </ul>
                                                                        </div>
                                                                    </li>
        <?php }
    } ?>

                                                        </ul>
                                                    </div></li>

                                                </li>
                                                        <?php } ?>
<?php if ($this->auction_setting) { ?>
                                            <li <?php if (isset($this->is_auction)) {
                                                            echo "class='active'";
                                                        } ?>><a href="<?php echo PATH; ?>auction.html" title="AUCTION">
                                                    <span class="aerro_right_common1">  AUCTION</span>
          <span class="aerro_right_common">&nbsp; </span>
                                                  </a>
                                                <div class="sub_menu1">
                                                    <b>Shop By Category</b>
                                                    <ul>
<?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
$cat1 = array_unique($cat);
?>

                                            <?php foreach ($this->category_list as $d) {
                                                if ($d->auction == 1) {
                                                    ?>
                                                                <li>
																	<?php $type="auction"; $categories=$d->category_url; ?>
                                                                    <a style="cursor:pointer;" class="sample325" id="sample325-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>"onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');">
        <?php echo ucfirst($d->category_name); ?>
                                                                    </a>
                                                                    <div class="sub_menu2">
                                                                        <span class="white">&nbsp;</span>
                                                                        <ul>
                                                                            
                                                                            <a style="cursor:pointer;"><div id="categeory325-<?php echo $d->category_id; ?>">
                                                    <?php echo new View("themes/" . THEME_NAME . "/auction/sub_categorey_list"); ?>
                                                                                    </div></a>

                                                                        </ul>
                                                                    </div>
                                                                </li>
    <?php }
} ?>

                                                    </ul>
                                                </div>
                                            </li>
                                     
   <?php } ?>
                                    <?php if ($this->past_deal_setting) { ?>

                                                <li <?php if (isset($this->is_soldout)) {
                                            echo "class='active'";
                                        } ?>>
                                                    <a   class="aerrnone" href="<?php echo PATH; ?>soldout.html" title="SOLD OUT">
                                                          <span class="aerro_right_common1">          SOLD OUT</span>
                                                      </a>

                                                </li> 
                                                <?php } ?>

<?php if ($this->store_setting) { ?>
                                                <li <?php if (isset($this->is_store)) {
        echo "class='active'";
    } ?>><a  class="aerrnone" href="<?php echo PATH; ?>stores.html" title="STORES">
                                                        <span class="aerro_right_common1">             STORES</span>
                                                     </a></li>
                                                        <?php } ?>

<?php if (($this->deal_setting ==1 || $this->product_setting ==1 || $this->auction_setting ==1 ) && $this->map_setting) { ?>
                                                <li <?php if (isset($this->is_map)) {
        echo "class='active'";
    } ?>>

                                                    <a   class="aerrnone"href="<?php echo PATH; ?>near-map.html" title="<?php echo $this->Lang['NEAR_MAP']; ?>">
                                                          <span class="aerro_right_common1"><?php echo $this->Lang['NEAR_MAP']; ?></span>
                                                        </a>

                                                </li>
                                                                <?php } ?>

<?php if ($this->blog_setting) { ?>
                                                <li <?php if (isset($this->is_blog)) {
        echo "class='active'";
    } ?>>


                                                    <a  class="aerrnone" href="<?php echo PATH; ?>blog" title="<?php echo $this->Lang['BLO']; ?>">
                                                         <span class="aerro_right_common1"> <?php echo $this->Lang['BLO']; ?></span>
                                                       </a>

                                                </li>
                                    <?php } ?>

                                        </ul>
                                    </div>
<?php if (CITY_SETTING) { ?>

                                        
                                <?php }  else {?>

 				<div class="city_cat12">
                                      
                                        </div>

				<?php } ?>


                                </div>


                                <!--end-->
                                <div class='popup_block'><?php echo new View("themes/" . THEME_NAME . '/users/login_popup'); ?></div>
                                <div class='popup_block1'><?php echo new View("themes/" . THEME_NAME . '/users/sign_up_popup'); ?></div> 
                                <div class='popup_block2'><?php echo new View("themes/" . THEME_NAME . '/users/forget_popup'); ?></div> 


                                <script>
                                    $(document).ready(function () {
                                        $(".show1").click(function() {
                                            $(".arro").toggle("slow", "linear");
                                            $(".drop_down").toggle("slow", "linear");
                                        });
                                    });
                                </script>

                               
        </div>
    </div>
</div>


<?php } ?>


