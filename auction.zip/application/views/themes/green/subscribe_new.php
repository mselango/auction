
        <div class="contianer_outer" id="home_page_margin_top">
            <div class="contianer_inner">

                <div class="contianer">

                    <!--content start-->
                    <div class="content">
						
                        <!--sidebar start-->
                        <div class="conntent_left">

               <div class="cat_outer1">
                                <div class="category1">
                                    <h1>Categories</h1>
                                    
                                    <ul>
                    <?php  $cat=explode(",", substr($this->session->get('categoryID'), 0, -1));
							$cat1=array_unique($cat);?>
                    
					<?php foreach ($this->category_list as $d) {
											if ($d->product == 1 && isset($this->is_product)) { ?>

                                                <li>
                                                    <span class="cate_check">


               <?php $type="products"; $categories=$d->category_url; ?>
              

														</span>

											<a style="cursor:pointer;" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo $d->category_name; ?>"  class="sample12" id="sample12-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>">
												<?php echo ucfirst($d->category_name); ?>
											</a>
                                            <div class="sub_menu_top1">	
                                                  <span class="white">&nbsp; </span>
                                                <ul>
                                                    
													<li>
                                                    <a style="cursor:pointer;">


                                                <div id="categeory12-<?php echo $d->category_id; ?>">
												<?php echo new View("themes/" . THEME_NAME . "/products/sub_categorey_list"); ?>

                                                </div></a>
												</li>
                                                </ul>
                                            </div>
                                                </li>


								<?php }   } ?>
								<?php foreach ($this->category_list as $d) {
        if ($d->deal == 1 && isset($this->is_deals)) { ?>
                                                <li>
                                                    <span class="cate_check">
                               <?php $type="deal"; $categories=$d->category_url; ?>

<a style="cursor:pointer;" class="sample23" id="sample23-<?php echo $d->category_id; ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>">
		<?php echo ucfirst($d->category_name); ?>
	</a>
                                            <div class="sub_menu_top1">	
                                                 <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;">


                                            <div id="categeory23-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/deals/subcategory_list"); ?>
                                                </div></a>
                                       
                                                </ul>
                                            </div>
                                                </li>



                                                
        <?php }   } ?>
         <?php foreach ($this->category_list as $d) {
        if ($d->auction == 1  && isset($this->is_auction)) { ?>
                                                <li>
                                                    <span class="cate_check">
                              <?php $type="auction"; $categories=$d->category_url; ?>

<a style="cursor:pointer;" class="sample33" id="sample33-<?php echo $d->category_id; ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>">
		<?php echo ucfirst($d->category_name); ?>
	</a>
                                            <div class="sub_menu_top1">	
                                                 <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;">


                                            

                                                <div id="categeory33-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/auction/sub_categorey_list"); ?>
                                                </div></a>
                                       
                                                </ul>
                                            </div>

                                                </li>



        <?php } }  ?>
        <?php foreach($this->category_list as $d){ if ((!isset($this->is_deals)) && (!isset($this->is_product)) && (!isset($this->is_auction))) { ?> 
                                        <li>
<a style="cursor:pointer;" class="sample_12" id="sample-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>">
		<?php echo ucfirst($d->category_name); ?>
	</a>
                                            <div class="sub_menu_top1">	
                                                 <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;"><div id="categeory1-<?php echo $d->category_id; ?>"><?php echo new View("themes/".THEME_NAME."/deals/subcategory_list"); ?></div></a>
                                       
                                                </ul>
                                            </div>
                                        </li>
  <?php   } } ?>
  <?php  ?>
   
                                        <input type="submit" value="submit" id="submit" style="display:none;">
                                    </ul>
                                   
                                </div>
                            </div>


                            
                        </div>
                        <!--end-->
                        
                        <div class="content_right">
                            <div class="content_deals_top">
                                 <a href="#" title="city"><img alt="city" src="<?php echo PATH.'themes/'.THEME_NAME ?>/images/city_rgt_img.png" /></a> 
                            </div> 
                            <div class="deals_under_bg">
                                <p>Sorry, there are no items today under this category</p>
                            </div>
                            <div class="content_deals_midd">
                                <span>Sign Up for Deal alerts and never miss out on the saving !</span>
                                <div class="cont_deal_city">
									<form name="Subscribe" method="post" id="commentForm_deals" action="<?php echo PATH;?>users/subscribe_city">
                                    <div class="deal_email_add">
										<input type="text" name="subscribe_email" value="" placeholder="<?php echo $this->Lang['EMAIL_ADDR']; ?>"  />
                                        <em style="padding-top:2px;"><?php if(isset($this->form_error['subscribe_email'])){ echo $this->form_error['subscribe_email']; }?></em>
                                    </div>
                                    
                                    <div class="deal_your_city">
										
                                        <select name="city_id" >
											<?php  foreach($this->all_city_list as $city){?>
												<option <?php if($this->city_id == $city->city_id){ echo "selected='selected'"; } ?>   value="<?php echo $city->city_id;?>"><?php echo ucfirst($city->city_name); ?></option>
											<?php } ?>
										</select>
										
                                    </div>
                                   
                                    <div class="deal_sub_button">
                                        <div class="new_submit">
                                            <div class="gren_left">
                                                <div class="gren_right">
                                                    <div class="gren_mid"><input type="submit" title="Submit" value="<?php echo $this->Lang['SUBS_NW']; ?>" /></div> 
                                                </div>
                                            </div>															
                                        </div>
                                    </div>
                                    </form>
                                </div>
								
                                <div class="deal_already">
									  <?php if(!$this->UserID){ ?>
                                    <a href="javascript:showlogin();" title="Already Have An Access? Log In Here">Already Have An Access? Log In Here</a>
                                    <?php } ?>
                                    <p>WE APPRECIATE YOUR BUSINESS AND WE WILL NEVER SHARE YOUR EMAIL ADDRESS WITH THIRD PARTIES.</p>
                                </div>

                            </div>

                        </div>
                    </div>
                    <!--end-->
                </div>

            </div>
        </div>


                            <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample12').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample12-','');
                                        var url = Path+"deals/today_deals/?cate_id="+getUID;

    	
                                        $.post(url,function(check){

    			
                                            if(getUID!=""){
                                                $('#categeory12-'+getUID).html(check);
    		
                                                $('#categeory12-'+getUID).show();
                                 
    		
                                            }
    			
                                        });

                                    });


                                });  
      

                            </script>
                             <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample23').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample23-','');
                                        var url = Path+"deals/today_deals/?cate_id="+getUID;

    	
                                        $.post(url,function(check){

    			
                                            if(getUID!=""){
                                                $('#categeory23-'+getUID).html(check);
    		
                                                $('#categeory23-'+getUID).show();
                                 
    		
                                            }
    			
                                        });

                                    });


                                });  
      

                            </script>
                              <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample33').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample33-','');
                                        var url = Path+"auction/today_auction/?cate_id="+getUID;
    	
                                        $.post(url,function(check){
    			
                                            if(getUID!=""){
                                                $('#categeory33-'+getUID).html(check);
    			
                                                $('#categeory33-'+getUID).show();
                                       

                                            }
                                        });
                                    });
                                });  
                            </script>

