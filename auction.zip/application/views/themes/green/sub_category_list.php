         <script >
												 $('.submit-link1')
                               .click(function(e){ 
								   
                                       var cat = $(this).attr('id').replace('samples-','').split('-');
                                       $('input[name="c"]').val(cat[0]);
                                       $('input[name="m_c"]').val(cat[1]);
                                       $('input[name="c_t"]').val('<?php echo base64_encode("sub"); ?>');
                                       
                                       e.preventDefault();
                                      $(this).closest('form').submit();
                                               
   });
												</script>                              
												
                                                <?php foreach($this->categeory_list as $cate){  $type = ""; ?>
													
                                              <li> <a class="submit-link1" id="samples-<?php echo base64_encode($cate->category_id)."-".base64_encode($cate->main_category_id); ?>"title="<?php echo ucfirst($cate->category_name); ?>"><?php echo $cate->category_name;?></a> </li>
												
                                                <?php } ?>		
		
 					
                                 
