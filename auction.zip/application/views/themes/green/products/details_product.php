<script type="text/javascript">
    $(document).ready(function(){
	$('.error_size').hide();
	$('.error_color').hide();
	$('.error_all').hide();
    $('.cart_butval').click(function(){		
            
                $('.error_size').show();
				$(".new_bid").css('border','1px solid red');
					return false;	
	}); 
	$('.cart_colorval').click(function(){            
                $('.error_color').show();
				$(".new_color").css('border','1px solid red');
					return false;	
	});
	$('.cart_totalval').click(function(){          
                $('.error_all').show();
				$(".new_color").css('border','1px solid red');
				$(".new_bid").css('border','1px solid red');
					return false;	
	});

});	
</script>


<link rel="stylesheet" type="text/css" href="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/css/zoom.css" media="all">
<script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery-1.5.js"></script> 
<script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/easySlider1.7.js"></script>
    <script src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/zoom.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery.jcarousel.min.js "></script> 
        <script type="text/javascript">
            jQuery(document).ready(function() {
                jQuery('#mycarousel2').jcarousel({
                    wrap: 'circular'
                });
            });
        </script>
  <script type="text/javascript"> 
    var aliceImageHost = 'http://ndot.in';
    var globalConfig = {};     
</script>
      	
 <?php foreach( $this->product_deatils as $products){
		        $symbol = CURRENCY_SYMBOL; 
	                ?>

       
        <div class="contianer_outer1">
            <div class="contianer_inner">
                <div class="contianer">
                    
                     <!--header start-->
                    <div class="bread_crumb">
                        <ul>
                            <li><p><a href="index.html" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            <li><p><a href="<?php echo PATH;?>products.html" title="<?php echo $this->Lang['PRODUCTS']; ?>"><?php echo $this->Lang["PRODUCTS"]; ?></a></p></li>
                            
                            <li><p><?php echo ucfirst($products->deal_title); ?></p></li>
                        </ul>
                    </div>
        <!--end-->

                    <!--content start-->
                    <div class="product_detail_top">
                        <div class="all_del_detail">
                            <div class="all_deal_top">


                                <div class="all_deal_top_left">
                                    <div id="prdMedia" class="prd-media">

        <?php /* $con=0; 
                for($i=1; $i<=5; $i++){ 
                        if(file_exists(DOCROOT.'images/products/1000_700/'.$products->deal_key.'_'.$i.'.png')) { 
                                $con=$con+1; 
                        } 
                 } */ ?>
 <?php  if(file_exists(DOCROOT.'images/products/1000_700/'.$products->deal_key.'_1'.'.png'))  { ?>
    
    <div id="productZoom" style="background-image: url(&quot;<?php echo PATH.'images/products/1000_800/'.$products->deal_key.'_1.png';?>&quot;); background-position: 0px -499.56px; opacity: 1; display: none;background-repeat:no-repeat;height:400px; width:620px;" data-zoom-image="<?php echo PATH.'images/products/1000_800/'.$products->deal_key.'_1.png';?>"></div>

    <div id="prd-imageBox-container" class="prd-imageBoxLayout ">
        <a href="" class="prd-imageBox" id="prdZoomBox">
            <span rel="foaf:depiction">
				<?php if($products->purchase_count >= $products->user_limit_quantity)  { ?>
                <div class="should_out_images">
                    &nbsp;
                </div>
                <?php } ?>
               <img src="<?php echo PATH.'images/products/1000_700/'.$products->deal_key.'_1.png';?>" class="prd-image" id="prdImage" data-js-function="setPlaceholderOnError" title="<?php echo ucfirst($products->deal_title); ?>" alt="<?php echo ucfirst($products->deal_title); ?>"  width="355" >
            </span>

            <div style="top: 181px; left: 0px; display: none;" id="magnifier"></div>
        </a>
    </div>
     <?php }  else { ?>
    <div id="productZoom" style="background-image: url(&quot;<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png&quot;); background-position: 0px -499.56px; opacity: 1; display: none;background-repeat:no-repeat;height:400px; width:355px;" data-zoom-image="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png"></div>

    <div id="prd-imageBox-container" class="prd-imageBoxLayout ">
        <a href="" class="prd-imageBox" id="prdZoomBox">
            <span rel="foaf:depiction">
					<?php if($products->purchase_count >= $products->user_limit_quantity)  { ?>
                <div class="should_out_images">
                    &nbsp;
                </div>
                <?php } ?>
               <img class="prd-image" id="prdImage" data-js-function="setPlaceholderOnError" title="<?php echo ucfirst($products->deal_title); ?>" alt="<?php echo ucfirst($products->deal_title); ?>" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png" height="380" width="355">
            </span>

            <div style="top: 181px; left: 0px; display: none;" id="magnifier"></div>
        </a>
    </div>

	<?php } ?>

    <h2 class="s-visuallyhidden">More Images</h2>
    <div class="prd-more-images-slider-container">
        
        <div class="prd-more-images-slider lfloat">
            <ul id="productMoreImagesList" class="prd-moreImagesList ui-listItemBorder ui-listLight clearfix">
      
                                         <?php for($i=1; $i<=5; $i++){ ?>
             <?php  if(file_exists(DOCROOT.'images/products/1000_700/'.$products->deal_key.'_'.$i.'.png'))  { ?>
                <li class="lfloat ui-border selected"
                    data-js-function="setImage"
                    data-image-product="<?php echo PATH.'images/products/1000_700/'.$products->deal_key.'_'.$i.'.png';?>"
                    data-image-big="<?php echo PATH.'images/products/1000_800/'.$products->deal_key.'_'.$i.'.png';?>">
                    <img data-js-function="setPlaceholderOnError"
                         data-placeholder="<?php echo PATH.'images/products/1000_800/'.$products->deal_key.'_'.$i.'.png';?>"
                         id="gal<?php echo $i; ?>"
                         width="37"
                         height="54"
                         src="<?php echo PATH.'images/products/1000_800/'.$products->deal_key.'_'.$i.'.png';?>"
                         alt="zoom" />
                </li>





  <?php } else {  }  
  } ?>
            </ul>
        </div>
        
        
    </div>


    
    
    

</div>
                                    
   
                                </div>


                            </div>
                            <div class="all_deal_top_rgt">
                                <h1 class="tit_tag"><?php echo ucfirst($products->deal_title); ?></h1>

                                <div class="pro_delivery_det">

                                    <div class="deliv_lft1">
                                        <p><?php echo $symbol." ".$products->deal_price; ?></p>
                                        <?php $country = COUNTRY_CODE; ?>
                                        <span><?php echo $symbol." ".$products->deal_value . " ".$country; ?> </span>
                                    </div>
                                    <div class="deliv_rgt1">
                                        <p>Delivered in 2-3 business days</p>
                                        <span>(Delivery time may vary on shipping address)</span>
                                    </div>
                                    <div class="free_shiping">
                                    <?php
                                    if($this->shipping_setting  == 1){ ?>
                                    <p>Free Shipping on this product</p>
                                    <?php } elseif($this->shipping_setting  == 2){ ?>
                                     <p>Flat Shipping on this product -  Flat amount for (<?php echo FLAT_SHIPPING_AMOUNT; ?>)</p>
                                    <?php } elseif($this->shipping_setting  == 3){ ?>
                                    <p>Per Product Shipping on this product - Product shipping amount (<?php  echo $products->shipping_amount; ?> )</p>
                                    <?php } elseif($this->shipping_setting  == 4){ ?>
                                     <p>Per Item Shipping on this product - Product per item shipping amount (<?php  echo $products->shipping_amount; ?> ) </p>
                                    <?php } ?>
                                       
                                    </div>
                                    <?php if($products->purchase_count == $products->user_limit_quantity) { }  else { ?> 
                                    <?php  if(count($this->product_size)>0){ ?>
                                    <div class="choose_your_size">
                                        <h2 class="new_bid">Choose Your Size</h2>
                                        
                                        <ul>
                                       <?php $nosize = ""; foreach($this->product_size as $size){  
                                        if($size->size_name=="None"){ $nosize = 1;  echo "No Size "; } else { ?>           
                                        <?php if($size->quantity != 0){ ?><li  class="<?php if($size->quantity != 0){ if($this->session->get('product_size_qty'.$products->deal_id) == $size->size_id) { ?> act <?php } }  ?>" ><a href="<?php echo PATH.'products/addmore_size/'.$size->size_id.'/'.$products->deal_id.'/'.$size->quantity;?>" > <?php echo $size->size_name; ?> </a></li> <?php } else { ?><li><a class="sold_out" > <?php echo $size->size_name; ?> </a></li><?php } } } ?>
                                            
                                        </ul>
                                    </div>
                                    <?php }  ?>

                                     <?php $color_count = 0; if(count($this->product_color)>0){ $color_count = 1;?>  
                                     
                                    <div class="chose_color">
   
                                        <p class="new_color">Choose Your Color </p>
                                            
                                       
                                          
                                        <ul>
                                        <?php foreach($this->product_color as $color){ ?>       
                                                      
                                          <li>
                                                <a href="<?php echo PATH.'products/addmore_color/'.$color->color_code_id.'/'.$products->deal_id;?>" title="<?php echo $color->color_code_name; ?>" class="<?php if($this->session->get('product_color_qty'.$products->deal_id)==$color->color_code_id){ ?> active <?php } ?>">                                                
                                                                                                
                                                <span class="choose_color_div" style="background:#<?php echo $color->color_name; ?>;"></span>
                                                
                                                </a>  
                                                
                                            </li>
                                            
                                            <?php } ?>

                                        </ul>
                                          
                                    </div>
                                   
                                    <?php } ?>
                                    <?php } ?>
                                    
                                    <div  class="rating_ican">
                                       
        <div class="rating">
											<p>Rating:</p>

                            <link href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/jRating.jquery.css" rel="stylesheet" type="text/css"/>
                            <script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jRating.jquery.js"></script>
                            <script type="text/javascript">
                            $(document).ready(function(){
                            $(".basic<?php echo $products->deal_id;?>").jRating({ 
                            bigStarsPath : '<?php echo PATH;?>/images/stars_detail.png', // path of the icon stars.png
                            smallStarsPath : '<?php echo PATH;?>/images/small.png', // path of the icon small.png
                            phpPath : '<?php echo PATH;?>product-rating.html', // path of the php file jRating.php
                            length:5,
                            rateMax : 10,
                            decimalLength:1,
                            showRateInfo: false,
                            <?php if((!$this->UserID)){?>	
                            isDisabled : true			
                            <?php } ?>
                            });
                            });
                            </script>
                            
                                            <label class="basic<?php echo $products->deal_id;?>" id="<?php echo $this->avg_rating; ?>">
													<!--
														Check the images folder for 'black_star.png' and 'white_star.png'
													-->
											</label>
                                       
             </div>
                                        <a class="add_short_list1"  title="Availability  (<?php echo $products->user_limit_quantity-$products->purchase_count; ?>)">Total <?php echo $this->Lang['AVIL']; ?>   ( <?php echo $products->user_limit_quantity-$products->purchase_count; ?> )</a>

                            <span class="error_size" >select any size from list</span>
                        <span class="error_color" >select any color from list</span>
                        <span class="error_all" >Please choose color and size from the list</span> 


<?php if($products->purchase_count >= $products->user_limit_quantity)  { ?>
        <div class="buy_now">
             
                                            <div class="buy_now_left">
                                                <div class="buy_now_right">
                                                    <div class="buy_now_mid">

						 <a>SOLD OUT</a>

                   				 </div>
                                                </div>

                                            </div>	


                                        </div>

					<?php }  else { ?> 
                                        <div class="buy_now">
             
                                            <div class="buy_now_left">
                                                <div class="buy_now_right">
                                                    <div class="buy_now_mid">
                                                    
			

                                                        <?php if($color_count == 1){ ?>
                                <?php if(($this->session->get('product_quantity_qty'.$products->deal_id)!="")&&($this->session->get('product_color_qty'.$products->deal_id)!="")){ ?>
                                <a href="<?php echo PATH; ?>payment_product/cart_items?deal_id=<?php echo base64_encode($products->deal_id); ?>" class="cart_button" title="<?php echo $this->Lang['ADD_TO_CART']; ?>"><?php echo $this->Lang['ADD_TO_CART']; ?></a>
                                <?php } else { ?>

                                            <?php if(($this->session->get('product_quantity_qty'.$products->deal_id)=="")&&($this->session->get('product_color_qty'.$products->deal_id)=="")){ ?>
                                            <a href="" class="cart_totalval" title="<?php echo $this->Lang['ADD_TO_CART']; ?>"><?php echo $this->Lang['ADD_TO_CART']; ?></a>

                                            <?php } elseif(($this->session->get('product_quantity_qty'.$products->deal_id)=="")) { ?>
                                            <a href="" class="cart_butval" title="<?php echo $this->Lang['ADD_TO_CART']; ?>"><?php echo $this->Lang['ADD_TO_CART']; ?></a>
                                            <?php } elseif(($this->session->get('product_color_qty'.$products->deal_id)=="")) { ?> 
                                            <a href="" class="cart_colorval" title="<?php echo $this->Lang['ADD_TO_CART']; ?>"><?php echo $this->Lang['ADD_TO_CART']; ?></a>
                                            <?php } ?>          

                                <?php } ?>
                        
                        
                        <?php } else { ?> 

                                <?php if(($this->session->get('product_quantity_qty'.$products->deal_id)!="")||($nosize == 1)){ ?>

                                        <a href="<?php echo PATH; ?>payment_product/cart_items?deal_id=<?php echo base64_encode($products->deal_id); ?>" class="cart_button" title="<?php echo $this->Lang['ADD_TO_CART']; ?>"><?php echo $this->Lang['ADD_TO_CART']; ?></a>
                                <?php } else { ?>  
					        
                                        <a href="" class="cart_butval" title="<?php echo $this->Lang['ADD_TO_CART']; ?>"><?php echo $this->Lang['ADD_TO_CART']; ?></a>                    
                                <?php } ?>
                                
                        <?php } ?>
                                                     
                                                    
                                                    </div>
                                                </div>

                                            </div>	


                                        </div>
			<?php } ?>



                                    </div>
                                    <div class="detail_bottom">

                                        <div class="rating_share">
                                            <p>Share: </p>
                                            <ul>
                        <li>  <iframe src="http://www.facebook.com/plugins/like.php?href=<?php echo $url = (!empty($_SERVER['HTTPS'])) ? 'https://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] : 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];?> &amp;layout=button_count&amp;show_faces=true&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden;  height:21px; width:105px;" allowTransparency="true"></iframe></li>
                        <li>  
                        <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
                        <a href="http://twitter.com/share" class="twitter-share-button" data-url="<?php echo $url = (!empty($_SERVER['HTTPS'])) ? 'https://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] : 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];?>" data-count="horizontal"><?php echo $this->Lang['Tweet']; ?></a></li>

                        <li> <script type="text/javascript" src="https://apis.google.com/js/plusone.js">
                        {parsetags: 'explicit'}
                        </script>

                        <!-- Place this tag where you want the +1 button to render -->
                        <div class="g-plusone" data-size="medium" data-href="<?php echo PATH.'deals/'.$products->deal_key.'/'.$products->url_title.'.html';?>"></div>
                        <!-- Place this render call where appropriate -->
                        <script type="text/javascript">gapi.plusone.go();</script> </li>
                        </ul>
                   </div>
                </div>
            </div>
        </div>
    </div>
                <div class="all_deals_bottom">
                        <div class="top_tab">
                        <ul>
                        <li><a href="#" title="Product Details">Product Details</a></li>
                        </ul>
                        <!--<div class="produt_review">
                        <a href="#" title="Product Reviews">Product Reviews</a>
                        </div> -->
                        </div>
                    <div class="bot_mid_det">
                    <?php echo $products->deal_description; ?>
                    </div>
                </div>


                     
                        <!--   my carousel2  -->    
                    <div class="branch_detail branch_detail1 pro_top">
						<?php if(count($this->all_products_list) > 0){ ?>     
                        <h2>FEATURED  PRODUCTS</h2>

                        <div class="content_store_list">
                            <div class="slider_wrap">
                                <ul  <?php if(count($this->all_products_list) > 5){ ?>  id="mycarousel2" class="jcarousel-skin-tango2" <?php } else {?> <?php } ?>>
                               


  <?php $deal_offset = $this->input->get('offset'); foreach( $this->all_products_list as $products_list){
$symbol = CURRENCY_SYMBOL; 
?>			
                                    <li>

                                        <div class="pro_listing">
                                            <div class="det_img1">
												<?php if(file_exists(DOCROOT.'images/category/icon/'.$products_list->category_url.'.png')){ ?>
												<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH.'images/category/icon/'.$products_list->category_url.'.png'; ?>"></span>
											<?php } else { ?>
												<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cate_icon.png"/></span>
                                            <?php } ?>
                                                
                                                <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products_list->deal_key.'_1'.'.png')){ ?>
          <a href="<?php echo PATH.'product/'.$products_list->deal_key.'/'.$products_list->url_title.'.html';?>" title="<?php echo $products_list->deal_title; ?>"><img src="<?php echo PATH.'images/products/290_215/'.$products_list->deal_key.'_1'.'.png';?>"  alt="<?php echo $products_list->deal_title; ?>" title="<?php echo $products_list->deal_title; ?>"/></a>
          <?php } else { ?>
          <a href="<?php echo PATH.'product/'.$products_list->deal_key.'/'.$products_list->url_title.'.html';?>" title="<?php echo $products_list->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" alt="<?php echo $products_list->deal_title; ?>" title="<?php echo $products_list->deal_title; ?>"/></a>
          <?php }?>
                                            </div>

                                            <div class="deal_list_detail">
                                                <h2><a href="#" title="Computers"><?php echo $products_list->category_name; ?></a></h2>
                                                <h3><a href="<?php echo PATH.'product/'.$products_list->deal_key.'/'.$products_list->url_title.'.html';?>" title="<?php echo $products_list->deal_title;?>"><?php echo substr(ucfirst($products_list->deal_title),0,25)."..";?></a></h3>
                                                <p><span class="price">Price :</span> <span class="usd"><?php echo $symbol." ".$products_list->deal_value; ?></span></p>
                                                <div class="view_deals">
                                                    <div class="view_lft">
                                                        <div class="view_rgt">
                                                            <div class="view_mid">
                                                                
                                                                <a href="<?php echo PATH.'product/'.$products_list->deal_key.'/'.$products_list->url_title.'.html';?>" title="<?php echo 'VIEW DETAILS'; ?>">VIEW DETAILS</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    </li>
                                   <?php } $deal_offset++; ?>


                                </ul>
                            </div>
                        </div>

					 <?php } else { } ?>
                    </div>
                   
                    <!--   my carousel3  -->  
                        <div class="some_of_otheritems">
                         
                            <div class="addres_common">
                                
                                   
                                        <div class="addres_left_cont1">
                                             <div class="map_common_top">
                                                     <div class="pro_title3 branch_detail1 pro_top">
                                    <h2>address</h2>
                                </div>
                                    <div class="map_page">
                             
                                   
                                        <div> 

                                            </div>
                               <div id="map_main" style="width:447px; height:305px;"></div>
                                <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
                                <script type="text/javascript">
                                var latlng = new google.maps.LatLng(<?php echo $products->latitude; ?>,<?php echo $products->longitude; ?>);
                                var myOptions = {

                                zoom: 12,
                                center: latlng,
                                mapTypeId: google.maps.MapTypeId.ROADMAP,
                                navigationControl: true,
                                mapTypeControl: true,
                                scaleControl: true
                                };

                                var map = new google.maps.Map(document.getElementById("map_main"), myOptions);
                                var marker = new google.maps.Marker({
                                position: latlng,
                                animation: google.maps.Animation.BOUNCE
                                });
                                
                                var infowindow = new google.maps.InfoWindow({
                                   content: '<b><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $products->store_name); ?></b><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $products->addr1); ?></p><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $products->addr2); ?></p><p><?php echo $products->city_name; ?>,<?php echo $products->country_name; ?></p>'
                                });

                               google.maps.event.addListener(marker, 'click', function() { 
                                        infowindow.open(map, marker);
                               });
                               marker.setMap(map);
                               
                                </script>
                            </div>
                                <div class="common_all">
                                    <div class="addres_left_right">
                                        <h3><a href="<?php echo PATH.'stores/'.$products->store_key.'/'.$products->store_url_title.'.html';?>" title="<?php echo $products->store_name; ?>"><?php echo $products->store_name; ?></a></h3>
                                        <p><?php echo $products->addr1; ?>,</p>
		                                <p><?php echo $products->addr2; ?>,</p> 
                                        <p><?php echo $products->city_name; ?> - <?php echo $products->zipcode; ?>,  </p>
                                        <p><?php echo $products->country_name; ?></p>
                                        <p><?php echo $this->Lang['MOBILE']; ?>: <?php echo $products->phone; ?></p>
                                        <p><?php echo $this->Lang['WEBSITE']; ?>: <a href="<?php echo $products->website; ?>" target="blank" > <?php echo $products->website; ?></a></p>
                                        
                                    </div>                                    
                                </div>
                                    </div>
                                    <div class="commont_common1">
                                        <div class="pro_title3 branch_detail1 pro_top">
                                    <h2>Comments</h2>
                                </div>
                                        
                                        <div class="face_commont">
                                            <div class="face_comm_top">
                                                <div class="face_top_left">
                                                    <?php if(($this->session->get("UserID")) && file_exists(DOCROOT.'images/user/150_115/'.$this->session->get("UserID").'.png'))  { ?> <img src="<?php echo PATH.'images/user/150_115/'.$this->session->get("UserID").'.png';?>"  alt="side_vdeio"  style="width:50px; height:50px;" />
        <?php }else{ ?>
         <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/comm_user.png"  alt="side_vdeio" border="0"  style="width:50px; height:50px;" />
         <?php } ?>
                                                </div>
                                               <form method="post" >
                                            <div class="face_top_textarea">
                                             <?php  $Url="home"; if($this->uri->segment(1)== "deals"){ $Url="deals"; } ?>
											<input type="hidden" name="deal_key" value="<?php echo $products->deal_key; ?>" />
											<input type="hidden" name="deal_id" id="deal_id"  value="<?php echo $products->deal_id; ?>" />
											<input type="hidden" name="url_title" value="<?php echo $products->url_title; ?>" />
											<input type="hidden" name="last_url" value="<?php echo $Url; ?>" />
											<input type="hidden" name="type" id="type" value="2" />
											<input type="hidden" name="user" id="user_id" value="<?php echo $this->session->get('UserID'); ?>" />
											<textarea name ="comments" placeholder="Add a comment..."  id="comment_box" class="comment_box" ></textarea>
											
                                            <em id="error"></em> 
                                            </div>
                                            
                                                <div class="post_button">
                                                    
                                                    <div class="button1">
                                                            <div class="gren_left_3">
                                                                  <div class="gren_right_3">
                                                                         <div class="gren_mid_3"><input type="button" title="POST" value="POST" onclick="check_comment();" /></div>
                                                                  </div>
                                                            </div>
                                                         
                                                          
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="face_comm_midd">
												<div id="show"> <?php echo new View("themes/".THEME_NAME."/deals/comment");?> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                

                            </div>
                        </div>
                    
					
					
					</div>  


                </div>
                <!--end-->
            </div>
        </div>
       </div>
      </div>
    </div>       
<?php } ?>

<script type="text/javascript"> $(document).ready(function() { 
    Rocket.SizeChart.rows = [{"CHEST (INCH)":"38","SHOULDER(INCH)":"16","LENGTH(INCH)":"27"},{"CHEST (INCH)":"40","SHOULDER(INCH)":"17","LENGTH(INCH)":"28"},{"CHEST (INCH)":"42.5","SHOULDER(INCH)":"18","LENGTH(INCH)":"29"},{"CHEST (INCH)":"45","SHOULDER(INCH)":"19","LENGTH(INCH)":"30"},{"CHEST (INCH)":"47","SHOULDER(INCH)":"19","LENGTH(INCH)":"31"},{"CHEST (INCH)":"49","SHOULDER(INCH)":"20","LENGTH(INCH)":"32"}];
    Rocket.SizeChart.columns = ["CHEST (INCH)","SHOULDER(INCH)","LENGTH(INCH)"];
    Rocket.SizeChart.conversionHoverActive = false;

    Rocket.SizeChart.preparePopup(false);

    // stop highlight animation if user overs list item
    $('#listProductSizes > li').bind('mouseover', function() {
        $(this).stop(false, true);
    });
    $(document).bind("Quicklist.productRemoved", function (e, sku) {
        //We are on the detail page of the product we just removed from quicklist
        //Enable the add to quicklist link
        if ($('#configSku').val() == sku) {
            $('#qlPrdAdded').hide();
            $('#qlPrdAdd').show();
        }
    });$('.tool-tip').hover(function() {
        var tipId = $(this).attr('label');
        var pos = $(this).position();
        $('#' + tipId).css({'top':(pos.top + 10), 'left': (pos.left + 10)});
        $('#' + tipId + ' span').css('background-color', '#fff' );
        $("#" + tipId).fadeIn(200);
    }, function() {
        var tipId = $(this).attr('label');
        $("#" + tipId).fadeOut(200);
    });

    globalConfig.product = globalConfig.product || {};
    globalConfig.product.rDetails = {"sku":"UN573MA91PPSINDFAS","chain":"3270|3328|3329|3330","brand":"United Colors of Benetton","brandId":"573","price":799,"sessionId":"qonohdq1sn843pl0afp0biklg3","userId":"","catId":"3270","cat":"Clothing","brickId":"3330","brick":"Crew Neck T-Shirts"};

    Jabong.image.initSetImage();
    $( '#prdZoomImgPrev' ).live( 'click', function() { Jabong.image.imgNavigate( 'prev' ) } );
    $( '#prdZoomImgNext' ).live( 'click', function() { Jabong.image.imgNavigate( 'next' ) } );

    if(window.location.hash == "#productReviews") {
        $("#productReviewsTab").trigger('click');
    }

    $('#recommSliderSolr').bxSlider({
        mode: 'vertical',
        auto: false,
        displaySlideQty: 3,
        moveSlideQty: 1,
        speed: 250
    });

    Rocket.QuickList.loadList([], []);
});</script>



