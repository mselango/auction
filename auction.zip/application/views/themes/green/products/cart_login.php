<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript"> 
        $(document).ready(function(){
	$('.cancel_login').hide();
	$('.what_happens').hide();
	$('.what_buygift').hide();
	$('.can_change').hide();
	$('#down1').hide();
         $('#down2').hide();
         $('#down3').hide();
});

$('.cancel_login').hide();
function SimilarDeals() {
        $('.cancel_login').show();
        $('.befor_login').hide();
}
function SimilarProducts() {
        $('.befor_login').show();
        $('.cancel_login').hide();
}

</script>
<script type="text/javascript"> 
        function WhatHappens() {
                $('.what_happens').slideToggle(300);
                $('#down1').slideToggle(300);
                $('#right1').slideToggle(300);
                
        }
        function Whatbuygift() {
                 $('.what_buygift').slideToggle(300);
                 $('#down2').slideToggle(300);
                $('#right2').slideToggle(300);
        }
        function CanChange() {
                $('.can_change').slideToggle(300);
                $('#down3').slideToggle(300);
                $('#right3').slideToggle(300);
        }
</script>

                </div>
            </div>
        </div>
        <!--end-->
        <div class="contianer_outer">
            <div class="contianer_inner">
<div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            <li><p><?php echo $this->Lang['PRODUCT_DET']; ?></p></li>
                        </ul>
                    </div>
                <div class="contianer">




                    <!--content start-->
                    <div class="content">
                        <!--Blog content starts-->
                        <div class="blog_left">
                            <div class="blog_left_inner">
                                  <div class="pro_top">
                                <h2><?php echo $this->Lang['PRODUCT_DET']; ?>  </h2>
                                  </div>
                                <div class="about_cont">


                                    <p class="lp-status-text">You currently have
            <?php if($this->session->get('count') != "") { echo $this->session->get('count'); } else { echo "0"; } ?> product(s) in cart. <span class="continue-shop"><a href="<?php echo PATH ?>products.html" title="<?php echo $this->Lang['CONTINUE_SHOPPING'];?>"><?php echo $this->Lang['CONTINUE_SHOPPING'];?></a></span></p>



                                    <div class="lp-order-table">



                                        							<?php  
        $total_amount= "0";
        $empty="";
        foreach($_SESSION as $key=>$value) 
        {
        if(($key=='product_cart_id'.$value)){
                $this->products = new Products_Model();
                $this->get_cart_products = $this->products->get_cart_products($this->session->get($key));
                foreach( $this->get_cart_products as $products){   $empty="1"; ?>
                
                
                <?php }}}?>
                <?php if($empty){ ?>	
                                        <div class="lp-table-heading-text">
                                            <div class="lp-table-heading-text-left">
                                                <div class="lp-tb-img">Image</div>
                                            </div>
                                            <div class="lp-table-heading-text-right">
                                                <div class="lp-tb-desc">Description</div>
                                                <div class="lp-tb-price">Price</div>						

                                            </div>
                                        </div>
                                        <?php } ?>
                                        					<?php  
$total_amount= "0";
        foreach($_SESSION as $key=>$value) 
        {
                if(($key=='product_cart_id'.$value)){
                        $this->products = new Products_Model();
                        $this->get_cart_products = $this->products->get_cart_products($this->session->get($key));
                        foreach( $this->get_cart_products as $products){?>
                                        <div class="lp-table-content-text">

                                            <div class="lp-table-content-left">
                                               <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products->deal_key.'_1'.'.png')){ ?>
                        <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH.'images/products/100_100/'.$products->deal_key.'_1'.'.png';?>"  alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>
                        <?php } else { ?>
                        <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" width="80" height="80" alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>
                        <?php }?> 
                                            </div>
                                            <div class="lp-table-content-right">
                                                <div class="lp-tb-desc-text2">

                                                    <p class="lp-desc-title"><a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><?php echo $products->deal_title; ?></a></p>
                                                    <p class="lp-desc-text"><?php echo text::limit_words($products->deal_description,12, '&nbsp;'); ?></p>

                                                </div>
                                                <?php  $total_amount +=$products->deal_value; ?>
                                                <div class="lp-tb-price-value"><?php  echo CURRENCY_SYMBOL.$products->deal_value; ?></div>	

                                                <div class="lp-tb-delete">
                                                    <a href="<?php echo PATH.'payment_product/cart_remove/product_cart_id'.$value;?>" title="<?php echo $this->Lang['DELETE']; ?>">&nbsp;</a>
                                                </div>

                                            </div>

                                        </div>
					                     <?php 
                        }
                } 
        }
?>

                                       

<?php if($total_amount!=0)
{ ?>
                                        <div class="checkout-section">
                                            <div class="continue-shop-text"><a href="<?php echo PATH ?>products.html"><?php echo $this->Lang['CONTINUE_SHOPPING']; ?></a>&nbsp;&nbsp;&nbsp;Or</div>
                                            <div class="checkout-button">
                                                <div class="checkout-but-left">
                                                     <div class="checkout-but-right">
                                                           <div class="checkout-but-mid">
                                                    <a <?php if($this->UserID){ ?>   href="<?php echo PATH ?>cart_checkout.html"  <?php } else { ?> href="javascript:showlogin();" <?php } ?> title="<?php echo $this->Lang['PROCEDURE']; ?>"><?php echo $this->Lang['PROCEDURE']; ?></a>
                                                </div>
                                                </div>
                                                </div>
                                              
                                               

                                            </div>


                                        </div>
                                        <?php } else { ?> 
                                        <div class="content_empt_lft">
                                                
                                                  <h2><?php echo $this->Lang['YOUR_SHOPPING_BAG'];?></h2>
                                                
                                                 <div class="complete-order-button">
                                                
                                    <div class="ora_left_1">
                                        <div class="ora_right_1">
                                            <div class="ora_mid2_1">
                                                 <a href="<?php echo PATH ?>products.html">
                                                <?php echo $this->Lang['CONTINUE_SHOPPING']; ?>
                                                     </a>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                        </div>  
                                        
                                        <div class="content_empt_rgt">
                                <img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cat_ta_img.png"/>
                            </div>                                              
                                        
                                        <?php } ?>
                                        <div class="account-info-panel1 befor_login">
                                            <div class="pro_top">
                                            <h2 style="padding:0;">Account Information</h2>
                                            </div>
                                            <div class="acc-login-panel">
                                                <div class="acc-login-panel-left1">
                                                </div>
                                                <div class="acc-login-panel-mid1 ">
                                                        <div class="acc-login-form1">
                                                            <div class="acc_login_text"><p><?php echo $this->Lang['ALREADY_ACC'];?>
                                                                </p>
                                                                <p><?php echo $this->Lang['PURCHACED_GR'];?></p></div> 
																
                                                            <div class="sign_up_submit_outer1">  
                                                                <div class="button1">
                                                                    <div class="but_lft">
                                                                           <div class="but_rgt">
                                                                                   <div class="but_mid"><a style="cursor:pointer;"onclick="return SimilarDeals();" id="SimilarDeals"  title="Sign in"/><?php echo $this->Lang['LOGIN'];?></a></div>
                                                                           </div>
                                                                    </div>
                                                                
                                                                 
                                                                </div>

                                                            </div>
                                                        </div>
                                                    
                                                </div>
                                                <div class="acc-login-panel-right1">
                                                </div>
                                            </div>
                                        </div>
                                        
                                         <div class="account-info-panel1 cancel_login" id="login" >
                                             <div class="pro_top" style="padding:0;">
                                             <h2>Account Information</h2>
                                             </div>
                                    <div class="acc-login-panel">
                                        <div class="acc-login-panel-left1">
                                        </div>
                                        <div class="acc-login-panel-mid1">
                                           <form method="post" action="<?php echo PATH;?>payment_product/p_login">
                                                <div class="acc-login-form1">

                                                    <div class="login_form1">
                                                        <ul>
                                                            <li>
                                                                <label>Email:</label>
                                                                <div class="fullname1"><input name="email" placeholder="<?php echo $this->Lang['ENTER_EMAIL']; ?>" type="text"  /></div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="login_form_pass1">
                                                        <ul>
                                                            <li>
                                                                <label>Password:</label>
                                                                <div class="fullname1"><input name="password"  placeholder="<?php echo $this->Lang['ENTER_PASS']; ?>" type="password" /></div>
                                                                <label class="acc-login-forgot-pass-text1"><a onclick="showforgotpassword();" style="cursor:pointer;" title="<?php echo $this->Lang['FORGOT_PASS']; ?>"><?php echo $this->Lang['FORGOT_PASS']; ?></a></label>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="sign_up_submit_outer1">  
                                                        <div class="button1">
                                                            <div class="but_lft">
                                                                 <div class="but_rgt">
                                                                       <div class="but_mid"><input name="Submit" type="submit" value="<?php echo $this->Lang['LOGIN'];?>" title="Login"/></div>
                                                                 </div>
                                                            </div>
                                                          
                                                           
                                                        </div>
                                                        <div class="cancel">
                                                            <div class="sub_lft1">
                                                                 <div class="sub_rgt1">
                                                                      <div class="sub_mid1"><a style="cursor:pointer;" title="Cancel" "class="cancle" onclick="return SimilarProducts();"  id="SimilarProducts"  ><?php echo $this->Lang['CANCEL'];?></a></div>
                                                                 </div>
                                                            </div>
                                                           
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="acc-login-panel-right1">
                                        </div>
                                    </div>
                                </div>
                                
                                
                                        <div class="personal-info-panel1">

                                            <div class="branch_detail branch_detail1 pro_top">
                                            <h2><?php echo $this->Lang['PERSONAL_INFO'];?></h2>
                                            </div>
                                            <form method="post" action="<?php echo PATH;?>payment_product/p_signup">
                                            <div class="per-info-section1">

                                                <div class="personal-info-left1">

                                                    <div class="contact_form_2">
                                                        <ul>
                                                            <li>
                                                                <label><?php echo $this->Lang['NAME']; ?>:</label>
                                                                <div class="fullname"><input name="f_name" size="40" placeholder="<?php echo $this->Lang['ENTER_NAME']; ?>" type="text" value="<?php if(!isset($this->form_error['f_name']) && isset($this->userPost['f_name'])){ echo $this->userPost['f_name']; } ?>" />
                                                                <em><?php if(isset($this->form_error['f_name'])){ echo $this->form_error["f_name"]; }?></em>
                                                                </div>
                                                            </li>
                                                            
                                                            <li>
                                                                <label><?php echo $this->Lang['EMAIL']; ?>:</label>
                                                                <div class="fullname"><input name="email" placeholder="<?php echo $this->Lang['ENTER_EMAIL']; ?>" type="text" value="<?php if(!isset($this->form_error['email']) && isset($this->userPost['email'])){echo $this->userPost['email'];} else if(isset($this->email)){ echo $this->email; }?>" size="40"  /> <em><?php if(isset($this->form_error['email'])){ echo $this->form_error["email"]; }?> </em></div>
                                                            </li>
                                                            <li>
                                                                <label><?php echo $this->Lang['PASSWORD']; ?>:</label>
                                                                <div class="fullname"><input name="password"  placeholder="<?php echo $this->Lang['ENTER_PASS']; ?>" type="password" value="" size="40"/> <em> <?php if(isset($this->form_error['password'])){ echo $this->form_error["password"]; }?> </em></div>
                                                            </li>

                                                            <li>
                                                                <label><?php echo $this->Lang['SEL_CITY']; ?>:</label>
                                                                <div class="fullname">
                                                                    <select name="city">
                    <?php $cityid = $this->city_id;
				if(isset($this->current_cityid)){ $cityid = $this->current_cityid;}
				$cityURL = "";
				foreach($this->all_city_list as $CData){ if($CData->city_id == $cityid){ $cityURL = $CData->city_url.".html";?>
                    <option value="<?php echo $CData->city_id; ?>"><?php echo ucfirst($CData->city_name); ?></option>
                    <?php 	}
					}
					foreach($this->all_city_list as $CityL){ ?>
                    <option <?php if($CityL->city_url==$this->input->get('city')){ echo 'Selected="true"'; } ?> value="<?php echo $CityL->city_id; ?>"><?php echo ucfirst($CityL->city_name); ?></option>
                    <?php } ?>
                  </select>
                                                                </div>

                                                            </li>
                                                        </ul>
														
                                                       <div class="complete-order-button">
                                                        <div class="ora_left">
                                                              <div class="ora_right">
                                                                   <div class="ora_mid2">
                                                            <input type="submit" value="Complete Order" title="Complete Order" />
                                                        </div>
                                                                  
                                                        </div>
                                                        </div>
                                                       
                                                      
														
                                                    </div>
                                                        <div class="payment_terms_outer">
                                                            <p  id="terms1" class="terms-conditons-text">
                                                                <span class="fl font_myriad_pro">By clicking Complete Order I accept the </span>
                                                                <a class="font_myriad_pro mt5" title="<?php echo $this->Lang['TERMS_COND']; ?>" href="<?php echo PATH;?>terms-and-conditions.php"><?php echo $this->Lang['TERMS_COND']; ?>.</a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    </FORM>

                                                </div>



                                            </div>
                                            <!--<p class="terms-conditons-text">By clicking Complete Order I accept the <a href="#" title="Terms & Conditions">Terms and contitions.</a></p>-->

                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                        <div class="blog_right1">

                            <div class="payment-faq-container">
                                <p class="faq-heading-text"><?php echo $this->Lang['PAY_MEN']; ?></p>
                                
                                <div class="faq-content2">
						<div class="faq-content-heading" onclick="return WhatHappens();">
													
							<div class="faq-content-heading-left" id="right1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
						</div>
					     <div class="what_happens">
						<div class="faq-content-text">
						    
							<p><?php echo $this->Lang['WHILE_BUY_A_PRODUCT']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content2">
						<div class="faq-content-heading" onclick="return Whatbuygift();">
							
							<div class="faq-content-heading-left" id="right2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
						</div>
						  <div class="what_buygift">  
						<div class="faq-content-text">
							<p><?php echo $this->Lang['ITS_QUITE_OPTIONAL']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content3">
						<div class="faq-content-heading" onclick="return CanChange();">
							<div class="faq-content-heading-left" id="right3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
						</div>
						<div class="can_change">

						<div class="faq-content-text">
							<p><?php echo $this->Lang['OBVIOUSLY_YES']; ?></p>
						</div>
						</div>
					</div>
				</div>




                        </div>
                    </div>
                    <!--Blog content ends-->
                </div>
            </div>
        </div>




    </body>

</html>












