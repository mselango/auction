<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript"> 
        $(document).ready(function(){  
        $('.cancel_login').hide();
        $('.what_happens').hide();
        $('.what_buygift').hide();
        $('.can_change').hide();
        $('#down1').hide();
        $('#down2').hide();
        $('#down3').hide();
        });
</script>

<script type="text/javascript"> 
        function WhatHappens() {
                $('.what_happens').slideToggle(300);
                $('#down1').slideToggle(300);
                $('#right1').slideToggle(300);
                
        }
        function Whatbuygift() {
                 $('.what_buygift').slideToggle(300);
                 $('#down2').slideToggle(300);
                $('#right2').slideToggle(300);
        }
        function CanChange() {
                $('.can_change').slideToggle(300);
                $('#down3').slideToggle(300);
                $('#right3').slideToggle(300);
        }
</script>
				</div>
            </div>
        </div>
        <div class="contianer_outer">
            <div class="contianer_inner">
                <div class="contianer">
                    <div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            <li><p><?php echo $this->Lang['PRODUCT_DET']; ?></p></li>

                        </ul>
                    </div>
              



                    <!--content start-->
                    <div class="content">
                        <!--Blog content starts-->
                        <div class="blog_left">
                            <div class="blog_left_inner">
                                 <div class="pro_top">
                                <h2><?php echo strtoupper($this->Lang['PRODUCT_DET']); ?></h2>
                                 </div>
                                        <div class="about_cont">


                                            
                                            <p class="lp-status-text"><?php echo $this->Lang['YOU_CURRENTLY_HAVE']; ?>
                <?php if($this->session->get('count') != "") { echo $this->session->get('count'); } else { echo "0"; } ?>
                <?php echo "product(s) in your shopping cart"; ?> <span class="continue-shop"><a href="<?php echo PATH ?>products.html" style="cursor:pointer"><?php echo $this->Lang['CONTINUE_SHOPPING'];?></a> <?php if($this->session->get('count') != 0) { ?></span><?php echo $this->Lang['OR'];?> <span class="continue-shop"><a href="<?php echo PATH ?>cart_checkout.html"><?php echo $this->Lang['PROCEDURE']; ?></a></span><?php } ?> </p> 

                                            <div class="lp-order-table">




                                               <?php  
        $total_amount= "0";
        $empty="";
        foreach($_SESSION as $key=>$value) 
        {
        if(($key=='product_cart_id'.$value)){
                $this->products = new Products_Model();
                $this->get_cart_products = $this->products->get_cart_products($this->session->get($key));
                foreach( $this->get_cart_products as $products){   $empty="1"; ?>
                
                
                <?php }}}?>
                <?php if($empty){ ?>	
                                        <div class="lp-table-heading-text">
                                            <div class="lp-table-heading-text-left">
                                                <div class="lp-tb-img">Image</div>
                                            </div>
                                            <div class="lp-table-heading-text-right">
                                                <div class="lp-tb-desc">Description</div>
                                                <div class="lp-tb-price">Price</div>						

                                            </div>
                                        </div>
                                        <?php } ?>
                                                <?php  
$total_amount= "0";
        foreach($_SESSION as $key=>$value) 
        {
                if(($key=='product_cart_id'.$value)){
                        $this->products = new Products_Model();
                        $this->get_cart_products = $this->products->get_cart_products($this->session->get($key));
                        foreach( $this->get_cart_products as $products){?>
                                        <div class="lp-table-content-text">

                                            <div class="lp-table-content-left">
                                               <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products->deal_key.'_1'.'.png')){ ?>
                        <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH.'images/products/100_100/'.$products->deal_key.'_1'.'.png';?>"  alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>
                        <?php } else { ?>
                        <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" width="80" height="80" alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>
                        <?php }?> 
                                            </div>
                                            <div class="lp-table-content-right">
                                                <div class="lp-tb-desc-text2">

                                                    <p class="lp-desc-title"><a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><?php echo $products->deal_title; ?></a></p>
                                                    <p class="lp-desc-text"><?php echo text::limit_words($products->deal_description,12, '&nbsp;'); ?></p>

                                                </div>
                                                <?php  $total_amount +=$products->deal_value; ?>
                                                <div class="lp-tb-price-value"><?php  echo CURRENCY_SYMBOL.$products->deal_value; ?></div>	

                                                <div class="lp-tb-delete">
                                                    <a href="<?php echo PATH.'payment_product/cart_remove/product_cart_id'.$value;?>" title="<?php echo $this->Lang['DELETE']; ?>">&nbsp;</a>
                                                </div>

                                            </div>

                                        </div>
					                     <?php 
                        }
                } 
        }
?>

<?php if($total_amount != 0) { ?>
                                                <div class="checkout-section">
                                                <a class="gift_card" <?php if($this->session->get("UserID")){ ?>href="<?php echo PATH.'product/payment_details_friend.html';?>" <?php }else{ ?>onclick="showlogin();" style="cursor:pointer;"<?php } ?> title="Buy it  for friend"> Buy it  for friend </a> 
                                                    <div class="continue-shop-text"><a href="<?php echo PATH ?>products.html"><?php echo $this->Lang['CONTINUE_SHOPPING']; ?></a>&nbsp;&nbsp;&nbsp;Or</div>
                                                    
                                                    
                                                    
                                                     <div class="checkout-button">
                                                        <div class="checkout-but-left">
                                                             <div class="checkout-but-right">
                                                                   <div class="checkout-but-mid">
                                                           <a <?php if($this->UserID){ ?>   href="<?php echo PATH ?>cart_checkout.html"  <?php } else { ?> href="javascript:showlogin();" <?php } ?> title="<?php echo $this->Lang['PROCEDURE']; ?>"><?php echo $this->Lang['PROCEDURE']; ?></a>
                                                        </div>
                                                        </div>
                                                        </div>
                                                      
                                                       

                                                    </div>                                                  
                                               
                                                </div>                                               
                                                
                                                 <?php } else { ?>                                               
                                                
                                                
                                                 <div class="content_empt_lft">
                                                
                                                  <h2>Your shopping Cart is empty.</h2>
                                                
                                                 <div class="complete-order-button">
                                                
                                    <div class="ora_left_1">
                                        <div class="ora_right_1">
                                            <div class="ora_mid2_1">
                                                 <a href="<?php echo PATH ?>products.html">
                                                <?php echo $this->Lang['CONTINUE_SHOPPING']; ?>
                                                     </a>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                        </div>  
                                        
                                        <div class="content_empt_rgt">
                                <img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cat_ta_img.png"/>
                            </div>                                              
                          <?php } ?>
                                                

                                            </div>

                                        </div>

                            </div>
                        </div>
                         <div class="blog_right1">

                            <div class="payment-faq-container">
                                <p class="faq-heading-text"><?php echo $this->Lang['PAY_MEN']; ?></p>
                                
                                <div class="faq-content2">
						<div class="faq-content-heading" onclick="return WhatHappens();">
													
							<div class="faq-content-heading-left" id="right1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
						</div>
					     <div class="what_happens">
						<div class="faq-content-text">
						    
							<p><?php echo $this->Lang['WHILE_BUY_A_PRODUCT']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content2">
						<div class="faq-content-heading" onclick="return Whatbuygift();">
							
							<div class="faq-content-heading-left" id="right2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
						</div>
						  <div class="what_buygift">  
						<div class="faq-content-text">
							<p><?php echo $this->Lang['ITS_QUITE_OPTIONAL']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content3">
						<div class="faq-content-heading" onclick="return CanChange();">
							<div class="faq-content-heading-left" id="right3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
						</div>
						<div class="can_change">
						<div class="faq-content-text">
							<p><?php echo $this->Lang['OBVIOUSLY_YES']; ?></p>
						</div>
						</div>
					</div>
				</div>



                        </div>
                    </div>
                    <!--Blog content ends-->
                    
                </div>
            </div>
        </div>
        
