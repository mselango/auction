<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>


<?php /* Pagination */ ?>
<script type="text/javascript">
    $(document).ready(function () {
	


        $('a.view_more1').live("click", function(e){
            var offset  = 0;
            offset = document.getElementById('offset').value;
            var record = document.getElementById('record').value;
            var record1 = document.getElementById('record1').value;
	    
            var url = '<?php echo PATH; ?>'+'products/all_products_1?offset='+offset+'&record='+record;
            $.post(url,function(check){ 

                if(check){ 
				  
                    $('#product').append(check);
                    $('#loading').show();
                    offset = parseInt(offset)+8;

                    $("#offset").val(offset);

                    if(offset >= record1 ) {

                        $('#loading').hide();

                    }

                }
            });     
        
        });
    });

</script>



    <div class="contianer_outer">
        <div class="contianer_inner">
            <div class="contianer">
                <div class="bread_crumb">
					<ul>
						<li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
						<li><p>
								<?php if (($this->uri->last_segment() != "products.html") && ($this->uri->last_segment() != "search.html")) { ?>
								<a href="<?php echo PATH; ?>products.html" title="<?php echo $this->Lang['PRODUCTS']; ?>"><?php echo $this->Lang["PRODUCTS"]; ?></a></p>
							<?php } else {
								echo $this->Lang['PRODUCTS1'];
							} ?>
						</li>
						<?php if (($this->uri->last_segment() != "products.html") && ($this->uri->segment(2) != "page")) { ?>

						<li class="bread_crum_about">
														
							<?php if(isset($this->sub_cat)) { ?>
								<p><a href="<?php echo PATH; ?>products/category/main/<?php echo strtolower($this->category_name); ?>.html"><?php echo $this->category_name; ?></a>&nbsp;&nbsp;&nbsp;<?php echo $this->sub_cat; ?></p>
							<?php } else { ?>
								<p>  <?php echo $this->category_name; ?></p>
							<?php } ?>
						</li>
					<?php } ?>
					</ul>
				</div>
          <?php if (count($this->all_products_list) > 0) { ?>      
                
                
                
                <!--content start-->
                <div class="content">
                    <!--sidebar start-->
                    <div class="conntent_left">
                        <div class="cat_outer1">
                            <div class="category2">
                                <h1>Categories</h1>
                                <form action="" method="get" name="form1"  >
                                    <ul>

                                        <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
                                        $cat1 = array_unique($cat);
                                  
                                        ?>

										<?php foreach ($this->category_list as $d) {
											if ($d->product == 1) { ?>

                                                <li>
                                                   <span class="cate_check">
														 </span> 

               <?php $type="products"; $categories=$d->category_url; ?>
              
                                  


											<a style="cursor:pointer;" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo $d->category_name; ?>"   class="sample" id="sample-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>">
												 <?php echo ucfirst($d->category_name); ?>
											</a>
                                            <div class="sub_menu_top1">	
                                                <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;">


                                                <div id="categeory-<?php echo $d->category_id; ?>">
													<?php echo new View("themes/" . THEME_NAME . "/products/sub_categorey_list"); ?>

                                                </div></a>
                                       
                                                </ul>
                                            </div>
                                                </li>


								<?php }  } ?>
   
                                        <input type="submit" value="submit" id="submit" style="display:none;">
                                    </ul>
                                </form>

                                <script type="text/javascript">
                                    $(function() {
    		
                                        $('.sample').mouseover(function() {
                                            var getUID =  $(this).attr('id').replace('sample-','');
                                            var url = Path+"products/all_products/?cate_id="+getUID;

    	
                                            $.post(url,function(check){

    			
                                                if(getUID!=""){
    				
                                                    $('#categeory-'+getUID).html(check);
    			
            
                                                    $('#categeory-'+getUID).show();
              

                                                }
    	
    			
    			
    			
                                            });

                                        }); 


                                    });  
      

                                </script>            

                            </div>		

                        </div>
<?php /*
                        <div class="cat_outer2">
                            <div class="category">	
                                <form action="" method="get" name="form1"  >						 
                                    <h1>Sizes</h1>
    <?php $cat = explode(",", substr($this->session->get('size'), 0, -1));
    $cat1 = array_unique($cat);
    ?>
    <?php foreach ($this->size_list as $size) { ?>
                                        <div class="apparel_size">
                                            <div class="apparel_size_left">
                                                <span><input  type="checkbox" name="size1[]" onclick="change_category1();" <?php foreach ($cat1 as $c) {
            if ($size->size_id == $c) { ?> checked <?php }
        } ?> value="<?php echo $size->size_id; ?>" /></span>
        <?php /*         * <input type="checkbox" id="size" onclick="filter_size('<?php echo $size->size_id; ?>');" />  */ ?> <?php /* <p><?php echo $size->size_name; ?></p>
                                            </div>
                                        </div>
    <?php } ?>
                                    <input type="submit" value="submit" id="submit_1" style="display:none;">
                                </form>
                            </div>
                        </div>
*/ ?>
                        <div class="cat_outer2">

                            <div class="category" style="padding-bottom:10px;">							 
                                <h1>Price Range</h1>


                                <div class="catogory_list2 fl clr">


                                    <div id="slider-range"></div>

                                    <br/>
                                    <div><input type="text"style="float:left;  height:25px;font:normal 12px/25px arial;color:#787878; border:none; background: #fff; text-align: center; border:1px solid #d4d4d4; margin-left: 23px; margin-top:6px;" id="amount" style="border:none; color:#333;  font-weight:normal;" readonly="readonly" name="amount"/></div>
                                    <br/>
                                    <br/>
                                </div>
                            </div>
                        </div>

<?php /*
                        <div class="cat_outer3">

                            <div class="category">				 
                                <h1>Colors <?php if(isset($this->color_filter)){ ?>
                                <a href="<?php echo PATH.'products.html'?>" class="a_reset">Reset</a>
                                <?php }?></h1>
                                
                            </div>
                            <div class="color_left23">
                                <div class="chose_color1">   
                                    <ul>

                                        <?php  foreach ($this->color_list as $color) { ?>     

                                            <li>
                                                <a  name="color"  class="<?php if($this->color_id==$color->color_id){ ?> active <?php } ?>"    onclick="filtercolor('<?php echo $color->color_id; ?>');" title="color1" >                                             

                                                    <span class="choose_color_div" style="background:#<?php echo $color->color_name; ?>;"> </span>

                                                </a>  


                                            </li>

   					 <?php } ?>

                                    </ul>

                                </div>

                            </div>
                        </div>
                        */ ?>
                    </div>


                    <!--end-->
                    <div class="content_right">



                        <!-- product list-->


                        <!--feture deal-->


                        <!--action deal list-->
                        <div class="product_details_list">
                            <div class="pro_top">
                                <div class="pro_title"><h2>PRODUCTS</h2></div>
                                <!--a class="view_more" href="#" title="VIEW MORE ">VIEW MORE</a-->
                            </div>
                            <div class="pro_mid" id="product">

    <?php echo new View("themes/" . THEME_NAME . "/products/products_list"); ?>

                            </div>
    <?php if (($this->uri->last_segment() == "products.html") && ($this->all_products_count > 1)) { ?>
                                <div id="loading">
        <?php if (($this->pagination) != "") { ?> 
                                        <div class="feature_viewmore">
                                            <div class="fea_view_more">
                                                <div class="view_more_inne">
                                                    <div class="viewmore_lft"></div>
                                                    <div class="viewmore_midd">
                                                        <a style="cursor:pointer;" class="view_more1">-------See More Products-------</a>
                                                    </div>
                                                    <div class="viewmore_rgt"></div>
                                                </div>
                                            </div>
                                        </div>
        <?php } ?>
                                </div>
    <?php } ?> 
                        </div>
                    </div>


                </div>
            </div>
            <!--end-->
            <?php } else { ?>
    <?php echo new View("themes/" . THEME_NAME . "/subscribe"); ?>
<?php } ?>
        </div>
    </div>
    </div>
    <!--scroll filter start-->
    <input type="hidden" name="offset" id="offset" value="8">
    <input type="hidden" name="record" id="record" value="8">
    <input type="hidden" name="record" id="record1" value="<?php echo $this->all_products_count; ?>">

    <!--scroll filter end-->



<!--price and discount script-->
<link rel="stylesheet" href="<?php echo PATH.'themes/'.THEME_NAME.'/css/jquery-ui.css' ?>" />
<script src="<?php echo PATH.'themes/'.THEME_NAME.'/js/jquery-ui.js' ?>"></script>
<script>
		
    $(function() { 
        $( "#slider-range" ).slider({


            range: true,
            min: <?php echo $this->pro_min; ?>,
            max: <?php echo $this->pro_max; ?>,
            values: [<?php echo $this->pro_min; ?>,<?php echo $this->pro_max; ?>  ],
            slide: function( event, ui ) {

                $( "#amount" ).val("<?php echo CURRENCY_SYMBOL; ?>"+ui.values[ 0 ] + " - " +"<?php echo CURRENCY_SYMBOL; ?>"+ ui.values[ 1 ] );
		
                var amo=$( "#amount" ).val();
		


                var url = Path+"products/ajax_post_products/?amount="+amo;
                $.post(url,function(check){
                    $('#product').html(check);
		  			$('div#loading').hide();
		    
                });
					
            },
				
        });
			
        $( "#amount" ).val("<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 0 ) +
            " - " +"<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 1 ) );
	
    });
</script>		 
<!--price filter end--> 



