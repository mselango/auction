<?php foreach($this->categeory_list as $cate){ $type = "products"; ?>


<li><a href="javascript:filtercategory('<?php echo $cate->category_url; ?>','<?php echo $type; ?>','sub');" title="<?php echo ucfirst($cate->category_name); ?>"><?php echo $cate->category_name;?></a> </li>

<?php } ?>
