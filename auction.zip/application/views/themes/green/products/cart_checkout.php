<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript"> 
        $(document).ready(function(){ 
        	function blink(selector){
            $(selector).fadeOut('slow', function(){
            $(this).fadeIn('slow', function(){
            blink(this);
            });
            });
            }   
            blink('.blink');
        <?php if($this->paypal_setting) { ?> 
            $('.cancel_login').hide();
        <?php } else { ?>
            $('.befor_login').hide();
            $('.cancel_login').show();
        <?php } ?>
        $('.AuthorizeNet_pay').hide();
		$('.cash_pay').hide();
        $('.what_happens').hide();
        $('.what_buygift').hide();
        $('.can_change').hide();
        $('.ref_paypal').hide();
        $('#down1').hide();
        $('#down2').hide();
        $('#down3').hide();
        
        
        
        
var tooltipTimeout;
$("#someelem").hover(function()
{tooltipTimeout = setTimeout(showTooltip, 2);}, 
hideTooltip);
function hideTooltip()
    {
    clearTimeout(tooltipTimeout);
    $("#tooltip").fadeOut().remove();
    }
    
    
    var tooltipTimeouttax;
$("#someelemtax").hover(function()
{tooltipTimeouttax = setTimeout(showTooltiptax, 2);}, 
hideTooltiptax);
function hideTooltiptax()
    {
    clearTimeout(tooltipTimeouttax);
    $("#tooltiptax").fadeOut().remove();
    }
    
    function showTooltiptax()
            {
                
            var tooltiptax = $("<div id='tooltiptax' class='tooltiptax'> Tax Amount = <?php echo TAX_PRECENTAGE_VALUE; ?>% <br> Total Amount = Total + Shipping Amount <br> Tax = (Tax Amount/100)* Total Amount </div>");
            tooltiptax.appendTo($("#someelemtax"));
            }

        });
</script>

<script type="text/javascript"> 
        $('.cancel_login').hide();
        function SimilarDeals() {
                $('.cancel_login').show();
                $('.befor_login').hide();
                $('.AuthorizeNet_pay').hide();
				$('.cash_pay').hide();
        }
        function SimilarProducts() {
                $('.befor_login').show();
                $('.cancel_login').hide();
                $('.AuthorizeNet_pay').hide();
				$('.cash_pay').hide();
        }
        function Authorize() {
                $('.befor_login').hide();
                $('.cancel_login').hide();
                $('.AuthorizeNet_pay').show();
				$('.cash_pay').hide();
        }
		function cash_delivery() {
				$('.cash_pay').show();
                $('.befor_login').hide();
                $('.cancel_login').hide();
                $('.AuthorizeNet_pay').hide();
				
        }
        
</script>

<script type="text/javascript"> 
        function WhatHappens() {
                $('.what_happens').slideToggle(300);
                $('#down1').slideToggle(300);
                $('#right1').slideToggle(300);
                
        }
        function Whatbuygift() {
                 $('.what_buygift').slideToggle(300);
                 $('#down2').slideToggle(300);
                $('#right2').slideToggle(300);
        }
        function CanChange() {
                $('.can_change').slideToggle(300);
                $('#down3').slideToggle(300);
                $('#right3').slideToggle(300);
        }
</script>

                </div>
            </div>
        </div>
        <!--end-->
        <div class="contianer_outer">
            <div class="contianer_inner">
                    <div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            <li><p><?php echo $this->Lang['PRO_PAY']; ?></p></li>
                        </ul>
                    </div>
                <div class="contianer">

                    <!--content start-->
                    <div class="content1_2">
                        <!--Blog content starts-->
                        <div class="blog_left">
                            <div class="blog_left_inner">
                                  <div class="pro_top">
                                <h2><?php echo $this->Lang['PRO_PAY']; ?></h2>
                                  </div>
                                <div class="about_cont">


                                    <p class="lp-status-text">You currently have <?php if($this->session->get('count') != "") { echo $this->session->get('count'); } else { echo "0"; } ?> product(s) in cart.</p>

                                    <div class="lp-order-table">




                                        <div class="lp-table-heading-text">
                                            <div class="lp-table-heading-text-left">
                                                <div class="lp-tb-img"><?php echo $this->Lang['IMAGE']; ?></div>
                                            </div>
                                            <div class="lp-table-heading-text-right2">
                                                <div class="lp-tb-desc2" style="width: 290px;"><?php echo $this->Lang['DESC']; ?></div>
                                                <div class="tb-qty2"><?php echo $this->Lang['QUAN']; ?></div>

                                                <div class="lp-tb-price2" style=" width: 46px;"><?php echo $this->Lang['PRI']; ?></div>
                                                <?php if($this->shipping_setting  == 4){ ?>
							                     <div class="tb-total1">Shipping</div>
							                    <?php } ?>
							
                                                <div class="tb-total1"><?php echo $this->Lang['TOTAL']; ?></div>

                                            </div>
                                        </div>
                                        <?php
						$total_amount= "0";
						$shippingamount ="0";
						$flatamount = "0";
						$per_productshipping = "0";
						$add_productshipping = "0";
						$itemshippingamount = "0";
						$taxamount = "0";

						if($this->shipping_setting  == 3){

							foreach($_SESSION as $key=>$value){
								if(($key=='product_cart_id'.$value)){
										$this->products = new Products_Model();
										$this->get_cart_products = $this->products->get_cart_products($this->session->get($key));
											foreach( $this->get_cart_products as $products){ 
												$per_productshipping += $products->shipping_amount; 
												$add_productshipping .= number_format((float)$products->shipping_amount, 2, '.', '')." + <br> "; 
												
											 }
								} ?>
								
								<script type="text/javascript"> 
												function showTooltip()
                                                {
                                                    
                                                var tooltip = $("<div id='tooltip' class='tooltip'><?php echo $add_productshipping; ?> <hr> Shipping Amount = <?php echo number_format((float)$per_productshipping, 2, '.', ''); ?>   </div>");
                                                tooltip.appendTo($("#someelem"));
                                                }
                                                
                                                
                                                </script>
							<?php }
						} ?>
						
						<?php foreach($_SESSION as $key=>$value) 
        {
                if(($key=='product_cart_id'.$value)){
                        $this->products = new Products_Model();
                        $this->get_cart_products = $this->products->get_cart_products($this->session->get($key));
                        foreach( $this->get_cart_products as $products){ 
                        $get_size_name = $this->products->get_size_data($products->deal_id);
                        $get_color_data = $this->products->get_color_data($products->deal_id);
                        $taxamount = TAX_PRECENTAGE_VALUE;
                        
                        /* 1- Free Shipping ,  2- Flat Shipping, 3- Per Product Shipping , 4- Per Item Shipping */
                        if($this->shipping_setting  == 1){
                        $shippingamount = 0;
                        } elseif($this->shipping_setting  == 2){
                        $shippingamount = 0;
                        $flatamount = FLAT_SHIPPING_AMOUNT;
                        } elseif($this->shipping_setting  == 3){                        
                        $shippingamount = 0;
                        $flatamount = $per_productshipping;                        
                        } elseif($this->shipping_setting  == 4){
                        $itemshippingamount = $products->shipping_amount;
                        $shippingamount = $products->shipping_amount;
                        }
                        
                        
                        ?>
                                        <div class="lp-table-content-text">

                                            <div class="lp-table-content-left" style="width: 102px;">
                                                <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products->deal_key.'_1'.'.png')){ ?>
                        <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH.'images/products/290_215/'.$products->deal_key.'_1'.'.png';?>" width="80" height="80" alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>

                        <?php } else { ?>
                        <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" width="80" height="80" alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>

                        <?php }?> 
                                            </div>
                                            <div class="lp-table-content-right" style=" width: 592px;">
                                                <div class="lp-tb-desc-text" style="width:283px;">

                                                    <p class="lp-desc-title"><a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>"><?php echo $products->deal_title; ?></a></p>
                                                    <p class="lp-desc-text"><?php echo substr($products->deal_description,0,50); ?></p>
													
													
                                
													<div  class="ip_desc_common">
                                                            <div class="color_red">
																<div class="select_color_text">
																<?php if(count($get_color_data)>0){ foreach($get_color_data as $gc){
                                if($gc->color_code_id == $this->session->get('product_color_qty'.$products->deal_id)){ ?>
                                <p class="cc-desc-title" ><p>Selected color: <span><?php echo $gc->color_code_name; ?></span></p> </p>                                
                                <?php } } } ?>
																 </div>
																 
																 
																 <div class="select_color_text">
																 <?php $nosize = ""; if(count($get_size_name)>0){ foreach($get_size_name as $gs){
                                if($gs->size_name=="None"){ $nosize = 1;    $this->session->set('product_quantity_qty'.$products->deal_id,$gs->quantity); } else {  if($gs->size_id == $this->session->get('product_size_qty'.$products->deal_id)){ ?>
                                
                                <p>Select your size: <span><?php echo $gs->size_name; ?></span></p>
								<p>Available Quantity: <span><?php echo $gs->quantity; ?></span></p>     
                                                              
                                <?php } } } }?>
																 
																</div>
                                                               
                                                                
                                                            </div> 
                                                            <?php if(count($get_color_data)>0){ ?> 
                                                        <div class="id_desc_color">
                                                            <label>Color</label>
                                                            
                                                            <select onchange="window.open(this.options[this.selectedIndex].value,'_top')">
                                <option> Color(s) </option> 
                                <?php foreach($get_color_data as $gc){ if($gc->color_code_id != $this->session->get('product_color_qty'.$products->deal_id)){ ?>
                                <option value="<?php echo PATH.'products/addmore_paycolor/'.$gc->color_code_id.'/'.$products->deal_id;?>" style="color:#<?php echo $gc->color_name; ?>"> <?php echo $gc->color_code_name; ?> </option>  
                                <?php } } ?>
                                </select>		
                                
                                
                                                            
                                                        </div>
                                                        <?php } ?>
                                                        <?php  if(count($get_size_name)>0){ if($nosize ==""){ ?>
                                                        <div class="id_desc_size">
                                                            <label>Size</label>
                                                        
                                                        <select onchange="window.open(this.options[this.selectedIndex].value,'_top')">
                                                        <option> Size(s) </option> 
                                                        <?php 
                                                        foreach($get_size_name as $gs){   if(($gs->quantity != 0)&&($gs->size_id != $this->session->get('product_size_qty'.$products->deal_id))) { ?>
                                                        <option value="<?php echo PATH.'products/addmore_cart_size/'.$gs->size_id.'/'.$products->deal_id.'/'.$gs->quantity;?>"> <?php echo $gs->size_name; ?> </option>  
                                                        <?php  } } ?>
                                                        </select>
                                                           </div> 
                                                        <?php } ?>	
                                                        <?php } ?>
                                                               
                                                        <?php if(($this->shipping_setting  == 3)){ ?>
                                                        <p>Shipping fee: <span><?php echo CURRENCY_SYMBOL; ?><?php echo number_format((float)$products->shipping_amount, 2, '.', ''); ?></span></p>							
                                                        <?php } ?>
                                                    </div>

                                                </div>
                                                <div class="tb-qty-content2">
                                                    <div class="lessthen">
                                                        <a class="less_min" id="QtyDown" onclick="<?php echo $key; ?>1()"></a>
                                                     </div>
                                                    <div class="lessthen1">
                                                        <input name="QTY" id="<?php echo $key; ?>" value="1" readonly="readonly" type="text" rel="20">
                                                    </div>
                                                    <div class="greaterthen">
                                                        <a class="plus" id="QtyUp" onclick="<?php echo $key; ?>()"></a>
                                                    </div>

                                                </div>
                                                
                                                

                                                <div class="lp-tb-price-value2">X</div>	
                                                <div class="lp-tb-price-value2"><?php echo CURRENCY_SYMBOL.$products->deal_value; ?></div>
                                                
                                                <?php if($this->shipping_setting  == 4){ ?>
                                                <div class="lp-tb-price-value2">+</div>	
                                                <div class="lp-tb-price-value2"><?php echo CURRENCY_SYMBOL; ?><span id="<?php echo $key; ?>amount_shipping"><?php echo number_format((float)$products->shipping_amount, 2, '.', ''); ?></span></div>	
							                    <?php } ?>
                                                <div class="lp-tb-price-value3">=<?php $product_quantity = $this->session->get('product_quantity_qty'.$products->deal_id); ?></div>
                                                
                                                <script>
							
                        function <?php echo $key; ?>()
                        {   
                             if($('#<?php echo $key; ?>').val()!=<?php echo $product_quantity; ?>) {
                                         var plus_amount = parseInt($('#<?php echo $key; ?>').val()) + 1;
                                         $('#RE_QTY_VAL').val(plus_amount);
                                         $('#PC_QTY_VAL<?php echo $key; ?>').val(plus_amount);
                                         $('#PCC_QTY_VAL<?php echo $key; ?>').val(plus_amount); 
										 $('#COD_QTY_VAL<?php echo $key; ?>').val(plus_amount); 										
                                         $('#APCC_QTY_VAL<?php echo $key; ?>').val(plus_amount); 
                                         
                                         $('#PRO_REFERRAL').val('0');
                                         $('#PC_REFERRAL').val('0');
                                         $('#COD_REFERRAL').val('0');
                                         if(plus_amount!="0"){
                                                $('#<?php echo $key; ?>').val(plus_amount); 
                                         }
                                         var total_amount = ((<?php echo $itemshippingamount; ?>)*plus_amount) + ((<?php echo $products->deal_value; ?>)*plus_amount);
                                        var total_shipp = ((<?php echo $shippingamount; ?>)*plus_amount);
                                        var keyamountshipping = total_shipp.toFixed(2);
                                         $('#<?php echo $key; ?>amount_shipping').text(keyamountshipping);
                                         if(total_amount!="0") {
                                                
                                                var keyamount = total_amount.toFixed(2);
                                                $('#<?php echo $key; ?>amount').text(keyamount);
                                                var qqqq = parseFloat($('#totalamount').text())+<?php echo $products->deal_value; ?>+<?php echo $itemshippingamount; ?>;
                                                var qqq = qqqq.toFixed(2); 
                                                var flatqqq = qqqq+<?php echo $flatamount; ?>;
                                                var flat = flatqqq.toFixed(2);    
                                                                                            
                                                var taxqqq = (<?php echo $taxamount; ?>/100)*flat;
                                                var taxvalue = taxqqq.toFixed(2); 
                                               
                                                $('#totalamount').text(qqq);  
                                                $('#Grandamount').text(qqq);
                                                $('#TotalAmount').val(qqq);
                                                $('#P_TotalAmount').val(qqq);
                                                $('#COD_TotalAmount').val(qqq);
                                                $('#ref').val('0');
                                                $('#PRO_REFERRAL').val('0');
                                                $('#PC_REFERRAL').val('0');
                                                $('#COD_REFERRAL').val('0');
                                        }
                                }
                               $('#taxamount').text(taxvalue); 
                               var totgrand = (parseFloat(flat)+parseFloat(taxvalue));
                               var totgrandval = totgrand.toFixed(2);
                               if(totgrandval != "NaN"){
                               $('#Grandamount').text(totgrandval); 
                               }
                               
                              
                            
                        }

                        function <?php echo $key; ?>1()
                        {
                                if($('#<?php echo $key; ?>').val()>1){
                                var plus_amount = parseInt($('#<?php echo $key; ?>').val()) - 1;
                                $('#RE_QTY_VAL').val(plus_amount);
                                $('#PC_QTY_VAL<?php echo $key; ?>').val(plus_amount);
                                $('#PCC_QTY_VAL<?php echo $key; ?>').val(plus_amount);
                                $('#COD_QTY_VAL<?php echo $key; ?>').val(plus_amount);
                                $('#APCC_QTY_VAL<?php echo $key; ?>').val(plus_amount);
                                $('#PRO_REFERRAL').val('0');
                                $('#PC_REFERRAL').val('0');
                                $('#COD_REFERRAL').val('0');
                                 var total_shipp = ((<?php echo $shippingamount; ?>)*plus_amount);
                                        var keyamountshipping = total_shipp.toFixed(2);
                                         $('#<?php echo $key; ?>amount_shipping').text(keyamountshipping);
                                if(plus_amount!="0"){
                                        $('#<?php echo $key; ?>').val(plus_amount); 
                                } 
                                var total_amount = <?php echo $shippingamount; ?> + (<?php echo $products->deal_value; ?>*plus_amount);
                                if(total_amount!="0") {
                                        var keyamount = total_amount.toFixed(2);
                                        $('#<?php echo $key; ?>amount').text(keyamount);
                                        var qqqq = parseFloat($('#totalamount').text())-<?php echo $products->deal_value; ?>-<?php echo $itemshippingamount; ?>;
                                        var qqq = qqqq.toFixed(2); 
                                        var flatqqq = qqqq+<?php echo $flatamount; ?>;
                                        var flat = flatqqq.toFixed(2);    
                                                
                                        var taxqqq = (<?php echo $taxamount; ?>/100)*flat;
                                        var taxvalue = taxqqq.toFixed(2);
                                        
                                        $('#totalamount').text(qqq);
                                        $('#Grandamount').text(qqq);
                                        $('#TotalAmount').val(qqq);
                                        $('#P_TotalAmount').val(qqq);
                                        $('#COD_TotalAmount').val(qqq);
                                        $('#ref').val('0');
                                        $('#PRO_REFERRAL').val('0');
                                        $('#PC_REFERRAL').val('0');
                                        $('#COD_REFERRAL').val('0');
                                }
                                }
                               
                                  $('#taxamount').text(taxvalue); 
                               var totgrand = (parseFloat(flat)+parseFloat(taxvalue));
                               var totgrandval = totgrand.toFixed(2);
                               if(totgrandval != "NaN"){
                               $('#Grandamount').text(totgrandval); 
                               }
                              
                        }  
                        
                        </script>
                                                <div class="lp-tb-price-value2"><?php echo CURRENCY_SYMBOL; ?><span id="<?php echo $key; ?>amount"><?php echo number_format((float)$products->deal_value+$shippingamount, 2, '.', ''); ?></span></div>
                                                <?php  $total_amount +=$products->deal_value+$shippingamount; ?>
                                                <div class="lp-tb-delete2">
                                                    <a href="<?php echo PATH.'payment_product/cart_remove/product_cart_id'.$value;?>" title="<?php echo $this->Lang['DELETE']; ?>">&nbsp;</a>
                                                </div>

                                            </div>

                                        </div>
<?php 
                        }
                } 
        }
?>

                                        

                                        <div class="table_payment_total">
                                            <div class="payment_num">
                                                <div class="payment_num_top">
                                                    <label><?php echo $this->Lang['TOTAL']; ?></label>
                                                    <b>=</b>
                                                    <p><?php echo CURRENCY_SYMBOL; ?><span id="totalamount"><?php echo number_format((float)$total_amount, 2, '.', ''); ?></span></span></p>
                                                </div>
                                
                                                
                                                
                                                <?php if(($this->shipping_setting  == 2)|| ($this->shipping_setting  == 1)|| ($this->shipping_setting  == 3)){ ?>
                                                <div class="payment_num_top">
                                                    <label><?php if($this->shipping_setting  == 1) { ?>
							Shipping 
							<?php } if($this->shipping_setting  == 2) { ?>
							   Flat Shipping Amount
			 				<?php } if($this->shipping_setting  == 3) {  if($this->session->get('count') !="1"){ ?><span id="someelem"> <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/message_box.png" class="blink" > </span><?php echo $this->session->get('count')." Products "; } ?>
							    Shipping Amount
							<?php } ?></label>
                                                    <b>=</b>
                                                    <p><?php if($this->shipping_setting  == 1) { ?>
							<span>FREE</span>
							<?php } if($this->shipping_setting  == 2) { ?>
							
							   <span><?php echo CURRENCY_SYMBOL.number_format((float)$flatamount, 2, '.', ''); ?></span>
							<?php } if($this->shipping_setting  == 3) { ?>
							   <span><?php echo CURRENCY_SYMBOL.number_format((float)$flatamount, 2, '.', ''); ?></span>
							<?php } ?></p>
                                                </div>
                                                <?php } ?>
                                                <?php $taxamounttot = "0"; if($taxamount != 0){ ?>
                                                <div class="payment_num_top">
                                                    <label>
                                                       
                                                        <span>
                                                                <span id="someelemtax"> <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/message_box.png" class="blink" >
                                                        </span>
                                                            Tax</span>
                                                     
                                                    </label>
                                                    <b>=</b>
                                                    <p><?php  $taxamounttot = ($taxamount/100)*($total_amount+$flatamount); ?>
							<span><?php echo CURRENCY_SYMBOL; ?><span id="taxamount"><?php echo number_format((float)$taxamounttot, 2, '.', ''); ?></span></span></p>
                                                </div>
                                                <?php } ?>
                                                <div class="payment_num_top">
                                                    <label><?php echo $this->Lang['GRAND_TOTAL']; ?></label>
                                                    <b>=</b>
                                                    <p><span><?php echo CURRENCY_SYMBOL; ?><span id="Grandamount"><?php echo number_format((float)$total_amount+$flatamount+$taxamounttot, 2, '.', ''); ?></span></span></p>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="payment_sel_common">
                                            
                                            <h2><?php echo $this->Lang['TYPE_PAY']; ?></h2>
                                            <div class="payment_select"> 
                                            <?php if($this->paypal_setting) { ?>
                                                <div class="payment_sel_lft">
                                                <a onclick="return SimilarProducts();" id="SimilarProducts"  >
          <input id="paypal_radio" type="radio" name="name"  checked/></a><p class="fl width60 color333333"><?php echo $this->Lang['PAYPAL']; ?></p></div>
                                                 <?php } ?>
                   <?php if($this->credit_card_setting) { ?>
                                                <div class="payment_sel_lft1">  <a onclick="return SimilarDeals();" id="SimilarDeals"  >
          <input type="radio" name="name"  <?php if($this->paypal_setting) { } else { ?> checked <?php } ?>  /></a><p class="fl width220"><?php echo $this->Lang['PAYPAL_CREDIT']; ?></p></div>
                                                <?php } ?>
                   <?php if($this->authorize_setting) { ?>
                                                <div class="payment_sel_lft2"> 
                                                
                                                <a onclick="return Authorize();" id="Authorize"  > <input type="radio" name="name"  /></a> <p class="fl width220">Authorize.net</p></div>
                                                 <?php } ?>
                                                 <?php if($this->uri->last_segment() != "payment_details_friend.html"){ ?>
					<?php if($this->cash_on_delivery_setting) { ?>
                                                <div class="payment_sel_lft2"> <a onclick="return cash_delivery();" > <input type="radio" name="name"  /></a> <p class="fl width220">Cash On Delivery</p></div>
                                                <?php } ?>
                                                <?php } ?>
                                            </div>


                                        <div class="befor_login">
								<?php echo new View("themes/".THEME_NAME."/paypal/p_paypal"); ?>
							</div>

							<div class="AuthorizeNet_pay">
								<?php echo new View("themes/".THEME_NAME."/paypal/p_Authorize"); ?>
							</div>
							  <?php if($this->uri->last_segment() != "payment_details_friend.html"){ ?>
							<div class="cash_pay">
								<?php echo new View("themes/".THEME_NAME."/paypal/cash_delivery"); ?>
							</div>
                                                            <?php } ?>
							
							<div class="cancel_login">
								<?php echo new View("themes/".THEME_NAME."/paypal/p_dodirect_creditcard"); ?>
							</div>
                                        </div>

                                        
                                    </div>

                                </div>

                            </div>
                                    </div>                   

                          </div>
                         <div class="blog_right1">

                            <div class="payment-faq-container">
                                <p class="faq-heading-text"><?php echo $this->Lang['PAY_MEN']; ?></p>
                                
                                <div class="faq-content2">
						<div class="faq-content-heading" onclick="return WhatHappens();">
													
							<div class="faq-content-heading-left" id="right1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down1">
							<a><?php echo $this->Lang['WAT_HAPP']; ?></a>
							</div>
						</div>
					     <div class="what_happens">
						<div class="faq-content-text">
						    
							<p><?php echo $this->Lang['WHILE_BUY_A_PRODUCT']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content2">
						<div class="faq-content-heading" onclick="return Whatbuygift();">
							
							<div class="faq-content-heading-left" id="right2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down2">
							<a><?php echo $this->Lang['DO_I_NEED']; ?></a>
							</div>
						</div>
						  <div class="what_buygift">  
						<div class="faq-content-text">
							<p><?php echo $this->Lang['ITS_QUITE_OPTIONAL']; ?></p>
						</div>
						</div>
					</div>
					<div class="faq-content3">
						<div class="faq-content-heading" onclick="return CanChange();">
							<div class="faq-content-heading-left" id="right3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
							<div class="faq-content-heading-left1" id="down3">
							<a><?php echo $this->Lang['MAY_I_USE']; ?></a>
							</div>
						</div>
						<div class="can_change">
						<div class="faq-content-text">
							<p><?php echo $this->Lang['OBVIOUSLY_YES']; ?></p>
						</div>
						</div>
					</div>
				</div>


 <div class="blog_right1">

                            <div class="payment-faq-container">
                               <iframe src="//www.facebook.com/plugins/likebox.php?href=<?php echo FB_PAGE; ?>&amp;width=235&amp;height=268&amp;colorscheme=light&amp;show_faces=true&amp;border_color&amp;stream=false&amp;header=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:234px; height:300px;" class="fan_box connections_grid  grid_item" allowTransparency="true"></iframe>
				</div>



                        </div>
                    
                              </div>
                    <!--Blog content ends-->
                </div>
            </div>
   
            </div>

        
   
