<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<?php  if(count($this->all_products_list) > 0){ ?>

<link rel="stylesheet" href="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/css/style.css" type="text/css" media="screen" />
  <?php $deal_offset = $this->input->get('offset'); foreach( $this->all_products_list as $products){
$symbol = CURRENCY_SYMBOL; 
?>
 <div class="pro_listing">
        <div class="det_img1">
	<?php if($this->session->get('cate')!="") { ?> <?php $url=$this->session->get('cate'); ?> <?php } else { ?> <?php $url=$products->category_url; ?>  <?php } ?>
    <?php  if(file_exists(DOCROOT.'images/category/icon/'.$url.'.png')){ ?> 
												<span class="cat_icon1">

<img alt="category icon" src="<?php echo PATH.'images/category/icon/'.$url.'.png'; ?>" title="<?php echo $url; ?>"></span>



											<?php } else { ?>
												<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png"/ title="no-image"></span>
                                            <?php } ?>
            <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products->deal_key.'_1'.'.png')){ ?>
          <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH.'images/products/290_215/'.$products->deal_key.'_1'.'.png';?>"  alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"/></a>
          <?php } else { ?>
          <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>" /></a>
          <?php }?>
                </div>

               <?php $type="products"; $categories=$products->category_url; ?>
              
											
														
                <div class="deal_list_detail">
                  <?php /*  <h2><a style="cursor:pointer;" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo $products->category_name; ?>"><?php echo $products->category_name; ?></a></h2> */ ?>
                    <h3>
                    <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title;?>"><?php echo substr(ucfirst($products->deal_title),0,25)."..";?></a>
                    </h3>
                    <p><span class="price">Price :</span> <span class="usd"> <?php echo $symbol." ".$products->deal_value; ?></span></p>
                    <div class="view_deals">
                        <div class="view_lft">
                            <div class="view_rgt">
                                <div class="view_mid">
                                <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo 'VIEW DETAILS'; ?>">
                                    VIEW DETAILS</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php } $deal_offset++; } else {?>

<p>Nodata Found</p>
<?php } ?>




