<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php foreach($this->cms as $d){  ?>

                </div>
            </div>
        </div>
        <!--end-->
        <div class="contianer_outer1">
            <div class="contianer_inner">
<div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang["HOME1"]; ?></a></p></li>
                            <li><p><?php echo $d->cms_title;?></p></li>
                        </ul>
                    </div>
                <div class="contianer">

                    <!--content start-->
                    <div class="content_abouts">
                        <div class="content_abou_common">
                             <div class="pro_top">
                            <h2><?php echo strtoupper($d->cms_title);?></h2>
                             </div>
                          
                            <div class="content_abou_text">
								<p><?php echo $d->cms_desc;?></p>
                               
                            </div>
                        </div>  


                    </div>
                    <!--end-->
                </div>
            </div>
        </div>
  <?php  }  ?>
<?php /*

<?php foreach($this->cms as $d){  ?>
<div class="container_outer">
	<div class="continer_outer_common fl">
	<div class="brad_com_out">
		<div class="brad_com_inn">
			<div class="brad_com">
				<ul>
			
					<li><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang["HOME1"]; ?></a></li>
					<li>\</li>
					
					<li class="act"><?php echo $d->cms_title;?></li>
				</ul>
			</div>
		</div>
	</div>
	
<div class="container_inner">
      <div class="container">
		  <div class="todays_deal deals_detail">
		  
				<h1><?php echo strtoupper($d->cms_title);?></h1>
		  <div class="about_us">
				<div class="about_top">
					<div class="about_tl">
						<div class="about_tr">
							<div class="about_tm"></div>
						</div>
					</div>
				</div>
				<div class="about_mid">
					<div class="about_ml">
						<div class="about_mr">
							<div class="about_mm">
								<div class="about_cont">
									<div class="about_det">
										<p><?php echo $d->cms_desc;?></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="about_bot">
					<div class="about_bl">
						<div class="about_br">
							<div class="about_bm"></div>
						</div>
					</div>
				</div>
			</div>
     
		  </div>
 </div>
</div>
<?php  }  ?>

*/ ?>
