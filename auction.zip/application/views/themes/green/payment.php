<script type="text/javascript"> 
        $(document).ready(function(){  
 
       <?php if($this->paypal_setting) { ?> 
        $('.cancel_login').hide();
        $('.cod_show').hide();
        <?php } else { ?>
        $('.befor_login').hide();
         $('.cancel_login').show();
         $('.cod_show').hide();
        <?php } ?>
        $('.AuthorizeNet_pay').hide();
        $('.cod_show').hide();
        $('.no_paypal').hide();
        
        });
</script>
<script type="text/javascript"> 
        $('.cancel_login').hide();
        function SimilarDeals() {
			 $('.cod_show').hide();
                $('.cancel_login').show();
		$('#order_hide').hide();
		
                $('.befor_login').hide();
                $('.AuthorizeNet_pay').hide();
		
        }
        
           function SimilarCod() {
			    $('.cod_show').show();
                $('.cancel_login').hide();
					$('#order_hide').hide();
		
                $('.befor_login').hide();
                $('.AuthorizeNet_pay').hide();
		
        }
        
        function SimilarProducts() {

		 $('.cod_show').hide();
                $('.befor_login').show();
                $('.cancel_login').hide();
                $('.AuthorizeNet_pay').hide();
		$('#order_hide').show();

        }
        function Authorize() {
			 $('.cod_show').hide();
		$('#order_hide').hide();
                $('.befor_login').hide();
                $('.cancel_login').hide();
                $('.AuthorizeNet_pay').show();
        }
       
</script>
<SCRIPT language=Javascript>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</SCRIPT>    
   </div>
            </div>
        </div>   
     <div class="contianer_outer1">
            <div class="contianer_inner">
                <div class="contianer">
                    <div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            <li><p>Type of Payment</p></li>
                        </ul>
                    </div>

                    <!--content start-->
                    <div class="content_abouts">
                        <div class="content_abou_common">
                             <div class="pro_top">
                            <h2>TYPE OF PAYMENT</h2>
                             </div>
                            <div class="payment_select"> 
                   <?php if($this->paypal_setting) { ?>
                   <a onclick="return SimilarProducts();" id="SimilarProducts"  > <div class="payment_sel_lft"> <input id="paypal_radio" type="radio" name="name" checked/></a> <p class="fl width60 color333333"><?php echo $this->Lang['PAYPAL']; ?></p></div>
                   <?php } ?>
                   <?php if($this->credit_card_setting) { ?>
                   <a onclick="return SimilarDeals();" id="SimilarDeals"  >   <div class="payment_sel_lft1"> <input type="radio" name="name"  <?php if($this->paypal_setting) { } else { ?> checked <?php } ?> /></a> <p class="fl width220"><?php echo $this->Lang['PAYPAL_CREDIT']; ?></p></div>
                   <?php } ?>
                   <?php if($this->authorize_setting) { ?>
                  <a onclick="return Authorize();" id="Authorize"  >       <div class="payment_sel_lft1"><input type="radio" name="name"  /></a> <p class="fl width220"><?php echo $this->Lang['AUTHORIZE']; ?></p></div>
                  <?php } ?>
                  
                    
                   <a onclick="return SimilarCod();" id="Cod"  >   <div class="payment_sel_lft1"> <input type="radio" name="name"  /></a> <p class="fl width220">COD</p></div>
               
                   
                                </div>
           <?php  $referral_balance = $this->user_referral_balance;  ?>
                            <div class="table-heading-text">
                               <p class="color444444"><?php echo $this->Lang['YOUR_PAYMENT']; ?> <span class="colorC8161D font_myriad_pro"><?php echo CURRENCY_SYMBOL.$referral_balance;  ?></span><?php echo $this->Lang['USE_ONLY']; ?></p>
                                <div class="table-heading-text-left">
                                    <div class="tb-desc"><?php echo $this->Lang['DESC']; ?></div>
                                </div>
                                <div class="table-heading-text-right">
                                    <div class="tb-qty"><?php echo $this->Lang['QUAN']; ?></div>
                                    <div class="tb-price"><?php echo $this->Lang['PRI']; ?></div>
                                    <div class="tb-referral_balance"><?php echo $this->Lang['REFEREL']; ?></div>

                                    <div class="tb-total"><?php echo $this->Lang['TOTAL']; ?></div>
                                </div>
                            </div>
                <?php  foreach($this->deals_payment_deatils as $payment) {  ?>
                            <div class="table-content-text">
                                <div class="table-content-text-left">
                                    <div class="tb-desc-content"><?php echo $payment->deal_title; ?></div>
                                </div>
                                <div class="table-content-text-right">
                                    <div class="tb-qty-content">
                                        <div class="lessthen">
                                        <a id="QtyDown"  class="less_min" onclick="DownTotal()">&nbsp;</a>
                                        </div>
                                        <div class="lessthen1">
                                       <input name="QTY" id="QTY" class="QTY_val" value="1" readonly="readonly" type="text" rel="20">
                                        </div>
                                        <div class="greaterthen">
                                         <a id="QtyUp" class="plus" onclick="UpTotal()">&nbsp;</a>
                                        </div>

                                    </div>
        <script>
        function UpTotal()
        {
                var count_limit=<?php echo $payment->user_limit_quantity; ?>-$('.userlimit').text();
                var count_user_limit=<?php echo $payment->purchase_count; ?>+(parseInt($('#QTY').val()) + 1);
                if(($('#QTY').val()!=count_limit)&&(<?php echo $payment->maximum_deals_limit; ?> >= count_user_limit)) {
                
                         if($('.userlimit').text()<=<?php echo $payment->user_limit_quantity; ?>){
                         var plus_amount = parseInt($('#QTY').val()) + 1;
                         $('#QTY').val(plus_amount);
                         $('#PC_QTY_VAL').val(plus_amount);
                         $('#PCC_QTY_VAL').val(plus_amount);
                         $('#APCC_QTY_VAL').val(plus_amount);
                         $('#PCR_QTY_VAL').val(plus_amount);
                        
                        var total_amount = <?php echo $payment->deal_value; ?>*plus_amount;
                        if(total_amount!="0") {
                                $('#amount').text(total_amount);
                                $('#tot').text(total_amount);
                                $('#oldamount').text(total_amount);
                                $('#PC_AMOUNT').val(total_amount);
                                $('#PCC_AMOUNT').val(total_amount);
                                $('#APCC_AMOUNT').val(total_amount);
				                $('#PCR_AMOUNT').val(total_amount);
                                $('#ref').val('0');
                                $('#PC_REFERRAL').val('0')
                                $('#PCR_REFERRAL').val('0')
                                $('.no_paypal').hide();
                                $('.totlal_amount').show();
                                $('.payment_top').show();
                        }
                        
                        else {
                                if(val!="") {
                                $('#amount').text(1*<?php echo $payment->deal_value; ?>);
                                $('#tot').text(1*<?php echo $payment->deal_value; ?>);
                                $('#oldamount').text(1*<?php echo $payment->deal_value; ?>);
                                $('#PC_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#PCC_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#APCC_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
				$('#PCR_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#ref').val('0');
                                $('#PC_REFERRAL').val('0')
                                $('#PCR_REFERRAL').val('0')
                                } else {
                                        $('#amount').text('0');
                                        $('#tot').text('0');
                                        $('#oldamount').text('0');
                                        $('#PC_AMOUNT').val('0');
                                        $('#PCC_AMOUNT').val('0');
                                        $('#APCC_AMOUNT').val('0');
                                        
                                }
                        }
                    }
                }
                
        }
        
        function DownTotal()
        {
                if($('#QTY').val()!=1) {
                        var plus_amount = parseInt($('#QTY').val()) - 1;
                        $('#QTY').val(plus_amount);
                        $('#PC_QTY_VAL').val(plus_amount);
                        $('#PCC_QTY_VAL').val(plus_amount);
                        $('#APCC_QTY_VAL').val(plus_amount);
                        $('#PCR_QTY_VAL').val(plus_amount); 
                        
                        var total_amount = <?php echo $payment->deal_value; ?>*plus_amount;
                        if(total_amount!="0") {
                                $('#amount').text(total_amount);
                                $('#tot').text(total_amount);
                                $('#oldamount').text(total_amount);
                                $('#PC_AMOUNT').val(total_amount);
                                $('#PCC_AMOUNT').val(total_amount);
                                $('#APCC_AMOUNT').val(total_amount);
                                $('#PCR_AMOUNT').val(total_amount);
                                $('#ref').val('0');
                                $('#PC_REFERRAL').val('0')
                                $('#PCC_REFERRAL').val('0')
                                $('#APCC_REFERRAL').val('0')
                                $('#PCR_REFERRAL').val('0')
                        }
                        else {
                                if(val!="") {
                                $('#amount').text(1*<?php echo $payment->deal_value; ?>);
                                $('#tot').text(1*<?php echo $payment->deal_value; ?>);
                                $('#oldamount').text(1*<?php echo $payment->deal_value; ?>);
                                $('#PC_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#PCC_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#APCC_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#PCR_AMOUNT').val(1*<?php echo $payment->deal_value; ?>);
                                $('#ref').val('0');
                                $('#PC_REFERRAL').val('0');
                                $('#PCC_REFERRAL').val('0');
                                $('#APCC_REFERRAL').val('0');
                                $('#PCR_REFERRAL').val('0');
                                } else {

                                        $('#amount').text('0');
                                        $('#tot').text('0');
                                        $('#oldamount').text('0');

                                        $('#PC_AMOUNT').val('0');
                                        $('#PCC_AMOUNT').val('0');
                                        $('#APCC_AMOUNT').val('0');
                                        $('#PCR_AMOUNT').val('0');
                                }
                        }
                }
        }
        
        function ReferralTotal(ref)
        {      
                
                if(ref <= <?php echo $referral_balance;  ?>)
                {
                        if(ref==""){
                                var ref_amount=$('#oldamount').text();
                                $('#amount').text(ref_amount);
                                $('#PC_AMOUNT').val(ref_amount);
                                $('#PCC_AMOUNT').val(ref_amount);
                                $('#APCC_AMOUNT').val(ref_amount);
                                $('#PCR_AMOUNT').val(ref_amount);
                                $('#tot').text(ref_amount);
                        }
                        else{
                                var ref_amount=$('#oldamount').text()-ref;
                                
                                $('#PC_REFERRAL').val(ref);
                                $('#PCC_REFERRAL').val(ref);
                                $('#APCC_REFERRAL').val(ref);
                                $('#PCR_REFERRAL').val(ref);
                                if(ref_amount=="0")
                                        {       
                                                 
                                                $('.no_paypal').show();                                                
                                                $('.payment_type').hide();
                                                $('.totlal_amount').hide();
                                                $('.befor_login').hide();
                                                $('.payment_top').hide();
                                                $('.cancel_login').hide();
                                                $('.AuthorizeNet_pay').hide();
                                                
                                        }
                                
                                if(ref_amount >= 0) {
                                        $('#amount').text(ref_amount);
                                        $('#tot').text(ref_amount);
                                        $('#PC_AMOUNT').val(ref_amount);
                                        $('#PCC_AMOUNT').val(ref_amount);
                                        $('#APCC_AMOUNT').val(ref_amount);
                                        $('#PCR_AMOUNT').val(ref_amount);
                                        
                                        if(ref_amount!="0")
                                        {       
                                                $('.no_paypal').hide();
                                                $('.totlal_amount').show();
                                                  $('.payment_type').show();
                                                $('.befor_login').show(); 
                                                $('.payment_top').show();
                                                document.getElementById("paypal_radio").checked=true;
                                        }
                                        
                                }
                                else {
                                        $('#ref').val($('#oldamount').text());
                                        $('#PC_REFERRAL').val($('#oldamount').text());
                                        $('#PCC_REFERRAL').val($('#oldamount').text());
                                        $('#APCC_REFERRAL').val($('#oldamount').text());
                                        $('#PCR_REFERRAL').val($('#oldamount').text());
                                        var ref_amount=$('#oldamount').text()-$('#oldamount').text();
                                        
                                        $('#amount').text(ref_amount);
                                        $('#tot').text(ref_amount);
                                        $('#PC_AMOUNT').val(ref_amount);
                                        $('#PCC_AMOUNT').val(ref_amount);
                                        $('#APCC_AMOUNT').val(ref_amount);
                                        $('#PCR_AMOUNT').val(ref_amount);
                                        if(ref_amount=="0")
                                        {       
                                                $('.no_paypal').show();
                                                 $('.payment_type').hide();
                                                $('.totlal_amount').hide();
                                                $('.befor_login').hide();
                                                $('.payment_top').hide();
                                                $('.cancel_login').hide();
                                                $('.AuthorizeNet_pay').hide();
                                        }                                        
                                }
                        }
                }
                else{
                        $('#ref').val(<?php echo $referral_balance; ?>);  
                        $('#PC_REFERRAL').val(<?php echo $referral_balance; ?>);
                        $('#PCC_REFERRAL').val(<?php echo $referral_balance; ?>);
                        $('#APCC_REFERRAL').val(<?php echo $referral_balance; ?>);
                        $('#PCR_REFERRAL').val(<?php echo $referral_balance; ?>);
                        var ref_amount=$('#oldamount').text()-<?php echo $referral_balance;  ?>; 
                        
                        if(ref_amount >= 0) {
                                $('#amount').text(ref_amount);
                                $('#tot').text(ref_amount);
                                $('#PC_AMOUNT').val(ref_amount);
                                $('#PCC_AMOUNT').val(ref_amount);
                                $('#APCC_AMOUNT').val(ref_amount);
                                $('#PCR_AMOUNT').val(ref_amount);
                        }            
                        else {
                                $('#ref').val($('#oldamount').text());
                                $('#PC_REFERRAL').val($('#oldamount').text());
                                $('#PCC_REFERRAL').val($('#oldamount').text());
                                $('#APCC_REFERRAL').val($('#oldamount').text());
                                $('#PCR_REFERRAL').val($('#oldamount').text());
                                        var ref_amount=$('#oldamount').text()-$('#oldamount').text();
                                        $('#amount').text(ref_amount);
                                        $('#tot').text(ref_amount);
                                        $('#PC_AMOUNT').val(ref_amount);
                                        $('#PCC_AMOUNT').val(ref_amount);
                                        $('#APCC_AMOUNT').val(ref_amount);
                                        $('#PCR_AMOUNT').val(ref_amount);
                                        
                                        if(ref_amount=="0")
                                        {      
                                                 $('.no_paypal').show();
                                                  $('.payment_type').hide();
                                                $('.totlal_amount').hide();
                                                $('.befor_login').hide();
                                                $('.payment_top').hide();
                                                $('.cancel_login').hide();
                                                $('.AuthorizeNet_pay').hide();
                                        }  
                        }      
                }
                
                function Referralfriend(ref)
                {
                        $('.sign_in').show();
                }
                
                
        }
        
        </script>
        <div class="tb-x-mark">x</div>
        <div class="tb-price-content"><?php echo CURRENCY_SYMBOL.$payment->deal_value; ?></div>
        <div class="tb-refervalue"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/reg_img.png" alt="Qty-Counter" title="Qty Counter" /> <INPUT TYPE=TEXT NAME="ref" id="ref"  SIZE=10 maxlength="10" value="0" onkeypress="return isNumberKey(event)" onkeyup="ReferralTotal(this.value)" > </div>				
        <div class="tb-equals-mark">=</div>	

        <div class="tb-total-content"><?php echo CURRENCY_SYMBOL; ?><span id="amount"><?php echo $payment->deal_value; ?>
<INPUT TYPE="hidden"  id="ref_deal_id"  value="<?php echo $payment->deal_id; ?>"></div>
        </div>
        </div>
        <div class="table-myprice">
        <div class="myprice-text">Total to Pay</div>
        <div class="myprice-num">
        <span><?php echo CURRENCY_SYMBOL; ?></span><span id="tot"><?php echo $payment->deal_value; ?></span>
        </div>
        </div>
		<div style="display:none" id="oldamount"><?php echo $payment->deal_value; ?></div>
        <div class="befor_login">
        <?php echo new View("themes/".THEME_NAME."/paypal/paypal"); ?>
        </div>        
        <div class="cancel_login">
        <?php echo new View("themes/".THEME_NAME."/paypal/dodirect_creditcard"); ?>        
        </div></div>
        <div class="AuthorizeNet_pay">
        <?php echo new View("themes/".THEME_NAME."/paypal/deal_Authorize"); ?>        
        </div>
        
               <div class="cod_show">
			 <?php echo new View("themes/".THEME_NAME."/paypal/deal_cod"); ?>     
        
        </div>  
        
                <script>
                $(document).ready(function(){
                $("#commentForm_ref").validate();
                });
                </script>
                <div class="no_paypal">
                <form name="payment" method="POST" id="commentForm_ref" action="<?php echo PATH;?>payment/referral_payment">
                <input name="P_QTY" id="PCR_QTY_VAL" value="1" type="hidden" >
                <input name="deal_id"  type="hidden" value="<?php echo $payment->deal_id; ?>" >
                <input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" >
                <input name="deal_value" type="hidden" value="<?php echo $payment->deal_value; ?>" >
                <input name="amount" id="PCR_AMOUNT"  type="hidden" value="<?php echo $payment->deal_value; ?>" >
                <input name="p_referral_amount" id="PCR_REFERRAL" value="0" type="hidden">
                <?php if($this->uri->segment(2) == "payment_details_friend"){ ?>
                <div class="pop_up_1">
                <label><?php echo $this->Lang['FRI_NAME']; ?></label>
                <div class="text_box_2">
                <div class="pur_txt_box">
                <input type="text" value="" name="friend_name" class="required" onkeyup="Referralfriend(this.value)"/>
                </div>
                <em>
                <?php if(isset($this->form_error['friend_name'])){ echo $this->form_error["friend_name"]; }?>
                </em> </div>
                </div>
                <div class="pop_up_1">
                <label><?php echo $this->Lang['FRI_EMAIL']; ?></label>
                <div class="text_box_2">
                <div class="pur_txt_box">
                <input type="text" value="" name="friend_email" class="required email" onkeyup="Referralfriend(this.value)"/>
                </div>
                <em>
                <?php if(isset($this->form_error['friend_email'])){ echo $this->form_error["friend_email"]; }?>
                </em> </div>
                </div>
                <input name="friend_gift"  value="1" type="hidden">

                <?php } else {?>
                <input name="friend_name"  type="hidden" value="xxxyyy" >
                <input name="friend_email"   type="hidden" value="xxxyyy@zzz.com" >
                <input name="friend_gift"  value="0" type="hidden">
                <?php } ?>

  

		<div id="order_hide" style="dispaly:none;">
               <div class="complete-order-button">
                                                        <div class="ora_left">
                                                            <div class="ora_right">
              
                                                            <div class="ora_mid2">
                <input class="bnone" id="complete_order" name="Submit" type="submit" value="<?php echo $this->Lang['COMP_ODR']; ?>" onclick="return complete_ref();"/>
                </div>
                                                                  </div>
                                                        </div>
                
                   

                
                <div class="payment_terms_outer"><p class="terms-conditons-text" style="padding-left:0px;"> <span class="fl font_myriad_pro"><?php echo $this->Lang['BY_CLICK']; ?> </span> <a href="<?php echo PATH;?>terms-and-conditions.php" title="<?php echo $this->Lang['TEMRS']; ?>" class="font_myriad_pro mt5"><?php echo $this->Lang['TEMRS']; ?>.</a></p> </div>
                </div>

                
                </form>
                </div>
		</div>

<?php } ?>



                            </div>

                        </div>  


                    </div>
                    <!--end-->
                </div>
            </div>
        </div>



