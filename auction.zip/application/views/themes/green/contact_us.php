
                </div>
            </div>
        </div>

        <div class="contianer_outer1">
            <div class="contianer_inner">
<div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang["HOME1"]; ?></a></p></li>
                            <li><p><?php echo $this->Lang['CONTACT_US']; ?></p></li>
                        </ul>
                    </div>
                <div class="contianer">

                    <!--content start-->
                    <div class="content_abouts">
                        <div class="content_abou_common">
                             <div class="pro_top">
                            <h2><?php echo $this->Lang['CONTACT_US']; ?></h2>
                             </div>

                            <div class="about_cont">


                                <div class="contact_form_new">
                                    <div class="contact_form_new_left">
                                        <div class="contact_form_left_inner">
											<form action="" method="post">
                                                <div class="name_email">
                                                    <ul>
                                                        <li>
                                                            <label><?php echo $this->Lang["NAME"]; ?>:<span class="form_star">*</span></label>
                                                            <div class="fullname"><input name="name" type="text" value="<?php if(!isset($this->form_error['name']) && isset($this->userPost['name'])){echo $this->userPost['name'];}?>" size="40"/>&nbsp;
                                                              <em><?php if(isset($this->form_error['name'])){ echo $this->form_error["name"]; }?></em>
                                                            </div>
                                                          
                                                        </li>
                                                        <li id="email_li_ml">
                                                            <label><?php echo $this->Lang["EMAIL_F"]; ?>:<span class="form_star">*</span></label>
                                                            <div class="fullname"><input name="email" type="text" value="<?php if(!isset($this->form_error['email']) && isset($this->userPost['email'])){echo $this->userPost['email'];}?>" size="40"/>&nbsp;
                                                            <em><?php if(isset($this->form_error['email'])){ echo $this->form_error["email"]; }?></em>
                                                            </div>
														
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="name_email">
                                                    <ul>
                                                        <li>
                                                            <label><?php echo $this->Lang["PHONE"]; ?>:</label>
                                                            <div class="fullname"><input name="phone" type="text" value="<?php if(!isset($this->form_error['phone']) && isset($this->userPost['phone'])){echo $this->userPost['phone'];}?>" size="40"/>&nbsp;
                                                            <em><?php if(isset($this->form_error['phone'])){ echo $this->form_error["phone"]; }?></em>
                                                            </div>
														
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div class="contact_form_new_message">
                                                    <ul>
                                                        <li>
                                                            <label><?php echo $this->Lang["MSGG"]; ?>:<span class="form_star">*</span></label>
                                                            <div class="contact_form_new_textarea">
                                                            <textarea  cols="10" rows="10" name="message" title="Enter Your Message"><?php if(!isset($this->form_error['message']) && isset($this->userPost['message'])){echo $this->userPost['message'];}?></textarea>&nbsp;
                                                           <em><?php if(isset($this->form_error['message'])){ echo $this->form_error["message"]; }?></em>
                                                            </div>
                                                             
														
                                                            
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="sign_up_submit_outer">  
                                                    <div class="button4">
                                                        <div class="but_lft">
                                                             <div class="but_rgt">
                                                                   <div class="but_mid"><input type="submit" title="<?php echo $this->Lang['SUBMIT']; ?>" value="<?php echo $this->Lang['SUBMIT']; ?>" /></div>
                                                             </div>
                                                        </div>
                                                      
                                                       
                                                    </div>
                                                    <div class="cancel">
                                                        <div class="sub_lft1">

                                                            <div class="sub_rgt1">
                                                                <div class="sub_mid1"><input type="reset" title="<?php echo $this->Lang['CANCEL']; ?>" value="<?php echo $this->Lang['CANCEL']; ?>" onclick="window.location.href='<?php echo PATH; ?>'" /></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>  
                                            </form>
                                        </div>			
                                    </div>
                                    <div class="contact_form_new_right">


                                        <div class="new_contact_info">	
                                            <h2>Contact Detail</h2>
                                            
                                            <div class="new_contac_list">
                                                   <?php if(PHONE1 || PHONE2 || CONTACT_EMAIL || CONTACT_NAME){ ?>
												
												<?php if(CONTACT_NAME){ ?>
                                            <div class="new_conact_top">
                                                    <p> <a href="#" title="<?php echo CONTACT_NAME;?>"><?php echo CONTACT_NAME;?></a></p>
                                                </div>
                                                <?php } ?>
                                                <div class="new_conact_top3">
                                                    <p> <a href="#" title="<?php echo PHONE1;?>"><?php echo PHONE1;?></a></p>
                                                </div>
                                                <div class="new_conact_top1">
                                                    <p><a class="new_cont_top1" href="#" title="<?php echo PHONE2;?>"><?php echo PHONE2;?></a></p>
                                                </div>
                                                <div class="new_conact_top2">
                                                    <p><a href="mailto:<?php echo CONTACT_EMAIL; ?>" title="<?php echo CONTACT_EMAIL; ?>"><?php echo  CONTACT_EMAIL; ?></a></p>
                                                </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="contact_rgt_map">
                                           <div>
                                            <div id="map_main" style="width:318px; height:210px;"></div>
                                            <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
                                                <script type="text/javascript">
                                                var latlng = new google.maps.LatLng(<?php echo LATITUDE;?>,<?php echo LONGITUDE;?>);
                                                var myOptions = {
                                                zoom: 13,
                                                center: latlng,
                                                mapTypeId: google.maps.MapTypeId.ROADMAP,
                                                navigationControl: true,
                                                mapTypeControl: true,
                                                scaleControl: true
                                                };
                                                var map = new google.maps.Map(document.getElementById("map_main"), myOptions);
                                                var marker = new google.maps.Marker({
                                                position: latlng,
                                                animation: google.maps.Animation.BOUNCE
                                                });
                                                marker.setMap(map);
                                                </script>
                                            </div>
                                        </div>

                                    </div>
                                </div>



                            </div>
                        </div>  


                    </div>
                    <!--end-->
                </div>
            </div>
        </div>

