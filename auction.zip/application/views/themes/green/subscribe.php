<script type="text/javascript">
    $(document).ready(function(){
               $('.submit-link')
                               .click(function(e){ 
								   
                                       $('input[name="c"]').val($(this).attr('id').replace('sample-',''));
                                       $('input[name="c_t"]').val('<?php echo base64_encode("main"); ?>');
                                       e.preventDefault();
                                       $(this).closest('form')
                                               .submit();
                                               
   });
  
    });
</script>

        <div class="contianer_outer" id="home_page_margin_top">
            <div class="contianer_inner">

                <div class="contianer">

                    <!--content start-->
                    <div class="content">
						
                        <!--sidebar start-->
                        <div class="conntent_left">

               <div class="cat_outer1">
                                <div class="category1">
                                    <h1>Categories</h1>
                                    
                                    <ul>
                    <?php  $cat=explode(",", substr($this->session->get('categoryID'), 0, -1));
							$cat1=array_unique($cat);?>
                    
					<?php foreach ($this->category_list as $d) {
											if ($d->product == 1 && isset($this->is_product)) { ?>

                                                <li>
                                                    <span class="cate_check">


               <?php $type="products"; $categories=$d->category_url; ?>
              

														</span>

											<a style="cursor:pointer;" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo $d->category_name; ?>"  class="sample_new" id="sample_new-<?php echo $d->category_id; ?>" title="<?php echo ucfirst($d->category_name); ?>">
												<?php echo ucfirst($d->category_name); ?>
											</a>
                                            <div class="sub_menu_top1">	
                                                <span class="white">&nbsp; </span>
                                                
                                                <ul>
                                                 
													
                                                    <a style="cursor:pointer;">


                                                <div id="categeory_new-<?php echo $d->category_id; ?>">
												<?php echo new View("themes/" .THEME_NAME . "/products/sub_categorey_list"); ?>

                                                </div></a>
											
                                                </ul>
                                            </div>
                                                </li>


								<?php }   } ?>
								<?php foreach ($this->category_list as $d) {
        if ($d->deal == 1 && isset($this->is_deals)) { ?>
                                                <li>
                                                    <span class="cate_check">
                               <?php $type="deal"; $categories=$d->category_url; ?>

<a style="cursor:pointer;" class="sample23" id="sample23-<?php echo $d->category_id; ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>">
		<?php echo ucfirst($d->category_name); ?>
	</a>
                                            <div class="sub_menu_top1">	
                                                <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;">


                                            <div id="categeory23-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/deals/subcategory_list"); ?>
                                                </div></a>
                                       
                                                </ul>
                                            </div>
                                                </li>



                                                
        <?php }   } ?>
         <?php foreach ($this->category_list as $d) {
        if ($d->auction == 1  && isset($this->is_auction)) { ?>
                                                <li>
                                                    <span class="cate_check">
                              <?php $type="auction"; $categories=$d->category_url; ?>

<a style="cursor:pointer;" class="sample33" id="sample33-<?php echo $d->category_id; ?>" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo ucfirst($d->category_name); ?>">
		<?php echo ucfirst($d->category_name); ?>
	</a>
                                            <div class="sub_menu_top1">	
                                                <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;">


                                            

                                                <div id="categeory33-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/auction/sub_categorey_list"); ?>
                                                </div></a>
                                       
                                                </ul>
                                            </div>

                                                </li>



        <?php } }  ?> <form>
        <?php foreach($this->category_list as $d){ if ((!isset($this->is_deals)) && (!isset($this->is_product)) && (!isset($this->is_auction))) { ?> 
                              
                                         <li <?php if((isset($_GET['category']) && $_GET['category'] == $d->category_id) || (isset($_GET['main_cat']) && $_GET['main_cat'] == $d->category_id )) { ?> class="li_active" <?php } ?> >
        <?php $type = "";
        $categories = $d->category_url; ?>
                                            <a style="cursor:pointer;" class="sample_12 submit-link" id="sample-<?php echo base64_encode($d->category_id); ?>"  title="<?php echo ucfirst($d->category_name); ?>">
        <?php echo ucfirst($d->category_name); ?>
                                            </a>
                                            <div class="sub_menu_top1">
                                                <span class="white">&nbsp;</span>
                                                <ul>
                                                    <a style="cursor:pointer;"  ><div id="categeory1-<?php echo base64_encode($d->category_id); ?>"></div></a>

                                                </ul>
                                            </div>
                                        </li>
  <?php   } } ?>
  <input type="hidden" name="c" />
  <input type="hidden" name="c_t" />
  <input type="hidden" name="m_c">
<p><input type="submit" style="display:none;"> </p>
  <?php  ?>
   </form>
   
                                        <input type="submit" value="submit" id="submit" style="display:none;">
                                    </ul>
                                   
                                </div>
                            </div>
				<?php if (isset($this->is_product)) { ?>

                      <?php /*  <div class="cat_outer2">
                            <div class="category">	
                                <form action="" method="get" name="form1"  >						 
                                    <h1>Apparel Men Size</h1>
    <?php $cat = explode(",", substr($this->session->get('size'), 0, -1));
    $cat1 = array_unique($cat);
    ?>
    <?php foreach ($this->size_list as $size) { ?>
                                        <div class="apparel_size">
                                            <div class="apparel_size_left">
                                                <span><input  type="checkbox" name="size1[]" onclick="change_category1();" <?php foreach ($cat1 as $c) {
            if ($size->size_id == $c) { ?> checked <?php }
        } ?> value="<?php echo $size->size_id; ?>" /></span>
         <input type="checkbox" id="size" onclick="filter_size('<?php echo $size->size_id; ?>');" /> <p><?php echo $size->size_name; ?></p>
                                            </div>
                                        </div>
    <?php } ?>
                                    <input type="submit" value="submit" id="submit_1" style="display:none;">
                                </form>
                            </div>
                        </div> */ ?>
                         
                        <div class="cat_outer2">

                            <div class="category" style="padding-bottom:10px;">							 
                                <h1>Price</h1>


                                <div class="catogory_list2 fl clr">


                                    <div id="slider-range"></div>

                                    <br/>
                                    <div><input type="text"   style="float:left;  height:25px;font:normal 12px/25px arial;color:#787878; border:none; background: #fff; text-align: center; border:1px solid #d4d4d4; margin-left: 23px; margin-top:6px;" id="amount" style="border:none; color:#333;  font-weight:normal;" readonly="readonly" name="amount"/></div>
                                    <br/>
                                    <br/>
                                </div>
                            </div>
                        </div>


                        <?php /* <div class="cat_outer3">

                            <div class="category">				 
                                <h1>Color</h1>
                            </div>
                            <div class="color_left23">
                                <div class="chose_color1">   
                                    <ul>

                                        <?php  foreach ($this->color_list as $color) { ?>     

                                            <li>
                                                <a  name="color"  class="<?php if($this->color_id==$color->color_id){ ?> active <?php } ?>"    onclick="filtercolor('<?php echo $color->color_id; ?>');" title="color1" >                                             

                                                    <span class="choose_color_div" style="background:#<?php echo $color->color_name; ?>;"> </span>

                                                </a>  


                                            </li>

   					 <?php } ?>

                                    </ul>

                                </div>

                            </div>









                        </div>
					
					
					*/ ?>
					<?php } ?>
                            
                        </div>
                        <!--end-->
                        
<!--price and discount script-->

<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<script>
		
    $(function() {
        $( "#slider-range" ).slider({


            range: true,
            min: <?php if(isset($this->pro_min)) { echo $this->pro_min;  } ?>,
            max: <?php if(isset($this->pro_max)) { echo $this->pro_max; } ?>,
            values: [<?php if(isset($this->pro_min)) { echo $this->pro_min; } ?>,<?php if(isset($this->pro_max)) { echo $this->pro_max; } ?>  ],
            slide: function( event, ui ) {

                $( "#amount" ).val("<?php echo CURRENCY_SYMBOL; ?>"+ui.values[ 0 ] + " - " +"<?php echo CURRENCY_SYMBOL; ?>"+ ui.values[ 1 ] );
		
                var amo=$( "#amount" ).val();
		


                var url = Path+"products/ajax_post_products/?amount="+amo;
                $.post(url,function(check){
                    $('#product').html(check);
		  
               });
					
            },
				
        });
			
        $( "#amount" ).val("<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 0 ) +
            " - " +"<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 1 ) );
	
    });
</script>		 
<!--price filter end--> 

                        
                        <div class="content_right">
                            <div class="content_deals_top">
                                 <a href="#" title="city"><img alt="city" src="<?php echo PATH.'themes/'.THEME_NAME ?>/images/city_rgt_img.png" /></a> 
                            </div> 
                            <div class="deals_under_bg">
                                <p>Sorry, there are no items today under this category</p>
                            </div>
                            <div class="content_deals_midd">
				<?php if(!$this->UserID){ ?>
                                <span>Sign Up for <?php if(isset($this->is_deals)){ echo "Deal"; } elseif(isset($this->is_product)){ echo "Product"; } elseif(isset($this->is_auction)){ echo "Auction"; } else { echo "Deal";} ?> alerts and never miss out on the saving !</span>
				<?php } ?>
                                <div class="cont_deal_city">
									<form name="Subscribe" method="post" id="commentForm_deals" action="<?php echo PATH;?>users/subscribe_city">
                                    <div class="deal_email_add">
										<input type="text" name="subscribe_email" value="" placeholder="<?php echo $this->Lang['EMAIL_ADDR']; ?>"  />
                                        <em style="padding-top:2px;"><?php if(isset($this->form_error['subscribe_email'])){ echo $this->form_error['subscribe_email']; }?></em>
                                    </div>
                                    
                                    <div class="deal_your_city">
										
                                        <select name="city_id" >
											<?php  foreach($this->all_city_list as $city){?>
												<option <?php if($this->city_id == $city->city_id){ echo "selected='selected'"; } ?>   value="<?php echo $city->city_id;?>"><?php echo ucfirst($city->city_name); ?></option>
											<?php } ?>
										</select>
										
                                    </div>
                                   
                                    <div class="deal_sub_button">
                                        <div class="new_submit">
                                            <div class="gren_left">
                                                <div class="gren_right">
                                                    <div class="gren_mid"><input type="submit" title="Submit" value="<?php echo $this->Lang['SUBS_NW']; ?>" /></div> 
                                                </div>
                                            </div>															
                                        </div>
                                    </div>
                                    </form>
                                </div>
								
                                <div class="deal_already">
									  <?php if(!$this->UserID){ ?>
                                    <a href="javascript:showlogin();" title="Already Have An Access? Log In Here">Already Have An Access? Log In Here</a>
                                    <?php } ?>
                                    <p>WE APPRECIATE YOUR BUSINESS AND WE WILL NEVER SHARE YOUR EMAIL ADDRESS WITH THIRD PARTIES.</p>
                                </div>

                            </div>

                        </div>
                    </div>
                    <!--end-->
                </div>

            </div>
        </div>


                            <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample_new').mouseover(function() {


                                        var getUID =  $(this).attr('id').replace('sample_new-','');
                                        var url = Path+"products/all_products/?cate_id="+getUID;

    	
                                        $.post(url,function(check){

    			
                                            if(getUID!=""){
                                                $('#categeory_new-'+getUID).html(check);
    		
                                                $('#categeory_new-'+getUID).show();
                                 
    		
                                            }
    			
                                        });

                                    });


                                });  
      

                            </script>
                             <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample23').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample23-','');
                                        var url = Path+"deals/today_deals/?cate_id="+getUID;

    	
                                        $.post(url,function(check){

    			
                                            if(getUID!=""){
                                                $('#categeory23-'+getUID).html(check);
    		
                                                $('#categeory23-'+getUID).show();
                                 
    		
                                            }
    			
                                        });

                                    });


                                });  
      

                            </script>
                              <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample33').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample33-','');
                                        var url = Path+"auction/today_auction/?cate_id="+getUID;
    	
                                        $.post(url,function(check){
    			
                                            if(getUID!=""){
                                                $('#categeory33-'+getUID).html(check);
    			
                                                $('#categeory33-'+getUID).show();
                                       

                                            }
                                        });
                                    });
                                });  
                            </script>




