<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<style type="text/css">
* { font-family: Verdana; font-size: 96%; }
label { width: 10em; float: left; }
</style>
<script>
$(document).ready(function(){
 
$("#commentForm_deals").validate();
});
</script>
<?php  foreach($this->deals_payment_deatils as $payment) {  ?>
<form name="payment" method="POST" id="commentForm_deals" action="<?php echo PATH;?>auction_paypal/dodirectpayment">
	<input name="P_QTY" id="PC_QTY_VAL" value="1" type="hidden" >
	<input name="deal_id"  type="hidden" value="<?php echo $payment->deal_id; ?>" >
	<input name="merchant_id"  type="hidden" value="<?php echo $payment->merchant_id; ?>" >
	<input name="bid_id"  type="hidden" value="<?php echo $this->bid_id; ?>" >
	<input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" >
	<input name="url_title" type="hidden" value="<?php echo $payment->url_title; ?>" >
	<input name="deal_value" type="hidden" value="<?php echo $payment->deal_value; ?>" >
	<input name="shipping_amount"  type="hidden" value="<?php echo $payment->shipping_fee; ?>" >
	<input name="amount" id="PC_AMOUNT"  type="hidden" value="<?php echo $this->current_bid_value; ?>" >     
  
				<div class="contianer">
				<!--content start-->
                    <div class="content_abouts" id="payment_credit_card">
                        <div class="content_auction_top">
                            <h2>Credit card Account</h2>
                            
                        </div>
                        
                        <div class="personal_info_panel">
                            <p class="per-info-heading_2"><?php echo $this->Lang['ACC_INFO']; ?></p>
                            <div class="per-info-section">
                                <div class="contact_form_3">
                                    <ul>
                                        <li>
                                            <label>  <?php echo $this->Lang['CAR_HOLDER']; ?> :<span class="form_star">*</span></label>
                                            <div class="fullname">
                                                <input type="text" value="" AUTOCOMPLETE="OFF"  name="firstName" class="required"/>
                                            </div>
                                            <em><?php if(isset($this->form_error['firstName'])){ echo $this->form_error["firstName"]; }?></em>
                                        </li>
                                        <li>
                                            <label><?php echo $this->Lang['CARD_NUMBER']; ?>:<span class="form_star">*</span></label>
                                            <div class="fullname">
                                                <input type="text" maxlength="19" AUTOCOMPLETE="OFF" name="creditCardNumber" class="required creditcard"/>
                                            </div>
                                            <em><?php if(isset($this->form_error['creditCardNumber'])){ echo $this->form_error["creditCardNumber"]; }?></em>
                                            <div class="security_cards_img">   </div>   
                                        </li>
                                        <li>
                                            <label><?php echo $this->Lang['SECU_CODE']; ?> :<span class="form_star">*</span></label>
                                            <div class="security_code_outer">
                                                <div class="security_code">
                                                    <input type="text" maxlength="4" AUTOCOMPLETE="OFF"  name="cvv2Number" class="required number"/>
                                                </div>
                                                 <div class="card_img">  </div>
                                                <em><?php if(isset($this->form_error['cvv2Number'])){ echo $this->form_error["cvv2Number"]; }?></em>
                                               
                                                
                                            </div>


                                        </li>

                                        <li>
                                            <label><?php echo $this->Lang['EXPI_DATE']; ?>:<span class="form_star">*</span></label>
                                            <div class="exp_date_outer"><div class="expir_date"> 
												<select name=expDateMonth >
													<?php for($m=1; $m<=12; $m++){ ?>
														<option value="<?php echo $m;?>" <?php if(date("n",time()) == $m){echo "Selected";}?>><?php echo $m;?></option>
													<?php } ?>
									  			</select>
                                            </div>
                                                <div class="expir_date"> 
													<select name=expDateYear>
														<?php for($y=2012; $y<=2024; $y++){ ?>
															<option value="<?php echo $y;?>"   <?php if(date("Y",time()) == $y){echo "Selected";}?>><?php echo $y;?></option>
														<?php } ?>
													</select>
                                                </div>
                                            </div>
                                        </li>

                                    </ul>

                                </div>

                                <div class="contact_form">
                                    <ul>
                                        <li>
                                            <label> <?php echo $this->Lang['BILL_ADD']; ?> :<span class="form_star">*</span></label>
                                            <div class="fullname">
                                                <input type="text" maxlength="100" AUTOCOMPLETE="OFF"  name="address1" class="required" />
                                            </div>
                                            <em><?php if(isset($this->form_error['address1'])){ echo $this->form_error["address1"]; }?>	</em>
                                        </li>
                                        <li>
                                            <label><?php echo $this->Lang['CITY']; ?> :<span class="form_star">*</span></label>
                                            <div class="fullname">
                                                <input type="text" maxlength="40" AUTOCOMPLETE="OFF"  name="city" class="required"/>
                                            </div>
                                            <em><?php if(isset($this->form_error['city'])){ echo $this->form_error["city"]; }?></em>
                                        </li>
                                        <li>
											<label><?php echo $this->Lang['STATE_PROVINCE']; ?> :<span class="form_star">*</span></label>
											<div class="fullname">
												<input type="text" maxlength="2" AUTOCOMPLETE="OFF"  name="state" class="required"/>
											</div>
											<em><?php if(isset($this->form_error['state'])){ echo $this->form_error["state"]; }?></em>     
                                            
                                        </li>

                                        <li>
											<label><?php echo $this->Lang['POSTAL_CODE']; ?> :<span class="form_star">*</span></label>
											<div class="fullname">
												<input type="text" maxlength="10" name="zip" AUTOCOMPLETE="OFF"  class="required number"/>
											</div>
											<em><?php if(isset($this->form_error['zip'])){ echo $this->form_error["zip"]; }?></em>
                                            
                                        </li>
                                    </ul>
                                </div>

                            </div>

                        </div>
                        <div class="personal_info_panel">
                            <p class="per-info-heading_2"><?php echo $this->Lang['SHIPPING_INFO']; ?></p>
                            <div class="per-info-section">
                                <div class="contact_form_3">
                                    <ul>
                                        <li>
                                            <label> <?php echo $this->Lang['NAME']; ?>  :<span class="form_star">*</span></label>
                                            <div class="fullname"><input name="shipping_name" size="40" AUTOCOMPLETE="OFF"  placeholder="<?php echo $this->Lang['ENTER_NAME']; ?>" type="text" value="" class="required" maxlength="256"/>
                                            </div>
                                        </li>
                                        <li>
                                            <label> <?php echo $this->Lang['ADDR2']; ?>  :<span class="form_star">*</span></label>
                                            <div class="fullname"><input name="shipping_address2" AUTOCOMPLETE="OFF"  placeholder="<?php echo $this->Lang['ENTER_ADD']; ?>" type="text" value="" size="40" class="required" maxlength="256"/>
                                            </div>
                                        </li>
                                        <li>
											<label><?php echo $this->Lang['SEL_CITY']; ?> :<span class="form_star">*</span></label>
												<div class="fullname">
												<select name="shipping_city">
                                                <?php $cityid = $this->city_id;
                                                if(isset($this->current_cityid)){ $cityid = $this->current_cityid;}
                                                $cityURL = "";
                                                foreach($this->all_city_list as $CData){ if($CData->city_id == $cityid){ $cityURL = $CData->city_url.".html";?>
                                                <option value="<?php echo $CData->city_id; ?>"><?php echo ucfirst($CData->city_name); ?></option>
                                                <?php 	}   }
                                                foreach($this->all_city_list as $CityL){ ?>
                                                <option <?php if($CityL->city_url==$this->input->get('city')){ echo 'Selected="true"'; } ?> value="<?php echo $CityL->city_id; ?>"><?php echo ucfirst($CityL->city_name); ?></option>
                                                <?php } ?>
                                                </select>
												
                                           
                                            </div>

                                        </li>
                                        <li>
                                            <label><?php echo $this->Lang['POSTAL_CODE']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input name="shipping_postal_code" size="40" AUTOCOMPLETE="OFF"  placeholder="<?php echo $this->Lang['ENTER_POSTAL_CODE']; ?>" type="text" value="" class="required number" maxlength="10"/></div>
                                        </li>

                                    </ul>

                                    <div class="complete-order-button">
                                        <div class="ora_left_1">
                                             <div class="ora_right_1">
                                                 <div class="ora_mid2_1">
													<input type="submit" value="<?php echo $this->Lang['COMP_ODR']; ?>" title="<?php echo $this->Lang['COMP_ODR']; ?>" />
												</div>
											</div>
										</div>
                                    </div>



                                </div>

                                <div class="contact_form">
                                    <ul>
                                        <li>
											<label><?php echo $this->Lang['ADDR1']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input name="shipping_adderss1" size="40" AUTOCOMPLETE="OFF"  placeholder="<?php echo $this->Lang['ENTER_ADD']; ?>" type="text" value="" class="required" maxlength="256"/></div>
                                           
                                        </li>
                                        <li>
                                            <label><?php echo $this->Lang['STATE']; ?> :<span class="form_star">*</span> </label>
												<div class="fullname"><input name="shipping_state" AUTOCOMPLETE="OFF"  placeholder="<?php echo $this->Lang['ENTER_STATE']; ?>" type="text" value="" size="40" class="required" maxlength="256"/></div>
                                        </li>
                                        <li>
												<label><?php echo $this->Lang['COUNTRY']; ?> :<span class="form_star">*</span></label>
												<div class="fullname">
												<select name="shipping_country">
												<?php foreach($this->all_country_list as $countryL){ ?>
                                                <option <?php if($countryL->country_url==$this->input->get('country')){ echo 'Selected="true"'; } ?> value="<?php echo $countryL->country_name; ?>"><?php echo ucfirst($countryL->country_name); ?></option>
                                                <?php } ?>
                                                </select>
												
										</li>
											
											
										<li>
												<label><?php echo $this->Lang['PHONE']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input name="shipping_phone" size="40" AUTOCOMPLETE="OFF"  placeholder="<?php echo $this->Lang['ENTER_PHONE']; ?>" type="text" value="" class="required number" maxlength="18"/></div>
										</li>

                                    </ul>
                                </div>

                            </div>

                        </div>
                    </div>
                    
                    <!--end-->
                </div>
</form>
<?php } ?>
				
