<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script>
$(document).ready(function(){
 
$("#commentpaypal_deals").validate();
});
</script>
<form name="payment" method="POST" id="commentpaypal_deals" action="<?php echo PATH; ?>payment/paypal.php">
<div class="paypal_but">
<?php  foreach($this->deals_payment_deatils as $payment) {  ?>

        <?php if($this->uri->segment(2) == "payment_details_friend"){ ?>
     
                        <p class="per-info-heading"><?php echo $this->Lang['FRI_INFO']; ?></p>
						<div class="per-info-section">
						<div class="contact_form">
										<ul>
											<li>
												<label> <?php echo $this->Lang['FRI_NAME']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text" value="" name="friend_name" AUTOCOMPLETE="OFF"  class="required"/></div>
												<em>
                        <?php if(isset($this->form_error['friend_name'])){ echo $this->form_error["friend_name"]; }?>
                        </em>
											</li>
											<li>
												<label><?php echo $this->Lang['FRI_EMAIL']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text" value="" name="friend_email" AUTOCOMPLETE="OFF"  class="required email"/></div>
												<em>
                        <?php if(isset($this->form_error['friend_email'])){ echo $this->form_error["friend_email"]; }?>
                        </em>
											</li>
											</ul>
											</div>
											</div>
                
                <input name="friend_gift"  value="1" type="hidden">

        <?php } else {?>
                <input name="friend_name"  type="hidden" value="xxxyyy" >
                <input name="friend_email"   type="hidden" value="xxxyyy@zzz.com" >
                <input name="friend_gift"  value="0" type="hidden">
        <?php } ?>
        <input name="P_QTY" id="PC_QTY_VAL" value="1" type="hidden" >
        <input name="deal_id"  type="hidden" value="<?php echo $payment->deal_id; ?>" >
        <input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" >
        <input name="deal_value" type="hidden" value="<?php echo $payment->deal_value; ?>" >
        <input name="amount" id="PC_AMOUNT"  type="hidden" value="<?php echo $payment->deal_value; ?>" >
        <input name="p_referral_amount" id="PC_REFERRAL" value="0" type="hidden" >


          <div class="personal_info_panel"> <div class="paypal_link"> <a > <input name="Submit" type="submit" value="" /> </a></div>  </div>
        <div class="payment_terms_outer"><p class="terms-conditons-text"> <span class="fl font_myriad_pro"><?php echo $this->Lang['BY_CLICK']; ?> </span> <a href="<?php echo PATH;?>terms-and-conditions.php" title="<?php echo $this->Lang['TEMRS']; ?>" class="font_myriad_pro mt5"><?php echo $this->Lang['TEMRS']; ?>.</a></p> </div>        
        
        <?php } ?>
</div>
</form>
