<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<style type="text/css">
    * { font-family: Verdana; font-size: 96%; }
    label { width: 10em; float: left; }
</style>
<script>
    $(document).ready(function(){
         $("#commentForm_authorize").validate({
 submitHandler: function(form) {
   // some other code
   // maybe disabling submit button
   // then:
	$('div#submit').hide();
   form.submit();
 }
});
});
   
</script>
<?php  foreach($this->deals_payment_deatils as $payment) {  ?>
<form name="payment" method="POST" id="commentForm_authorize" action="<?php echo PATH;?>authorize/dodirectpayment">
  <input name="P_QTY" id="APCC_QTY_VAL" value="1" type="hidden" >
  <input name="deal_id"  type="hidden" value="<?php echo $payment->deal_id; ?>" >
  <input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" >
  <input name="deal_value" type="hidden" value="<?php echo $payment->deal_value; ?>" >
  <input name="amount" id="APCC_AMOUNT"  type="hidden" value="<?php echo $payment->deal_value; ?>" >
  <input name="p_referral_amount" id="APCC_REFERRAL" value="0" type="hidden">
  <?php if($this->uri->segment(2) == "payment_details_friend"){ ?>
  <p class="per-info-heading">
      <?php echo $this->Lang['FRI_INFO']; ?></p>
			<div class="per-info-section">
			<div class="contact_form">
							<ul>
								<li>
									<label> <?php echo $this->Lang['FRI_NAME']; ?> :<span class="form_star">*</span></label>
									<div class="fullname"><input type="text" value=""  AUTOCOMPLETE="OFF" name="friend_name" class="required"/></div>
									<em>
            <?php if(isset($this->form_error['friend_name'])){ echo $this->form_error["friend_name"]; }?>
            </em>
								</li>
								<li>
									<label><?php echo $this->Lang['FRI_EMAIL']; ?> :<span class="form_star">*</span></label>
									<div class="fullname"><input type="text" value="" AUTOCOMPLETE="OFF" name="friend_email" class="required email"/></div>
									<em>
            <?php if(isset($this->form_error['friend_email'])){ echo $this->form_error["friend_email"]; }?>
            </em>
								</li>
						</ul>
				    </div>
				</div>
                <input name="friend_gift"  value="1" type="hidden">

  <?php } else {?>
          <input name="friend_name"  type="hidden" value="xxxyyy" >
          <input name="friend_email"   type="hidden" value="xxxyyy@zzz.com" >
          <input name="friend_gift"  value="0" type="hidden">

  <?php } ?>
<div class="personal-info-panel">
<p class="per-info-heading"><?php echo $this->Lang['ACC_INFO']; ?></p>
						<div class="per-info-section">
						<div class="contact_form">
										<ul>
											<li>
												<label> <?php echo $this->Lang['CAR_HOLDER']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text" value=""  AUTOCOMPLETE="OFF" name="firstName" class="required"/></div>
												<em>
        <?php if(isset($this->form_error['firstName'])){ echo $this->form_error["firstName"]; }?>
        </em>    
											</li>
											<li>
												<label><?php echo $this->Lang['CARD_NUMBER']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text"  AUTOCOMPLETE="OFF" maxlength="19" name="creditCardNumber" class="required creditcard"/></div>
												<em>
        <?php if(isset($this->form_error['creditCardNumber'])){ echo $this->form_error["creditCardNumber"]; }?>
        </em>    
											</li>
											<li>
												<label><?php echo $this->Lang['SECU_CODE']; ?> :<span class="form_star">*</span></label>
											<div class="security_code_outer">	<div class="security_code"><input type="text" maxlength="4"  AUTOCOMPLETE="OFF" name="cvv2Number" class="required number"/></div>
											<div class="card_img">  </div>
                                                                                            <em>
        <?php if(isset($this->form_error['cvv2Number'])){ echo $this->form_error["cvv2Number"]; }?>
        </em> 
                                                 
                                                 
                                                                                        </div>
                                            <div class="security_cards_img">   </div>     
                                                
											</li>
                                            
                                            <li>
												<label><?php echo $this->Lang['EXPI_DATE']; ?> :</label>
												<div class="exp_date_outer"><div class="expir_date"> <select name=expDateMonth >
            <?php for($m=1; $m<=12; $m++){ ?>
            <option value="<?php echo $m;?>" <?php if(date("n",time()) == $m){echo "Selected";}?>><?php echo $m;?></option>
            <?php } ?>
          </select></div>
                                                <div class="expir_date"> <select name=expDateYear>
            <?php for($y=2012; $y<=2024; $y++){ ?>
            <option value="<?php echo $y;?>"   <?php if(date("Y",time()) == $y){echo "Selected";}?>><?php echo $y;?></option>
            <?php } ?>
          </select></div></div>
											</li>
											
											
										
										</ul>
                                        
                                        <div class="complete-order-button" id="submit">
											 <div class="ora_left">
                                                                                              <div class="ora_right">
                                                                                                  <div class="ora_mid2">
												<input type="submit" value="<?php echo $this->Lang['COMP_ODR']; ?>" title="<?php echo $this->Lang['COMP_ODR']; ?>" />
											</div>
											</div>
                                                        </div>
										
											
										</div>
                                        
                                        
                                        <div class="payment_terms_outer"><p class="terms-conditons-text" style="padding-left:0px;"> <span class="fl font_myriad_pro"><?php echo $this->Lang['BY_CLICK']; ?> </span> <a href="<?php echo PATH;?>terms-and-conditions.php" title="<?php echo $this->Lang['TEMRS']; ?>" class="font_myriad_pro mt5"><?php echo $this->Lang['TEMRS']; ?>.</a></p> </div>
                                        
                                        	
						  </div>
						  
						  <div class="contact_form">
										<ul>
											<li>
												<label><?php echo $this->Lang['BILL_ADD']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text"  AUTOCOMPLETE="OFF" maxlength="100" name="address1" class="required" /></div>
												<em>
                                                <?php if(isset($this->form_error['address1'])){ echo $this->form_error["address1"]; }?>
                                                </em>
											</li>
											<li>
												<label><?php echo $this->Lang['CITY']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text"  AUTOCOMPLETE="OFF" maxlength="40" name="city" class="required"/></div>
												<em>
                                                <?php if(isset($this->form_error['city'])){ echo $this->form_error["city"]; }?>
                                                </em>
											</li>
											<li>
												<label><?php echo $this->Lang['STATE_PROVINCE']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text" maxlength="2"  AUTOCOMPLETE="OFF" name="state" class="required"/></div>
												<em>
                                                <?php if(isset($this->form_error['state'])){ echo $this->form_error["state"]; }?>
                                                </em>    
											</li>
											
											<li>
												<label><?php echo $this->Lang['COUNTRY']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text"  AUTOCOMPLETE="OFF" maxlength="64" name="country" class="required"/></div>


												<em>
                                                <?php if(isset($this->form_error['country'])){ echo $this->form_error["country"]; }?>
                                                </em>     
											</li>
                                            
                                            <li>
												<label><?php echo $this->Lang['POSTAL_CODE']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text"  AUTOCOMPLETE="OFF" maxlength="10" name="zip" class="required number"/></div>
												<em>
                                                <?php if(isset($this->form_error['zip'])){ echo $this->form_error["zip"]; }?>
                                                </em>     
											</li>
											<li>
												<label><?php echo $this->Lang['PHONE']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text"  AUTOCOMPLETE="OFF" maxlength="10" name="phone" class="required number"/></div>
												<em>
                                                <?php if(isset($this->form_error['phone'])){ echo $this->form_error["phone"]; }?>
                                                </em>     
											</li>
											
											
										</ul>
						  </div>
                          
                         
						
						</div>
						</div>
                          
                        </form>
<?php } ?>

