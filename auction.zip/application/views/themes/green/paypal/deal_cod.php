<?php defined('SYSPATH') OR die('No direct access allowed.');


if(count($this->user_shipping)>0)
{
	foreach($this->user_shipping as $user_shipping)
	{
		$s_address=isset($user_shipping->address)?$user_shipping->address:0;
		$s_email=isset($user_shipping->email)?$user_shipping->email:0;
		$s_phone=isset($user_shipping->phone)?$user_shipping->phone:0;
		$s_city=isset($user_shipping->city)?$user_shipping->city:0;
		$s_state=isset($user_shipping->state)?$user_shipping->state:0;
		$s_country=isset($user_shipping->country)?$user_shipping->country:0;
		$s_fb_id=isset($user_shipping->fb_id)?$user_shipping->fb_id:0;
		$s_sname=isset($user_shipping->shipping_name)?$user_shipping->shipping_name:0;
		$s_postal_code=isset($user_shipping->pin)?$user_shipping->pin:0;
	}
}
else
{
		$s_address="";
		$s_email="";
		$s_phone="";
		$s_city="";
		$s_state="";
		$s_country="";
		$s_fb_id="";
		$s_sname="";
		$s_postal_code="";
	
}

?>
<script>
$(document).ready(function(){
 

 $("#Cod_deals").validate({
 submitHandler: function(form) {
   // some other code
   // maybe disabling submit button
   // then:
	$('div#submit').hide();
   form.submit();
 }
});
});
</script>
<form name="payment" method="POST" id="Cod_deals" action="<?php echo PATH; ?>payment/deal_cod.php">
<div class="paypal_but">
<?php  foreach($this->deals_payment_deatils as $payment) {  ?>

        <?php if($this->uri->segment(2) == "payment_details_friend"){ ?>
     
                        <p class="per-info-heading"><?php echo $this->Lang['FRI_INFO']; ?></p>
						<div class="per-info-section">
						<div class="contact_form">
										<ul>
											<li>
												<label> <?php echo $this->Lang['FRI_NAME']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text" value="" name="friend_name" AUTOCOMPLETE="OFF"  class="required"/></div>
												<em>
                        <?php if(isset($this->form_error['friend_name'])){ echo $this->form_error["friend_name"]; }?>
                        </em>
											</li>
											<li>
												<label><?php echo $this->Lang['FRI_EMAIL']; ?> :<span class="form_star">*</span></label>
												<div class="fullname"><input type="text" value="" name="friend_email" AUTOCOMPLETE="OFF"  class="required email"/></div>
												<em>
                        <?php if(isset($this->form_error['friend_email'])){ echo $this->form_error["friend_email"]; }?>
                        </em>
											</li>
											</ul>
											</div>
											</div>
                
                <input name="friend_gift"  value="1" type="hidden">

        <?php } else {?>
                <input name="friend_name"  type="hidden" value="xxxyyy" >
                <input name="friend_email"   type="hidden" value="xxxyyy@zzz.com" >
                <input name="friend_gift"  value="0" type="hidden">
        <?php } ?>
        <input name="P_QTY" id="PC_QTY_VAL" value="1" type="hidden" >
        <input name="deal_id"  type="hidden" value="<?php echo $payment->deal_id; ?>" >
        <input name="deal_key" type="hidden" value="<?php echo $payment->deal_key; ?>" >
        <input name="deal_value" type="hidden" value="<?php echo $payment->deal_value; ?>" >
        <input name="amount" id="PC_AMOUNT"  type="hidden" value="<?php echo $payment->deal_value; ?>" >
        <input name="p_referral_amount" id="PC_REFERRAL" value="0" type="hidden" >


          
        <?php } ?>
  <div class="personal_info_panel">
        <p class="per-info-heading">shipping Information</p>
        <div class="per-info-section">
            <div class="contact_form1">
                <ul>
                    <li>
                        <label><?php echo $this->Lang['NAME']; ?> :<span class="form_star">*</span></label>
                        <div class="fullname"><input name="shipping_name" size="40" AUTOCOMPLETE="OFF"   type="text" value="<?php echo $s_sname;?>" class="required" maxlength="256"/></div>
                        <em>
        <?php if(isset($this->form_error['shipping_name'])){ echo $this->form_error["shipping_name"]; }?>
        </em>    
                    </li>

                    <li>
                        <label><?php echo $this->Lang['EMAIL']; ?> :<span class="form_star">*</span> </label>
                        <div class="fullname"><input name="email" AUTOCOMPLETE="OFF"  type="text" value="<?php echo $s_email;?>" size="40" class="required" maxlength="256"/></div>
                 
                  <em>
        <?php if(isset($this->form_error['email'])){ echo $this->form_error["email"]; }?>
        </em>    
                    </li>



                    <li>
                        <label><?php echo $this->Lang['SEL_CITY']; ?> :</label>
                        <div class="fullname">
                            <select name="city">
                                <?php
                                $cityid = $this->city_id;
                                if (isset($this->current_cityid)) {
                                    $cityid = $this->current_cityid;
                                }
                                $cityURL = "";

foreach ($this->all_city_list as $CityL) {
    ?>
 <option <?php if ($CityL->city_id ==  $s_city) {
        echo 'Selected="true"';
    } ?> value="<?php echo $CityL->city_id; ?>"><?php echo ucfirst($CityL->city_name); ?></option>
<?php } ?>
                            </select>

                        </div>

                    </li>

                    <li>
                        <label><?php echo $this->Lang['POSTAL_CODE']; ?> :<span class="form_star">*</span></label>
                        <div class="fullname"><input name="postal_code" size="40" AUTOCOMPLETE="OFF"  type="text" value="<?php echo $s_postal_code;?>" class="required number" maxlength="256"/></div>
                                 
                  <em>
        <?php if(isset($this->form_error['postal_code'])){ echo $this->form_error["postal_code"]; }?>
        </em>  
                    </li>

                </ul>




          
                <div class="payment_terms_outer"><p class="terms-conditons-text" id="terms1"> <span class="fl font_myriad_pro"><?php echo $this->Lang['BY_CLICK']; ?> </span> <a href="<?php echo PATH; ?>terms-and-conditions.php" title="<?php echo $this->Lang['TEMRS']; ?>" class="font_myriad_pro mt5"><?php echo $this->Lang['TEMRS']; ?>.</a></p> </div>



            </div>

            <div class="contact_form">
                <ul>
                    <li>
                        <label><?php echo $this->Lang['ADDRESS']; ?> :<span class="form_star">*</span></label>
                        <div class="fullname"><input name="address" size="40" AUTOCOMPLETE="OFF"  type="text" value="<?php echo $s_address;?>" class="required" maxlength="256"/></div>
                   
                           <em>
        <?php if(isset($this->form_error['address'])){ echo $this->form_error["address"]; }?>
        </em> 
                    </li>

                    <li>
                        <label><?php echo $this->Lang['STATE']; ?> :<span class="form_star">*</span> </label>
                        <div class="fullname"><input name="state" AUTOCOMPLETE="OFF"  type="text" value="<?php echo $s_state;?>" size="40" class="required" maxlength="256"/></div>
                                   <em>
        <?php if(isset($this->form_error['state'])){ echo $this->form_error["state"]; }?>
        </em> 
                    
                    </li>

                    <li>
                        <label><?php echo $this->Lang['COUNTRY']; ?> :<span class="form_star">*</span></label>
                        <div class="fullname">
                            <select name="country">
<?php foreach ($this->all_country_list as $countryL) { ?>
                                    <option <?php if ($countryL->country_id == $s_country	) {
        echo 'Selected="true"';
    } ?> value="<?php echo $countryL->country_id; ?>"><?php echo ucfirst($countryL->country_name); ?></option>
<?php } ?>
                            </select>
                        </div>

                    </li>


                    <li>
                        <label><?php echo $this->Lang['PHONE']; ?> :<span class="form_star">*</span></label>
                        <div class="fullname"><input name="phone" size="40" AUTOCOMPLETE="OFF"   type="text" value="<?php echo $s_phone;?>" class="required number" maxlength="18"/></div>
                        
                                                           <em>
        <?php if(isset($this->form_error['phone'])){ echo $this->form_error["phone"]; }?>
        </em> 
                    </li>



 <li>
												<label><?php echo "Facebook ID" ?> :<span class="form_star"></span></label>
												<div class="fullname"><input value="<?php echo $s_fb_id;?>" type="text" AUTOCOMPLETE="OFF"  maxlength="20" name="fb_id" /></div>
												<em>
                                                <?php if(isset($this->form_error['fb_id'])){ echo $this->form_error["fb_id"]; }?>
                                                </em>     
											</li>


                </ul>
            </div>
    <div class="complete-order-button" id="submit">
                                                        <div class="ora_left">
                                                             <div class="ora_right">
                                                                    <div class="ora_mid2">
                                                            <input type="submit" value="Complete Order" title="Complete Order" />
                                                        </div>
                                                        </div>
                                                        </div>


        </div>


    </div>
    
</div>
</form>
