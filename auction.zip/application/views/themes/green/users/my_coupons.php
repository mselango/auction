<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript"> 
    $(document).ready(function(){
        $('.products_coupon').hide();
        $('.auctions_coupon').hide();
    });
</script>
<script type="text/javascript"> 
    function CouponsDeals() {
        $('.deals_coupon').show();
        $('.products_coupon').hide();
        $('.auctions_coupon').hide();
                                
        $("#CouponsDeals").addClass("sub_act");
        $("#CouponsProducts").addClass("sub_act");
        $("#CouponsAuctions").removeClass("sub_act");
        $("#CouponsProducts").addClass("sub_act");	
        $("#CouponsDeals").addClass("sub_act1");
        $("#CouponsAuctions").removeClass("sub_act1");
        $("#CouponsProducts").removeClass("sub_act1");			
       		
    }
        
    function CouponsProducts() {


        $('.products_coupon').show();
        $('.deals_coupon').hide();
        $('.auctions_coupon').hide();
                
        $("#CouponsProducts").addClass("sub_act");
	
        $("#CouponsAuctions").removeClass("sub_act");
        $("#CouponsDeals").addClass("sub_act");
        $("#CouponsProducts").addClass("sub_act1");
        $("#CouponsAuctions").removeClass("sub_act1");
        $("#CouponsDeals").removeClass("sub_act1");
    }
    function CouponsAuctions() {


        $('.auctions_coupon').show();
        $('.deals_coupon').hide();
        $('.products_coupon').hide();

               
        $("#CouponsProducts").addClass("sub_act");
				
       		
        $("#CouponsProducts").removeClass("sub_act1");
        $("#CouponsAuctions").addClass("sub_act1");
        $("#CouponsAuctions").removeClass("sub_act");
        $("#CouponsDeals").removeClass("sub_act1");
    }
</script>

<div class="contianer_outer1">
    <div class="contianer_inner">

        <div class="contianer">
            <div class="bread_crumb">

                <ul>
                    <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                    <li><p>  <?php echo $this->Lang['MY_BUYS']; ?></p></li>
                </ul>
            </div>
            <!--content start-->
            <div class="content_abouts">
                <div class="all_mapbg_mid_common">
                    <div class="content_abou_common">
                         <div class="pro_top">
                        <h2>  <?php echo $this->Lang['MY_BUYS']; ?></h2>
                         </div>
                        <div class="all_mapbg_mid">   
                            <div class="myemai_mnu">
                                <div class="top_menu myemail_subbor">
                                    <ul>
                                        <li class="tab_act">
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div>
                                            <div class="tab_rgt"></div>

                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> 
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-winner-list.html" title="Won Auction"><?php echo 'Won Auction'; ?></a></div> 
                                            <div class="tab_rgt"></div>

                                        </li>
                                    </ul>                                                                
                                </div> 
                            </div>
                        </div>
                        <div class="bot_menu">
                            <ul>
                                <li  class="sub_act sub_act1" id="CouponsDeals">
                                    <a onclick="return CouponsDeals();"  style="cursor:pointer;" title="<?php echo $this->Lang['DEALS']; ?>"  ><?php echo $this->Lang['DEALS']; ?></a>
                                </li>
                                <li class="sub_act" id="CouponsProducts">
                                    <a onclick="return CouponsProducts();"title="<?php echo $this->Lang['PRODUCTS']; ?>" style="cursor:pointer;" ><?php echo $this->Lang['PRODUCTS']; ?></a>
                                </li>
                                <li id="CouponsAuctions">
                                    <a onclick="return CouponsAuctions();"title="<?php echo "Auctions"; ?>" style="cursor:pointer;" ><?php echo 'Auctions'; ?></a>
                                </li>
                            </ul>                                                                
                        </div>
                        <div class="mybuys_content">  

                            <div class="mybuys_content_top deals_coupon"> 
                                <ul>
                                    <li class="my_buy_title"><?php echo $this->Lang['TITLE']; ?></li>
                                    <li class="my_buy_storename"><?php echo $this->Lang['STORE_NAME']; ?></li>
                                    <li class="my_buy_pur_date"><?php echo $this->Lang['PURCHASE_DATE']; ?></li>
                                    <li class="my_buy_expiry"><?php echo $this->Lang['EXPIRY']; ?></li>
                                    <li class="my_buy_status"><?php echo $this->Lang['STATUS1']; ?></li>
                                    <li class="my_buy_daysleft" ><center><?php echo $this->Lang['DAYS_LEFT']; ?></center></li>
                                    <li class="my_buy_downloadcoupon"><?php echo $this->Lang['DOWNLOAD']; ?></li>
                                </ul>
                            </div>
                            <div class="mybuys_content_top products_coupon"> 
                                <ul>
                                    <li class="my_buy_title"><?php echo $this->Lang['TITLE']; ?></li>
                                    <li class="my_buy_title"><?php echo $this->Lang['STORE_NAME']; ?></li>
                                    <li class="my_buy_pur_date"><?php echo $this->Lang['PURCHASE_DATE']; ?></li>
                                    <li class="my_buy_title"><?php echo 'Address'; ?></li>
                                    <li class="my_buy_storename"><?php echo $this->Lang['STATUS1']; ?></li>
                                </ul>
                            </div>

                            <div class="mybuys_content_top auctions_coupon"> 
                                <ul>
                                    <li class="my_buy_title"><?php echo $this->Lang['TITLE']; ?></li>
                                    <li class="my_buy_title"><?php echo $this->Lang['STORE_NAME']; ?></li>
                                    <li class="my_buy_pur_date"><?php echo $this->Lang['PURCHASE_DATE']; ?></li>
                                    <li class="my_buy_title"><?php echo 'Address'; ?></li>
                                    <li class="my_buy_storename"><?php echo $this->Lang['STATUS1']; ?></li>
                                </ul>
                            </div> 
                            <div class="mybuys_content_bottom deals_coupon">   
                                <?php echo new View("themes/" . THEME_NAME . "/users/deals"); ?>
                            </div>
                            <div  class="mybuys_content_bottom products_coupon">
                                <?php echo new View("themes/" . THEME_NAME . "/users/products"); ?>
                            </div>
                            <div  class="mybuys_content_bottom auctions_coupon">
                                <?php echo new View("themes/" . THEME_NAME . "/users/auction"); ?>
                            </div>
                            <div class="pagenation myrefer_pagenation deals_coupon">
                                <?php echo $this->pagination; ?>
                            </div>

                        </div>
                    </div>
                </div>  


            </div>
            <!--end-->
        </div>
    </div>
</div>

