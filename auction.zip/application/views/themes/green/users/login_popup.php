<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
	<div class="shadow_bg"></div>
	    <div class="sign_up_outer">
<div class="sign_up_top1">
	        <div class="sign_up_bott1">
                <div class="sign_up_mid1">

                    <div class="sign_up_top_logo">
                        <a href="<?php echo PATH;?>"><img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/></a>
                    </div>	
		        <a class="close2" title="close" id="close" style="cursor:pointer;">&nbsp;</a>
          <div class="sign_up_inner">        
            <div class="full_about_midd_left pro_top">
                <h2><?php echo "Sign In"; ?></h2>
                <form id="login" name="login" method="post" action="<?php echo PATH; ?>users/login" onsubmit="return validateForms();"  autocomplete="off">
                    <div class="email">
                        <label><?php echo $this->Lang['EMAIL']; ?>:<span class="form_star">*</span> </label>
                        <div class="input_box">
                            <input type="text" value="" name="email" placeholder="Enter your email here" autocomplete="off">
                        </div>   
                        <em id="email_error"></em>
                    </div>
                    <div class="email">
						<label><?php echo $this->Lang['PASSWORD']; ?>:<span class="form_star">* </span> </label>
                        <div class="input_box">
                            <input type="password" placeholder="Enter your password here" value="" name="password" autocomplete="off">
                        </div> 
                        <em id="password_error"></em>
                    </div>
                    <a href="javascript:showforgotpassword();" title="<?php echo $this->Lang['FORGOT_PASS']; ?>?"><?php echo $this->Lang['FORGOT_PASS']; ?>?</a>
                    <div class="sign_up_submit_outer4">  
                        <div class="submit">
                            <div class="sub_lft">
                               <div class="sub_rgt">
                                   <div class="sub_mid"><input type="submit" value="Sign In" title="Sign In" onclick="return validateForms();"></div>
                               </div> 
                                
                            </div>
                            
                            
                        </div>
                    </div>
                </form>
            </div>
            <div class="full_about_midd_right">
                <div class="log_bot_det">
					<p><?php echo $this->Lang['SIGN_IN_WITH']; ?></p>
					<a class="f_connect cursor" onclick="facebookconnect();" title="<?php echo $this->Lang['SIGN_UP_WITH']; ?>">&nbsp;</a>
					<p><?php echo $this->Lang['DONT_HAV']; ?> <a title="<?php echo $this->Lang['SIGN_UP']; ?>" href="javascript:showsignup();"><?php echo $this->Lang['SIGN_UP']; ?></a> </p>
                </div>
            </div>
           </div>
         </div>
       </div>
  </div>
       <div class="bottom_common_popup">&nbsp; </div>
    </div>
<script type="text/javascript">
$(document).ready(function(){
$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); //Fade in the fade layer 				   		   
//Close Popups and Fade Layer
$('#close').live('click', function() { //When clicking on the close or fade layer...
	$('#popup1').css({'visibility' : 'hidden'});
		$('.popup_block').css({'visibility' : 'hidden'});
		$('#fade').css({'visibility' : 'hidden'});
		  location.reload();
	
	
	return false;
});
		$(document).keyup(function(e) { 
        if (e.keyCode == 27) { // esc keycode
            $('#popup1').css({'visibility' : 'hidden'});
			$('.popup_block').css({'visibility' : 'hidden'});
			$('#fade').css({'visibility' : 'hidden'});
	  	
		
		return false;
        }
    });
});	
</script>


