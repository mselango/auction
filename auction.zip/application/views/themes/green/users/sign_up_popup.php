<div class="shadow_bg"></div>
            <div class="sign_up_outer">
  <div class="sign_up_top1">
	        <div class="sign_up_bott1">
                <div class="sign_up_mid1">
                    <div class="sign_up_top_logo">
                        <a href="<?php echo PATH;?>"><img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/></a>
                    </div>	
			<a class="close2" title="close" id="close1" style="cursor:pointer;" ></a>
                <div class="sign_up_inner">
                    <div class="full_about_midd_left pro_top">
                        <h2>User Sign Up</h2>
                        <form name="signup" method="post"  onsubmit="return validatesignup();" action="<?php echo PATH; ?>users/signup">
                            <div class="email">
                                <label><?php echo $this->Lang["NAME"]; ?>:<span class="form_star">*</span></label>
                                <div class="input_box">
                                   <input name="f_name" type="text" value="" />
                                   <em id="fname_error"></em>
                                </div>   
                            </div>
                            <div class="email">
                                <label><?php echo $this->Lang['EMAIL']; ?>:<span class="form_star">*</span></label>
                                <div class="input_box">
                                  <input name="email" type="text" value="" />
                                  <em id="emai_error"></em>
                                </div>   
                            </div>
                            <div class="password">
                                <label><?php echo $this->Lang['PASSWORD'];?>:<span class="form_star">*</span></label>
                                <div class="input_box">
                                    <input name="password" type="password" value="" />
                                    <em id="pass_error"></em>
                                </div>   
                            </div>


                            <div class="email">
                                <label><?php echo $this->Lang['SEL_CITY'];?>:<span class="form_star">*</span></label>
                                <div class="input_box">
                                    <select name="city">
										<option value="-99">Select Your City</option>
										<?php foreach($this->all_city_list as $c){ ?>
										<option value="<?php echo $c->city_id; ?>"><?php echo $c->city_name; ?></option>
										<?php } ?>
									</select>
                                     <em id="city_error"></em>
                                </div>
                            

                            </div>
                               
                            <div class="check_box">
                                <p><?php echo $this->Lang['BY_CLICKING_SUBMIT']; ?> 
									<span>
										<a title="<?php echo $this->Lang['TEMRS']; ?>" href="<?php echo PATH; ?>terms-and-conditions.php"><?php echo $this->Lang['TEMRS']; ?></a>
									</span>
								</p>
                            </div>
                            <div class="sign_up_submit_outer4   z">  
                                <div class="submit">
                                    <div class="sub_lft">
                                         <div class="sub_rgt">
                                              <div class="sub_mid"><input type="submit" title="Sign Up" value="Sign Up" /></div>
                                         </div>
                                    </div>
                                   
                                   
                                </div>
                            </div>



                        </form>
                    </div>

                    <div class="full_about_midd_right">
                        <div class="log_bot_det">
                           <p><?php echo $this->Lang['SIGN_IN_WITH']; ?>..</p>
                           <a class="f_connect" onclick="facebookconnect();" title="facebook connect">&nbsp;</a>
						<p><?php echo $this->Lang['ALREADY_A_MEMBER']; ?> <a title="<?php echo $this->Lang['SIGN_IN']; ?> " href="javascript:showlogin();"><?php echo $this->Lang['SIGN_IN']; ?> </a> </p>
                           
                        </div>
                    </div>
                </div>
            </div>
              </div>
 </div>
                <div class="bottom_common_popup">&nbsp; </div>
            </div>
              

<script type="text/javascript">
$(document).ready(function(){
$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); //Fade in the fade layer 				   		   
//Close Popups and Fade Layer
$('#close1').live('click', function() {
		$('.popup_block1').css({'visibility' : 'hidden'});
		$('#fade').css({'visibility' : 'hidden'});
			  location.reload();
	
	return false;
});
	$(document).keyup(function(e) { 
        if (e.keyCode == 27) { // esc keycode
        	$('.popup_block1').css({'visibility' : 'hidden'});
			$('#fade').css({'visibility' : 'hidden'});
	  	
		
		return false;
        }
    });
});	
</script> 



<?php /*<div class="login_inner">
		<div class="login">
			<div class="login_top"></div>
			<div class="login_mid">
				<a class="close" title="close" id="close1" style="cursor:pointer;" >&nbsp;</a>
				<div class="login_det">
				<div class="login_top_det">
					<div class="log_logo"><a href="<?php echo PATH; ?>"><img alt="logo" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/></a></div>
					<h1>User Signup</h1>
					<form name="signup" method="post"  onsubmit="return validatesignup();" action="<?php echo PATH; ?>users/signup">
						<ul>
							<li>
								<label><?php echo $this->Lang["NAME"]; ?> <span class="form_star"></span></label>
								<div class="full"><input name="f_name" type="text" value="" /></div>
							</li><li><em id="fname_error"></em></li>
							<li>
								<label><?php echo $this->Lang['EMAIL']; ?>:<span class="form_star"></span> </label>
								<div class="full"><input name="email" type="text" value="" /></div>
							</li><li><em id="emai_error"></em></li>
							<li>
								<label><?php echo $this->Lang['PASSWORD'];?>:<span class="form_star"></span> </label>
								<div class="full"><input name="password" type="password" value="" /></div>
							</li><li><em id="pass_error"></em></li>
							<li>
								<label><?php echo $this->Lang['SEL_CITY']; ?>:<span class="form_star"></span> </label>
								<div class="full_sel">
								<select name="city">
									<option value="-99">Select Your City</option>
								    <?php foreach($this->all_city_list as $c){ ?>
									<option value="<?php echo $c->city_id; ?>"><?php echo $c->city_name; ?></option>
									<?php } ?>
								</select>
								</div>
							</li><li><em id="city_error"></em></li>
							<li>
							<label><?php echo $this->Lang['BY_CLICKING_SUBMIT']; ?> 
								<a title="<?php echo $this->Lang['TEMRS']; ?>" href="<?php echo PATH; ?>terms-and-conditions.php"><?php echo $this->Lang['TEMRS']; ?></a></label>
							</li>
							<li>
								<div class="sign_up_submit_outer">  
                                <div class="submit">
									<div class="sub_lft"></div>
									<div class="sub_mid"><input type="submit" title="<?php echo $this->Lang['SUBMIT']; ?>" value="<?php echo $this->Lang['SUBMIT']; ?>"   onclick="return validatesignup();"/></div>
									<div class="sub_rgt"></div>
								</div>
                                </div>
							</li>
						</ul>
					</div>
					</form>
					<div class="log_bot_det">
						<p><?php echo $this->Lang['SIGN_IN_WITH']; ?>..</p>
						<a class="f_connect cur" onclick="facebookconnect();" title="facebook connect">&nbsp;</a>
						<p><?php echo $this->Lang['ALREADY_A_MEMBER']; ?> <a title="<?php echo $this->Lang['SIGN_IN']; ?> " href="javascript:showlogin();"><?php echo $this->Lang['SIGN_IN']; ?> </a> </p>
					</div>
				</div>

			</div>
			<div class="login_bot"></div>
		</div>
	</div>

<script type="text/javascript">
$(document).ready(function(){
$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); //Fade in the fade layer 				   		   
//Close Popups and Fade Layer
$('#close1').live('click', function() {
		$('.popup_block1').css({'visibility' : 'hidden'});
		$('#fade').css({'visibility' : 'hidden'});
	
	return false;
});
	$(document).keyup(function(e) { 
        if (e.keyCode == 27) { // esc keycode
        	$('.popup_block1').css({'visibility' : 'hidden'});
			$('#fade').css({'visibility' : 'hidden'});
	  	
		
		return false;
        }
    });
});	
</script> 

*/?>
