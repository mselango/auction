<div class="shadow_bg"></div>
<div class="sign_up_outer">
  <div class="sign_up_top1">
	        <div class="sign_up_bott1">
                <div class="sign_up_mid1">
                    <div class="sign_up_top_logo">
                        <a href="<?php echo PATH;?>"><img alt="logo" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png"/></a>
                    </div>	
	<a class="close2" title="close" style="cursor:pointer;">&nbsp;</a>
		<div class="sign_up_inner">
			<div class="full_about_midd_left pro_top">
				<h2>Forgot Password</h2>
				<form name="forget_password" method="post" action="<?php echo PATH; ?>users/forgot" onsubmit="return validate_forget_password();">
                    <div class="email">
                        <label><?php echo $this->Lang['EMAIL']; ?>:<span class="form_star"> * </span></label>
                        <div class="input_box">
                            <input type="text" value="" name="email"/>
                            
                        </div> 
                        <em id="femail_error"></em>  
                        <em></em>
                    </div>
                    <div class="enter_code">
                        <div class="input_comm">
                            
                            </div>
                        </div>

                        <div class="sign_up_submit_outer4">  
                            <div class="button4">
                                <div class="sub_lft">
                                    <div class="sub_rgt">
                                        <div class="sub_mid"><input type="submit" title="<?php echo $this->Lang['SUBMIT']; ?>" value="<?php echo $this->Lang['SUBMIT']; ?>" onclick="return validate_forget_password();"/></div>
                                    </div>
                                </div>
                                
                                
                            </div>
                            <div class="submit">
                                <div class="sub_lft1">
                                     <div class="sub_rgt1">
                                        <div class="sub_mid1">
									<a href="javascript:showlogin();"> <input type="button" title="<?php echo $this->Lang['CANCEL']; ?>" value="<?php echo $this->Lang['CANCEL']; ?>"/></a>
									</div>  
                                     </div>
                                </div>
                               
                               
                            </div>
                        </div>



                    </form>
                </div>

                <div class="full_about_midd_right">
                    <div class="log_bot_det">
                       <p><?php echo $this->Lang['SIGN_IN_WITH']; ?></p>
						<a class="f_connect cursor" onclick="facebookconnect();" title="<?php echo $this->Lang['SIGN_UP_WITH']; ?>">&nbsp;</a>
						<p><?php echo $this->Lang['ALREADY_A_MEMBER']; ?> <a title="<?php echo $this->Lang['SIGN_IN']; ?> " href="javascript:showlogin();"><?php echo $this->Lang['SIGN_IN']; ?> </a> </p>
                    </div>
                </div>
            </div>
        </div>
              </div> </div>
                <div class="bottom_common_popup">&nbsp; </div>
        </div>


<script type="text/javascript">
$(document).ready(function(){
$('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); //Fade in the fade layer 				   		   
//Close Popups and Fade Layer
$('.close2').live('click', function() {
		$('.popup_block2').css({'visibility' : 'hidden'});
		$('#fade').css({'visibility' : 'hidden'});
	
	
	return false;
});
	$(document).keyup(function(e) { 
        if (e.keyCode == 27) { // esc keycode
        	$('.popup_block2').css({'visibility' : 'hidden'});
			$('#fade').css({'visibility' : 'hidden'});
	  	
		
		return false;
        }
    });
});	
</script> 







