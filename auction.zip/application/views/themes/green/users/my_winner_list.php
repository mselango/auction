<div class="contianer_outer1">
    <div class="contianer_inner">
        <div class="contianer">
            <div class="bread_crumb">
                <ul>
                    <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang['HOME']; ?></a></p></li>
                    <li><p><?php echo "Won Auction"; ?></p></li>
                </ul>
            </div>					
            <!--content start-->
            <div class="content_abouts">

                <div class="all_mapbg_mid_common">
                    <div class="won_auction_outer">
                         <div class="pro_top">
                        <h2>Won Auction</h2>
                         </div>
                        <div class="myemai_mnu" style=" float:left; margin: 7px 0 0 0px;">
                            <div class="top_menu myemail_subbor">
                                <ul>
                                    <li>
                                        <div class="tab_left"></div>
                                        <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div>
                                        <div class="tab_rgt"></div>
                                    </li>
                                    <li>
                                        <div class="tab_left"></div>
                                        <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div>
                                        <div class="tab_rgt"></div>
                                    </li>
                                    <li>
                                        <div class="tab_left"></div>
                                        <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div>
                                        <div class="tab_rgt"></div>
                                    </li>
                                    <li>
                                        <div class="tab_left"></div>
                                        <div class="tab_mid"><a href="<?php echo PATH; ?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> 
                                        <div class="tab_rgt"></div>
                                    </li>
                                    <li class="tab_act">
                                        <div class="tab_left"></div>
                                        <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-winner-list.html" title="Won Auction"><?php echo 'Won Auction'; ?></a></div> 
                                        <div class="tab_rgt"></div>
                                    </li>
                                </ul>                                                                
                            </div> 
                        </div>
                    </div>
                    <div class="ownaction_for_common">
                    <div class="wa_heading">
                        <div class="wa_product">
                            <p>Product</p>
                        </div>
                        <div class="wa_title">
                            <p>Title</p>
                        </div>
                        <div class="wa_stype">

                        </div>
                        <div class="wa_pdate">
                            <p>Purchase Date</p>
                        </div>
                        <div class="wa_amt">
                            <p>Amount</p>
                        </div>
                        <div class="wa_samt">
                            <p>Shipping Amount</p>
                        </div>
                        <div class="wa_tamt">
                            <p>Total Amount</p>
                        </div>
                    </div>
                    <div class="wa_content_outer">
                        <?php
                        $i = 0;
                        if (count($this->user_winner_list) > 0) {
                            $first_item = $this->pagination->current_first_item;
                            foreach ($this->user_winner_list as $u) {
                                ?> 
                                <div class="wa_content">

                                    <div class="wa_product">
        <?php if (file_exists(DOCROOT . 'images/auction/220_160/' . $u->deal_key . '_1' . '.png')) { ?>
                                            <a href="<?php echo PATH . 'auction/' . $u->deal_key . '/' . $u->url_title . '.html'; ?>" title="<?php echo $u->deal_title; ?>">
                                                <img src="<?php echo PATH . 'images/auction/220_160/' . $u->deal_key . '_1' . '.png'; ?>" alt="won_auction_img" />
                                            </a>
        <?php } else { ?>
                                            <a href="<?php echo PATH . 'auction/' . $u->deal_key . '/' . $u->url_title . '.html'; ?>" title="won_auction_img">
                                                <img src="<?php echo PATH . '/images/no-images.png'; ?>" alt="won_auction_img" />
                                            </a>
        <?php } ?>
                                    </div>
                                    <div class="wa_title">
                                        <p><a href="<?php echo PATH . 'auction/' . $u->deal_key . '/' . $u->url_title . '.html'; ?>" title="<?php echo $u->deal_title; ?>"><?php echo $u->deal_title; ?></a></p>
                                    </div>

                                    <!--<div class="wa_stype">
                                                                                <p>Shipping Type</p>
                                                                        </div>-->

                                    <div class="wa_pdate">
                                        <p><?php echo date('d-M-Y h:i:s A', $u->bidding_time); ?><br/></p>
                                    </div>
                                    <div class="wa_amt">
                                        <p><?php echo CURRENCY_SYMBOL . $u->bid_amount; ?> </p>
                                    </div>
                                    <div class="wa_samt">
                                        <p><?php echo CURRENCY_SYMBOL . $u->shipping_amount; ?></p>
                                    </div>
                                    <div class="wa_tamt">
                                        <p><?php $total = $u->bid_amount + $u->shipping_amount;
        echo CURRENCY_SYMBOL . $total; ?></p>
                                    </div>

                                </div>
        <?php $i++;
    }
} else { ?>
                            <p class="no_data"><?php echo 'No Data Found'; ?></p>
<?php } ?> 
                        <div class=""><?php echo $this->pagination; ?></div>
                    </div>
                    </div>
                </div>



            </div>
            <!--end-->
        </div>
    </div>
</div>


