<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="container_outer">
<div class="continer_outer_common fl">
<div class="brad_com_out">
		<div class="brad_com_inn">
			<div class="brad_com">
<ul>
	<li><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></li>
        <li>\</li>
	<li ><a  href="<?php echo PATH; ?>/users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></li>
	<li >\</li>
	<li  class="act"><p title="<?php echo $this->Lang['CONNECTIONS']; ?>"><?php echo $this->Lang['CONNECTIONS']; ?></p></li>
</ul>   

		  </div>
	  </div>
	</div>

<div class="container_inner">
      <div class="container">
		  <div class="todays_deal deals_detail">
				<h1 class="txt_upp"><?php echo $this->Lang['CONNECTIONS']; ?></h1>
			<div class="about_us">
				<div class="about_top">
					<div class="about_tl">
						<div class="about_tr">
							<div class="about_tm"></div>
						</div>
					</div>
				</div>
				<div class="about_mid">
                                    <div class="about_ml">
                                        <div class="about_mr">
                                            <div class="about_mm">
                                                    <div class="about_cont">
                                                        <div class="change_pass">
                                                            <div class="top_menu">
            
	<ul>

	
			 <li ><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div> <div class="tab_rgt"></div></li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div> <div class="tab_rgt"></div></li>

			<li class="tab_act"><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div> <div class="tab_rgt"></div> </li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> <div class="tab_rgt"></div> </li>

			</ul>
    </div> 
       <div class="bot_menu">


               <ul>
               <li ><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_PROFILE']; ?>"><?php echo $this->Lang['MY_PROFILE']; ?></a></li>
               <li class="sub_act"><a href="<?php echo PATH;?>users/connections.html" title="<?php echo $this->Lang['CONNECTIONS']; ?>"><?php echo $this->Lang['CONNECTIONS']; ?></a></li>
               <li><a href="<?php echo PATH;?>users/edit-profile.html" title="<?php echo $this->Lang['EDIT_PROFILE']; ?>"><?php echo $this->Lang['EDIT_PROFILE']; ?></a></li>
               <li><a href="<?php echo PATH;?>users/change-password.html" title="<?php echo $this->Lang['CHANGE_PASS']; ?>"><?php echo $this->Lang['CHANGE_PASS']; ?></a></li>
               </ul>
</div>
               

		<div class="connections">
	         <?php foreach($this->user_detail as $u){ ?> 
		<?php  $facebook_id=$u->fb_user_id;
		 if($facebook_id==''){ 
		 ?>
               <h1>  <?php echo $this->Lang['CONNECTED_WITH']; ?></h1>
                 <p><?php echo $this->Lang['SIGN_IN_WITH']; ?></p>

                  <a onclick="facebookconnect_share();" style="cursor:pointer;" class="face_connect" title="<?php echo $this->Lang['FB_CONN']; ?>"></a> 
                <?php } else { ?>


                  <div class="user_img"><img src="http://graph.facebook.com/<?php echo $facebook_id; ?>/picture"/></div> 

<form method="post" class="admin_form" name="edit_users" enctype="multipart/form-data" >
    
    <div class="face_det">
        <ul>
            <li>
                <label><?php echo $this->Lang['USER_NAME']; ?> : </label>
                <p><?php echo ucfirst($u->firstname);?></p>
            </li>
            <li>
                <label><?php echo $this->Lang['EMAIL']; ?>  : </label>
                <p><?php echo ucfirst($u->email);?></p>
            </li>
            <li>
                <label>&nbsp;</label>
                <input class="fl" value="1" type="checkbox" name="facebook" <?php if($u->facebook_update =='1'){ ?> checked="checked" <?php  } ?> ><span class="facebook_wall"><?php echo $this->Lang['AUTO_POST']; ?></span>
                
            </li>
            <li>
                <label>&nbsp;</label>
                <div class="new_submit">
                <div class="new_sub">
                <input  name="Submit" type="submit" value="<?php echo $this->Lang['UPDATE']; ?>" />
                </div>
                </div>
            </li>
        </ul>
        
    
    </div>
</form>

 <?php } }?>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="about_bot">
					<div class="about_bl">
						<div class="about_br">
							<div class="about_bm"></div>
						</div>
					</div>
				</div>
			</div>
     
		  </div>
 </div>
</div>
</div>
</div>


