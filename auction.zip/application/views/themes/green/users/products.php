				<?php if(count($this->products_coupons_list) > 0 ) { ?>
				<?php foreach($this->products_coupons_list as $p){ ?>
			 
				  <ul>
				    <li class="my_buy_title"><a href="<?php echo PATH.'product/'.$p->deal_key.'/'.$p->url_title.'.html';?>" title="<?php echo $p->deal_title;?>S" class="fl clear"><?php echo $p->deal_title;?></a></li>
				    <li class="my_buy_title"><a href="<?php echo PATH.'stores/'.$p->store_key.'/'.$p->store_url_title.'.html';?>" title="Reebok"><?php echo $p->store_name; ?></a></li>
				    <li class="my_buy_pur_date"><?php echo date('d-M-Y',$p->transaction_date);?></li>
					<li class="my_buy_title"><?php echo $p->saddr1.",".$p->saddr2;?></li>
			<li class="my_buy_storename"><a id="details-panel<?php echo $p->shipping_id; ?>" title="<?php echo $this->Lang['SEND_MAIL']; ?>"  href="javascript:;" ><img src="<?php echo PATH;?>images/details_view.gif"><input type="hidden" name="email1" id="mail" value="<?php echo $p->email; ?>"></a>
			
			
            
			<div class="popup_show1" id="lightboxdetails-panel<?php echo $p->shipping_id; ?>" style="display:none;"  >
			<div id="divToPrint<?php echo $p->shipping_id; ?>"   class="divToPrintval" >
			<div class="rejected_shipping" id="details-close<?php echo $p->shipping_id; ?>" ></div>

			<script type="text/javascript">     
        
		$(document).ready(function(){

			$('a#details-panel<?php echo $p->shipping_id; ?>').click(function(){ 
			$('#lightboxdetails-panel<?php echo $p->shipping_id; ?>').show();
			$('.divToPrintval').show();
			})

			$('#details-close<?php echo $p->shipping_id; ?>').click(function(){ 
			$('#lightboxdetails-panel<?php echo $p->shipping_id; ?>').hide();
			})
			})

     </script> 	
     
				<div class="display" style="width:666px; margin: 15px auto;"> 
		         <div style="width:99%;">
		           
		            
		            <div style="float:right; margin-right: 5px;text-align:center;">
		                <div style="font-weight: bold; font-size: 15px; float:left; margin: 60px 10px 0 0;"></div>
		                
		               <div style="clear:both;"></div>
		            </div>
		           
		        </div>
		        
		        
		        
		        <div style="text-align:center;">
		            <strong style="font-size: 15px; font-weight:bold; font-family: Arial;">Shipping Details</strong><br>
		            <b>Note:</b> This shipment contains following items<br><br>
		        </div>
		        <table cellpadding="0" cellspacing="0" width="99%">
    <tbody><tr>
        <td><hr style="border: 1px solid black;"></td>
    </tr>
    <tr>
    <td>
            <table class="printtable" cellpadding="0" cellspacing="0" width="99%">
        <tbody><tr>
                        <td colspan="7"><b>1.  <?php echo $p->deal_title; ?></b></td>
        </tr>
        <tr><td colspan="7">&nbsp;</td></tr>
        
        <tr>
            <td width="10%">&nbsp;</td>
				<td width="13%" align="center">Color</td>
				<td width="13%" align="center">Size</td>
	            <td width="13%" align="center">Quantity</td>
	            <td width="13%" align="center">Unit Price</td>
	            <td width="13%" align="center">Discount</td>
	            <td width="13%" align="right">Sub Total</td>
	                </tr>
        <tr><td>&nbsp;</td><td colspan="6"><hr style="border:1px dotted #AAAAAA;"></td></tr>
        <tr>
			   <td width="16%">&nbsp;</td>
																	
					<?php if($p->product_color !=0 ) { foreach($this->product_color as $pro){ ?>
					<?php if($p->product_color == $pro->id){ ?>                   
					<td align="center">
					<?php echo ucfirst($pro->color_name); ?></td>
					<?php } } } else { ?><td align="center">-</td> <?php } ?>
					
					 <?php if($p->product_size != 0 ){ foreach($this->product_size as $size){ ?>
					<?php if($p->product_size == $size->size_id){ ?>                 
					<td align="center">
					<?php echo $size->size_name; ?></td>
					<?php } } } else { ?><td align="center">-</td> <?php } ?>
				<td align="center"><?php echo $p->quantity; ?></td>
				<td align="center"><?php echo CURRENCY_SYMBOL.$p->deal_price; ?></td>
				<td align="center"><?php echo CURRENCY_SYMBOL.$p->deal_savings; ?></td>
				<td align="right"><?php echo CURRENCY_SYMBOL.$p->deal_value * $p->quantity; ?></td>
			</tr>
        <tr><td colspan="7">&nbsp;</td></tr>
         
    </tbody></table>
        </td>
    </tr>
    <tr>
        <td><hr style="border: 1px solid black;"></td>
    </tr>
</tbody></table>

 <div style="clear:both;"></div>
		    <div style="width:99%;  line-height: 2em; text-align:left; page-break-before: auto;">
	        <div style="float:left; width: 55%">&nbsp;</div>
	        <div style="float:left; width: 27%; text-align:left;">Shipment Value</div>
	        <div style="float:left; width: 18%; text-align:right;"><b><?php echo CURRENCY_SYMBOL.$p->deal_value * $p->quantity; ?></b></div>
	        <div style="clear:both;"></div>
	    
	        	        	        	        	    
		    <div style="float:left; width: 55%">&nbsp;</div>
		    <div style="float:left; width: 27%; text-align:left;">Shipping</div>
		    <div style="float:left; width: 18%; text-align:right;"><b><?php if($p->shipping != 0 ) echo $p->shipping; else echo '-'; ?> </b></div>
		    <div style="clear:both;"></div>
	    
		    		        		            <div style="float:left; width: 55%; margin-top: 10px;">
		                &nbsp;		            </div>
		            <div style="float:left; width: 45%; margin-top: 10px;">
		                <div style="padding: 10px 0px; border-top: solid 0.15em; border-bottom: 0.15em solid;">
		                    <div style="width:50%; float:left;">Amount to be paid</div>
		                    <div style="text-align:right; float:right; width:50%;">
									<strong style="font-size: 17px;"><?php echo CURRENCY_SYMBOL.(($p->deal_value * $p->quantity) + ($p->shipping)); ?></strong>
							</div>
		                    <div style="clear:both;"></div>
		                </div>
		           </div>
		           <div style="clear:both"></div>
		           
		           
		        		    	    </div>
		
	 <div style="clear:both"></div>
	 
	 <hr style="border: 1px solid black; padding:0; margin: 20px 0 0 0; width: 99%;">
		        
		        <div style="margin-top: 20px; width:99%;">
		            			            <div style="float:left; margin-top: 20px;">
			              
			            </div>
		            		            <div style="float:left; width: 45%; font-size:15px; border-right: 1px dotted #666666; margin-left: 10px;">
		            		           
		                		                	<strong style="font-size: 15px; font-weight:bold;">Order Date: </strong><br>
		                		                	<strong style="font-size: 12px; "><?php echo date("d-M-Y h:i:s A",$p->transaction_date); ?></strong>
		               
		                			        </div>
		                			         <div style="float:left; width: 45%; font-size:15px;  margin-left: 10px;">
		            		           
		                		                	<strong style="font-size: 15px; font-weight:bold;">Delivery Status:</strong><br>
		                		                	<strong style="font-size: 12px; "> 2 or 3 days on working days </strong>
		               
		                			        </div>
		                			         <div style="clear:both;"></div>
		           
		        </div>
		        
	 <hr style="border: 1px solid black; padding:0; margin: 20px 0 0 0; width: 99%;">
		        
		        <div style="margin-top: 20px; width:99%;">
		            			            <div style="float:left; margin-top: 20px;">
			              
			            </div>
		            		            <div style="float:left; width: 45%; font-size:15px; border-right: 1px dotted #666666; margin-left: 10px;">
		            		            <strong style="font-size: 15px; font-weight:bold;">Shop  Address</strong>
			                <br>
		                		                <strong style="font-size: 15px; font-weight:bold;"><?php echo $p->store_name ; ?> </strong><br>
		              
									<?php echo $p->addr1.','.$p->addr2 ; ?>,<br>
									<?php echo $p->city_name.'-'.$p->zipcode; ?>.<br>
		                		                	<strong style="font-size: 15px; font-weight:bold;">Phone: <?php echo $p->str_phone; ?> </strong><br>
		                		                	<strong style="font-size: 15px; font-weight:bold;">Website: <?php echo $p->website; ?> </strong>
		               
		                			        </div>
		            <div style="float:left; width: 45%; margin-left: 20px;">
			            			                 <strong style="font-size: 15px; font-weight:bold;">Shipping Address</strong>
			                <br>
		                		                <strong style="font-size: 15px; font-weight:bold;"><?php echo ucfirst($p->name); ?> </strong><br>
		                <?php echo $p->saddr1."<br />".$p->saddr2; ?>,<br>
										<?php echo $p->city_name . '-' . $p->postal_code; ?><br>
										<?php echo $p->country; ?><br>
		                		                	<strong style="font-size: 15px; font-weight:bold;">Phone: <?php echo $p->phone; ?> </strong>
		                		                				            		                		            </div>
		            <div style="clear:both;"></div>
		        </div>
		        
		        <hr style="border: 1px dotted black; padding:0; margin: 20px 0 0 0; width: 99%;">
		    	       
		</div>
		
			
               
	    </div>
			</div>
			
			
			</li>
				  </ul>
				<?php } } else { ?>
				<div class="no_referal"><p>No products found</p></div>
				<?php }?>
