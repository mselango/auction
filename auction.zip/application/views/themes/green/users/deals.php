<?php if(count($this->deals_coupons_list) > 0 ) { ?>
					<?php foreach($this->deals_coupons_list as $u){
					  $enddate=date('d-M-Y',$u->expirydate);
					  $current_date=Date("d -F - Y");
					  $start_time = strtotime($current_date);
				  	  $end_time = strtotime($enddate);
				  	  $days_left =  round(($end_time-$start_time)/(3600*24));
				  	  $m=round(($u->expirydate-time())/60); 
				 	  ?>

				 

					  <ul>
					    <li class="my_buy_title"><a href="<?php echo PATH.'deals/'.$u->deal_key.'/'.$u->url_title.'.html';?>" title="<?php echo $u->deal_title;?>" class="fl clear"><?php echo $u->deal_title;?></a></li>
					    <li class="my_buy_storename"><a href="<?php echo PATH.'stores/'.$u->store_key.'/'.$u->store_url_title.'.html';?>" title="Reebok"><?php echo $u->store_name; ?></a></li>
					    <li class="my_buy_pur_date"><?php echo date('d-M-Y',$u->transaction_date);?></li>
					    <li class="my_buy_expiry"><?php echo date('d-M-Y',$u->expirydate);?></li>
					  
					    <?php  if(($u->minimum_deals_limit > $u->purchase_count)||($u->captured == 1)) {?>
					    <li class="my_buy_status ornage"><?php echo $this->Lang['PENDING']; ?></li>
					     <?php } else { ?>    
					    <?php if($u->coupon_code_status =="1") { ?>
					    <?php if($m > 0){ ?>
					    <li class="my_buy_status green"><?php echo $this->Lang['ACTIVE']; ?></li>
					    <?php } else { ?>
					    <li class="my_buy_status red"><?php echo $this->Lang['EXPIRY']; ?></li>
					    <?php } } else { ?>
					    <li class="my_buy_status black"><?php echo $this->Lang['CLOSED']; ?></li>
					    <?php } }?>
					    
					    
					    <li class="my_buy_daysleft"><center>
					    <?php if(($days_left == "0")and($m > 0)){ ?>
					    <?php echo $m; ?><?php echo $this->Lang['MINUTES']; ?>
					    <?php } else if($m < 0 ) {?>
					    ----
					    <?php } else {?>
					    <?php echo $days_left; ?><?php echo $this->Lang['DAYS']; ?>
					    
					    <?php } ?>
					    </li>


					    <?php  if(($m < 0)||($u->minimum_deals_limit > $u->purchase_count)||($u->captured == 1)) {?>
					     <li class="my_buy_downloadcoupon"> <center>----</center> </li>    
					    <?php } else if($u->trans_type == 5) {?>
							 <li class="my_buy_downloadcoupon"> <center>COD</center> </li>    
						<?php } else { ?>
					   <li class="my_buy_downloadcoupon">
					  <script>
					    function pdf(id)
					    {

						window.location = "<?php echo PATH; ?>pdf.html?id="+id;
					    }
					  </script>
                                          <a class="cur" style="margin-left:48px; cursor:pointer;" title="click to download" onclick="pdf('<?php echo $u->coupon_code;?>')"><img src="<?php echo PATH;?>images/user/150_115/pdfimg.png" /></a></li>
					 
					 <?php } ?>
					      
					  </ul>
					<?php } } else { ?>
				      <div class="no_referal"><p>No deals found</p></div>
					<?php }?>
