

<div class="contianer_outer1">
    <div class="contianer_inner">
        <div class="contianer">
            <div class="bread_crumb">
                <ul>
                    <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang['HOME']; ?></a></p></li>
                    <li><p><?php echo $this->Lang['MY_REFERAL']; ?></p></li>
                </ul>
            </div>
            <!--content start-->
            <div class="content_abouts">
                <div class="all_mapbg_mid_common">
                    <div class="content_abou_common">
                         <div class="pro_top">
                        <h2><?php echo $this->Lang['MY_REFERAL']; ?></h2>
                         </div>
                        <div class="all_mapbg_mid">   
                            <div class="myemai_mnu">
                                <div class="top_menu myemail_subbor">
                                    <ul>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li  class="tab_act">
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div>
                                            <div class="tab_rgt"></div>

                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> 
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-winner-list.html" title="Won Auction"><?php echo 'Won Auction'; ?></a></div> 
                                            <div class="tab_rgt"></div>

                                        </li>
                                    </ul>                                                                
                                </div> 
                            </div>
                        </div>
                        <div class="mybuys_content mybuys_products">  

                            <div class="mybuys_content_top">
                                <ul>
                                    <li class="myref_sno"><?php echo $this->Lang['S_NO']; ?></li>
                                    <li class="myref_username4"> <?php echo $this->Lang['USER_NAME']; ?></li>
                                    <li class="myref_emailid3"> <?php echo $this->Lang['EMAIL_ID']; ?></li>
                                    <li class="myref_joindate"><?php echo $this->Lang['JOIN_DATE']; ?></li>
                                    <li class="myref_pur_count"><?php echo $this->Lang['PURCHACE_COUNT']; ?></li>
                                </ul>
                            </div>


                            <div class="mybuys_content_bottom">
                                <?php
                                $i = 0;

                                if (count($this->user_refrel_list) > 0) {
                                    $first_item = $this->pagination->current_first_item;
                                    foreach ($this->user_refrel_list as $u) {
                                        ?> 
                                        <ul>
                                            <li class="myref_sno"><?php echo $i + $first_item; ?></li>
                                            <li class="myref_username4"><?php echo ucfirst($u->firstname); ?> </li>
                                            <li class="myref_emailid3"><?php echo $u->email; ?> </li>
                                            <li  class="myref_joindate"><?php echo date('d-M-Y', $u->joined_date); ?></li>
                                            <li class="myref_pur_count2"><?php echo $u->deal_bought_count; ?> </li>
                                             </ul> 
                                            <?php $i++;
                                        }
                                    } else { ?>
                                        <div class="no_referal"><p><?php echo $this->Lang['NO_REFERAL']; ?></p></div>
                                        
<?php } ?> 
                               



                            </div>
                            <div class="pagenation myrefer_pagenation"><?php echo $this->pagination; ?></div>
                        </div>


                    </div>
                </div>  


            </div>
            <!--end-->
        </div>
    </div>
</div>

