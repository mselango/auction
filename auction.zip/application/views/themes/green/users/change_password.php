<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="container_outer">
<div class="continer_outer_common fl">
<div class="brad_com_out">
		<div class="brad_com_inn">
			<div class="brad_com">
<ul>
	<li><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></li>
        <li>\</li>
	<li ><a  href="<?php echo PATH; ?>/users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></li>
	<li >\</li>
	<li  class="act"><p title="<?php echo $this->Lang['CHANGE_PASS']; ?>"><?php echo $this->Lang['CHANGE_PASS']; ?></p></li>
</ul>   

		  </div>
	  </div>
	</div>

<div class="container_inner">
      <div class="container">
		  <div class="todays_deal deals_detail">
				<h1 class="txt_upp"><?php echo $this->Lang['CHANGE_PASS']; ?></h1>
			<div class="about_us">
				<div class="about_top">
					<div class="about_tl">
						<div class="about_tr">
							<div class="about_tm"></div>
						</div>
					</div>
				</div>
				<div class="about_mid">
                                    <div class="about_ml">
                                        <div class="about_mr">
                                            <div class="about_mm">
                                                    <div class="about_cont">
                                                        <div class="change_pass">
                                                            <div class="top_menu">
            
	<ul>

	
			 <li ><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div> <div class="tab_rgt"></div></li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div> <div class="tab_rgt"></div></li>

			<li class="tab_act"><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div> <div class="tab_rgt"></div> </li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> <div class="tab_rgt"></div> </li>

			</ul>
    </div> 
       <div class="bot_menu">


               <ul>
               <li><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_PROFILE']; ?>"><?php echo $this->Lang['MY_PROFILE']; ?></a></li>
               <li><a href="<?php echo PATH;?>users/connections.html" title="<?php echo $this->Lang['CONNECTIONS']; ?>"><?php echo $this->Lang['CONNECTIONS']; ?></a></li>
               <li><a href="<?php echo PATH;?>users/edit-profile.html" title="<?php echo $this->Lang['EDIT_PROFILE']; ?>"><?php echo $this->Lang['EDIT_PROFILE']; ?></a></li>
               <li class="sub_act"><a href="<?php echo PATH;?>users/change-password.html" title="<?php echo $this->Lang['CHANGE_PASS']; ?>"><?php echo $this->Lang['CHANGE_PASS']; ?></a></li>
               </ul>
</div>            
                                                              <div class="changepass_form">
						<form action="" method="post" class="admin_form">
                                                                <ul>
                                                                    <li>
                                                                        <label><?php echo $this->Lang['OLD_PASS']; ?></label>
                                                                        <span>:</span>
                                                                         <div class="fullname_chan">
                                                                        <div class="full"><input type="password" name="oldpassword"  /></div>
                                                                        <em><?php if(isset($this->form_error['oldpassword'])){ echo $this->form_error['oldpassword']; }?></em>
                                                                         </div>
                                                                    </li> 
                                                                    <li>
                                                                        <label><?php echo $this->Lang['NEW_PASS']; ?></label>
                                                                        <span>:</span>
                                                                         <div class="fullname_chan">
                                                                        <div class="full"><input type="password"  name="password"  /></div>
                                                                        <em><?php if(isset($this->form_error['password'])){ echo $this->form_error["password"]; }?></em>
                                                                         </div>
                                                                    </li>   
                                                                    <li>
                                                                        <label><?php echo $this->Lang['RE_ENTER']; ?></label>
                                                                        <span>:</span>
                                                                        <div class="fullname_chan">
                                                                        <div class="full"><input type="password"  name="cpassword"  /></div><em><?php if(isset($this->form_error['cpassword'])){ echo $this->form_error["cpassword"]; }?></em>
                                                                        </div>
                                                                    </li>  
                                                                     <li>
                                                                          <label>&nbsp; </label>
                                                                          <span>&nbsp; </span>
                                                                         <div class="new_submit">
                                                                            <div class="new_sub"><input type="Submit" type="button" value="<?php echo $this->Lang['UPDATE']; ?>" /></div>
                                                                          </div>
                                                                    </li>   
                                                                </ul>     

                                                           </form>
                                                            </div>


                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
				</div>
				<div class="about_bot">
					<div class="about_bl">
						<div class="about_br">
							<div class="about_bm"></div>
						</div>
					</div>
				</div>
			</div>
     
		  </div>
 </div>
</div>

</div>
</div>

