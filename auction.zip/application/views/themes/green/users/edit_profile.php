<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="container_outer">
<div class="continer_outer_common fl">
<div class="brad_com_out">
		<div class="brad_com_inn">
			<div class="brad_com">
<ul>
	<li><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></li>
        <li>\</li>
	<li ><a  href="<?php echo PATH; ?>/users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></li>
	<li >\</li>
	<li  class="act"><p title="<?php echo $this->Lang['EDIT_PROFILE']; ?>"><?php echo $this->Lang['EDIT_PROFILE']; ?></p></li>
</ul>   

		  </div>
	  </div>
	</div>

<div class="container_inner">
      <div class="container">
		  <div class="todays_deal deals_detail">
				<h1 class="txt_upp"><?php echo $this->Lang['EDIT_PROFILE']; ?></h1>
			<div class="about_us">
				<div class="about_top">
					<div class="about_tl">
						<div class="about_tr">
							<div class="about_tm"></div>
						</div>
					</div>
				</div>
				<div class="about_mid">
                                    <div class="about_ml">
                                        <div class="about_mr">
                                            <div class="about_mm">
                                                    <div class="about_cont">
                                                        <div class="change_pass">
                                                            <div class="top_menu">
            
	<ul>

	
			 <li ><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div> <div class="tab_rgt"></div></li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div> <div class="tab_rgt"></div></li>

			<li class="tab_act"><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div> <div class="tab_rgt"></div> </li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> <div class="tab_rgt"></div> </li>

			</ul>
    </div> 
       <div class="bot_menu">


               <ul>
               <li  ><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_PROFILE']; ?>"><?php echo $this->Lang['MY_PROFILE']; ?></a></li>
               <li><a href="<?php echo PATH;?>users/connections.html" title="<?php echo $this->Lang['CONNECTIONS']; ?>"><?php echo $this->Lang['CONNECTIONS']; ?></a></li>
               <li class="sub_act"><a href="<?php echo PATH;?>users/edit-profile.html" title="<?php echo $this->Lang['EDIT_PROFILE']; ?>"><?php echo $this->Lang['EDIT_PROFILE']; ?></a></li>
               <li><a href="<?php echo PATH;?>users/change-password.html" title="<?php echo $this->Lang['CHANGE_PASS']; ?>"><?php echo $this->Lang['CHANGE_PASS']; ?></a></li>
               </ul>
</div>   
            


 		<div class="mypro_form">
	    <?php foreach($this->user_detail as $u){ ?> 

	     <form method="post" class="admin_form" name="edit_users" enctype="multipart/form-data" >

			<ul>
			<li>
			<label><?php echo $this->Lang['FIRST_NAME']; ?></label><span>:</span><div class="full"><input type="text" name="firstname" value="<?php echo $u->firstname;?>" /><em><?php if(isset($this->form_error['firstname'])){ echo $this->form_error["firstname"]; }?></em></div>


			</li>


		<li>
			<label><?php echo $this->Lang['LAST_NAME']; ?></label><span>:</span><div class="full"><input type="text"  name="lastname" value="<?php echo $u->lastname;?>" /> </div>
	 <em><?php if(isset($this->form_error['lastname'])){ echo $this->form_error["lastname"]; }?></em>
</li>

		<li>
			<label><?php echo $this->Lang['EMAIL']; ?></label><span>:</span><div class="full"><input type="text"  name="email"  value="<?php echo $u->email;?>" /><em><?php if(isset($this->form_error['email'])){ echo $this->form_error["email"]; }?></em></div>

</li>
	
		<li>
			<label><?php echo $this->Lang['MOBILE']; ?></label><span>:</span><div class="full"><input type="text"  name="mobile" value="<?php echo $u->phone_number;?>" /></div>
	<em><?php if(isset($this->form_error['mobile'])){ echo $this->form_error["mobile"]; }?></em>
</li>

		<li>
			<label><?php echo $this->Lang['ADDR1']; ?></label><span>:</span><div class="full"><input type="text" name="address1" value="<?php echo $u->address1;?>" /></div>
<em><?php if(isset($this->form_error['address1'])){ echo $this->form_error["address1"]; }?></em></li>

		<li>
			<label><?php echo $this->Lang['ADDR2']; ?></label><span>:</span><div class="full"><input type="text" name="address2" value="<?php echo $u->address2;?>" /></div>
	<em><?php if(isset($this->form_error['address2'])){ echo $this->form_error["address2"]; }?></em>
</li>
	
	<li>
      <label><?php echo $this->Lang['MY_FAVO']; ?></label><span>:</span><div class="full_che">
	
    
    <div class="edit_profile_checkbox">
<ul>
     <?php foreach($this->category_list as $categories){
	 foreach($this->users_category_list as $cate){
	 $user_categories = $cate->my_favouites;

         $CategoryTags = explode(",", $user_categories);
	
	 ?>
        

          <li>   <input type="checkbox" <?php if(in_array($categories->category_id, $CategoryTags)){?> checked="checked" <?php } ?>  value="<?php echo $categories->category_id;?>"  name="categorytag[]"/><p><?php echo ucfirst($categories->category_name); ?></p>
            
       
          <?php  } }?>
          </li>
          
</ul>
</div>
</li>

		<li><label><?php echo $this->Lang['PROFILE_PICTURE']; ?></label><span>:</span><div class="full_file">
	        <input type="file" name="user_image" value="Browse" " />
		<em><?php if(isset($this->form_error['user_image'])){ echo $this->form_error["user_image"]; }?></em>
		</div>
	</li> 


<li>
<label>&nbsp;</label>
<span>&nbsp;</span>
<div class="full_file">
<div class="myprofile_left">
  		<?php  if(file_exists(DOCROOT.'images/user/150_115/'.$u->user_id.'.png'))       
	                        { ?>
                     <img border="0" src="<?php echo PATH.'images/user/150_115/'.$u->user_id.'.png';?>" alt="<?php echo $this->Lang['IMAGE']; ?>" />				
				<?php } elseif(file_exists(DOCROOT.'images/user/150_115/'.$u->user_id.'.jpg')) { ?>
				<img border="0" src= "<?php echo PATH.'images/user/150_115/'.$u->user_id.'.jpg';?>" alt="<?php echo $this->Lang['IMAGE']; ?>"  />			
                 <?php } else { ?>
                         <img src="<?php echo PATH;?>images/user/150_115/profileimg.png" alt="<?php echo $this->Lang['IMAGE']; ?>" /> 
                 <?php } ?>

</div>
</div>
</li> 
<li> 
<label>&nbsp; </label> <div class="new_submit ml5">
 	<div class="new_sub"><input name="Submit" type="submit" value="<?php echo $this->Lang['UPDATE']; ?>" /></div>
 	 </div>
</li>   
	</ul>    

          </form>
           <?php  }?></div></div>
		</div>
	</div>
</div>
</div>
</div>
</div>
<div class="about_bot">
<div class="about_bl">
<div class="about_br">
<div class="about_bm"></div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>


</div>
</div>


