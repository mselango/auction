<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<script type="text/javascript" src="<?php echo PATH; ?>js/jquery-ui-1.8.11.custom.min.js" ></script>
<link rel="stylesheet" type="text/css" href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/jquery-ui-1.8.7.custom.css" /> 
<script type="text/javascript"> 
    function select_all()
    {
        var text_val=eval("document.form1.user_referral_url");
        text_val.focus();
        text_val.select();
    }
    function cancel_hide_pr() {
        $('.Editprofile').hide();
        $('#fname_error').html('');
        $('#user_name').show();
        $('#edit_hide').show();
	
	
    }
    function cancel_hide_pr3() {
        $('#shw_address').hide();
        $('#show3').show();
        $('.profile_edit_3').show();
	
    }

	
    function cancel_hide_pr4() {
        $('#shw_city').hide();
        $('#show4').show();
        $('.profile_edit4').show();
	
    }
    function cancel_hide_pr_2() {
        $('.Editprofile_2').hide();
        $('#city_ic').show();
        $('#city_user').show();
	
	
    }
    function cancel_hide_pr2() {
        $('#shw_phone').hide();
        $('.profile_edit_2').show();
        $('#show2').show();
	
	
    }


    function cancel_hide_pr_3() {
        $('.Editprofile_3').hide();
        $('#dob_ic').show();
        $('#dob_user').show();
	
	
    }
    function cancel_hide_pr_4() {
        $('.Editprofile_4').hide();
        $('#old_pass_error').html('');
        $('#new_pass_error').html('');
        $('#pass_error_1').html('');
        $('#password_ic').show();
        $('#password_user').show();
	
	
    }

    function cancel_hide_pr5() {
        $('#shw_country').hide();
        $('#show5').show();
        $('.profile_edit5').show();
	
    }
    function popup_show() {



        $( "#dialog:ui-dialog" ).dialog( "destroy" );

        $( "#model_dailog" ).dialog({
            height: 470,
            width: 550,
	
            modal: true
        });

        $('.pop_close').click(function() {
            $('#model_dailog').remove();
	  
            $('.ui-widget-overlay').remove();
            $('#empty_value').val('');
            window.location.reload();
	   	
        });
		

    }

    function canceljd_hide() {


        $('#model_dailog').remove();

        $('.ui-widget-overlay').remove();
	

    }

    window.onload = function () {
        var form = document.getElementById('admin_form'),


        imageInput = document.getElementById('empty_value_1');

        form.onsubmit = function () {



            if(imageInput.value==''){

                alert('The field should not be empty!');
                return false;
            }



            var iSize = ($("#empty_value_1")[0].files[0].size / 1024);

            var img = imageInput.files[0].size;

            iSize = (Math.round((iSize / 1024) * 100) / 100)
            if(iSize > 1){

                alert('The image  should  be less then or equal to 1 Mb!'); 

                return false;
  
            } 

            $("#lblSize").html( iSize + "Mb");


	    
            var isValid = /\.(jpe?g|gif|png)$/i.test(imageInput.value); 

            if (!isValid) {
	     
                alert('upload valid image format like jpg,png,jpeg format');
	    	
            }

            return isValid;
	  
        }
    };
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(function(){
            // onfocus
            $('.opassTxt').focus(function(e){
	
                var getPass = $('.opassTxt').val();

                if(getPass=='Enter Your Old Password*'){
                    $(this).val('');
                    this.type = 'password';
			
                }
            });
 
            //onblur
            $('.opassTxt').blur(function(){
                var getPass = $('.opassTxt').val();
                if(getPass==''){
                    this.type = 'text';
                    $(this).val('Enter Your Old Password*');
                }
                else{
                    $('.opassTxt').val(getPass);
                }
            });

            $('.cpassTxt').focus(function(e){
	
                var getPass = $('.cpassTxt').val();

                if(getPass=='Enter Your Confirm Password*'){
                    $(this).val('');
                    this.type = 'password';
                }
            });
 
            //onblur
            $('.cpassTxt').blur(function(){
                var getPass = $('.cpassTxt').val();
                if(getPass==''){
                    this.type = 'text';
                    $(this).val('Enter Your Confirm Password*');
                }
                else{
                    $('.cpassTxt').val(getPass);
                }
            });

            $('.npassTxt').focus(function(e){
	
                var getPass = $('.npassTxt').val();

                if(getPass=='Enter Your New Password*'){
                    $(this).val('');
                    this.type = 'password';
                }
            });
 
            //onblur
            $('.npassTxt').blur(function(){
                var getPass = $('.npassTxt').val();
                if(getPass==''){
                    this.type = 'text';
                    $(this).val('Enter Your New Password*');
                }
                else{
                    $('.npassTxt').val(getPass);
                }
            });

	
        });
    });

</script>



<div class="contianer_outer1">
    <div class="contianer_inner">
        <div class="contianer">
            <div class="bread_crumb">
                <ul>
                    <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang['HOME']; ?></a></p></li>
                    <li><p><?php echo $this->Lang['MY_PROFILE']; ?></p></li>
                </ul>
            </div>

            <!--content start-->
            <div class="content_abouts">
                <div class="all_mapbg_mid_common">
                    <div class="content_abou_common">
                         <div class="pro_top">
                        <h2><?php echo $this->Lang['MY_PROFILE']; ?></h2>
                         </div>
                        <div class="all_mapbg_mid">   
                            <div class="myemai_mnu">
                                <div class="top_menu myemail_subbor">
                                    <ul>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li   class="tab_act">
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div>
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> 
                                            <div class="tab_rgt"></div>
                                        </li>
                                        <li>
                                            <div class="tab_left"></div>
                                            <div class="tab_mid"><a href="<?php echo PATH; ?>users/my-winner-list.html" title="Won Auction"><?php echo 'Won Auction'; ?></a></div> 
                                            <div class="tab_rgt"></div>
                                        </li>
                                    </ul>                                                                
                                </div> 
                            </div>
                        </div>
                        <div class="mybuys_content mybuys_products"> 
                            <div class="pi_mc_rl_outer">
                                <div class="pi_left">
                                    <?php foreach ($this->user_detail as $u) { ?>
                                        <div class="pi_border_top">
                                        </div>
                                        <div class="pi_border_mid">
                                            <ul>
                                                <li>
                                                    <h4>Name</h4>
                                                    <div class="pi_detail">
                                                        <div class="pi_detail_info" id="user_name">
                                                            <div id="name_user" class="un_detail"><?php echo ucfirst($u->firstname) . " " . ucfirst($u->lastname); ?></div>
                                                        </div>
                                                        <div class="Editprofile" id="Editprofile-<?php echo $u->user_id; ?>" style="display:none;">
                                                            <div class="followup">
                                                                <div class="followup_tb_mid">  
                                                                    <input type="text"  name="phone" id="fname-<?php echo $u->user_id; ?>"  class="followupnext" value="<?php echo $u->firstname; ?>" placeholder="Enter your First Name.." />
                                                                    <br/><span id="fname_error_12" style="color:red;font:13px kreonregular;letter-spacing:0.01em;"></span>
                                                                </div>
                                                            </div>
                                                            <div class="followup">
                                                                <div class="followup_tb_mid"> 
                                                                    <input type="text"  name="phone" id="laneme-<?php echo $u->user_id; ?>"  class="followupnext" value="<?php echo $u->lastname; ?>" placeholder="Enter your Last Name.."/>
                                                                    <br/><span id="fname_error_12" style="color:red;font:13px kreonregular;letter-spacing:0.01em;"></span>
                                                                </div>
                                                            </div>
                                                            <div class="followup_buttons">
                                                                <div class="button4">
                                                                    <div class="sub_lft">
                                                                        <div class="sub_rgt">
                                                                            <div class="sub_mid4">
                                                                               <a style="cursor:pointer;" id="Upprofile-<?php echo $u->user_id; ?>" class="Upprofile cursor" title="Update"><?php echo $this->Lang['UPDATE']; ?> </a>  
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                               
                                                                </div>
                                                                <div class="submit">
                                                                    <div class="sub_lft1">
                                                                        <div class="sub_rgt1">
                                                                            <div class="sub_mid5">
                                                                                <a  style="cursor:pointer; " id="Cancelfollowup-<?php echo $u->user_id; ?>" onclick="javascript:cancel_hide_pr()" class="Cfollowup cursor" title="Cancel"><?php echo $this->Lang['CANCEL']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                
                                                                </div>
                                                                </div>
                                                        </div>
                                                        <div class="pi_detail_edit" id="edit_hide">
                                                            <p><a class="cursor profile_edit" style="cursor:pointer;"id="NEDIT-<?php echo $u->user_id; ?>" title="edit">edit</a></p>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <h4><?php echo $this->Lang['EMAIL']; ?></h4>
                                                    <div class="pi_detail">
                                                        <div class="pi_detail_info">
                                                            <p><?php echo $u->email; ?></p>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <h4>Password</h4>
                                                    <div class="pi_detail">
                                                        <div class="pi_detail_info" id="password_user">
                                                            <p>*************</p>
                                                        </div>
                                                        <div class="Editprofile_4" style="display:none;">
                                                            <div class="followup_4">
                                                                <div class="followup4_tb_mid">
                                                                    <input name="old_pass"  id="old_pass" class="opassTxt" type="text" value="Enter Your Old Password*" />
                                                                    <BR/><span id="old_pass_error" style="color:red;font:13px kreonregular;letter-spacing:0.01em;"></span>
                                                                </div>

                                                                <div class="followup4_tb_mid">
                                                                    <input name="new_pass"  id="new_pass" class="npassTxt" type="text" value="Enter Your New Password*" />
                                                                    <br/><span id="new_pass_error" style="color:red;font:13px kreonregular;letter-spacing:0.01em;"></span>
                                                                </div>

                                                                <div class="followup4_tb_mid">
                                                                    <input name="confirm_pass"  id="confirm_pass" class="cpassTxt" type="text" value="Enter Your Confirm Password*" />
                                                                    <br/><span id="pass_error_1" style="color:red;font:13px kreonregular;letter-spacing:0.01em;"></span>
                                                                </div>
                                                            </div>
                                                            <div class="followup_buttons">
                                                                
                                                                      <div class="button4">
                                                                    <div class="sub_lft">
                                                                        <div class="sub_rgt">
                                                                            <div class="sub_mid4">
                                                                              <a style="cursor:pointer;" class="Uppro_file_3 cursor"><?php echo $this->Lang['UPDATE']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                               
                                                                </div>
                                                                <div class="submit">
                                                                    <div class="sub_lft1">
                                                                        <div class="sub_rgt1">
                                                                            <div class="sub_mid5">
                                                                               <a  style="cursor:pointer;" onclick="javascript:cancel_hide_pr_4()" ><?php echo $this->Lang['CANCEL']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="pi_detail_edit" id="password_ic">
                                                            <p><a class="cursor profile_edit_4" style="cursor:pointer;" title="edit">edit</a></p>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <h4>Phone Number</h4>
                                                    <div class="pi_detail">
                                                        <div class="pi_detail_info" id="city_user">
                                                            <p id="show2"><?php echo $u->phone_number; ?>&nbsp;</p>
                                                        </div>
                                                        <div id="shw_phone" style="display:none;">
                                                            <div class="followup">
                                                                <div class="followup_tb_mid"> 
                                                                    <input type="text"  name="phone_number" id="phone" value="<?php echo $u->phone_number; ?>" placeholder="Enter your Mobile Number.." title="<?php echo $u->phone_number; ?>"/>
                                                                </div>
                                                            </div>
                                                            <div class="followup_buttons">
                                                                
                                                                
                                                                <div class="button4">
                                                                    <div class="sub_lft">
                                                                        <div class="sub_rgt">
                                                                            <div class="sub_mid4">
                                                                             <a style="cursor:pointer;" class="Upprofile2" title="Update"><?php echo $this->Lang['UPDATE']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                               
                                                                </div>
                                                                <div class="submit">
                                                                    <div class="sub_lft1">
                                                                        <div class="sub_rgt1">
                                                                            <div class="sub_mid5">
                                                                            <a  style="cursor:pointer;" onclick="javascript:cancel_hide_pr2()" class="Cfollowup cursor" title="Cancel"><?php echo $this->Lang['CANCEL']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                
                                                                </div>
                                                                
                                                                
                                                              
                                                               
                                                                <br/><span id="phone_error" style="color:red;font:13px kreonregular;letter-spacing:0.01em;"></span>
                                                            </div>
                                                        </div>
                                                        <div class="pi_detail_edit" id="phone" >
                                                            <p><a class="cursor profile_edit_2" style="cursor:pointer;" title="edit">edit</a></p>
                                                        </div>
                                                    </div>
                                                </li>		
                                                <li>
                                                    <h4>Address</h4>
                                                    <div class="pi_detail">
                                                        <div class="pi_detail_info" id="city_user">
                                                            <p id="show3"><?php echo $u->address1; ?><?php if($u->address1 !='' && $u->address2 !='') { echo ","; } else { echo "&nbsp"; } ?><?php echo $u->address2; ?></p>
                                                        </div>
                                                        <div id="shw_address" style="display:none;">
                                                            <div class="followup">
                                                                <div class="followup_tb_mid"> 
                                                                    <input type="text"  name="address1" id="address1" value="<?php echo $u->address1; ?>" placeholder="Enter your address1.." title="<?php echo $u->address1; ?>"/>
                                                                </div>
                                                            </div>
                                                            <div class="followup">
                                                                <div class="followup_tb_mid"> 
                                                                    <input type="text"  name="address2" id="address2" value="<?php echo $u->address2; ?>" placeholder="Enter your address2 .." />
                                                                </div>
                                                            </div>
                                                            <div class="followup_buttons">
                                                                
                                                                    <div class="button4">
                                                                    <div class="sub_lft">
                                                                        <div class="sub_rgt">
                                                                            <div class="sub_mid4">
                                                                             <a style="cursor:pointer;" class="Upprofile3" title="Update"><?php echo $this->Lang['UPDATE']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                               
                                                                </div>
                                                                <div class="submit">
                                                                    <div class="sub_lft1">
                                                                        <div class="sub_rgt1">
                                                                            <div class="sub_mid5">
                                                                           <a  style="cursor:pointer;" onclick="javascript:cancel_hide_pr3()" class="Cfollowup cursor" title="Cancel"><?php echo $this->Lang['CANCEL']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                
                                                                </div>
                                                                
                                                                
                                                              
                                                               
                                                            </div>
                                                        </div>
                                                        <div class="pi_detail_edit"  id="city_ic">
                                                            <p><a class="cursor profile_edit_3" style="cursor:pointer;" title="edit">edit</a></p>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li id="border_none">
                                                    <h4>Profile Image</h4>
                                                    <div class="pi_detail">
                                                        <div class="pi_detail_info">
                                                            <?php if (file_exists(DOCROOT . 'images/user/150_115/' . $u->user_id . '.png')) {
                                                                ?>
                                                                <img src="<?php echo PATH . 'images/user/150_115/' . $u->user_id . '.png'; ?>"  />
                                                            <?php } elseif (file_exists(DOCROOT . 'images/user/150_115/' . $u->user_id . '.jpg')) { ?>
                                                                <img src="<?php echo PATH . 'images/user/150_115/' . $u->user_id . '.jpg'; ?>"  />
                                                            <?php } else { ?>
                                                                <img src="<?php echo PATH; ?>images/user/150_115/profileimg.png"  /> 
                                                            <?php } ?>
                                                        </div>
                                                        <div class="pi_detail_edit">
                                                            <p><a style="cursor:pointer" onclick="javascript:popup_show()" title="edit">edit</a></p>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="pi_border_bot">
                                        </div>
                                    </div>

                                    <div class="mc_rl_right">
                                        <div class="mc_section">
                                            <div class="mc_section_heading">
                                                <div class="mc_section_heading_left">

                                                </div>
                                                <div class="mc_section_heading_right">
                                                    <p>

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="mc_top"></div>
                                            <div class="mc_mid">
                                                <ul>
                                                    <li>
                                                        <h4>City</h4>
                                                        <div class="pi_detail">
                                                            <div class="pi_detail_info" id="city_user">
                                                                <p id="show4" style="color: #231F20;
    font: bold 19px overlockregular;"><?php echo $u->city_name; ?></p>
                                                            </div>
                                                            <div id="shw_city" style="display:none;">
                                                                <div class="followup_2">
                                                                    <select name="city" id="city">
                                                                        <?php foreach ($this->all_city_list as $c) { ?>
                                                                            <option  <?php if ($c->city_id == $u->city_id) { ?> selected <?php } ?> title="<?php echo $c->city_name; ?>"value="<?php echo $c->city_id; ?>" ><?php echo $c->city_name; ?></option>
                                                                        <?php } ?>
                                                                    </select> 
                                                                </div>		
                                                                <div class="followup_buttons" style="padding-top:10px;">	
                                                                    
                                                                    
                                                                     <div class="button4">
                                                                    <div class="sub_lft">
                                                                        <div class="sub_rgt">
                                                                            <div class="sub_mid4">
                                                                          <a style="cursor:pointer;" class="Upprofile4" title="Update"><?php echo $this->Lang['UPDATE']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                               
                                                                </div>
                                                                <div class="submit">
                                                                    <div class="sub_lft1">
                                                                        <div class="sub_rgt1">
                                                                            <div class="sub_mid5">
                                                                          <a  style="cursor:pointer;" onclick="javascript:cancel_hide_pr4()" class="Cfollowup cursor" title="Cancel"><?php echo $this->Lang['CANCEL']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                
                                                                </div>
                                                                    
                                                                    
                                                                    
                                                                  
                                                                </div>
                                                            </div>
                                                            <div class="pi_detail_edit" style="color: #0033A0;font: bold 13px overlockregular;padding: 1px 17px;text-align: right;" id="city_ic">
                                                                <p><a class="cursor profile_edit4" style="cursor:pointer;" title="edit">edit</a></p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <h4>Country</h4>
                                                        <div class="pi_detail">
                                                            <div class="pi_detail_info">
                                                                <p id="show5" style="color: #231F20;
    font: bold 19px overlockregular;">	<?php echo $c->country_name; ?></p>
                                                            </div>
                                                            <div id="shw_country" style="display:none;">
                                                                <div class="followup_2">
                                                                    <select name="country" id="country">
                                                                        <?php foreach ($this->country_list as $c) { ?>
                                                                            <option  <?php if ($c->country_id == $u->country_id) { ?> selected="selected" <?php } ?> title="<?php echo $c->country_name; ?>" value="<?php echo $c->country_id; ?>" ><?php echo $c->country_name; ?></option>
                                                                        <?php } ?>
                                                                    </select> 
                                                                </div>
                                                                <div class="followup_buttons" style="padding-top:10px;">	
                                                                    
                                                                    
                                                                           <div class="button4">
                                                                    <div class="sub_lft">
                                                                        <div class="sub_rgt">
                                                                            <div class="sub_mid4">
                                                                      <a style="cursor:pointer;" class="Upprofile5" title="Update"><?php echo $this->Lang['UPDATE']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                               
                                                                </div>
                                                                <div class="submit">
                                                                    <div class="sub_lft1">
                                                                        <div class="sub_rgt1">
                                                                            <div class="sub_mid5">
                                                                           <a  style="cursor:pointer;" onclick="javascript:cancel_hide_pr5()" class="Cfollowup cursor" title="Cancel"><?php echo $this->Lang['CANCEL']; ?> </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                
                                                                </div>
                                                                    
                                                                    
                                                                    
                                                                   
                                                               
                                                                </div>	
                                                            </div>	
                                                            <div class="pi_detail_edit" style="color: #0033A0;font: bold 13px overlockregular;padding: 1px 17px;text-align: right;" id="city_ic">
                                                                <p><a class="cursor profile_edit5" style="cursor:pointer;" title="edit" >edit</a></p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="mc_bot"></div>
                                        </div>

                                        <div class="empty_space">&nbsp;</div>
                                        <div class="rl_section">
                                            <h3>Referral Link</h3>
                                            <div class="rl_top"></div>
                                            <div class="rl_mid">
                                                <h4>User referral balance  <span style="color: #FF6500;"><?php echo CURRENCY_SYMBOL . " " . $u->user_referral_balance; ?> </span></h4>
                                                <h4>Earn <span style="color: #FF6500;"><?php echo CURRENCY_SYMBOL . " " . REFERRAL_AMOUNT; ?> </span>Points for each successful referral!*</h4>
                                                <div class="rl_tbox_outer">
                                                    <div class="rl_tbox_left_outer">
                                                        <form name="form1">
                                                            <div class="rl_tbox_left"></div>
                                                            <div class="rl_tbox_mid">
                                                                <input  class="auto_select text G_event E-Share_Link_ReferPage" width="160" onclick="select_all();" id="user_referral_url" name="user_referral_url" readonly="readonly" type="text" value="<?php echo PATH; ?>referral/<?php echo $u->referral_id; ?>"  />
                                                            </div>
                                                            <div class="rl_tbox_right"></div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rl_bot">
                                            </div>

                                        </div>
                                        <div class="rl_section">
                                            <h3>Connections</h3>
                                            <div class="rl_top">
                                            </div>
                                            <div class="rl_mid">
                                                <div class="rl_tbox_outer">
                                                    <div class="connections">
                                                        <?php foreach ($this->user_detail as $u) { ?> 
                                                            <?php
                                                            $facebook_id = $u->fb_user_id;
                                                            if ($facebook_id == '') {
                                                                ?>

                                                                <p><?php echo $this->Lang['SIGN_IN_WITH']; ?></p>
                                                                <p><a onclick="facebookconnect_share();" style="cursor:pointer;" class="face_connect" title="<?php echo $this->Lang['FB_CONN']; ?>"></a> 
                                                                </p>

        <?php } else { ?>
                                                                <div class="user_img"><img src="http://graph.facebook.com/<?php echo $facebook_id; ?>/picture"/></div> 
                                                                <form method="post" class="admin_form" name="edit_users" enctype="multipart/form-data" >
                                                                    <div class="face_det2">
                                                                        <ul>
                                                                            <li>
                                                                                <label style="font: 19px kreonregular;"><?php echo $this->Lang['USER_NAME']; ?> : </label>
                                                                                <p style="color: #231F20;font: bold 11px overlockregular;"><?php echo ucfirst($u->firstname); ?></p>
                                                                            </li>
                                                                            <li>
                                                                                <label style="font: 19px kreonregular;"><?php echo $this->Lang['EMAIL']; ?>  : </label>
                                                                                <p style="color: #231F20;font: bold 11px overlockregular;"><?php echo $u->email; ?></p>
                                                                            </li>
                                                                            <li>
                                                                                <label>&nbsp;</label>
                                                                                <input class="fl" value="1" type="checkbox" name="facebook" <?php if ($u->facebook_update == '1') { ?> checked="checked" <?php } ?> ><span class="facebook_wall" style="color: #231F20;font: bold 11px overlockregular;"><?php echo $this->Lang['AUTO_POST']; ?></span>
                                                                            </li>
                                                                            <li>
                                                                                <label>&nbsp;</label>
                                                                                <div class="new_submit">
                                                                                    <div class="new_sub">
                                                                                        <div class="sub_lft">
                                                                                            <div class="sub_rgt">
                                                                                                <div class="sub_mid">
                                                                                                     <input  name="Submit" type="submit" value="<?php echo $this->Lang['UPDATE']; ?>" />
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                       
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </form>
        <?php }
    } ?>
                                                    </div>
                                                </div>
                                                <div class="rl_bot"></div>	
                                            </div>
                                        </div>
                                    </div>
<?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="model_dailog" style="display:none">
    <div class="pop_up_profile">
        <div class="pop_up_top_profile">
            <h1>Changes profile picture</h1><a  class="pop_close cursor" style="cursor:pointer;">&nbsp;</a>
        </div>
        <div class="pop_up_mid_profile">
            <div  class="pop_form_profile" >
                <form action="<?php echo PATH; ?>users/edit-profile-images.html" method="post"  id="admin_form" class="admin_form" enctype="multipart/form-data" />
                <input type="file" id="empty_value_1" size="15" name="image"/>
                <em>
<?php if (isset($this->form_error['image'])) {
    echo $this->form_error["image"];
} ?>
                </em><br/>
                <span style="font:normal 15px arial; color:#333;">image  upload size 1[MB]</span>
                <div class="pop_but_profile">
                    <div class="submit">
                        <div class="sub_lft">
                            <div class="sub_rgt">
                                <div class="sub_mid">
                            <input class="bnone"  type="submit" value="submit"/>
                        </div>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
                </form>
            </div>
        </div>
        <div class="pop_up_bot_profile"></div>
    </div>
</div>

