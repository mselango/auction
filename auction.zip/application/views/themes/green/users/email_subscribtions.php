<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script language="javascript"> 
function toggle() {
	var ele = document.getElementById("toggleText");
	var text = document.getElementById("displayText");
	if(ele.style.display == "none") {
    		ele.style.display = "";
    		text.style.display = "none";
  	}
	else {
		ele.style.display = "none";
		text.style.display = "";
	}
} 

        $(document).ready(function() {
	       $('#toggleText').change(function() {
               var count=$(this).val();
               $.post("<?php echo PATH;?>add_city.html?count="+count,{
                       }, function(response){ 
                               $("#city_display").append(response);
                       });
               });
          });
</script>



        <div class="contianer_outer1">
            <div class="contianer_inner">
                <div class="contianer">
                    
                    <div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                            
                            <li><p title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></p></li>
                        </ul>
                    </div>
                    <!--content start-->
                    <div class="content_abouts">
                         <div class="all_mapbg_mid_common">
                        <div class="content_abou_common">
                            <div class="pro_top">
                            <h2><?php echo $this->Lang['MY_ELAL_SUB']; ?></h2>
                            </div>
                            <div class="all_mapbg_mid">   
                                <div class="myemai_mnu">
                                    <div class="top_menu myemail_subbor">
                                        <ul>
                                            <li>
                                                <div class="tab_left"></div>
                                                <div class="tab_mid"><a href="<?php echo PATH;?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div>
                                                <div class="tab_rgt"></div>
                                            </li>
                                            <li>
                                                <div class="tab_left"></div>
                                                <div class="tab_mid"><a href="<?php echo PATH;?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div>
                                                <div class="tab_rgt"></div>
                                            </li>
                                            <li>
                                                <div class="tab_left"></div>
                                                <div class="tab_mid"><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div>
                                                <div class="tab_rgt"></div>

                                            </li>
                                            <li   class="tab_act">
                                                <div class="tab_left"></div>
                                                <div class="tab_mid"><a href="<?php echo PATH;?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> 
                                                <div class="tab_rgt"></div>
                                            </li>
                                            <li>
                                                <div class="tab_left"></div>
                                                <div class="tab_mid"><a href="<?php echo PATH;?>users/my-winner-list.html" title="Won Auction"><?php echo 'Won Auction'; ?></a></div> 
                                                <div class="tab_rgt"></div>

                                            </li>
                                        </ul>                                                                
                                    </div> 
                                </div>
                            </div>
                                <div class="my_email_sub pos_rel">  

                                    <div class="title">
										<h1></h1>    
                                    </div>
									
                                    <p class="fl mt10">  <?php echo $this->Lang['TELL_US']; ?> <span style="float:right; font: normal 12px arial; color:#666; padding-top:9px;"><?php echo $this->Lang['EMAIL_ADDRESS']; ?>:<?php foreach($this->users_select_list as $city1){ ?><span style=" font: normal 12px arial; color:#666;"><?php echo $city1->email_id; ?></span><?php }?></span> </p>                
									
                                    <div class="myemail_daily_deals">
										<form method="post" class="admin_form" name="email_subscribe">
										<?php if(CITY_SETTING) { ?>
                                        <h1><?php echo $this->Lang['NATION']; ?></h1>
                                        <ul>
											 <?php $city1->city_id=""; foreach($this->get_city_list as $city) {
											foreach($this->users_select_list as $city1){
											 $user_city = $city1->city_id;
											 $city_Tags = explode(",", $user_city);
											 if(in_array($city->city_id, $city_Tags)){
											?>
											  <li><input type="checkbox"  <?php if(in_array($city->city_id, $city_Tags)){?> checked="checked" <?php } ?>value="<?php echo $city->city_id;?>"  name="city_tag[]" /><p> <?php echo ucfirst($city->city_name); ?></p></li>
										  <?php } } } ?>
										   <span id="city_display"> </span>
											  <li><a  id="displayText" href="javascript:toggle();" title="<?php echo $this->Lang['ADD_ANOTHER']; ?>"><div class="add_city"><?php if(($city1->city_id=='') || ($city1->city_id==$this->city_id) ){?>

											<?php echo $this->Lang['ADD_ANY']; ?>
								
									<?php } else{ ?>
											<?php echo $this->Lang['ADD_ANOTHER']; ?>
								
									<?php } ?> </a></li>
										<select name="city_tag[]" id="toggleText" style="display: none">
										  
										<option value="">Select city</option>
										<?php foreach($this->get_city_list as $CityL){ 
										foreach($this->users_select_list as $city1){
										 $user_city = $city1->city_id;
										 $city_Tags = explode(",", $user_city);
										 if(!in_array($CityL->city_id, $city_Tags)){
										?>
										<option <?php if($CityL->city_url==$this->input->get('city')){ echo 'Selected="true"'; } ?> value="<?php echo $CityL->city_id; ?>"><?php echo ucfirst($CityL->city_name); ?></option>
										<?php } }
										} ?>
										</select>
											   </ul>
											   <?php } ?>

																	  
															   
                                    </div>
                                    <div class="myemail_daily_deals_cat">
                                        <h1><?php echo $this->Lang['DEAL_CATE']; ?></h1>
                                        <?php foreach($this->category_list as $categories){
			      foreach($this->users_select_list1 as $categories1){
			 $category = $categories1->category_id;
		 	 $category_Tags = explode(",", $category); 
			      ?>
                                        <ul>
											<li><input type="checkbox" <?php if(in_array($categories->category_id, $category_Tags)){?> checked="checked" <?php } ?> value="<?php echo $categories->category_id;?>"  name="category_tag[]" /> <p><?php echo ucfirst($categories->category_name); ?></p></li>
                                            
                                        </ul>
                                        <?php }}?>
                                      
                                    </div>
                                </div>
                                <div class="fl clr width350">
                                    <div class="submit ml20">
                                        <div class="sub_lft">
                                              <div class="sub_rgt">
                                                   <div class="sub_mid">
                                           <input name="Submit" type="Submit" value="<?php echo $this->Lang['SAVE']; ?>" />
                                        </div>
                                              </div>
                                        </div>
                                       
                                      
                                    </div>
                                      <?php foreach($this->users_select_list as $city){  ?>    
		    <?php if($city->suscribe_city_status == 1){?>
                    <div class="myemail_unsub" style="cursor:pointer;" ><a onclick="return SubscribeUnsubscribe('<?php echo $city->user_id; ?>','suscribe');" class="color0079D8"><?php echo $this->Lang['SUBSC']; ?></a></div>
                    <?php } else{  ?>
                    <div class="myemail_unsub" style="cursor:pointer;"><a onclick="return SubscribeUnsubscribe('<?php echo $city->user_id; ?>','unsuscribe');" class="color0079D8"><?php echo $this->Lang['UNSUBSC']; ?></a></div>
                    <?php } ?>
                    <?php }?> 
                                    
                                </div>
                                </form>
                            </div>
                        </div>  


                    </div>
                    <!--end-->
                </div>
            </div>
        </div>

<?php /*
<script language="javascript"> 
function toggle() {
	var ele = document.getElementById("toggleText");
	var text = document.getElementById("displayText");
	if(ele.style.display == "none") {
    		ele.style.display = "block";
    		text.style.display = "none";
  	}
	else {
		ele.style.display = "none";
		text.style.display = "block";
	}
} 

        $(document).ready(function() {
	       $('#toggleText').change(function() {
               var count=$(this).val();
               $.post("<?php echo PATH;?>add_city.html?count="+count,{
                       }, function(response){ 
                               $("#city_display").append(response);
                       });
               });
          });
</script>
<div class="container_outer">
	<div class="continer_outer_common fl">
	<div class="brad_com_out">
		<div class="brad_com_inn">
			<div class="brad_com">
<ul>
	<li><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></li>
        <li>\</li>
	<li ><a  href="<?php echo PATH; ?>/users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></li>
	<li >\</li>
	<li  class="act"><p title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></p></li>
  

	</ul>
			</div>
		</div>
	</div>

<div class="container_inner">
      <div class="container">
		  <div id="mybuys_deals" class="my_referrallist">
				<h2 class="txt_upp top_title pt_20"><?php echo $this->Lang['MY_ELAL_SUB']; ?></h2>
			      <div class="all_deals_map">
                <div class="all_mapbg_top">  </div>
                  <div class="all_mapbg_mid">   
 			
                      
                      <div class="myemai_mnu">
                         <div class="top_menu myemail_subbor">
            
	<ul>

	
			 <li ><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-coupons.html" title="<?php echo $this->Lang['MY_BUYS']; ?>"><?php echo $this->Lang['MY_BUYS']; ?></a></div> <div class="tab_rgt"></div></li>

			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-referral-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo $this->Lang['MY_REFERAL']; ?></a></div> <div class="tab_rgt"></div></li>

			<li ><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-account.html" title="<?php echo $this->Lang['MY_ACC']; ?>"><?php echo $this->Lang['MY_ACC']; ?></a></div> <div class="tab_rgt"></div> </li>

			<li class="tab_act"><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/email-subscribtions.html" title="<?php echo $this->Lang['MY_ELAL_SUB']; ?>"><?php echo $this->Lang['MY_ELAL_SUB']; ?></a></div> <div class="tab_rgt"></div> </li>
			<li><div class="tab_left"></div><div class="tab_mid"><a href="<?php echo PATH;?>users/my-winner-list.html" title="<?php echo $this->Lang['MY_REFERAL']; ?>"><?php echo 'Auction Bid List'; ?></a></div> <div class="tab_rgt"></div></li>
			</ul>
    </div> 
                   
	<div class="my_email_sub pos_rel"> 
		         <div class="title"><h1><?php echo $this->Lang['MY_ELAL_SUB']; ?></h1>
			 
			<h2><span class="color333333"><?php echo $this->Lang['EMAIL_ADDRESS']; ?> </span>:<span class="color676767 ml5">
			<?php foreach($this->users_select_list as $city1){ ?><span><?php echo $city1->email_id; ?></span><?php }?>
			</span></h2>    
		        </div>
       		  	<p class="fl mt10"> <?php echo $this->Lang['TELL_US']; ?> </p> 
    
			<div class="myemail_daily_deals">
		
		        <form method="post" class="admin_form" name="email_subscribe">
				<?php if(CITY_SETTING) {	?>
		           <h1><?php echo $this->Lang['NATION']; ?></h1>
	 		
		           <ul>

			  <?php $city1->city_id=""; foreach($this->get_city_list as $city) {
			 	foreach($this->users_select_list as $city1){
				 $user_city = $city1->city_id;
		 		 $city_Tags = explode(",", $user_city);
		 		 if(in_array($city->city_id, $city_Tags)){
				?>
		
		          <li><input type="checkbox"  <?php if(in_array($city->city_id, $city_Tags)){?> checked="checked" <?php } ?>value="<?php echo $city->city_id;?>"  name="city_tag[]" /><p> <?php echo ucfirst($city->city_name); ?></p></li>
			  <?php } } } ?>
			  <span id="city_display"> </span>
		          <li><a id="displayText" href="javascript:toggle();" title="<?php echo $this->Lang['ADD_ANOTHER']; ?>"><div class="add_city"><?php if(($city1->city_id=='') || ($city1->city_id==$this->city_id) ){?>

				<?php echo $this->Lang['ADD_ANY']; ?>
	
		<?php } else{ ?>
				<?php echo $this->Lang['ADD_ANOTHER']; ?>
	
		<?php } ?> </a></li>
		



			<select name="city_tag[]" id="toggleText" style="display: none">
			  
			<option value="">Select city</option>
			<?php foreach($this->get_city_list as $CityL){ 
			foreach($this->users_select_list as $city1){
			 $user_city = $city1->city_id;
	 		 $city_Tags = explode(",", $user_city);
	 		 if(!in_array($CityL->city_id, $city_Tags)){
			?>
			<option <?php if($CityL->city_url==$this->input->get('city')){ echo 'Selected="true"'; } ?> value="<?php echo $CityL->city_id; ?>"><?php echo ucfirst($CityL->city_name); ?></option>
			<?php } }
			} ?>
			</select>
		           </ul>
		           <?php } ?>
		</div>
		

			<div class="myemail_daily_deals_cat">

		           <h1><?php echo $this->Lang['DEAL_CATE']; ?></h1>
			<?php foreach($this->category_list as $categories){
			      foreach($this->users_select_list1 as $categories1){
			 $category = $categories1->category_id;
		 	 $category_Tags = explode(",", $category); 
			      ?>
		           <ul>
		           <li><input type="checkbox" <?php if(in_array($categories->category_id, $category_Tags)){?> checked="checked" <?php } ?> value="<?php echo $categories->category_id;?>"  name="category_tag[]" /> <p><?php echo ucfirst($categories->category_name); ?></p></li>
		    
		           </ul>	
		           
			<?php }}?>

	 		</div>
   			 </div>

		    <?php foreach($this->users_select_list as $city){  ?>    
		    <?php if($city->suscribe_city_status == 1){?>
                    <div class="my_email_unsublink" style="cursor:pointer;" ><a onclick="return SubscribeUnsubscribe('<?php echo $city->user_id; ?>','suscribe');" class="color0079D8"><?php echo $this->Lang['SUBSC']; ?></a></div>
                    <?php } else{  ?>
                    <div class="my_email_unsublink" style="cursor:pointer;"><a onclick="return SubscribeUnsubscribe('<?php echo $city->user_id; ?>','unsuscribe');" class="color0079D8"><?php echo $this->Lang['UNSUBSC']; ?></a></div>
                    <?php } ?>
                    <?php }?> 
					
				<div class="fl clr">
					<div class="new_submit ml20">
						<div class="new_sub">
							<input name="Submit" type="Submit" value="<?php echo $this->Lang['SAVE']; ?>" />
						</div>
					</div>
					
                </div>
				
				</form>
                    
                      </div>
        
		        </div> 
           
      <div class="all_mapbg_bot"> </div>
     			</div>
                                
              
	  </div>
 </div>
</div>
</div>
</div>
*/ ?>
               



