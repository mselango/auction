<?php if(count($this->auctions_coupons_list) > 0 ) { ?>
				<?php foreach($this->auctions_coupons_list as $p){ ?>
			 
				  <ul>
				    <li class="my_buy_title"><a href="<?php echo PATH.'auction/'.$p->deal_key.'/'.$p->url_title.'.html';?>" title="<?php echo $p->deal_title;?>" class="fl clear"><?php echo $p->deal_title;?></a></li>
				    <li class="my_buy_title"><a href="<?php echo PATH.'stores/'.$p->store_key.'/'.$p->store_url_title.'.html';?>" title="Reebok"><?php echo $p->store_name; ?></a></li>
				    <li class="my_buy_pur_date"><?php echo date('d-M-Y',$p->transaction_date);?></li>
					<li class="my_buy_title"><?php echo $p->de_add1.",".$p->de_add2;?></li>
					<li class="my_buy_storename"><?php if($p->delivery_status == 0){ echo 'Non Delivered'; } else echo "Delivered";?></li>
				  </ul>
				<?php } } else { ?>
				<div class="no_referal"><p>No auctions found</p></div>
				<?php }?>
			      </div>
