<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>  


<script type="text/javascript" src="<?php echo PATH; ?>js/timer/kk_countdown_1_2_jquery_min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $("body").kkCountDown({
            colorText:'#000000',
            colorTextDay:'#000000'
	
        });
         $('.submit-link')
                               .click(function(e){ 
									
                                       $('input[name="c"]').val($(this).attr('id').replace('sample-',''));
                                       $('input[name="c_t"]').val('<?php echo base64_encode("main");?>');
                                       e.preventDefault();
                                       $(this).closest('form')
                                               .submit();
                                               
   });
  
    });
</script>

</div>
</div>
</div>


<?php if (!$this->session->get("Skip")) {
    $cityid = $this->city_id; ?>


    <div id="popup" class='popup_block_sub'>
        <div class="banner1">
            <div class="sub_scr_top"></div>
            <div class="sub_scr_mid">
                <div class="common_src">
                    <div class="agree">
                        <a href="#" title="facebook"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/logo.png" alt="facebook"/></a>

                        <span ><a href="<?php echo PATH; ?>welcome/set_session"  class="clos1"></a></div>

                </div>
                <div class="agree2">



                    <div class="left_content fl">
                        <div class="home_subscribe fl clr">

                            <form action="" method="post" name="subsc" id="emailform" >
                                <div class="land_popup_midd">
                                    <h2>Your Email Address</h2>
                                    <p style="color:#666666;float:left;font: bold 12px/25px arial; padding: 0 0;width: 100%"> Enter your email id to get super saver deals from all reputed sources</p>
                                    <div class="common_colors">
                                        <div  class="land_email_input">
                                            <label>Email Address : </label>
                                            <div class="left_cor"> <input type="text" id="email" placeholder="Enter your email address" title="Email Address" name="email" /><em id="email_1"></em></div>
                                        </div>

                                        <div  class="land_email_input">
                                            <label>Select Your City : </label>
                                            <div class="left_cor"><select title="<?php echo $this->Lang['SELECT UR CITY HERE']; ?>" name="city">
                                                    <?php
                                                    $cityid = "";
                                                    if (isset($this->current_cityid)) {
                                                        $cityid = $this->current_cityid;
                                                    }
                                                    foreach ($this->all_city_list as $CData) {
                                                        if ($CData->city_id == $cityid) {
                                                            ?>
                                                            <option value="<?php echo $CData->country_id . "_" . $CData->city_id . "_" . $CData->city_url; ?>"><?php echo ucfirst($CData->city_name); ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    foreach ($this->all_city_list as $C) {
                                                        ?>
                                                        <option value="<?php echo $C->country_id . '_' . $C->city_id . '_' . $C->city_url; ?>"><?php echo ucfirst($C->city_name); ?></option>
    <?php } ?>      
                                                </select></div>
                                        </div>
                                    </div>

                                    <div class="button_cont">
                                        <div class="sign_up_submit_outer2">  


                                            <div class="sub_lft11"></div>
                                            <div class="sub_mid11">    <input type="submit" value="Subscribe" onclick="return validatesubscribeForm();"  />

                                            </div>
                                            <div class="sub_rgt11"></div>

                                        </div>
                                    </div>

                                </div>


                            </form>
                        </div>
                    </div> 

                </div>
                <div class="right_top_left">
                    <p>Save Upto</p>
                    <span>75%</span>
                </div>
                <div class="right_content2">
                    &nbsp;

                </div>
            </div>

        </div>
        <div class="sub_scr_bot" style="padding-top:10px;"></div>


    </div>


    </div>


    <script type="text/javascript">
        $(document).ready(function(){
    		
            var popID = 'popup'; 
            var popWidth = '500'; 

            $('#' + popID).fadeIn().css({ 'width': Number( popWidth ) }).prepend('');
    		
    	
            var popMargTop = ($('#' + popID).height() + 80) / 2;
            var popMargLeft = ($('#' + popID).width() + 80) / 2;
    		
    		
            $('#' + popID).css({ 
                'margin-top' : -popMargTop,
                'margin-left' : -popMargLeft
            });
    		
    		
            $('body').append('<div id="fade_sub"></div>'); 
            $('#fade_sub').css({'filter' : 'alpha(opacity=80)'}).fadeIn(); 
    		
    		
    					   		   
    	
            $('a.close').live('click', function() { 
                $('#fade_sub , .popup_block_sub').fadeOut(function() {
                    $('a.close').remove();  
                }); 
    		
                return false;
            });	

        });
        function validatesubscribeForm()
        {
            var email = document.subsc.email.value;		
            var atpos=email.indexOf("@");
            var dotpos=email.lastIndexOf(".");
            if(email =='' || (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length))
            {
                if(email == '')
                {
                    $('#email_1').css({'color':'red'});
                    $('#email_1').html('required*');
                    return false;
                }
                if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length)
                {
                    $('#email_1').css({'color':'red'});
                    $('#email_1').html('Invalid Email');
                    return false;	
                }
    		
            }
    		
            else{			
                document.subsc.submit();
            }
    	
        }
    </script>
<?php } ?>


<!--slider css-->
<link rel="stylesheet" href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/demo.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/flexslider.css" type="text/css" media="screen" />

<!--slider jquery-->
<!-- jQuery -->



<!-- FlexSlider -->
<script src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jquery.flexslider.js"  type="text/javascript"></script>

<script type="text/javascript">
    $(function(){
        SyntaxHighlighter.all();
    });
    $(window).load(function(){
        $('.flexslider').flexslider({
            animation: "slide",
            start: function(slider){
                $('body').removeClass('loading');
            }
        });
    });
</script>

<div class="contianer_outer" id="home_page_margin_top">
    <div class="contianer_inner">
        <div class="contianer">
            <!--content start-->    
                <!--sidebar start-->
<?php if ((count($this->deals_details) > 0) || (count($this->auction_details) > 0) || (count($this->products_details) > 0)) {?>

                    <div class="conntent_left">
                        <div class="cat_outer1">
                            <div class="category1">
                                <h1>Categories</h1>
                               <form>
                                <ul>
                                    <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
                                    $cat1 = array_unique($cat);
                                    ?>

                                            <?php if($this->category_list){  foreach ($this->category_list as $d) { ?>
                                        <li <?php if((isset($_GET['c']) && $_GET['c'] == $d->category_id) || (isset($_GET['m_c']) && $_GET['m_c'] == $d->category_id )) { ?> class="li_active" <?php } ?>>

        <?php $type = "";

        $categories = $d->category_url; ?>
                                            <a style="cursor:pointer;" class="sample_12 submit-link" id="sample-<?php echo base64_encode($d->category_id); ?>"  title="<?php echo ucfirst($d->category_name); ?>">
        <?php echo ucfirst($d->category_name); ?>
                                            </a>
                                            <div class="sub_menu_top1">
                                                <span class="white">&nbsp;</span>
                                                <ul>
                                                    <a style="cursor:pointer;" ><div id="categeory1-<?php echo base64_encode($d->category_id); ?>"></div></a>

                                                </ul>
                                            </div>
                                        </li>
    <?php } } ?>
    
                                </ul>
                                <input type="hidden" name="c" />
                                <input type="hidden" name="c_t" />
                                <input type="hidden" name="m_c">
<p><input type="submit" style="display:none;"> </p>
	</form>
                            </div>
                        </div>



                                <?php if (count($this->ads_details) > 0) { ?>   
                                    <?php foreach ($this->ads_details as $ads) { ?>    
            <?php if ($ads->ads_position == "bh") { ?>                     
                                    <div class="cat_outer4">
                                        <div class="right_left">
                             <a href="<?php echo $ads->link; ?>"> <img src="<?php echo PATH; ?>images/ads/<?php echo $ads->ads_id; ?>.png"/> </a>
                                        </div>
                                    </div>
            <?php } ?>
        <?php } ?>
    <?php } ?>

                    </div>
                    <!--end-->

                    <div class="content_right">
                                        <?php if (count($this->banner_details) > 0) { ?>
                            <div class="banner">
                                <div class="banner_bor">
                                    <div class="flexslider">
                                        <ul class="slides">
        <?php foreach ($this->banner_details as $banner) { ?>
                                                <li>
                                                    <div class="left">

                                                    </div>
                                                    <a target="_blank" href="<?php echo $banner->redirect_url; ?>" ><img alt="<?php echo $banner->image_title; ?>" src="<?php echo PATH . 'images/banner_images/' . $banner->banner_id . '.png'; ?>" /></a>
                                                </li>
        <?php } ?>


                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php }
                    } ?>



                    <!-- product list-->
<?php if ($this->product_setting) { ?>
                                    <?php if (count($this->products_details) > 0) { ?>

                            <div class="product_details">

                                <div class="pro_top">
                                    <div class="pro_title"><h2>FEATURED PRODUCTS</h2>
        <?php if ($this->products_details1 > 8) { ?><a class="view_more" href="<?php echo PATH . 'products.html'; ?>" title="<?php echo $this->Lang['VIW_MRE_PRO']; ?>"><?php echo "VIEW MORE"; ?></a><?php } ?>
                                    </div>


                                </div>



                                <div class="pro_mid">

                                            <?php
                                            foreach ($this->products_details as $p) {
                                                $symbol = CURRENCY_SYMBOL;
                                                ?>
                                        <div class="pro_listing">

                                            <div class="det_img1">
												
                                                <?php $url = $p->category_url; if( $this->cat != "" ) $url = $this->cat; if (file_exists(DOCROOT . 'images/category/icon/' . $url . '.png')) { ?>
                                                    <span class="cat_icon1"><img alt="category icon"  title="<?php echo $p->category_name; ?>" src="<?php echo PATH . 'images/category/icon/' . $url . '.png'; ?>"></span>
                                                <?php } else { ?>
                                                    <span class="cat_icon1"><img alt="category icon" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png" title="no-image"/></span>
            <?php } ?>
            <?php if (file_exists(DOCROOT . 'images/products/290_215/' . $p->deal_key . '_1' . '.png')) { ?>
                                                    <a href="<?php echo PATH . 'product/' . $p->deal_key . '/' . $p->url_title . '.html'; ?>" title="<?php echo $p->deal_title; ?>"><img src="<?php echo PATH . 'images/products/290_215/' . $p->deal_key . '_1' . '.png'; ?>" alt="<?php echo $p->deal_title; ?>"   border="0" /></a>
                                                <?php } else { ?>
                                                    <a href="<?php echo PATH . 'product/' . $p->deal_key . '/' . $p->url_title . '.html'; ?>" title="<?php echo $p->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" alt="<?php echo $p->deal_title; ?>" /></a>
            <?php } ?>
                                            </div>

                                            <div class="deal_list_detail">
            <?php $type = "products";
            $categories = $p->category_url; ?>

                                               <?php /* <h2><a class="cursor" onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');" title="<?php echo $p->category_name; ?>"><?php echo $p->category_name; ?></a></h2> */ ?>
                                                <h3><a href="<?php echo PATH . 'product/' . $p->deal_key . '/' . $p->url_title . '.html'; ?>" title="<?php echo $p->deal_title; ?>"><?php echo substr($p->deal_title, 0, 50) . '...'; ?></a></h3>
                                                <p><span class="price">Price :</span> <span class="usd"><?php echo $symbol . " " . $p->deal_value; ?></span></p>
                                                <div class="view_deals">
                                                    <div class="view_lft">
                                                        <div class="view_rgt">
                                                            <div class="view_mid">
                                                                <a href="<?php echo PATH . 'product/' . $p->deal_key . '/' . $p->url_title . '.html'; ?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                            <?php } ?>

                                </div>

                            </div>


    <?php }
} ?> 




                                <?php if ($this->deal_setting) { ?>
    <?php if (count($this->deals_details) > 0) { ?>

                            <!--feture deal-->
                            <div class="product_details">
                                <div class="pro_top">
                                    <div class="pro_title">
                                        <h2>FEATURED DEALS</h2>
        <?php if ($this->deals_details1 > 6) { ?><a class="view_more" href="<?php echo PATH . 'today-deals.html'; ?>" title="<?php echo $this->Lang['VIW_MRE_DEAL']; ?>" title="VIEW MORE ">VIEW MORE</a><?php } ?>
                                    </div>

                                </div>
                                <div class="pro_mid">
                                                <?php
                                                foreach ($this->deals_details as $d) {
                                                    $symbol = CURRENCY_SYMBOL;
                                                    ?>
                                        <div class="feture_deal_listing">
                                            <div class="feture_top"></div>
                                            <div class="feture_mid">
                                                <div class="fetur_img">
                                                    <?php $url = $d->category_url; if( $this->cat != "" ) $url = $this->cat; if (file_exists(DOCROOT . 'images/category/icon/' . $url . '.png')) { ?>
                                                        <span class="cat_icon"><img alt="category icon" title="<?php echo $d->category_name; ?> " src="<?php echo PATH . 'images/category/icon/' . $url . '.png'; ?>"></span>
                                                    <?php } else { ?>
                                                        <span class="cat_icon"><img alt="category icon" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/cate_icon.png" title="no-image"/></span>
            <?php } ?>

            <?php if (file_exists(DOCROOT . 'images/deals/220_160/' . $d->deal_key . '_1' . '.png')) { ?>
                                                        <a href="<?php echo PATH . 'deals/' . $d->deal_key . '/' . $d->url_title . '.html'; ?>" title="<?php echo $d->deal_title; ?>"><img src="<?php echo PATH . 'images/deals/220_160/' . $d->deal_key . '_1' . '.png'; ?>"  alt="<?php echo $d->deal_title; ?>" title="<?php echo $d->deal_title; ?>" border="0" /></a>

            <?php } else { ?>
                                                        <a href="<?php echo PATH . 'deals/' . $d->deal_key . '/' . $d->url_title . '.html'; ?>" title="<?php echo $d->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png"   alt="<?php echo $d->deal_title; ?>" title="<?php echo $d->deal_title; ?>" border="0" /></a>
            <?php } ?>
                                                    <div class="img_bought_det">
                                                        <p><?php echo $d->purchase_count; ?>Bought</p><span><?php echo $symbol . " " . $d->deal_value; ?></span>
                                                    </div>
                                                </div>
                                                <div class="feture_bot_det">
                                                    <p><a href="<?php echo PATH . 'deals/' . $d->deal_key . '/' . $d->url_title . '.html'; ?>"><?php echo substr($d->deal_title, 0, 50) . '...'; ?></a></p>
                                                    <div class="time_price">
                                                        <div class="time_price_lft">
                                                            <label><span  time="<?php echo $d->enddate; ?>" class="kkcount-down"></span></label>
                                                            <p><?php echo $symbol . " " . $d->deal_price; ?></p>
                                                        </div>
                                                        <div class="view_del">
                                                            <div class="view_deal_lft">
                                                                <div class="view_deal_rgt">
                                                                    <div class="view_deal_mid">
                                                                        <a href="<?php echo PATH . 'deals/' . $d->deal_key . '/' . $d->url_title . '.html'; ?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="feture_bot"></div>
                                        </div>


                            <?php } ?>  

								</div>

    <?php }
} ?>


                    
<?php if ($this->auction_setting) { ?>
    <?php if (count($this->auction_details) > 0) { ?>
                            <!--action deal list-->
                            <div class="product_details">

                                <div class="pro_top">
                                    <div class="pro_title"><h2>AUCTION</h2>
        <?php if ($this->auction_details1 > 4) { ?> <a class="view_more" href="<?php echo PATH; ?>auction.html" title="View more best auctions ">VIEW MORE</a><?php } ?>
                                    </div>

                                </div>

                                <div class="pro_mid">
                                                <?php
                                                foreach ($this->auction_details as $a) {
                                                    $symbol = CURRENCY_SYMBOL;
                                                    ?>
                                        <div class="auction_list">

                                            <div class="action_img">
                                                <div class="act_img_top"></div>
                                                <div class="act_img_mid">
                                                    <?php if (file_exists(DOCROOT . 'images/category/icon/' . $a->category_url . '.png')) { ?>
                                                        <span class="cat_icon1"><img alt="category icon"  title="<?php echo $a->category_name; ?> " src="<?php echo PATH . 'images/category/icon/' . $url . '.png'; ?>"></span>
                                                    <?php } else { ?>
                                                        <span class="cat_icon1"><img alt="category icon" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png" title="no-image"/></span>
            <?php } ?>

            <?php /** <span class="sold"><img alt="sold" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/sold.png"/></span> * */ ?>
            <?php if (file_exists(DOCROOT . 'images/auction/220_160/' . $a->deal_key . '_1' . '.png')) { ?>
                                                        <a href="<?php echo PATH . 'auction/' . $a->deal_key . '/' . $a->url_title . '.html'; ?>" title="<?php echo $a->deal_title; ?>"><img src="<?php echo PATH . 'images/auction/220_160/' . $a->deal_key . '_1' . '.png'; ?>"  alt="<?php echo $a->deal_title; ?>" title="<?php echo $a->deal_title; ?>" border="0" /></a>

            <?php } else { ?>
                                                        <a href="<?php echo PATH . 'auction/' . $a->deal_key . '/' . $a->url_title . '.html'; ?>" title="<?php echo $a->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_auctions_list.png"  alt="<?php echo $a->deal_title; ?>" title="<?php echo $a->deal_title; ?>" border="0" /></a>
            <?php } ?>
                                                </div>
                                                <div class="act_img_bot"></div>

                                            </div>
                                            <div class="action_rgt">
                                                <p><a href="<?php echo PATH . 'auction/' . $a->deal_key . '/' . $a->url_title . '.html'; ?>" title="<?php echo $a->deal_title; ?>"><?php echo substr($a->deal_title, 0, 40) . '...'; ?></a></p>

                                                <div class="bid_cont">
                                                    <div class="bid_value">

                                                        <label>  Price:</label>

                                                        <span><?php echo $symbol . " " . $a->deal_value; ?></span>
            <?php $q = 0;
            foreach ($this->all_payment_list as $payment) { ?>
                <?php
                if ($payment->auction_id == $a->deal_id) {
                    $firstname = $payment->firstname;
                    $transaction_time = $payment->transaction_date;
                    $q = 1;
                }
            }
            ?></div>
            <?php if ($q == 1) { ?>  
                                                        <div class="bid_value">
                                                            <label>  Last Bidder:</label>
                                                            <span><?php echo substr(ucfirst($firstname),0,10).'...'; ?></span>
                                                        </div>
                                                        <div class="bid_value">
                                                            <label> Bid:</label>
                                                            <span><?php echo date("d-m-Y", $transaction_time); ?></span>
                                                        </div>

            <?php } ?>

                                                    <?php if ($q == 0) { ?>

                                                        <div class="bid_value">
                                                            <label>  Last Bidder:</label>
                                                            <span> Not Yet Bid</span>
                                                            <div class="right_power">
                                                                <label>  Close Time:</label>
                                                                <span> <?php echo date("d-m-Y", $a->enddate); ?></span>

                                                            </div>
                                                        </div>



            <?php } ?>




                                                    <div class="time_price_lft">
                                                        <label><span  time="<?php echo $a->enddate; ?>" class="kkcount-down"></span></label>
                                                        <p></p>
                                                    </div>

            <!--<span style="color: #000000; float:left; margin: 0 0 0 75px;" time="<?php echo $a->enddate; ?>" class="kkcount-down timer_cont" ></span> -->


                                                </div>

                                                <div class="act_bid_values">                                        
                                                    <div class="view_deals">
                                                        <div class="view_lft">
                                                            <div class="view_rgt">
                                                                <div class="view_mid">
                                                                    <a href="<?php echo PATH . 'auction/' . $a->deal_key . '/' . $a->url_title . '.html'; ?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


        <?php } ?>
                                </div>

                            </div>


                        </div>
                  
                    <!--end-->

    <?php }
} ?>
        </div>

    </div>
</div>
</div>

<?php if ((count($this->products_details) == 0) && (count($this->deals_details) == 0) && (count($this->auction_details) == 0)) { ?>
    <?php echo new View("themes/" . THEME_NAME . "/subscribe"); ?>
<?php } ?>



<script type="text/javascript">
    // What is $(document).ready ? See: http://flowplayer.org/tools/documentation/basics.html#document_ready
    $(function() {

        $(".slidetabs").tabs(".images > div", {

            // enable "cross-fading" effect
            effect: 'fade',
            fadeOutSpeed: "medium",

            // start from the beginning after the last tab
            rotate: true

            // use the slideshow plugin. It accepts its own configuration
        }).slideshow();
    });
</script>




