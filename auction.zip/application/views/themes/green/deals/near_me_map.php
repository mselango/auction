<head>
<script type="text/javascript" src="<?php echo PATH;?>js/timer/kk_countdown_1_2_jquery_min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){

	$("body").kkCountDown({
	colorText:'#ED7E2C',
	colorTextDay:'#ED7E2C',
	addClass : 'shadow'

	});
		
	});
</script>

</head>
<script>
$(".show_full_map").live('click',function(){
	$('#map_canvas').css({'width' : '1348px'});
	$('#near_lft_auction').css({'display':'none'});
	$('.click_fun').removeClass('show_full_map');
	$('.click_fun').addClass('hide_full_map');
	$('.arrow_css').removeClass('nm_mid_arrow');
	$('.arrow_css').addClass('nm_mid_arrow1');
	$('.near_me_mid_right').css({'overflow':'visible'});

});
$(".hide_full_map").live('click',function(){
	$('#map_canvas').css({'width' : '1348px'});
	$('#near_lft_auction').css({'display':'block'});
	$('.click_fun').removeClass('hide_full_map');
	$('.click_fun').addClass('show_full_map');
	$('.arrow_css').addClass('nm_mid_arrow');
	$('.arrow_css').removeClass('nm_mid_arrow1');
	$('.near_me_mid_right').css({'overflow':'hidden'});
location.reload();
});
</script>  

<script type="text/javascript">
    function getval(sel) {
      var value= sel.value;


window.location = "<?php echo PATH; ?>nearmap.html?type="+value;

    }
</script>
<div class="header_outer">
    <div class="header_top_inner">
        <div class="header">
                  <div class="bread_crumb">
                       
                    </div>

                </div>
            </div>
        </div>
        <!--end-->


<?php if(count($this->deals_list) > 0){ ?>
        <div class="contianer_outer1">
            <div class="full_container_wrap">
                <div class="nm_mid">
                    <div class="near_me_map">
                        <div class="near_me_mid">
                            <div class="near_me_mid_left1" id="near_lft_auction">
								<div class="text_right_map">
									<select onchange="getval(this);" name="sort">
											
									<?php if($this->deal_setting) { ?>
										<option value="1" <?php if($this->type==1){ echo "selected";} ?> >Deals</option>
<?php } ?>

										<?php if($this->product_setting) { ?>
										<option value="2" <?php if($this->type==2){ echo "selected";} ?>>Products</option>
		<?php } ?>

				<?php if($this->auction_setting) { ?>
										<option value="3" <?php if($this->type==3){ echo "selected";} ?>>Auction</option> <?php } ?>
									</select>
								</div>
								<div class="near_me_mid_left" >
									<?php foreach($this->deals_list as $deals){ ?>
										<?php if (($this->type==1)||($this->type=='')) { ?>
											<?php $dealUrl = PATH."deals/".$deals->deal_key."/".$deals->url_title.".html"; 
											if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1'.'.png')){ 

												$imgpath = PATH.'images/deals/220_160/'.$deals->deal_key.'_1'.'.png'; }
											else{
													$imgpath = PATH.'themes/'.THEME_NAME.'/images/noimage_deals_list.png';
											} ?>

										<?php } else if($this->type==2){?> 

											<?php 
											 $dealUrl = PATH."product/".$deals->deal_key."/".$deals->url_title.".html";
											if(file_exists(DOCROOT.'images/products/290_215/'.$deals->deal_key.'_1'.'.png')){ 

												$imgpath = PATH.'images/products/290_215/'.$deals->deal_key.'_1'.'.png'; }
											else{
													$imgpath = PATH.'themes/'.THEME_NAME.'/images/noimage_deals_list.png';
											} ?>
										<?php  } else {?>
											<?php 
												 $dealUrl = PATH."auction/".$deals->deal_key."/".$deals->url_title.".html";
											if(file_exists(DOCROOT.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png')){ 
												$imgpath = PATH.'images/auction/220_160/'.$deals->deal_key.'_1'.'.png'; }

											else{
													$imgpath = PATH.'themes/'.THEME_NAME.'/images/noimage_deals_list.png';
											} ?>
											<?php 
											$dealUrl = PATH."auction/".$deals->deal_key."/".$deals->url_title.".html";
											if(file_exists(DOCROOT.'images/category/icon/'.$deals->category_url.'.png')){ 

												$category_img = PATH.'images/category/icon/'.$deals->category_url.'.png'; }
											else{
													$category_img = PATH.'images/cate_icon.png';
											} ?>
											

										<?php }?>
									<?php if (($this->type==1)||($this->type==2)||($this->type=='')) { ?>
									<div class="pro_listing_map">
										<div class="det_img1_1">
											<a href="<?php echo $dealUrl;?>" title="<?php echo $deals->deal_title; ?>">
												<img src="<?php echo $imgpath; ?>" width="100" height="128" alt="<?php echo $this->Lang['DEAL_IMG']; ?>"/>
											</a>
										</div>
										<div class="deal_list_detail_map">
											<h2><?php echo $deals->category_name; ?></h2>
											<h3><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><?php echo $deals->deal_title; ?></a></h3>
											<?php if(($this->type==1) ||($this->type==2) ||($this->type=='') ){ ?>
											<p><span class="price">Price :</span> <span class="usd"><?php echo CURRENCY_SYMBOL.$deals->deal_value; ?></span></p>	<p><span class="price">Store name :</span> <span class="usd"><?php echo $deals->store_name; ?></span></p>
											<?php } ?>
										</div>
									</div>  
									<?php } else { ?>
									<div class="auction_list_map1">
                                        <div class="action_img5">
                                           
                                            <div class="act_img_mid3">
                                               
                                               	<a href="<?php echo $dealUrl;?>" title="<?php echo $deals->deal_title; ?>">
													<img src="<?php echo $imgpath; ?>"alt="<?php echo $this->Lang['DEAL_IMG']; ?>"width="100" height="128"/>
												</a>
                                            </div>
                                          
                                        </div>
                                        <?php if($this->type==3) { ?>
                                        <div class="action_rgt_map5">
                                            <h3><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="<?php echo $deals->deal_title; ?>"><?php echo $deals->deal_title; ?></a></h3>
												<?php $q=0; foreach($this->all_payment_list as $payment){ ?>
												<?php if($payment->auction_id==$deals->deal_id){ 

														$firstname = $payment->firstname;
														$transaction_time = $payment->transaction_date;
														$q=1;
													}     } ?>
											 <?php if($q==1){ ?>
                                            <div class="bid_cont">
                                                <div class="bid_value_map">
                                                    <label>Last Bidder </label>
                                                    <b>:</b>
                                                    <p><?php echo ucfirst($firstname); ?></p>
                                                </div>
                                            </div>
                                            <div class="bid_cont">
                                                <div class="bid_value_map2">
                                                    <label>Bid Time </label>
                                                    <b>:</b>
                                                    <p> <?php echo date("d-m-Y",$transaction_time); ?> <span></span></p>
                                                </div>
                                            </div>
                                            <div class="bid_cont">
                                                <div class="bid_value_map">
                                                    <label>Time Left </label>
                                                    <b>:</b>
                                                    <p> <span time="<?php echo $deals->enddate; ?>"  class="kkcount-down" ></span></p>
                                                </div>
                                            </div>
											<?php } ?>
                                                                         <?php if($q==0){ ?>	
                                        <div class="bid_cont">
                                            <div class="bid_value_map">
                                                <label>Last Bidder </label>
                                                <b>:</b>
                                                    <p> Not yet bid</p>
                                                </div>
                                            </div>
                                            <div class="bid_value_map2">
                                                    <label>Close Time </label>
                                                    <b>:</b>
                                                    <p> <?php echo date("d-m-Y",$deals->enddate); ?> <span></span></p>
                                            </div>
                                            <div class="bid_cont">
                                                <div class="bid_value_map">
                                                    <label>Time Left </label>
                                                    <b>:</b>
                                                    <p><span time="<?php echo $deals->enddate; ?>"  class="kkcount-down" ></span> </p>
                                                </div>
                                            </div>
                                        <?php } ?>
                                       <div class="bid_cont">
                                                <div class="bid_value_map">
                                                    <label>Store name </label>
                                                    <b>:</b>
                                                    <p><span><?php echo $deals->store_name; ?></span> </p>
                                                </div>
                                            </div>
                                        </div>
           
                                        
                                        <?php } ?>
                                    </div>  
								<?php }  ?>
								
							<?php } ?>
								</div>
                            </div>
							<div class="near_me_mid_arrow">
                                <div class="arrow_css nm_mid_arrow">
                                    <a class="click_fun show_full_map" style="cursor:pointer;" href="javascript:void(0)" onclick ="reSize()">&nbsp;</a>
                                </div>
                            </div>
                            
                             <div class="near_me_mid_right">
								<?php echo new View('themes/'.THEME_NAME.'/deals/map'); ?>

                    
                               
                            </div>
                        </div>
                    </div>
                </div>
			</div>
        </div>

<?php }else{ ?>
<?php echo new View("themes/".THEME_NAME."/subscribe"); ?>
<?php } ?>
