<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php if (count($this->all_deals_list) > 0) { ?>
    <head>
        <script type="text/javascript">
            $(document).ready(function(){
                //$.noConflict();
                $("body").kkCountDown({
                    colorText:'#CC0000',
                    addClass : 'shadow'
                });
            });

        </script>
<script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jquery.jcarousel.min.js "></script> 
		 <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel3').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>

    </head>
    <ul <?php if (count($this->all_deals_list) > 4) { ?> id="mycarousel3" class="jcarousel-skin-tango3" <?php } else { ?> <?php } ?>>
        <?php
        foreach ($this->all_deals_list as $deals) {
            $symbol = CURRENCY_SYMBOL;
            ?>

            <li>

                <div class="feture_deal_listing">
                    <div class="feture_top"></div>
                    <div class="feture_mid">
                        <div class="fetur_img">
							<?php if($this->session->get('cate')!="") { ?> <?php $url=$this->session->get('cate'); ?> <?php } else { ?> <?php $url=$deals->category_url; ?>  <?php } ?>
                    <?php if (file_exists(DOCROOT . 'images/category/icon/' . $url. '.png')) { ?>
                    
                                <span class="cat_icon"><img alt="category icon" src="<?php echo PATH . 'images/category/icon/' . $url. '.png'; ?>"title="<?php echo $url; ?>"></span>
                            <?php } else { ?>
                                <span class="cat_icon"><img alt="category icon" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png" title="no-image"/></span>
                            <?php } ?>

                            <?php if (file_exists(DOCROOT . 'images/deals/220_160/' . $deals->deal_key . '_1' . '.png')) { ?>
                                <a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH . 'images/deals/220_160/' . $deals->deal_key . '_1' . '.png'; ?>"  alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>
        <?php } else { ?>
                                <a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png"  alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>

        <?php } ?>  
                            <div class="img_bought_det">
                                <p><?php echo round($deals->deal_percentage); ?>% Discount</p><span>Save <?php echo $symbol . " " . $deals->deal_savings; ?></span>
                            </div>
                        </div>
                        <div class="feture_bot_det">
                            <p><a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo $deals->deal_title; ?>"><?php echo substr(ucfirst($deals->deal_title), 0, 30) . "..."; ?></a></p>
                            <div class="time_price">
                                <div class="time_price_lft">
                                    <label> <span></span><span time="<?php echo $deals->enddate; ?>" class="kkcount-down" ></span></span></label>
                                    <p><?php echo $symbol . " " . $deals->deal_value; ?></p>
                                </div>
                                <div class="view_del">
                                    <div class="view_deal_lft">
                                        <div class="view_deal_rgt">
                                            <div class="view_deal_mid">
                                                <a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo 'VIEW DETAILS'; ?>">VIEW DETAILS</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="feture_bot"></div>
                </div> 
            </li>


    <?php }
} ?>


</ul>
