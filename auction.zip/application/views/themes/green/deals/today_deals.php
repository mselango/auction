<script type="text/javascript" src="<?php echo PATH; ?>js/timer/kk_countdown_1_2_jquery_min.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            //$.noConflict();
            $("body").kkCountDown({
                colorText:'#7b7b7b',
                addClass : 'shadow'
            });
        });
    </script>   
    <script type="text/javascript">
        $(document).ready(function () {
            $('a.cart_button').live("click", function(e){
                var offset  = 0;
                offset = document.getElementById('offset').value;
                var record = document.getElementById('record').value;
                var record1 = document.getElementById('record1').value;
    	    
                var url = '<?php echo PATH; ?>'+'deals/today_deals_1?offset='+offset+'&record='+record;
                $.post(url,function(check){ 

                    if(check){ 
    				  
                        $('#deal').append(check);
                        $('#loading').show();
                        offset = parseInt(offset)+9;

                        $("#offset").val(offset);

                        if(offset >= record1 ) {

                            $('#loading').hide();

                        }

                    }
                });     
            
            });
        });

    </script>
    </div>
    </div>
    </div>
    <div class="contianer_outer">

        <div class="contianer_inner">
            <div class="bread_crumb">
                <ul>
                    <li><p><a href="<?php echo PATH; ?>" title="Home">Home</a></p></li>
                    <li><p>
						<?php if (($this->uri->last_segment() != "today-deals.html") && ($this->uri->last_segment() != "search.html")) { ?>
						<a href="<?php echo PATH; ?>today-deals.html" title="<?php echo "Deal Listing"; ?>"><?php echo "DEAL LISTING"; ?></a></p>
					<?php } else {
							echo "DEAL LISTING";
					} ?>
                    </li>
                    <?php if (($this->uri->last_segment() != "today-deals.html") && ($this->uri->segment(2) != "page")) { ?>

						<li class="bread_crum_about">
														
							<?php if(isset($this->sub_cat)) { ?>
								<p><a href="<?php echo PATH; ?>deal/category/main/<?php echo strtolower($this->category_name); ?>.html"><?php echo $this->category_name; ?></a>&nbsp;&nbsp;&nbsp;<?php echo $this->sub_cat; ?></p>
							<?php } else { ?>
								<p>  <?php echo $this->category_name; ?></p>
							<?php } ?>
						</li>
					<?php } ?>
                </ul>
            </div>
    <?php if (count($this->all_deals_list) > 0) { ?>
            <div class="contianer">

                <!--content start-->
                <div class="content">
                   
                        <!--sidebar start-->
                        <div class="conntent_left">
                            <div class="cat_outer1">
                                <div class="category2">
                                    <form action="" method="get" name="form1"  >
                                    <h1>Categories</h1>
                                    <ul>
                                        <?php $cat = explode(",", substr($this->session->get('categoryID'), 0, -1));
                                        $cat1 = array_unique($cat);
                                        ?>

    <?php foreach ($this->category_list as $d) {
        if ($d->deal == 1) { ?>
                                                <li>
                        <?php $type="deal"; $categories=$d->category_url; ?>

<a style="cursor:pointer;" class="sample" id="sample-<?php echo $d->category_id; ?>"  onclick="filtercategory('<?php echo $categories; ?>','<?php echo $type; ?>','main');"  title="<?php echo ucfirst($d->category_name); ?>">
		<?php echo ucfirst($d->category_name); ?>
	</a>
                                            <div class="sub_menu_top1">	
                                                <span class="white">&nbsp; </span>
                                                <ul>
                                                    <a style="cursor:pointer;">


                                            <div id="categeory-<?php echo $d->category_id; ?>">
            <?php echo new View("themes/" . THEME_NAME . "/deals/subcategory_list"); ?>
                                                </div></a>
                                       
                                                </ul>
                                            </div>
                                                </li>



                                                
        <?php }
    } ?>

                                    </ul>
                                    </form>
                                </div>
                                <input type="submit" value="submit" id="submit" style="display:none;">
                                </form>
                            </div>

                            <script type="text/javascript">
                                $(function() {
    		
                                    $('.sample').mouseover(function() {
                                        var getUID =  $(this).attr('id').replace('sample-','');
                                        var url = Path+"deals/today_deals/?cate_id="+getUID;

    	
                                        $.post(url,function(check){

    			
                                            if(getUID!=""){
                                                $('#categeory-'+getUID).html(check);
    		
                                                $('#categeory-'+getUID).show();
                                 
    		
                                            }
    			
                                        });

                                    });


                                });  
      

                            </script>


                            <div class="cat_outer2" id="s1000">
                                <div class="category" id="f200" style="padding-bottom:10px;">	
                                    <h1>Price</h1>

                                    <div class="catogory_content2 fl clr" id="f300">
                                        <p style="padding-top:4px;font:normal 12px arial; color: 656565;" class="p1">Price bracket</p>

                                        <div id="slider-range"></div></br>

                                        <input type="text" style="float:left;  height:25px;font:normal 12px/25px arial;color:#787878; border:none; background: #fff; text-align: center; border:1px solid #d4d4d4; margin-left: 23px; margin-top:6px;" id="amount"  readonly="readonly" name="amount"/>
                                    </div>
                                    


                                </div>

                            </div>



                        </div>
                        <!--end-->
                        <div class="content_right">


                            <!-- product list-->


                            <!--feture deal-->


                            <!--action deal list-->
                            <div class="product_details_list">
                                <div class="pro_top">
                                    <div class="pro_title"><h2> DEALS </h2></div>

                                </div>

                                <div class="pro_mid">
                                    <div id="deal">

    <?php echo new View("themes/" . THEME_NAME . "/deals/today_deals_list"); ?>

                                    </div>
                                </div>



    <?php if (($this->uri->last_segment() == "today-deals.html") && ($this->all_deals_count > 1)) { ?>

                                    <div id="loading">
        <?php if (($this->pagination) != "") { ?> 
                                            <div class="feature_viewmore">
                                                <div class="fea_view_more">
                                                    <div class="view_more_inne">
                                                        <div class="viewmore_lft"></div>
                                                        <div class="viewmore_midd">
                                                            <a  style="cursor:pointer;" class="cart_button" title="-------See More Deals-------">-------See More Deals-------</a>
                                                        </div>
                                                        <div class="viewmore_rgt"></div>
                                                    </div>
                                                </div>
                                            </div>
        <?php } ?>
                                    </div>

    <?php } ?>




                            </div>
                        </div>


                </div>
            </div>
            <!--end-->
            	<?php } else { ?>
		<?php echo new View("themes/" . THEME_NAME . "/subscribe"); ?>
	<?php } ?>

        </div>
        
    </div>
    </div>
    <!--scroll filter start-->
    <input type="hidden" name="offset" id="offset" value="9">
    <input type="hidden" name="record" id="record" value="9">
    <input type="hidden" name="record" id="record1" value="<?php echo $this->all_deals_count; ?>">
    <script type="text/javascript">
        $(function() {
    		
            $('.sample').click(function() {
                var getUID =  $(this).attr('id').replace('sample-','');
                var url = Path+"deals/today_deals/?cate_id="+getUID;
   	
                $.post(url,function(check){
   			
                    if(getUID!=""){
                        $('#categeory-'+getUID).html(check);
    		
                    }
    			
                });

            });

        });  
    </script>



<!--price and discount script-->

<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<script>
		
    $(function() {
        $( "#slider-range" ).slider({

            range: true,
            min: <?php echo $this->deal_min; ?>,
            max: <?php echo $this->deal_max; ?>,
            values: [ <?php echo $this->deal_min; ?>,<?php echo $this->deal_max; ?>  ],
            slide: function( event, ui ) {
                         $( "#amount" ).val("<?php echo CURRENCY_SYMBOL; ?>"+ui.values[ 0 ] + " - " +"<?php echo CURRENCY_SYMBOL; ?>"+ ui.values[ 1 ] );
					
                var amount = $("#amount").val();


                var url = Path+"deals/ajax_post_deals/?amount="+amount;
                $.post(url,function(check){

                    $('#deal').html(check);
					$('div#loading').hide();
                });
					
            },
				
        });
			
        $( "#amount" ).val("<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 0 ) +
            " - " +"<?php echo CURRENCY_SYMBOL; ?>" + $( "#slider-range" ).slider( "values", 1 ) );
    });
		
		
    $(function() {
        $( "#slider-range1" ).slider({
            range: true,
            min: <?php echo $this->min_per; ?>,
            max: <?php echo $this->max_per; ?>,
            values: [ <?php echo $this->min_per; ?>,<?php echo $this->max_per; ?>  ],
            slide: function( event, ui ) {
                $( "#discount" ).val( ui.values[ 0 ] +"%"+ " - " + ui.values[ 1 ]+"%" );
                var discount = $("#discount").val();

                var url = Path+"deals/ajax_post_deals/?&discount="+discount;
                $.post(url,function(check){

                    $('#deal').html(check);
                });
					
            },
				
        });
        $( "#discount" ).val(  + $( "#slider-range1" ).slider( "values", 0 )+'%' +
            " - " + $( "#slider-range1" ).slider( "values", 1 ) +'%');
    });

</script>		 
<!--price filter end--> 

<!--scroll filter end-->


