<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/zoom.css" media="all">
<script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jquery-1.5.js"></script> 
<script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/easySlider1.7.js"></script>
    <script src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/zoom.js" type="text/javascript"></script> 

<script type="text/javascript"> 
    var aliceImageHost = 'http://ndot.in';
    var globalConfig = {};     
</script>


<script type="text/javascript" src="<?php echo PATH; ?>js/timer/kk_countdown_1_2_jquery_min.js"></script>

<div class="contianer_outer1">
    <div class="contianer_inner">
        <div class="contianer">

            <div class="bread_crumb">
                <ul>
                    <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>


                    <li>
                        <p><a href="<?php echo PATH; ?>today-deals.html" title="<?php echo $this->Lang['DEALS1']; ?>"><?php echo $this->Lang['DEALS1']; ?></a></p>

                    </li>
                    <?php foreach ($this->deals_deatils as $deals) {
                        $symbol = CURRENCY_SYMBOL;
                        ?> 
                        <li class="act"><p><?php echo ucfirst($deals->deal_title); ?></p></li>
<?php } ?>
                </ul>

            </div>





    <?php foreach ($this->deals_deatils as $deals) {
        $symbol = CURRENCY_SYMBOL;
        ?>
                    <!--content start-->

                    <!--content start-->
                    <div class="product_detail_top">
                        <div class="all_del_detail">
                            <div class="all_deal_top">


                                <div class="all_deal_top_left">
                                    <div id="prdMedia" class="prd-media">

                                        <?php /*
                                        $con = 0;
                                        for ($i = 1; $i <= 5; $i++) {
                                            if (file_exists(DOCROOT . 'images/deals/1000_800/' . $deals->deal_key . '_' . $i . '.png')) {
                                                $con = $con + 1;
                                            }
                                        } */
                                        ?>
        <?php if (file_exists(DOCROOT . 'images/deals/1000_700/' . $deals->deal_key . '_1' . '.png')) { ?>
                                            <div id="productZoom" style="background-image: url(&quot;<?php echo PATH . 'images/deals/1000_800/' . $deals->deal_key . '_1.png'; ?>&quot;); background-position: 0px -499.56px; opacity: 1; display: none;background-repeat:no-repeat;height:400px; width:620px;" data-zoom-image="<?php echo PATH . 'images/deals/1000_800/' . $deals->deal_key . '_1.png'; ?>"></div>

                                            <div id="prd-imageBox-container" class="prd-imageBoxLayout ">
                                                <a href="" class="prd-imageBox" id="prdZoomBox">
                                                    <span rel="foaf:depiction">
														 <?php if (($deals->maximum_deals_limit == $deals->purchase_count) || ($deals->maximum_deals_limit < $deals->purchase_count) || ($deals->enddate < time())) { ?>
														<div class="should_out_images">
															&nbsp;
														</div>
														<?php } else { } ?>
                                                        <img class="prd-image" id="prdImage" data-js-function="setPlaceholderOnError" title="<?php echo ucfirst($deals->deal_title); ?>" alt="<?php echo ucfirst($deals->deal_title); ?>" src="<?php echo PATH . 'images/deals/1000_700/' . $deals->deal_key . '_1.png'; ?>" width="355">
                                                    </span>

                                                    <div style="top: 181px; left: 0px; display: none;" id="magnifier"></div>
                                                </a>
                                            </div>
        <?php } else { ?>
                                            <div id="productZoom" style="background-image: url(&quot;<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png&quot;); background-position: 0px -499.56px; opacity: 1; display: none;background-repeat:no-repeat;height:400px; width:355px;" data-zoom-image="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png"></div>

                                            <div id="prd-imageBox-container" class="prd-imageBoxLayout ">
                                                <a href="" class="prd-imageBox" id="prdZoomBox">
                                                    <span rel="foaf:depiction">
														<?php if(($deals->maximum_deals_limit==$deals->purchase_count)||($deals->maximum_deals_limit < $deals->purchase_count)||($deals->enddate < time())) { ?>
														<div class="should_out_images">
															&nbsp;
														</div>
														<?php } else { } ?>
                                                        <img class="prd-image" id="prdImage" data-js-function="setPlaceholderOnError" title="<?php echo ucfirst($deals->deal_title); ?>" alt="<?php echo ucfirst($deals->deal_title); ?>" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_details.png" height="380" width="355">
                                                    </span>

                                                    <div style="top: 181px; left: 0px; display: none;" id="magnifier"></div>
                                                </a>
                                            </div>

        <?php } ?>

                                        <h2 class="s-visuallyhidden">More Images</h2>
                                        <div class="prd-more-images-slider-container">
                                            
                                            <div class="prd-more-images-slider lfloat">
                                                <ul id="productMoreImagesList" class="prd-moreImagesList ui-listItemBorder ui-listLight clearfix">
        
            <?php for ($i = 1; $i <= 5; $i++) { ?>
            <?php if (file_exists(DOCROOT . 'images/deals/1000_700/' . $deals->deal_key . '_'.$i.'.png')) { ?>
                                                            <li class="lfloat ui-border selected"
                                                                data-js-function="setImage"
                                                                data-image-product="<?php echo PATH . 'images/deals/1000_700/' . $deals->deal_key . '_' . $i . '.png'; ?>"
                                                                data-image-big="<?php echo PATH . 'images/deals/1000_800/' . $deals->deal_key . '_' . $i . '.png'; ?>">
                                                                <img data-js-function="setPlaceholderOnError"
                                                                     data-placeholder="<?php echo PATH . 'images/deals/1000_800/' . $deals->deal_key . '_' . $i . '.png'; ?>"
                                                                     id="gal<?php echo $i; ?>"
                                                                     width="37"
                                                                     height="54"
                                                                     src="<?php echo PATH . 'images/deals/1000_800/' . $deals->deal_key . '_' . $i . '.png'; ?>"
                                                                     alt="zoom" />
                                                            </li>
            <?php } else { } ?>
        <?php }
        ?>






                                                </ul>
                                            </div>
                                            
                                            
                                        </div>

                                    </div>
 
                                </div>
                               
                            </div>

                            <div class="ad_deal_right">
                                <p><?php echo ucfirst($deals->deal_title); ?></p>
                                <div class="ad_rgt_top">
                                    <div class="add_top_left">
                                        <p><?php echo $symbol . " " . $deals->deal_price; ?></p>
<?php $country = COUNTRY_CODE; ?>
                                        <span><?php echo $symbol . " " . $deals->deal_value . " " .$country; ?> </span>
                                    </div>

							
								  
                                    <div class="add_top_right">
                                        <div class="today_rgt_bought">
											<?php if(($deals->maximum_deals_limit==$deals->purchase_count)||($deals->maximum_deals_limit < $deals->purchase_count)||($deals->enddate < time())) { ?>
											<?php } else { ?>
											  <?php if(($deals->purchase_count) < ($deals->minimum_deals_limit)){ ?>
											  
											<?php $total = ($deals->purchase_count * 100) / $deals->minimum_deals_limit; ?>
                                            <h3><?php echo $deals->purchase_count; ?> Bought</h3>
                                            <div class="probar_1"><div class="range_button_1" style="margin-left:<?php echo $total; ?>%"></div></div>
                                            <p><span class="range_left">0</span><span class="range_right"><?php echo $deals->minimum_deals_limit; ?></span></p>
                                             <?php } else {?>
                                            
												<h2 class="mt20"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/success_tick.png" alt="" title=""> <?php echo $this->Lang['THE_DEAL_IS']; ?></br><b><?php echo $deals->purchase_count; ?> <?php echo $this->Lang['BOUGHT']; ?></b></h2>
											
												<?php } ?>   
											<?php } ?>
                                        </div>   

                                    </div>
                                    
                              
                                </div>

                                <div class="ad_rgt_middle">
                                    <div class="add_midd_lft">
                                        <div class="price_common">
                                            <p>Value</p>
                                            <span><?php echo $symbol . " " . $deals->deal_price; ?></span>
                                        </div>
                                        <div class="price_common_1">
                                            <p>Discount</p>
                                            <span><?php echo round($deals->deal_percentage); ?>%</span>
                                        </div>
                                        <div class="price_common_2">
                                            <p>You Save</p>
                                            <span><?php echo $symbol . " " . $deals->deal_savings; ?></span>
                                        </div>
                                    </div>
                                    <div class="add_midd_rgt">
                                        <p>Time left</p>
                                        <span time="<?php echo $deals->enddate; ?>" class="kkcount-down" ></span>
                                    </div>
                                </div>
                                <div class="ad_rgt_bott">
                                    
                                    <div class="basic<?php echo $deals->deal_id; ?>" id="<?php echo $this->avg_rating; ?>"><p style="font:normal 14px arial; color:#333;">Rating</p></div>
                              
                                    <div class="ad_bot_lft">
                                        <link href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/css/jRating.jquery.css" rel="stylesheet" type="text/css"/>
                                        <script type="text/javascript" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/js/jRating.jquery.js"></script>
                                        <script type="text/javascript">
                                            $(document).ready(function(){
                                                $(".basic<?php echo $deals->deal_id; ?>").jRating({ 
                                                    bigStarsPath : '<?php echo PATH; ?>/images/stars_detail.png', // path of the icon stars.png
                                                    smallStarsPath : '<?php echo PATH; ?>/images/small.png', // path of the icon small.png
                                                    phpPath : '<?php echo PATH; ?>deal-rating.html', // path of the php file jRating.php
                                                    length:5,
                                                    rateMax : 10,
                                                    decimalLength:1,
                                                    showRateInfo: false,
        <?php if ((!$this->UserID) || ($deals->enddate < time())) { ?>	
                        isDisabled : true			
        <?php } ?>
                });
            });
                                        </script>
                                        

                                        <div class="today_list_left">



                                            <ul>
                                                <li><p><?php echo $this->Lang['SHARE']; ?>:</p></li>
                                                <li>
                                                    <iframe src="http://www.facebook.com/plugins/like.php?href=<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?> &amp;layout=button_count&amp;show_faces=true&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden;  height:21px; width:105px;" allowTransparency="true"></iframe>
                                                </li>
                                                <li>
                                                    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
                                                    <a href="http://twitter.com/share" class="twitter-share-button" data-url="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" data-count="horizontal"><?php echo $this->Lang['Tweet']; ?></a></li>
                                                <li>
                                                    <script type="text/javascript" src="https://apis.google.com/js/plusone.js">
                                                        {parsetags: 'explicit'}
                                                    </script>
                                                    <!-- Place this tag where you want the +1 button to render -->
                                                    <div class="g-plusone" data-size="medium" data-href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>"></div>
                                                    <!-- Place this render call where appropriate -->
                                                    <script type="text/javascript">gapi.plusone.go();</script>
                                                </li>

                                            </ul>

                                        </div>
                                    </div>
                                    <div class="ad_bot_rft">
                                        <div class="ora_left_1">
                                            <div class="ora_right_1">
                                                <div class="ora_mid2_5">
                                                    <?php if (($deals->maximum_deals_limit == $deals->purchase_count) || ($deals->maximum_deals_limit < $deals->purchase_count) || ($deals->enddate < time())) { ?>
                                                        <a class="buy_now" ><input type="submit" value="SOLD OUT" title="SOLD OUT" style="cursor:default"/></a>
        <?php } else { ?>
                                                        <a href="<?php echo PATH . 'deals/p/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo $this->Lang['SHOP_NW']; ?>"><input type="submit" value="BUY NOW " title="BUY NOW" /></a> 
        <?php } ?>

                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="ad_content2 deal_ad_content2">
						<?php if(strip_tags($deals->highlights) != "") { ?>
                        <div class="ad_content2_left branch_detail1 pro_top">
                            <h2>HIGHLIGHTS</h2>
                            <ul>
        <?php echo $deals->highlights; ?>
                            </ul>
                        </div>
                        <?php } ?>
                        <?php if(strip_tags($deals->fineprints) != "") { ?>
                        <div class="ad_content2_left_1 branch_detail1 pro_top">
                            <h2>FINE PRINTS</h2>
                            <ul>
									<?php echo $deals->fineprints; ?>
                            </ul>
                        </div>
                        <?php } ?>
                    </div>





                    <div class="all_deals_bottom">


                        <div class="top_tab">
                            <ul>
                                <li><a href="#" title="deal Details">Deal Details</a></li>
                            </ul>

                        </div>
                        <div class="bot_mid_det">
                            <h2><?php echo ucfirst($deals->deal_title); ?></h2>
                            <p>  <?php echo $deals->deal_description; ?>  </p>

                        </div>
                    </div>


                    <div class="branch_detail branch_detail1 pro_top">
                        <h2>FEATURED DEALS</h2>



                        <div class="content_store_list">
                            <div class="slider_wrap">

        <?php echo new View("themes/" . THEME_NAME . "/deals/deals_list"); ?>


                            </div>
                        </div>


                    </div>

                    <div class="some_of_otheritems">

                        <div class="pro_top">


                        </div>

                        <div class="addres_common">
                            <div class="addres_left_cont">
                               

                                <div class="map_page3">
                                     <div class="pro_title3 branch_detail1 pro_top">
                                    <h2>address</h2>
                                </div>
                                    <div class="map_page">
                                        <div id="map_main" style="width:447px; height:310px;"></div>
                                        <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
                                        <script type="text/javascript">
                                            var latlng = new google.maps.LatLng(<?php echo $deals->latitude; ?>,<?php echo $deals->longitude; ?>);
                                            var myOptions = {
                                                zoom: 12,
                                                center: latlng,
                                                mapTypeId: google.maps.MapTypeId.ROADMAP,
                                                navigationControl: true,
                                                mapTypeControl: true,
                                                scaleControl: true
                                            };

                                            var map = new google.maps.Map(document.getElementById("map_main"), myOptions);
                                            var marker = new google.maps.Marker({
                                                position: latlng,
                                                animation: google.maps.Animation.BOUNCE
                                            });
                            
                                            var infowindow = new google.maps.InfoWindow({
                                                content: '<b><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $deals->store_name); ?></b><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $deals->addr1); ?><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $deals->addr2); ?></p><p><?php echo $deals->city_name; ?>,<?php echo $deals->country_name; ?></p>'
                                            });

                                            google.maps.event.addListener(marker, 'click', function() { 
                                                infowindow.open(map, marker);
                                            });
                                           
                                            marker.setMap(map);
                            
                                        </script>


                                    </div>
                                    <div class="common_all">

                                        <div class="addres_left_right">
                                            <h3><?php echo $deals->store_name; ?></h3>
                                            <p><?php echo $deals->addr1; ?>,</p>
                                            <p><?php echo $deals->addr2; ?>,</p>
                                            <p><?php echo $deals->city_name; ?></p>
                                            <p><?php echo $deals->country_name; ?></p>
                                            <p><?php echo $this->Lang['MOBILE']; ?>: <?php echo $deals->phone; ?></p>
                                            <p><?php echo $this->Lang['WEBSITE']; ?>:<a href="<?php echo $deals->website; ?>" target="blank" class="color007BD9"> <?php echo $deals->website; ?></a>  </p>

                                        </div>


                                    </div>
                                </div>
                                <div class="cotent_face_right">
                                    <div class="pro_title3 branch_detail1 pro_top">
                                        <h2>Comments</h2>
                                        <div class="face_commont">
                                            <div class="face_comm_top">
                                                <div class="face_top_left">
        <?php if (($this->session->get("UserID")) && file_exists(DOCROOT . 'images/user/150_115/' . $this->session->get("UserID") . '.png')) { ?> <img src="<?php echo PATH . 'images/user/150_115/' . $this->session->get("UserID") . '.png'; ?>"  alt="side_vdeio"  style="width:50px; height:50px;" />
        <?php } else { ?>
                                                        <img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/comm_user.png"  alt="side_vdeio" border="0"  style="width:50px; height:50px;" />
                                                        <?php } ?>
                                                </div>
                                                <form method="post" >

                                                    <div class="face_top_textarea">
        <?php
        $Url = "home";
        if ($this->uri->segment(1) == "deals") {
            $Url = "deals";
        }
        ?>
                                                        <input type="hidden" name="deal_key" value="<?php echo $deals->deal_key; ?>" />
                                                        <input type="hidden" name="deal_id" id="deal_id"  value="<?php echo $deals->deal_id; ?>" />
                                                        <input type="hidden" name="url_title" value="<?php echo $deals->url_title; ?>" />
                                                        <input type="hidden" name="last_url" value="<?php echo $Url; ?>" />
                                                        <input type="hidden" name="type" id="type" value="1" />
                                                        <input type="hidden" name="user" id="user_id" value="<?php echo $this->session->get('UserID'); ?>" />
                                                        <textarea name ="comments" id="comment_box" cols="10" rows="10" placeholder="Add a comment..." class="comment_box" ></textarea>
                                                        <em id="error"></em>

                                                    </div>
                                                    <div class="post_button">

                                                        <div class="button1">
                                                            <div class="gren_left_3">
                                                                <div class="gren_right_3">
                                                                    <div class="gren_mid_3" ><input type="button" title="POST" value="POST" onclick="check_comment();" /></div> 
                                                                </div>
                                                            </div>		


                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div id="show"> <?php echo new View("themes/" . THEME_NAME . "/deals/comment"); ?> </div>



                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>






                    </div>

    <?php } ?>



                <!--end-->

            </div>
        </div>
    </div>


    <script type="text/javascript">
        $(document).ready(function(){
            //$.noConflict();
            $("body").kkCountDown({
                colorText:'#666',
                addClass : 'shadow'
            });
        });
    </script>


   
<script type="text/javascript"> $(document).ready(function() { 
    Rocket.SizeChart.rows = [{"CHEST (INCH)":"38","SHOULDER(INCH)":"16","LENGTH(INCH)":"27"},{"CHEST (INCH)":"40","SHOULDER(INCH)":"17","LENGTH(INCH)":"28"},{"CHEST (INCH)":"42.5","SHOULDER(INCH)":"18","LENGTH(INCH)":"29"},{"CHEST (INCH)":"45","SHOULDER(INCH)":"19","LENGTH(INCH)":"30"},{"CHEST (INCH)":"47","SHOULDER(INCH)":"19","LENGTH(INCH)":"31"},{"CHEST (INCH)":"49","SHOULDER(INCH)":"20","LENGTH(INCH)":"32"}];
    Rocket.SizeChart.columns = ["CHEST (INCH)","SHOULDER(INCH)","LENGTH(INCH)"];
    Rocket.SizeChart.conversionHoverActive = false;

    Rocket.SizeChart.preparePopup(false);

    // stop highlight animation if user overs list item
    $('#listProductSizes > li').bind('mouseover', function() {
        $(this).stop(false, true);
    });
    $(document).bind("Quicklist.productRemoved", function (e, sku) {
        //We are on the detail page of the product we just removed from quicklist
        //Enable the add to quicklist link
        if ($('#configSku').val() == sku) {
            $('#qlPrdAdded').hide();
            $('#qlPrdAdd').show();
        }
    });$('.tool-tip').hover(function() {
        var tipId = $(this).attr('label');
        var pos = $(this).position();
        $('#' + tipId).css({'top':(pos.top + 10), 'left': (pos.left + 10)});
        $('#' + tipId + ' span').css('background-color', '#fff' );
        $("#" + tipId).fadeIn(200);
    }, function() {
        var tipId = $(this).attr('label');
        $("#" + tipId).fadeOut(200);
    });

    globalConfig.product = globalConfig.product || {};
    globalConfig.product.rDetails = {"sku":"UN573MA91PPSINDFAS","chain":"3270|3328|3329|3330","brand":"United Colors of Benetton","brandId":"573","price":799,"sessionId":"qonohdq1sn843pl0afp0biklg3","userId":"","catId":"3270","cat":"Clothing","brickId":"3330","brick":"Crew Neck T-Shirts"};

    Jabong.image.initSetImage();
    $( '#prdZoomImgPrev' ).live( 'click', function() { Jabong.image.imgNavigate( 'prev' ) } );
    $( '#prdZoomImgNext' ).live( 'click', function() { Jabong.image.imgNavigate( 'next' ) } );

    if(window.location.hash == "#productReviews") {
        $("#productReviewsTab").trigger('click');
    }

    $('#recommSliderSolr').bxSlider({
        mode: 'vertical',
        auto: false,
        displaySlideQty: 3,
        moveSlideQty: 1,
        speed: 250
    });

    Rocket.QuickList.loadList([], []);
});</script>

<script type="text/javascript">$('.prd-more-images-slider').jCarouselLite({
btnNext: ".next",
btnPrev: ".prev",
circular: false,
            
visible: 5
});        $('#prd-imageBox-container').bind('mouseenter', function() {
$('.prd-zoom-info').hide();
});
$('#prd-imageBox-container').bind('mouseleave', function() {
$('.prd-zoom-info').show();
});
var reviewFieldMsg = "You must fill the empty field(s) highlighted above.";
var reviewSuccessMsg = "Thank you. Your review will start appearing soon.";
var reviewErrorMsg = "There has been an error saving your rating. Please try again.";
//<![CDATA[
jQuery.ajax({
type: "GET",
url: "//ndot.in",
success: function(data){
    new RecommendationView(data, 4);
}
});
//]]></script>  
