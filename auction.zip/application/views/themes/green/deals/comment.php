<?php foreach( $this->comments_deatils as $comments){ $i = 0; $j = 0; $like = 0; $unlike = 0; ?>
               <?php foreach($this->like_details as $c){ if($comments->discussion_id == $c->discussion_id){ $i++; }} ?>
                <?php foreach($this->unlike_details as $c){ if($comments->discussion_id == $c->discussion_id){ $j++; }} ?>
				<?php foreach($this->like_details as $c){
					 if($comments->discussion_id == $c->discussion_id){
					 if($c->user_id == $this->session->get('UserID')){ $like = 1; }} } ?>
				<?php foreach($this->unlike_details as $c){
					 if($comments->discussion_id == $c->discussion_id){
					 if($c->user_id == $this->session->get('UserID')){ $unlike = 1; }}} ?> 
		     <div class="face_comm_midd">
             <div class="face_mid_top">
             <div class="face_top_lft">
             <a href="#" title="profile"><?php  if(file_exists(DOCROOT.'images/user/150_115/'.$comments->user_id.'.png'))  { ?> 
             <img src="<?php echo PATH.'images/user/150_115/'.$comments->user_id.'.png';?>"  alt="side_vdeio" border="0" style="width:30px; height:30px;"  />
             <?php }else{ ?>
             <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/comm_user.png"  alt="side_vdeio" border="0"  style="width:30px; height:30px;" />
             <?php } ?></a>
             </div>
             <div class="face_top_rgt">
             <h3><a href=""><?php echo $comments->firstname; ?> </a><label><?php echo date('m/d/Y H:i:s ', $comments->created_date); ?></label></h3>
             <p> <?php echo $comments->comments; ?>... </p>
             <div class="like_dislike">
             <div class="face_like">
             <div class="flo_off" id="load_like_unlike_<?php echo $comments->discussion_id; ?>">
             <div class="lik_mor" id="like_<?php echo $comments->discussion_id; ?>" <?php if($like == 0){ ?>onclick="return like1('<?php echo $comments->deal_id;?>','<?php echo $this->session->get('UserID'); ?>','<?php echo $comments->discussion_id;?>','<?php echo $comments->type;?>')" <?php } ?>>
			 <a class="like" style="cursor:pointer;"title="like">(<?php echo $i; ?>)</a>
			 </div>
             <div class="lik_mor2" id="unlike_<?php echo $comments->discussion_id; ?>" <?php if($like == 1){ ?>onclick="return unlike1('<?php echo $comments->deal_id;?>','<?php echo $this->session->get('UserID'); ?>','<?php echo $comments->discussion_id;?>','<?php echo $comments->type;?>')" <?php } ?>>
             <a class="dislike"  style="cursor:pointer;" title="unlike">(<?php echo $j; ?>)</a>
             </div>
             </div>
             </div>
             </div>
             </div>			 
			 </div>
             </div>
             
			<?php /**		 
<div class="writ_coom">
<div class="images_over_process"><?php  if(file_exists(DOCROOT.'images/user/150_115/'.$comments->user_id.'.png'))  { ?> <img src="<?php echo PATH.'images/user/150_115/'.$comments->user_id.'.png';?>"  alt="side_vdeio" border="0" style="width:30px; height:30px;"  />
        <?php }else{ ?>
         <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/comm_user.png"  alt="side_vdeio" border="0"  style="width:30px; height:30px;" />
         <?php } ?></div>
<div class="images_over_nat">
<p><span><?php echo $comments->firstname; ?></span> <?php echo $comments->comments; ?>...</p>
<div class="like_over">
<div class="flo_off" id="load_like_unlike_<?php echo $comments->discussion_id; ?>">
<div class="lik_mor" id="like_<?php echo $comments->discussion_id; ?>" <?php if($like == 0){ ?>onclick="return like1('<?php echo $comments->deal_id;?>','<?php echo $this->session->get('UserID'); ?>','<?php echo $comments->discussion_id;?>','<?php echo $comments->type;?>')" <?php } ?>>
          <a style="cursor:pointer;"title="like"><?php echo $i; ?></a></div>
<div class="lik_mor2" id="unlike_<?php echo $comments->discussion_id; ?>" <?php if($like == 1){ ?>onclick="return unlike1('<?php echo $comments->deal_id;?>','<?php echo $this->session->get('UserID'); ?>','<?php echo $comments->discussion_id;?>','<?php echo $comments->type;?>')" <?php } ?>>
          <a title="unlike" style="cursor:pointer;"><?php echo $j; ?></a></div>
</div>
<div class="post_rel"><p>Posted on : <?php echo date('m/d/Y H:i:s', $comments->created_date); ?></p></div>
</div>
</div>
</div>
**/ ?>
<?php } ?>
