<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php if (count($this->all_deals_list) > 0) { ?>
    <head>
        <script type="text/javascript" src="<?php echo PATH; ?>js/timer/kk_countdown_1_2_jquery_min.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                //$.noConflict();
                $("body").kkCountDown({
                    colorText:'#CC0000',
                    addClass : 'shadow'
                });
            });
        </script>
    </head>
    <div class="container_outer">
        <div class="continer_outer_common fl">
            <div class="brad_com_out">
                <div class="brad_com_inn">
                    <div class="brad_com">
                        <ul>
                            <li><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></li>
                            <li>\</li>
                            <li blogclass="act" >
                                <?php if (($this->uri->last_segment() != "all-deals.html") && ($this->uri->last_segment() != "today-deals.html")) { ?>
                                    <a   href="<?php echo PATH; ?>today-deals.html" title="<?php echo $this->Lang['DEALS']; ?>"><?php echo $this->Lang['DEALS1']; ?></a>
                                <?php } else {
                                    echo $this->template->title;
                                } ?>
                            </li>
                            <?php if (($this->uri->last_segment() != "all-deals.html") && ($this->uri->last_segment() != "today-deals.html") && ($this->uri->segment(2) != "page")) { ?>
                                <li >\</li>
                                <li class="act"><?php echo ucfirst($this->category_name); ?></li>
    <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="container_inner">
                <div class="container">
                    <div class="todays_bot_det">


                    <?php echo new View("themes/" . THEME_NAME . "/deals/deals_list"); ?>

                    </div>
                            <?php if (($this->pagination) != "") { ?>
                        <div class="pro_tit_pagenation_1 mt20">
                            <div class="pagenation">
                        <?php echo $this->pagination; ?>
                            </div>
                        </div>
    <?php } ?>
                </div>
            </div>
        </div>



    <?php } else { ?>

        <?php echo new View("themes/" . THEME_NAME . "/subscribe"); ?>

<?php } ?>
