				
<?php if (count($this->all_deals_list) > 0) { ?>

    <?php
    $deal_offset = $this->input->get('offset');
    foreach ($this->all_deals_list as $deals) {

        $symbol = CURRENCY_SYMBOL;
        ?>
        <div class="feture_deal_listing">
            <div class="feture_top"></div>
            <div class="feture_mid">

                <div class="fetur_img">
					<?php if($this->session->get('cate')!="") { ?> <?php $url=$this->session->get('cate'); ?> <?php } else { ?> <?php $url=$deals->category_url; ?>  <?php } ?>
                    <?php if (file_exists(DOCROOT . 'images/category/icon/' . $url. '.png')) { ?>
                    
                        <span class="cat_icon"><img alt="category icon" src="<?php echo PATH . 'images/category/icon/' . $url . '.png'; ?>" title="<?php echo $url; ?>"></span>
                    <?php } else { ?>
                        <span class="cat_icon"><img alt="category icon" src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/cate_icon.png" title="<?php echo "no-image"; ?>" /></span>
                    <?php } ?>

                    <?php if (file_exists(DOCROOT . 'images/deals/220_160/' . $deals->deal_key . '_1' . '.png')) { ?>
                        <a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH . 'images/deals/220_160/' . $deals->deal_key . '_1' . '.png'; ?>"  alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>"  ></a>
                    <?php } else { ?>
                        <a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="<?php echo $deals->deal_title; ?>"><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png"  alt="<?php echo $deals->deal_title; ?>" title="<?php echo $deals->deal_title; ?>" ></a>  
        <?php } ?> 
                    <div class="img_bought_det">
                        <p><?php echo $deals->purchase_count; ?> <?php echo $this->Lang['BOUGHT']; ?></p><span><?php echo $symbol . " " . $deals->deal_value; ?></span>
                    </div>
                </div>

                <div class="feture_bot_det">
                    <p><a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>"><?php echo substr(ucfirst($deals->deal_title),0,30).'...'; ?></a></p>
                    <div class="time_price">
                        <div class="time_price_lft">                                                        
                            <label> <span time="<?php echo $deals->enddate; ?>" class="kkcount-down" ></span></label>
                            <p><?php echo $symbol . " " . $deals->deal_price; ?></p>
                        </div>
                        <div class="view_del">
                            <div class="view_deal_lft">
                                <div class="view_deal_rgt">
                                    <div class="view_deal_mid">
                                        <a href="<?php echo PATH . 'deals/' . $deals->deal_key . '/' . $deals->url_title . '.html'; ?>" title="DEAL DETAILS">DEAL DETAILS</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

            <div class="feture_bot"></div>

        </div>
    <?php } ?>

<?php } else { ?>

<p>Nodata Found</p>

<?php } ?>







