<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php /* Pagination */ ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('a.cart_button').live("click", function(e){
            var offset  = 0;
            offset = document.getElementById('offset').value;
            var record = document.getElementById('record').value;
            var record1 = document.getElementById('record1').value;
	    
            var url = '<?php echo PATH; ?>'+'stores/store_list_1?offset='+offset+'&record='+record;
            $.post(url,function(check){ 

                if(check){ 
				  
                    $('#stores').append(check);
                    $('#loading').show();
                    offset = parseInt(offset)+4;

                    $("#offset").val(offset);

                    if(offset >= record1 ) {

                        $('#loading').hide();

                    }

                }
            });     
        
        });
    });

</script>




    <div class="contianer_outer1">
        <div class="contianer_inner">
            <div class="contianer">
                <div class="bread_crumb">
                    <ul>
                        <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>

                        <li><p><?php if (isset($this->store_search)) { ?> <a href="<?php echo PATH; ?>stores.html" title="<?php echo $this->Lang['STORES1']; ?>"><?php echo $this->Lang['STORES1']; ?></a></p> <?php } else { ?><?php echo $this->Lang['STORES1']; ?> <?php } ?></p> </li>
                        <?php if (isset($this->store_search)) { ?>
                            <li><p><?php echo ucfirst($this->store_search); ?></p></li>
                        <?php } ?>

                    </ul>
                </div>
			<?php if (count($this->store_details) > 0) { ?>
                <!--content start-->
                <div class="content_abouts_1">
                    <div class="pro_top">
                        <h2>STORES</h2>
                        <div class="content_store_list">
                            <div id="stores">
                                <?php echo new View("themes/" . THEME_NAME . "/all_store_listing"); ?>
                            </div>

                            <?php if (($this->uri->last_segment() == "stores.html") && ($this->store_details_count > 1)) { ?>
                                <div id="loading">
                                    <?php if (($this->pagination) != "") { ?> 
                                        <div class="feature_viewmore">
                                            <div class="fea_view_more">
                                                <div class="view_more_inne">
                                                    <div class="viewmore_lft"></div>
                                                    <div class="viewmore_midd">
                                                        <a style="cursor:pointer;" class="cart_button">-------See More Stores-------</a>
                                                    </div>
                                                    <div class="viewmore_rgt"></div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            <?php } ?> 

                        </div>
                    </div>  


                </div>
                <!--end-->
                
<?php } else { ?>
    <?php echo new View("themes/" . THEME_NAME . "/subscribe"); ?>
<?php } ?>

            </div>
        </div>
    </div>

    <!--scroll filter start-->
    <input type="hidden" name="offset" id="offset" value="4">
    <input type="hidden" name="record" id="record" value="4">
    <input type="hidden" name="record" id="record1" value="<?php echo $this->store_details_count; ?>">

    <!--scroll filter end-->
