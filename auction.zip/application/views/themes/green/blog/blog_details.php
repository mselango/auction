<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript">
    function clearAll()
    {
        if((document.getElementById("sender_name").value)=='Name')
        {
            document.blog_comment.sender_name.value='';
                
        }
        if((document.getElementById("email").value)=='Email')
        {
            document.blog_comment.email.value='';
                   
        }
        if((document.getElementById("comments").value)=='comments here..')
        {
            document.blog_comment.comments.value='';
                      
        }               
        else{        
            return;
        }       
        
    }
</script>
<script type="text/javascript">
    function onClick(target){
        target.value= "";
    }
</script>

<div class="contianer_outer">
    <div class="contianer_inner">
        <div class="contianer">
            <div class="bread_crumb">
                <?php
                foreach ($this->blog_details as $blog_details) {
                    $imageName = PATH . "themes/" . THEME_NAME . "/images/noimage_deals_details.png";
                    if (file_exists(DOCROOT . "images/blog_images/100/" . $blog_details->blog_id . ".jpg")) {
                        $imageName = PATH . "images/blog_images/100/" . $blog_details->blog_id . ".jpg";
                    }
                    ?>
                    <ul>
                        <li><p><a href="<?php echo PATH; ?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
                        <li><p><a href="<?php echo PATH; ?>blog" title="Blog Listing">Blog Listing</a></p></li>
                        <li><p><?php echo html_entity_decode(ucfirst($blog_details->blog_title)); ?></p></li>
                    </ul>
                </div>
                <div class="blog_detalil_left_share">
                    <ul>
                        <li > <a href="https://twitter.com/share" class="twitter-share-button" data-count="vertical" data-url="<?php echo PATH . 'blog'; ?>" data-lang="en">Tweet</a> 
                            <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script> </li>
                        <li ><iframe src="https://www.facebook.com/plugins/like.php?href=<?php echo PATH . 'blog'; ?>&amp;layout=box_count&amp;show_faces=true&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:65px; width:46px;" allowTransparency="true"></iframe>   </li>
                        <li> 
                        <g:plusone size="tall" href="<?php echo PATH . 'blog'; ?>"></g:plusone>
                        <!-- Place this render call where appropriate -->
                        <script type="text/javascript">
                            (function() {
                                var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                                po.src = 'https://apis.google.com/js/plusone.js';
                                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                            })();
                        </script>
                        </li>
                        <li> <script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
                            <script type="IN/Share" data-url="<?php echo PATH . 'blog'; ?>" data-counter="top"></script>   </li>
                    </ul>             
                </div>
                <!--content start-->
                <div class="content">
                    <!--Blog content starts-->
                    <div class="blog_left">
                        <div class="blog_left_inner">
                              <div class="pro_top">
                            <h2><?php echo $this->Lang['BLOG_DET']; ?></h2>
                              </div>
                            <div class="blog_list">
                                <h3><?php echo html_entity_decode(ucfirst($blog_details->blog_title)); ?></h3>
                                <div class="post_info">
                                    <ul>
                                        <li>
                                            <p><?php echo date("M jS", $blog_details->blog_date); ?></p>
                                        </li>
                                        <li><p>|</p></li>
                                        <li>
                                            <p><?php echo $this->Lang['POSTED_BY']; ?> <a href="javascript:;" title="<?php echo $this->Lang['ADMIN']; ?>"> <?php echo $this->Lang['ADMIN']; ?></a></p></li><li><p>|</p></li><li><p><a href="<?php echo PATH . 'blog/category/' . $blog_details->category_url . '.html' ?>" title="<?php echo ucfirst($blog_details->category_name); ?>" class="post_on_new"><?php echo ucfirst($blog_details->category_name); ?> </a></p>
                                        </li>
                                        <li><p>|</p></li>
                                                <?php if ($this->allow_posting == 1) { /** allow comment posting start * */ ?>
                                            <li>
                                                <p><img src="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/blog_bg.png" width="12" height="12" alt="img"/> 
                                            <?php echo $blog_details->comments_count; ?>  <?php echo $this->Lang['COMM']; ?></p>
                                            </li>
    <?php } /** allow comment posting end * */ ?>
                                        <li class="twitter_1"> <a href="https://twitter.com/share" class="twitter-share-button" data-count="vertical" data-url="<?php echo PATH . 'blog/' . $blog_details->url_title . '.html' ?>">Tweet</a>
                                            <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                                        </li>
                                        <li class="quick" >
                                            <iframe src="https://www.facebook.com/plugins/like.php?href=<?php echo PATH . 'blog/' . $blog_details->url_title . '.html' ?>&amp;layout=box_count&amp;show_faces=true&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:65px; width:46px;" allowTransparency="true"></iframe>
                                        </li>
                                        <li>
                                            <!-- Place this tag where you want the +1 button to render -->
                                        <g:plusone size="tall" href="<?php echo PATH . 'blog/' . $blog_details->url_title . '.html' ?>"></g:plusone>
                                        <!-- Place this render call where appropriate -->
                                        <script type="text/javascript">
                                            (function() {
                                                var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                                                po.src = 'https://apis.google.com/js/plusone.js';
                                                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                                            })();
                                        </script>
                                        </li>	
                                    </ul>
                                </div>
                                <div class="post_outer">									
                                    <div class="post_right2">	
                                        <div class="post_content2">
                                            <div class="post_img">
                                                <img src="<?php echo $imageName; ?>"/>
                                            </div>
                                            <p><?php echo strip_tags(html_entity_decode(ucfirst($blog_details->blog_description))); ?></p>
                                        </div>											
                                    </div>
                                </div>
                            </div>
                            <div class="blog_comment_area">
                                <?php if ($this->allow_posting == 1) { ?>
                                    <?php echo count($this->comments_list); ?> User Comments </h1>
                                    <?php
                                    if (count($this->comments_list) > 0) {
                                        foreach ($this->comments_list as $blog_comments) {
                                            ?>
                                            <h4></h4>
                                            <div class="blog_comment1">
                                                <div class="blog_comment_post_info">
                                                    <ul>
                                                        <li><p><?php echo date("F j, Y g:i a", $blog_comments->comments_date); ?> </p></li>
                <!--li><p>|</p></li>
                <li><p><a href="#" title="Reply">Reply</a></p></li-->
                                                    </ul>
                                                </div>
                                                <div class="blog_user_comment">
                                                    <div class="blog_user_image">
                                                        <img src="http://www.gravatar.com/avatar/<?php echo md5($blog_comments->name . $blog_comments->name) ?>?d=wavatar&s=50" width="75" height="60" alt="img" />
                                                    </div>
                                                    <div class="blog_user_comment_text">
                                                        <b></b><?php echo $blog_comments->name; ?></b>
                                                        <p><?php echo $blog_comments->comments; ?></p>
                                                    </div>
                                                </div>
                                            </div>
            <?php }
        }
    }
} ?>
<?php if ($blog_details->allow_comments == 1) { ?>
                                <div class="blog_reply_area">
                                    <h5>LEAVE A REPLY</h5>
                                    <div class="blog_reply_form">
                                        <form  action="" method="post" name="blog_comment" onsubmit="clearAll()">
                                            <div class="blog_form_left">
                                                <div class="blog_txtbox">
                                                    <input type="text" name="sender_name" id="sender_name" value="<?php echo $this->Lang['NAME']; ?>" onBlur="if(this.value == '') { this.value='Name';}" onFocus="if (this.value == 'Name') {this.value='';}"/>
    <?php if (isset($this->name_error)) { ?>
                                                        <em><?php echo $this->name_error; ?></em>
                                                    <?php } else { ?>
                                                        <label><?php echo $this->Lang['REQ']; ?></label>
                                                    <?php } ?> 
                                                </div>
                                                <div class="blog_txtbox">
                                                    <input name="email" type="text"  id="email" value="<?php echo $this->Lang['EMAIL_F']; ?>" onblur="if (this.value == '') {this.value = 'Email';}"onfocus="if(this.value == 'Email') {this.value = '';}"   />
    <?php if (isset($this->comment_error)) { ?>
                                                        <em><?php echo $this->comment_error; ?></em>
    <?php } else { ?>
                                                        <label><?php echo $this->Lang['REQ_WILL_NOT']; ?></label>
    <?php } ?>
                                                </div>
                                                <div class="blog_txtbox">
                                                    <input name="website" type="text"  value="<?php echo $this->Lang['WEBSITE']; ?>" onblur="if (this.value == '') {this.value = 'Website';}"onfocus="if(this.value == 'Website') {this.value = '';}" />
                                                    <label><?php echo $this->Lang['OPTIONAL']; ?></label>
                                                </div>
                                                <div class="submit_comment_button">
                                                    <div class="submit_comment_left">
                                                        <div class="submit_comment_right">
                                                            <div class="submit_comment_mid">
                                                                <input type="submit" value="<?php echo $this->Lang['SUB_COMM']; ?>" title="<?php echo $this->Lang['SUB_COMM']; ?>"/> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="blog_form_checkbox">
                                                    <input type="checkbox"/> 
                                                    <span><?php echo $this->Lang['NOTIFY_EMAIL']; ?></span>
                                                </div>
                                            </div>
                                            <div class="blog_form_right">
                                                <div class="blog_form_textarea">											
                                                    <textarea name="comments" cols="" rows="" id="comments" placeholder="<?php echo $this->Lang['COMM_HERE']; ?>.."  ></textarea>
    <?php if (isset($this->message_error)) { ?>
                                                        <label style="float:left; width:260px; font:12px/25px arial; color:#f00;"><?php echo $this->message_error; ?></label>
                                        <?php } else { ?>
                                                        <label style="float:left; width:260px; font:12px/25px arial; color:#999;"><?php echo $this->Lang['REQ']; ?></label>
    <?php } ?>   
                                                </div>
                                            </div>
                                        </form>  
                    <?php } /** allow comment posting end * */ ?>                                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blog_right">
<?php echo new View("themes/" . THEME_NAME . "/blog/blog_categories"); ?>
                </div>
            </div>
            <!--Blog content ends-->
        </div>
    </div>
</div>

