<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<script type="text/javascript" src="<?php echo PATH;?>js/timer/kk_countdown_1_2_jquery_min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
	$.noConflict();
	$("body").kkCountDown({
	colorText:'#ED7E2C',
	colorTextDay:'#ED7E2C',
	addClass : 'shadow'
	});
	});
</script>
  <link href="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/css/style.css" type="text/css" rel="stylesheet" />
 <!--Carousel Script-->
     <script src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery.jcarousel.min.js"></script>

        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>
        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel2').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>
        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel3').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>
        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel4').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>
         <!--[if lte IE 7]>
                <link rel="stylesheet" type="text/css" href="public/css/ie7-and-down.css" />
        <![endif]-->
    

                </div>
            </div>
        </div>
        <!--end-->




        <div class="contianer_outer1">
            <div class="contianer_inner">
 <div class="bread_crumb">
                         <ul>
					<li><p><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang['HOME1']; ?></a></p></li>
					<li><p><a href="<?php echo PATH;?>stores.html" title="<?php echo $this->Lang['STORES1']; ?>"><?php echo $this->Lang['STORES1']; ?></a></p></li>
					<?php foreach( $this->get_store_details as $store){ ?>
					<li><p><?php echo ucfirst($store->store_name); ?></p></li>
					<?php }?>
				</ul>
                    </div>
                <div class="contianer">

                    <!--content start-->
                    <div class="branch_detail1 pro_top">
                        <h2><?php echo $this->Lang['STORE_DETAILS']; ?></h2>
                        <div class="addres_common">
                            <div class="addres_left_cont">
                                 <div class="sd_img">
                                     <div class="left_top_cont_cent">
                                <a href="#" title="sd_image">
                                    <?php  if(file_exists(DOCROOT.'images/merchant/600_370/'.$store->merchant_id.'_'.$store->store_id.'.png')){ ?>
        <img src="<?php echo PATH.'images/merchant/600_370/'.$store->merchant_id.'_'.$store->store_id.'.png';?>" alt="<?php echo $this->Lang['IMAGE']; ?>">
        <?php } else { ?>
        <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_stores_details.png"  alt="<?php echo $this->Lang['IMAGE']; ?>">
        <?php }?>
                                </a>
                                              <div class="pro_title">
                                    <h2><?php echo $this->Lang['ADDRES']; ?></h2>
                                </div>
                                         <div class="map_page">
                                   <div id="map_main" style="width:448px; height:308px;"></div>
                                <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
                                <script type="text/javascript">
                                var latlng = new google.maps.LatLng(<?php echo $store->latitude; ?>,<?php echo $store->longitude; ?>);
                                var myOptions = {
                                zoom: 12,
                                center: latlng,
                                mapTypeId: google.maps.MapTypeId.ROADMAP,
                                navigationControl: true,
                                mapTypeControl: true,
                                scaleControl: true
                                };

                                var map = new google.maps.Map(document.getElementById("map_main"), myOptions);
                                var marker = new google.maps.Marker({
                                position: latlng,
                                animation: google.maps.Animation.BOUNCE
                                });
                                
                                var infowindow = new google.maps.InfoWindow({
                                 content: '<b><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $store->store_name); ?></b><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $store->address1); ?></p><p><?php echo preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s", '', $store->address2); ?></p><p><?php echo $store->city_name; ?>,<?php echo $store->country_name; ?></p>'
                                });

                               google.maps.event.addListener(marker, 'click', function() { 
                                        infowindow.open(map, marker);
                               });
                               marker.setMap(map);
                               
                                </script>
                                </div>
                                         <div class="common_all">
                                    <div class="addres_left_right">
                                       <h3><?php echo $store->address1; ?>,</h3>
                                        <p><?php echo $store->address2; ?>,  </p>                                    
                                        <p><?php echo $store->city_name; ?>, <?php echo $store->city_name; ?>. </p>                  
                                        <p><?php echo $this->Lang['MOBILE']; ?>: <?php echo $store->phone_number; ?> </p>
                                        <p>Head Office: +91 422-434-2519. </p>
                                        <p><?php echo $this->Lang['WEBSITE']; ?>: <a href="<?php echo $store->website; ?>" target="blank" class="color007BD9"> <?php echo $store->website; ?></a></p>

                                    </div>
                                    
                                    
                                </div>
                                     </div>
                                
                            <div class="cotent_face_right">
                                <div class="pro_title3 branch_detail1 pro_top">
                                    <h2>Comments</h2>
                                    <div class="face_commont">
                                        <div class="face_comm_top">
                                            <div class="face_top_left">
        <?php if(($this->session->get("UserID")) && file_exists(DOCROOT.'images/user/150_115/'.$this->session->get("UserID").'.png'))  { ?> 
        <img src="<?php echo PATH.'images/user/150_115/'.$this->session->get("UserID").'.png';?>"  alt="side_vdeio"  style="width:50px; height:50px;" />
        <?php }else{ ?>
         <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/comm_user.png"  alt="side_vdeio" border="0"  style="width:50px; height:50px;" />
         <?php } ?>
                                            </div>
                                        <form method="post" >
                                            <div class="face_top_textarea">
                                           <input type="hidden" name="store_key" value="<?php echo $store->store_key; ?>" />
											<input type="hidden" name="store_id" id="store_id" value="<?php echo $store->store_id; ?>" />
											<input type="hidden" name="store_url_title" value="<?php echo $store->store_url_title; ?>" />
											<input type="hidden" name="user" id="user_id" value="<?php echo $this->session->get('UserID'); ?>" />
											<textarea name="comments" id="comment_box" placeholder="Add a comment..."  cols="10" rows="10" class="comment_box"></textarea>
											<em id="error"></em>
                                              
                                            </div>
                                            <div class="post_button">

                                                <div class="button1">
                                                   <div class="gren_left_3">
                                                           <div class="gren_right_3">
                                                                 <div class="gren_mid_3" ><input type="button" title="POST" value="POST" onclick="check_comment1();" /></div> 
                                                           </div>
                                                    </div>		
                                                   
                                                    
                                                </div>
                                            </div>
                                            </form>
                                          
                                        </div>
                                     <div id="show_comment">  <?php echo new View("themes/".THEME_NAME."/store_comments");?></div>	
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                                     
                          
                                
                                


                                

                            </div>

  </div>
                    <?php if(count($this->get_sub_store_details) > 0){ ?>
                    <div class="pro_top">
                        <h2>BRANCHES</h2>

                        <div class="content_store_list">
                            <div class="slider_wrap">
                               <ul <?php if(count($this->get_sub_store_details) > 4){ ?>id="mycarousel" class="jcarousel-skin-tango" <?php } else { ?> <?php } ?>>
                            
                               
                            <?php foreach( $this->get_sub_store_details as $stores){?>
                            
                                    <li>

                                        <div class="feture_deal_listing_1">

                                            <div class="feture_top"></div>
                                            <div class="feture_mid_1">
                                                <div class="fetur_img">                                                   
            <?php  if(file_exists(DOCROOT.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png')){ ?>
            <a href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" title="<?php echo $stores->store_name; ?>"><img  src="<?php echo PATH.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png';?>"   alt="<?php echo $stores->store_name; ?>" title="<?php echo $stores->store_name; ?>"></a>
            <?php } else { ?>
            <a href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" title="Test"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_stores.png"   alt="<?php echo $stores->store_name; ?>" title="<?php echo $stores->store_name; ?>" width="228px" height="250px;"></a>
            <?php }?>                                                   
                                                </div>
                                                <div class="feture_bot_det">
                                                <a class="bot_square" href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" title="<?php echo $stores->store_name; ?>"><?php echo substr(ucfirst($stores->store_name),0,30).'..';?></a>
                                                  <p class="bot_square_text"><?php echo $stores->address1; ?></p>
							                      
                                                   
                                                    <div class="bot_store_view">
                                                        <div class="store_view_deal">
                                                            <a class="view_product" href="" title="">&nbsp;</a>
                                                        </div>
                                                        <div class="store_view_produ">
                                                             <div class="view_lft">
                                                                <div class="view_rgt">
                                                                    <div class="view_mid">
                                                                        <a class="view_product" href="<?php echo PATH.'stores/'.$stores->store_key.'/'.$stores->store_url_title.'.html';?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                                    </div>
                                                                       </div>
                                                                    </div>
                                                            
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="feture_bot"></div>
                                        </div> 
                                    </li>
                                 <?php }  ?>   
                            
                            
                                </ul>
                            </div>
                        </div>
                     </div>
                 <?php } ?>
                       <!--   my carousel2  -->    
                    <?php if($this->product_setting) { ?>
                    <div class="pro_top">
                     <?php if(count($this->get_product_categories) > 0){ ?>
                        <h2>FEATURED  PRODUCTS</h2>
                        <?php }?>
                    
                        <div class="content_store_list">
                            <div class="slider_wrap">
                                <?php if(count($this->get_product_categories) > 0){ ?>  
                              
        <ul  <?php if(count($this->get_product_categories) > 4){ ?> id="mycarousel2" class="jcarousel-skin-tango2" <?php } else { ?> <?php } ?>>                         
             <?php $i=1; foreach( $this->get_product_categories as $products){
                $symbol = CURRENCY_SYMBOL; 
                ?>
                                    <li>

                                        <div class="pro_listing">
                                            <div class="det_img1">
												<?php if(file_exists(DOCROOT.'images/category/icon/'.$products->category_url.'.png')){ ?>
												<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH.'images/category/icon/'.$products->category_url.'.png'; ?>"></span>
											<?php } else { ?>
												   <span class="cat_icon1"><img alt="category icon" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png"/></span>
                                            <?php } ?>
                                               
                                               <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products->deal_key.'_1'.'.png')){ ?>
                <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH.'images/products/290_215/'.$products->deal_key.'_1'.'.png';?>"  alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>"></a>
                <?php } else { ?>
                <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png"  alt="<?php echo $products->deal_title; ?>" title="<?php echo $products->deal_title; ?>" width="167px" height="217px"></a>
                <?php }?>
                                            </div>

                                            <div class="deal_list_detail">
												
                                                <h2><?php echo $products->category_name; ?></h2>
                                                <h3><a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="<?php echo $products->deal_title;?>"><?php echo substr(ucfirst($products->deal_title),0,25).'...';?></a></h3>
                                                <p><span class="price">Price :</span> <span class="usd">US <?php echo $symbol." ".$products->deal_value; ?></span></p>
                                                <div class="view_deals">
                                                    <div class="view_lft">
                                                        <div class="view_rgt">
                                                            <div class="view_mid">
                                                                <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    </li>
                                     <?php }  ?>
                                   
                                </ul>
                                 <?php }  ?>
                            </div>
                             <?php } ?>
                        </div>


                    </div>
                    <!--   my carousel3  -->  
                      <div class="pro_top">
                    <?php if(($this->deal_setting)) { ?>
                        <?php if(count($this->get_deals_categories)>0) { ?>
                        <h2>FEATURED DEALS</h2>
                      <?php } ?>


                        <div class="content_store_list1">
                            <div class="slider_wrap">
                            <?php if(count($this->get_deals_categories)>0) { ?>
                                <ul  <?php if(count($this->get_deals_categories)>4) { ?> id="mycarousel3" class="jcarousel-skin-tango3" <?php } else { ?> <?php } ?>>
                                
          <?php foreach( $this->get_deals_categories as $deals_categories){
		        $symbol = CURRENCY_SYMBOL; 
		        
	                ?>
                                    <li>

                                        <div class="feture_deal_listing">
                                            <div class="feture_top"></div>
                                            <div class="feture_mid">
                                                <div class="fetur_img">
													<?php if(file_exists(DOCROOT.'images/category/icon/'.$deals_categories->category_url.'.png')){ ?>
												<span class="cat_icon"><img alt="category icon" src="<?php echo PATH.'images/category/icon/'.$deals_categories->category_url.'.png'; ?>"></span>
											<?php } else { ?>
												   <span class="cat_icon"><img alt="category icon" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png"/></span>
                                            <?php } ?>
                                                   
                                                    <?php  if(file_exists(DOCROOT.'images/deals/220_160/'.$deals_categories->deal_key.'_1'.'.png')){ ?>
                <a href="<?php echo PATH.'deals/'.$deals_categories->deal_key.'/'.$deals_categories->url_title.'.html';?>" title="Test"><img src="<?php echo PATH.'images/deals/220_160/'.$deals_categories->deal_key.'_1'.'.png';?>"   alt="<?php echo $this->Lang['IMAGE']; ?>" title="<?php echo $this->Lang['IMAGE']; ?>" ></a>
                <?php } else { ?>
                <a href="<?php echo PATH.'deals/'.$deals_categories->deal_key.'/'.$deals_categories->url_title.'.html';?>" title="Test"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png"   alt="<?php echo $this->Lang['IMAGE']; ?>" title="<?php echo $this->Lang['IMAGE']; ?>"  width="235px" height="250px" ></a>
                <?php }?>
                                                    <div class="img_bought_det">
                                                        <p><?php echo round($deals_categories->deal_percentage); ?>% Discount</p><span>Save <?php echo $symbol." ".$deals_categories->deal_savings; ?></span>
                                                    </div>
                                                </div>
                                                <div class="feture_bot_det">
                                                    <p>	<a href="<?php echo PATH.'deals/'.$deals_categories->deal_key.'/'.$deals_categories->url_title.'.html';?>"><?php echo substr(ucfirst($deals_categories->deal_title),0,25)."..."; ?></a></p>
                                                    <div class="time_price">
                                                        
                                                        <div class="time_price_lft">
                                                            <label> <span time="<?php echo $deals_categories->enddate; ?>" class="kkcount-down" ></span></label>
                                                            <p><?php echo $symbol." ".$deals_categories->deal_price; ?></p>
                                                        </div>
                                                        <div class="view_del">
                                                            <div class="view_deal_lft">
                                                                <div class="view_deal_rgt">
                                                                    <div class="view_deal_mid">
                                                                       <a href="<?php echo PATH.'deals/'.$deals_categories->deal_key.'/'.$deals_categories->url_title.'.html';?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="feture_bot"></div>
                                        </div> 
                                    </li>
                                <?php } ?>
                                </ul>
                                  <?php } ?>
                            </div>
                            	<?php }?>
                        </div>


                    </div>
                    <!--   my carousel4  -->  
                    <div class="pro_top">
						   <?php if(($this->auction_setting)) { ?>
                        <?php if(count($this->get_auction_categories)>0) { ?>
                             <h2>FEATURED  AUCTIONS</h2>
                      <?php } ?>
                   

                        <div class="content_store_list">
                            <div class="slider_wrap">
                               <?php if(count($this->get_auction_categories)>0) { ?>
                                <ul  <?php if(count($this->get_auction_categories)>5) { ?> id="mycarousel4" class="jcarousel-skin-tango4" <?php } else { ?> <?php } ?>>
								
							<?php foreach( $this->get_auction_categories as $deals1){ 
								$symbol = CURRENCY_SYMBOL; 
							?>			
                                    <li>

                                        <div class="auction_list">
                                            <div class="action_img">
                                                <div class="act_img_top"></div>
                                                <div class="act_img_mid">
                                                    <?php if(file_exists(DOCROOT.'images/category/icon/'.$deals1->category_url.'.png')){ ?>
												<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH.'images/category/icon/'.$deals1->category_url.'.png'; ?>"></span>
											<?php } else { ?>
												<span class="cat_icon1"><img alt="category icon" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/cate_icon2.png"/></span>
                                            <?php } ?>
                                                  
                                                   <?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$deals1->deal_key.'_1'.'.png')){ ?>
                <a href="<?php echo PATH.'auction/'.$deals1->deal_key.'/'.$deals1->url_title.'.html';?>" title="<?php echo $deals1->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$deals1->deal_key.'_1'.'.png';?>"  alt="<?php echo $deals1->deal_title; ?>" title="<?php echo $deals1->deal_title; ?>" border="0" /></a>

                <?php } else { ?>
                <a href="<?php echo PATH.'auction/'.$deals1->deal_key.'/'.$deals1->url_title.'.html';?>" title="<?php echo $deals1->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_auctions_list.png"  alt="<?php echo $deals1->deal_title; ?>" title="<?php echo $deals1->deal_title; ?>"  border="0" /></a>
                <?php }?>
                                            </div>
                                            <div class="act_img_bot"></div>

                                        </div>
                                        <div class="action_rgt">
                                            <p><a href="<?php echo PATH.'auction/'.$deals1->deal_key.'/'.$deals1->url_title.'.html';?>" title="<?php echo $deals1->deal_title;?>"><?php echo substr(ucfirst($deals1->deal_title),0,25).'..';?></a></p>
                                                
                                            <div class="bid_cont">
											                                           
							                       <?php $q=0; foreach($this->all_payment_list as $payment){ ?>
													<?php if($payment->auction_id==$deals1->deal_id){ 
															$firstname = $payment->firstname;
															$transaction_time = $payment->transaction_date;
															$q=1;
													}     } ?>
												  <?php if($q==1){ ?>
														
                                                <div class="bid_value">					
												  <label>  Last Bidder :</label>
													 <span><?php echo substr(ucfirst($firstname),0,10).'..'; ?></span>
												   </div>
												 <div class="bid_value">					
													<label> Bid:</label>
														<span> <?php echo date("d-m-Y ",$transaction_time); ?>
														<?php echo date("h:i A",$transaction_time); ?></span>
													</div>
													
                    
                    <?php } ?>
                      <?php if($q==0){ ?>
                     <div class="bid_value">  
                 
                    

                <label>  Last Bidder :</label>
                 <span> Not Yet Bid</span>
                 </div>
                <div class="bid_value">    
                <label>  Close Time:</label>
                     <span><?php echo date("d-m-Y",$deals1->enddate); ?><br/><?php echo date("h:i A",$deals1->enddate); ?></span>
                    </div>	
                    <?php } ?>
												<div class="bid_value3">
													<label>Time Left  :</label>
													<span time="<?php echo $deals1->enddate; ?>" class="kkcount-down" >
                                                   
                                                        <br/>
                                                        </span>
                                                </div>
                                           

                                            </div>

                                                <div class="act_bid_values">                                        
                                                    <div class="view_deals">
                                                        <div class="view_lft">
                                                            <div class="view_rgt">
                                                                <div class="view_mid">
                                                                     <a href="<?php echo PATH.'auction/'.$deals1->deal_key.'/'.$deals1->url_title.'.html';?>" title="VIEW DETAILS">VIEW DETAILS</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div> 
                                    </li>
                             <?php } } else { }?>
                            

                                </ul>
                            </div>
                        </div>

                    </div>

                </div>
				<?php } ?>
                <!--end-->

            </div>
        </div>


