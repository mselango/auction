<script type="text/javascript">
	$(document).ready(function(){
	    
   	 $('.submit-link1')
                               .click(function(e){ 
								   
                                       var cat = $(this).attr('id').replace('samples-','').split('-');
                                       $('input[name="c"]').val(cat[0]);
                                       $('input[name="m_c"]').val(cat[1]);
                                       $('input[name="c_t"]').val('<?php echo base64_encode("sub"); ?>');
                                       
                                       e.preventDefault();
                                      $(this).closest('form').submit();
                                               
   });
  
    });
</script>
<div class="contianer_outer1">
<div class="contianer_inner">
    <div class="content_abou_common">
       <div class="pro_top">
<h2>Shop All Categories</h2>
</div>
        <div class="left_menus_common">
			<form action="welcome">
				<div style="width:970px;border:0px solid red;float:left;clear:both;height:100%;">
					
			<?php 
				
			foreach($this->all_category_list as $k => $c) { 
				
				                if($k%3 == 0){ if($k > 2) echo '</ul></div><div style="float:left;width:220px;"><ul>'; else echo '<div style="float:left;width:220px;"><ul>'; } ?>
			
				

               <p class="sample_12 submit-link" style=" font: normal 14px arial; color:#85BE40; padding:9px 0 9px 0;"  id="sample-<?php echo base64_encode($c->category_id); ?>"><?php echo ucfirst($c->category_name); ?></p>
               <?php if(count($this->sub_category_list) > 0){ ?>
                
					 <?php foreach($this->sub_category_list as $d){ if($c->category_id == $d->main_category_id){ ?>
                     <li style=" list-style: none outside none;"><a style="cursor:pointer;  font: normal 12px/18px arial; color:#115798;"class="submit-link1" id="samples-<?php echo base64_encode($d->category_id)."-".base64_encode($d->main_category_id); ?>" title="<?php echo ucfirst($d->category_name); ?>"><?php echo ucfirst($d->category_name); ?></a></li>
                     <?php } } ?>
                     
                 
                 <?php } ?>
             
             <?php }?>	
             </div>
								<input type="hidden" name="c" />
                                <input type="hidden" name="c_t" />
                                <input type="hidden" name="m_c">
<p><input type="submit" style="display:none;"> </p>
	</form>
      
        </div>
    </div>
</div>
</div>
