<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
      <link href="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/css/style.css" type="text/css" rel="stylesheet" />
        <!--Carousel Script-->
        <script src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/js/jquery.jcarousel.min.js"></script>


        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel2').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>
        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel3').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>
        <script type="text/javascript">

            jQuery(document).ready(function() {
                jQuery('#mycarousel4').jcarousel({
                    wrap: 'circular'
                });
            });

        </script>

<!--[if lte IE 7]>
	<link rel="stylesheet" type="text/css" href="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/css/ie7-and-down.css" />
<![endif]-->



        <div class="contianer_outer1">
            <div class="contianer_inner">
                <div class="contianer">
                    
                    <div class="bread_crumb">
                        <ul>
                        
                            <li><p><a href="<?php echo PATH; ?>" title="Home">Home</a></p></li>
                            <li><p>Sold out </p></li>
                        </ul>
                    </div>
                    <!--content start-->


                    <div class="branch_detail1 pro_top" style="margin: 0px;">
                    <?php  if($this->product_setting){ ?>
        <?php if(count($this->get_sold_products)>0){ ?>
                        <h2><?php echo $this->Lang['PRODUCTS1']; ?></h2>

                        <div class="content_store_list">
                            <div class="slider_wrap">
                                <ul <?php if(count($this->get_sold_products)>5){ ?> id="mycarousel2" class="jcarousel-skin-tango2" <?php } else { ?> <?php } ?>>
                                <?php  foreach( $this->get_sold_products as $p){
					$symbol = CURRENCY_SYMBOL; 
					?>
                                    <li>

                                        <div class="pro_listing_2">
                                            <div class="det_img_2">
                                    <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$p->deal_key.'_1'.'.png')){ ?>
										<a href="<?php echo PATH.'product/'.$p->deal_key.'/'.$p->url_title.'.html';?>" title="<?php echo $p->deal_title; ?>"><img src="<?php echo PATH.'images/products/290_215/'.$p->deal_key.'_1'.'.png';?>" alt="<?php echo $p->deal_title; ?>"   border="0" /></a>
									<?php } else { ?>
										<a href="<?php echo PATH.'product/'.$p->deal_key.'/'.$p->url_title.'.html';?>" title="<?php echo $p->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" alt="<?php echo $p->deal_title; ?>" /></a>
									<?php  }?>    
                                            </div>
                                            <div class="green_out_img">
                                                <p>Sold out</p>
                                            </div>

                                            <div class="deal_list_detail">
                                               <?php /** <h2>Electronics</h2> **/ ?>
                                                <h3><a href="<?php echo PATH.'product/'.$p->deal_key.'/'.$p->url_title.'.html';?>" title="<?php echo $p->deal_title; ?>"><?php echo substr(ucfirst($p->deal_title),0,25).'...'; ?></a></h3>

                                            </div>
                                        </div> 
                                    </li>
                                    <?php }?> 
                                    
                                </ul>
                            </div>
                        </div>


                    </div>
                    <?php }  } ?>
                    <!--   my carousel3  -->  
                    <div class="branch_detail1 pro_top" style="margin: 0px;">
                     <?php  if($this->deal_setting){ ?>
                    <?php if(count($this->get_sold_deals)>0){ ?>
                        <h2><?php echo $this->Lang['DEALS1']; ?></h2>
                        <div class="content_store_list">
                            <div class="slider_wrap">
                                <ul <?php if(count($this->get_sold_deals)>4){ ?> id="mycarousel3" class="jcarousel-skin-tango3" <?php } else { ?> <?php } ?>>
                                <?php  foreach( $this->get_sold_deals as $d){
						        $symbol = CURRENCY_SYMBOL; 
			                 	?>
                                    <li>

                                        <div class="feture_deal_listing">
                                            <div class="feture_top"></div>
                                            <div class="feture_mid">
                                                <div class="fetur_img">
                                <?php if(file_exists(DOCROOT.'images/deals/220_160/'.$d->deal_key.'_1'.'.png')){ ?>
										<a href="<?php echo PATH.'deals/'.$d->deal_key.'/'.$d->url_title.'.html';?>" title="<?php echo $d->deal_title; ?>"><img src="<?php echo PATH.'images/deals/220_160/'.$d->deal_key.'_1'.'.png';?>"  alt="<?php echo $d->deal_title; ?>" title="<?php echo $d->deal_title; ?>" border="0" /></a>
								<?php } else { ?>
										<a href="<?php echo PATH.'deals/'.$d->deal_key.'/'.$d->url_title.'.html';?>" title="<?php echo $d->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png"  alt="<?php echo $d->deal_title; ?>" title="<?php echo $d->deal_title; ?>" border="0" /></a>
								<?php }?>
                                                    <div class="green_out_img1">
                                                        <p>Sold out</p>
                                                    </div>
                                                    <div class="img_bought_det">
                                                    <p><?php echo round($d->deal_percentage); ?>%</p><span style=" float:left; text-align: left;"><?php echo $this->Lang['OFF']; ?></span>
                                                    </div>

                                                </div>
                                                <div class="feture_bot_det">
                                                    <p><a href="<?php echo PATH.'deals/'.$d->deal_key.'/'.$d->url_title.'.html';?>" title="<?php echo $d->deal_title; ?>"><?php echo substr(ucfirst($d->deal_title),0,25).'...'; ?></a></p>

                                                </div>
                                            </div>
                                            <div class="feture_bot"></div>
                                        </div> 
                                    </li>
                                 <?php }?>     
                                </ul>
                            </div>
                        </div>


                    </div>
                        <?php }  } ?>
                    <!--   my carousel4  -->  
                    <div class="branch_detail1 pro_top" style="margin: 0px;">
                     <?php  if($this->auction_setting){ ?>
        <?php if(count($this->get_sold_auction)>0){ ?>
                        <h2><?php echo "AUCTION"; ?></h2>



                        <div class="content_store_list">
                            <div class="slider_wrap">
                                <ul <?php if(count($this->get_sold_auction)>4){ ?> id="mycarousel4" class="jcarousel-skin-tango4" <?php } else { ?> <?php } ?>>
                                <?php  foreach( $this->get_sold_auction as $d){
						                $symbol = CURRENCY_SYMBOL; 
					            ?>
                                    <li>

                                        <div class="auction_list">
                                            <div class="action_img">
                                                <div class="act_img_top"></div>
                                                <div class="act_img_mid">
                                                   <?php if(file_exists(DOCROOT.'images/auction/220_160/'.$d->deal_key.'_1'.'.png')){ ?>
									<a href="<?php echo PATH.'auction/'.$d->deal_key.'/'.$d->url_title.'.html';?>" title="<?php echo $d->deal_title; ?>"><img src="<?php echo PATH.'images/auction/220_160/'.$d->deal_key.'_1'.'.png';?>"  alt="<?php echo $d->deal_title; ?>" title="<?php echo $d->deal_title; ?>" border="0" /></a>

									<?php } else { ?>
									<a href="<?php echo PATH.'auction/'.$d->deal_key.'/'.$d->url_title.'.html';?>" title="<?php echo $d->deal_title; ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_auctions_list.png"  alt="<?php echo $d->deal_title; ?>" title="<?php echo $d->deal_title; ?>" border="0" /></a>
									<?php }?> 
                                                </div>
                                                <div class="green_out_img2">
                                                        <p>Sold out</p>
                                                    </div>
                                                <div class="act_img_bot"></div>

                                            </div>
                                            <div class="action_rgt">
                                                <p><a href="<?php echo PATH.'auction/'.$d->deal_key.'/'.$d->url_title.'.html';?>" title="<?php echo $d->deal_title; ?>"><?php echo substr(ucfirst($d->deal_title),0,20).'...'; ?></a></p>

                                            </div>
                                        </div> 
                                    </li>
                                    <?php }?> 
                                </ul>
                            </div>
                        </div>

                    </div>

                </div>
   <?php }  } ?>
   <!--end-->
       </div>
       </div>         
    <?php if((count($this->get_sold_products)==0) && (count($this->get_sold_auction)==0) && (count($this->get_sold_deals)==0)) { ?>
		<?php echo new View("themes/" . THEME_NAME . "/subscribe"); ?>
		<?php  }  ?>

            </div>
        </div>
         </div>

