<!DOCTYPE html>
<html lang="en" class="demo-1">
	<?php
$this->session = Session::instance();
$this->UserName = $this->session->get("UserName");

?>
    <head>
        <meta charset="UTF-8" />
        <title><?php echo $this->Lang["SUCC_MAIL"]; ?></title>
    </head>
    <body>
		
        <table cellspacing="0" cellpadding="0" border="0" width="700" style=" background:#fff; width:700px; border:  1px solid #ECE9E4;">
			<?php foreach($this->products_list as $p ) { ?>
            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0" style=" width:680px; margin:0 0 0 9px;">
                        <tr  style="height:20px"><td></td></tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" >

                                    <tr>				
                                        <td style=" width:544px;margin:0px; padding:0px; height:2px;">
                                            <div style="width:116px; margin:0px; padding:0px;  height:2px;">&nbsp;</div>
                                        </td>

                                    </tr>

                                </table>
                            </td>
                        </tr>



                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0">
                                    <tr style="height:16px;"><td></td></tr>
                                    <tr>

                                        <td style="margin:0px; padding:0px;">
                                            <a href="#" title=""><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png" border="0" alt="Logo" title="logo" /></a>
                                        </td>

                                    </tr>
                                    <tr style="height:12px;"><td></td></tr>

                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; background: #5CAACE;">
                                <table cellspacing="0" cellpadding="0" border="0">

                                    <tr>

                                        <td style="margin:0px; padding:0px;">
                                            <table>
                                                <tr style="height:3px"><td></td></tr>
                                                <tr>
                                                    <td style="vertical-align: top; width: 250px;">&nbsp;</td>
                                                    <td>
                                                        <p style=" font:  bold 20px arial; color: #fff; padding: 0px; margin: 0px;"> Shipping Details</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="vertical-align: top; width: 250px;">&nbsp;</td>
                                                    <td>
                                                        <p style=" font:  bold 16px arial; color: #fff; padding: 0px; margin: 0px;"> Note: <label  style=" font:  normal 12px arial; color: #fff; padding: 0px; margin: 0px;">This shipment contains following items</label></p>
                                                    </td>

                                                </tr>
                                            </table>	
                                        </td>

                                    </tr>
                                    <tr style="height:12px;"><td></td></tr>

                                </table>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0"  style="width:680px;    border: 1px solid #ECE9E4; background:#fff;">
                                    <tr style=" height:14px;"><td></td></tr>
                                    <tr>
                                        <td width="30">&nbsp;</td>
                                        <td style=" vertical-align: top; font:  bold 16px arial; color: #333;">1.<?php echo $p->deal_title; ?></td>
                                        <td width="30">&nbsp;</td>	
                                    </tr>
                                    <tr style="height:10px"><td></td></tr>
                                    <tr>
                                        <td width="30">&nbsp;</td>
                                        <td style=" vertical-align: top; font: bold 12px arial; color: #666;">
                                            <table cellspacing="0" cellpadding="0" border="0">
                                                <tr>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f; margin: 0px; padding: 0 0 6px 22px;">Color</p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0 0 6px;">Size</p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0 0 6px;">Quantity</p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0 0 6px;">Unit Price</p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top;font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0 0 6px 22px;">Discount</p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 100px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0 0 6px 32px;">Sub Total</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td width="30">&nbsp;</td>	
                                    </tr>
                                    <tr style=" height:10px;"><td></td></tr>
                                    <tr>
                                        <td width="30">&nbsp;</td>
                                        <td style=" vertical-align: top; font: bold 12px arial; color: #666;">
                                            <table cellspacing="0" cellpadding="0" border="0">
                                                <tr>
													<?php if($p->product_color !=0 ) { foreach($this->product_color as $pro){ ?>
													<?php if($p->product_color == $pro->id){ ?>   
                                                    <td style="vertical-align: top; width: 115px; border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px;padding: 0px 0px 25px 0;"><?php echo ucfirst($pro->color_name); ?> </p>
                                                    </td>
                                                    <?php } } } else { ?>
                                                     <td style="vertical-align: top; width: 115px; border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px;padding: 0px 0px 25px 0;">-</p>
                                                    </td>
                                                    <?php } ?>
                                                     <?php if($p->product_size != 0 ){ foreach($this->product_size as $size){ ?>
													<?php if($p->product_size == $size->size_id){ ?>  
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0px 0 6px 12px;"><?php echo $size->size_name; ?> </p>
                                                    </td>
                                                    <?php } } } else { ?>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0px 0 6px 12px;">-</p>
                                                    </td>
                                                    <?php } ?>
                                                    
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0px 0 6px 21px;"> <?php echo $p->quantity; ?> </p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 115px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0px 0 6px 20px;"><?php echo CURRENCY_SYMBOL.$p->deal_price; ?> </p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 120px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0px 0 6px 20px;"><?php echo CURRENCY_SYMBOL.$p->deal_value; ?> </p>
                                                    </td>
                                                    <td style="vertical-align: top; width: 88px;  border-bottom: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font: normal 14px arial; color: #1f1f1f;  margin: 0px; padding: 0px 0 6px 30px;"><?php echo CURRENCY_SYMBOL.$p->deal_value * $p->quantity; ?> </p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td width="30">&nbsp;</td>	
                                    </tr>
                                    <tr style="height:19px;"><td></td></tr>

                                    <tr>
                                        <td width="30">&nbsp;</td>
                                        <td style=" vertical-align: top; font: bold 12px arial; color: #666;">
                                            <table cellspacing="0" cellpadding="0" border="0">
                                                <tr>
                                                    <td style="vertical-align: top; width:350px;">&nbsp;</td>
                                                    <td style="vertical-align: top; ;">
                                                        <table cellspacing="0" cellpadding="0" border="0">
                                                            <tr>
                                                                <td style="vertical-align: top; width: 195px;">
                                                                    <p style="vertical-align: top; font:  normal 12px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px;">Shipment Value</p>
                                                                </td>
                                                                <td>
                                                                    <p style="vertical-align: top; font:  bold 14px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px; text-align:right;"><?php echo CURRENCY_SYMBOL.$p->deal_value * $p->quantity; ?> </p>    
                                                                </td>
                                                            </tr>
                                                            <tr style=" height:12px"><td></td></tr>
                                                            <tr>
                                                                <td style="vertical-align: top; width: 195px;">
                                                                    <p style="vertical-align: top; font:  normal 12px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px;">Shipping</p>
                                                                </td>
                                                                <td>
                                                                    <p style="vertical-align: top; font:  bold 14px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px; text-align:right;"> <?php if($p->shipping != 0 ) echo CURRENCY_SYMBOL.$p->shipping; else echo '-'; ?></p>    
                                                                </td>
                                                            </tr>
                                                            <tr style="height:12px;"><td></td></tr>
                                                            <tr>
                                                                <td style="vertical-align: top; width: 195px;">
                                                                    <p style="vertical-align: top; font:  normal 12px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px;">Tax</p>
                                                                </td>
                                                                <td>
                                                                    <p style="vertical-align: top; font:  bold 14px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px; text-align:right;"><?php if($p->tax_amount != 0 ) echo CURRENCY_SYMBOL.$p->tax_amount; else echo '-'; ?> </p>    
                                                                </td>
                                                            </tr>
                                                            <tr style="height:12px;"><td></td></tr>
                                                            <tr>
                                                                <td style="vertical-align: top; width: 195px; border-bottom: 1px solid #ECE9E4; border-top: 1px solid #ECE9E4;  padding: 5px; padding-left:0px; padding-right: 0px;">
                                                                    <p style="vertical-align: top; font:  bold 12px arial; color: #333; margin: 0px; padding:4px;">Amount to be paid</p>
                                                                </td>
                                                                <td style="border-bottom: 1px solid #ECE9E4; border-top: 1px solid #ECE9E4;  padding: 5px; padding-left: 0px;">
                                                                    <p style="vertical-align: top; font:  bold 20px arial; color: #333; margin: 0px; padding: 0px 0 0px 0px; text-align:right;"> <?php echo CURRENCY_SYMBOL.(($p->deal_value * $p->quantity) + ($p->shipping) + ($p->tax_amount)); ?> </p>    
                                                                </td>
                                                            </tr>
                                                        </table >
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td width="30">&nbsp;</td>	
                                    </tr>
                                    <tr>
                                        <td width="30">&nbsp;</td>
                                        <td style=" vertical-align: top; font: bold 12px arial; color: #666;">
                                            <table cellspacing="0" cellpadding="0" border="0">
                                                <tr style="height:34px;"><td></td></tr>
                                                <tr>
                                                   
                                                    <td style=" vertical-align: top; width: 347px; border-top: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font:  bold 18px arial; color: #333; margin: 0px; padding: 15px 0 0px 60px;">Order Date:</p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px; border-top: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font:  bold 18px arial; color: #333; margin: 0px; padding: 15px 0 0px 60px;">Delivery Status:</p>
                                                    </td>
                                                </tr>
                                                <tr style="height:10px;"><td></td></tr>
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px;">
                                                        <p style="vertical-align: top; font:  bold 12px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;"><?php echo date("d-M-Y h:i:s A",$p->transaction_date); ?></p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px;">
                                                        <p style="vertical-align: top; font:  bold 12px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;">2 or 3 days on working days</p>
                                                    </td>
                                                </tr>
                                                <tr style="height:30px;"><td></td></tr>
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px; border-top: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font:  bold 14px arial; color: #33; margin: 0px; padding: 16px 0 0px 60px;">Shop Address</p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px; border-top: 1px solid #ECE9E4;">
                                                        <p style="vertical-align: top; font:  bold 14px arial; color: #333; margin: 0px; padding: 16px 0 0px 60px;">Shipping Address</p>
                                                    </td>
                                                </tr>
                                                <tr style="height:5px;"><td></td></tr>
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px;">
                                                        <p style="vertical-align: top; font:  bold 18px arial; color: #333; margin: 0px; padding: 14px 0 0px 60px;"><?php echo $p->store_name ; ?> </p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px;">
                                                        <p style="vertical-align: top; font:  bold 18px arial; color: #333; margin: 0px; padding: 14px 0 0px 60px;"><?php echo ucfirst($p->name); ?></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px;">
                                                        <p style="vertical-align: top; font:  normal 12px/20px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;"><?php echo $p->addr1.','.$p->addr2 ; ?></p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px;">
                                                        <p style="vertical-align: top; font: normal 12px/20px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;"><?php echo $p->saddr1."<br />".$p->saddr2; ?></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px;">
                                                        <p style="vertical-align: top; font:  normal 12px/20px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;"><?php echo $p->city_name.'-'.$p->zipcode; ?>  ,</p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px;">
                                                        <p style="vertical-align: top; font: normal 12px/20px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;"><?php echo $p->city_name . '-' . $p->postal_code; ?></p>
                                                    </td>
                                                </tr>
                                                
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px;">
                                                        <p style="vertical-align: top; font: bold 14px/23px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;">Phone : <?php echo $p->str_phone; ?></p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px;">
                                                        <p style="vertical-align: top; font: normal 12px/23px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;"><?php echo $p->country; ?></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style=" vertical-align: top; width: 347px;">
                                                        <p style="vertical-align: top; font: bold 14px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;">Website: <a href="<?php echo PATH; ?>" style=" color: #0066cc;" title="<?php echo $p->website; ?>"><?php echo $p->website; ?></a></p>
                                                    </td>
                                                    <td style=" vertical-align: top; width: 259px;">
                                                        <p style="vertical-align: top; font: bold 14px arial; color: #666; margin: 0px; padding: 0px 0 0px 60px;">Phone : <?php echo $p->phone; ?> </p>
                                                    </td>
                                                </tr>
                                                <tr style="height:12px;"><td></td></tr>
                                            </table>

                                        </td>
                                        <td width="30">&nbsp;</td>	
                                    </tr>
    <?php } ?>
                                </table>
                            
                            </td>
                        </tr>

                
            <tr>
                <td style=" vertical-align: top; background: #E2E2E2; padding: 10px;border: 1px solid #ECE9E4; border-top: none;">
                    <p  style="width:589px; margin:0px 0 0 33px; padding: 7px 0 13px 0px; font: normal 12px arial; color:#777; text-align:center;"><?php echo $this->Lang["IN_STORE"]; ?> - <?php echo $this->Lang["BUY_CLOSE_EMAIL"]; ?> <a href="<?php echo PATH;?>users/my-coupons.html" ><?php echo $this->Lang["MY_BUYS"]; ?></a><?php echo $this->Lang["TICKET_PRINTED"]; ?>
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0">
                        <tr style="height:14px;"></tr>

                    </table>
                </td>
            </tr>
        </table>
    <tr style=" height:30px"></tr>	
</table>


<tr>
    <td width="20"></td>
    <td width="660">

    </td>
    <td width="20"></td>

</tr>
</body>
</html>
