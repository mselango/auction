  
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" /> 
        <title>Subscription Mail</title>
    </head>
    <body>
        <table cellspacing="0" cellpadding="0" border="0" width="700" style=" background:#fff; width:700px; border:  1px solid #ccc;">
            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0" style=" width:680px; margin:0 0 0 9px;">
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" >

                                    <tr>				
                                        <td style=" width:544px;margin:0px; padding:0px; height:2px;">
                                            <div style="width:116px; margin:0px; padding:0px;  height:2px;">&nbsp;</div>
                                        </td>

                                    </tr>

                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0">
                                    <tr style="height:16px;"><td></td></tr>
                                    <tr>

                                        <td style="margin:0px; padding:0px; width: 497px; vertical-align: top; ">
                                            <a style="padding:0; margin:10px 0;" href="#" title=""><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/logo.png" border="0" alt="" /></a>
                                        </td>
                                        <td style="vertical-align: top; width: 183px;">
                                            <table>
                                                <tr>
                                                    <td style=" vertical-align: top;  width: 183px; text-align: right;font:  normal 12px arial; color: #333; padding: 0px; margin: 0px;"><?php echo date("F j,Y");?> <?php echo date("l"); ?></td>
                                                </tr>
                                                <tr style="height:5px"><td></td></tr>
                                                <tr>
                                                    <td>
                                                        <a href="<?php echo FB_PAGE; ?>" title="Facebook" style=" padding: 0 0 0 82px;"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/facebook1_2.png"  border="0" alt="Facebook"/></a>
                                                        <a href="<?php echo TWITTER_PAGE; ?>" title="Twitter"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/twitter1_2.png"  border="0" alt="twitter"/></a>
                                                        <a href="<?php echo LINKEDIN_PAGE; ?>" title="linked In"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/linked_in1_2.png"  border="0" alt="linked_in"/></a>
                                                        <a href="<?php echo LINKEDIN_PAGE; ?>" title="Google+"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/goog1_2.png"  border="0" alt="Google+"/></a>
							 <?php if($this->city_id){?> 
							   <?php  foreach($this->all_city_list as $CX){if($this->city_id == $CX->city_id){ ?>
                                                        <a href="<?php echo PATH.'deals/rss/'.$this->city_id.'/'.$CX->city_url;?>" title="Rss"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/rss1_2.png"  border="0" alt="Rss"/></a>
							<?php }} }?>
                                                    </td>
                                                </tr>
                                                <tr style="height:15px"><td></td></tr>
                                                <tr>
                                                    <td style=" vertical-align: top;  width: 195px; text-align: left;font:bold  11.5px arial; color: #333; padding: 0px; margin: 0px;">
                                                        The Daily Deals For <?php echo $this->cityName; ?>
                                                    </td>
                                                </tr>

                                            </table>
                                        </td>

                                    </tr>
                                    <tr style="height:2px;"><td></td></tr>
                                </table>
                            </td>
                        </tr>


                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0"  style="width:680px;    border: 1px solid #d4d4d4; background:#fff;">
                                    <tr style="height:10px"><td></td></tr>
                                    <tr>
                                        <td width="8"></td>
                                        <td style=" vertical-align: top;    padding-bottom: 7px; font: bold 18px arial; color: #333;">DAILY DEALS</td>
                                        <td width="7"></td>
                                    </tr>
                                    <tr style="height:10px" ><td></td></tr>


                                    <tr>
                                        <td width="8"></td>
	<?php $i=1; 

	foreach($this->all_deals_list_by_city as $deals){



	$symbol = CURRENCY_SYMBOL; 
	?>
	<?php if(($deals->enddate >= time())&& ($deals->purchase_count < $deals->maximum_deals_limit) ) { ?>

	<?php if($i == 1) { ?>
                                        <td>

                                            <table cellspacing="0" cellpadding="0"  >
                                                <tr>
                                                    
 <?php  if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
								<td ><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>"><img width="283px" height="353px;" src="<?php echo PATH.'images/deals/220_160/'.$deals->deal_key.'_1'.'.png';?>" alt="<?php echo $this->Lang['PRODUCTS']; ?>" title="<?php echo $deals->deal_title;?>" style="border:none;" /></a></td> 
								<?php } else {?>
								<td ><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>"><img width="283px" height="353px;" src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" alt="<?php echo $this->Lang['PRODUCTS']; ?>" title="<?php echo $deals->deal_title;?>" style="border:none;" /></a></td> 
								<?php } ?>
                                                    <td valign="top">
                                                        <table cellspacing="0" cellpadding="0">

                                                            <tr>
                                                                <td valign="top" style=" font: bold 18px arial; color: #1f1f1f; padding:0 0 0 8px;">
                                                                    <?php echo $deals->deal_title; ?> 
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td valign="top" style=" font: normal  13px/20px arial; color: #1f1f1f; padding:11px 0 0 7px;">
                                                                   <?php echo $deals->deal_description; ?> 
                                                                </td>
                                                            </tr>
                
                                                            <tr style="height:15px;"><td></td></tr>
                                                            <tr>
                                                                <td>
                                                                    <table cellspacing="0" cellpadding="0" >
                                                                        <tr>
                                                                            <td style="font:normal 22px arial; width:110px; color:#000; padding:0 10px ; margin:0; text-decoration: line-through;">
                                                                               <?php echo $symbol.round($deals->deal_price); ?>
                                                                            </td>
                                                                            <td style="font:normal 30px arial; color:#000; padding:0 ; width:133px; margin:0; ">
                                                                                <?php echo $symbol.round($deals->deal_value); ?>
                                                                            </td>


                                                                            <td style=" font: normal 13px arial; color: #000;padding: 5px; margin: 0px;vertical-align: top;">
                                                                                <a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="View This Deals"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/view.png" border="0" alt="View This Deals" /></a>
                                                                            </td>

                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
<?php } $i++; }  }  ?>
                                        <td width="7"></td>
                                    </tr>



                                    <tr style="height:5px;" ><td></td></tr>




                                    
                                    <tr>
                                        <td width="8"></td>
                                        <td>
                                            <table>
                                                <tr>
                                                                 <td style=" vertical-align: top;   font: bold 18px/35px arial; color: #333;">SIMILAR DEALS</td>
                                                            </tr>




                                                <tr style="float:left; padding:20px;">
		<?php   $i=1; foreach( $this->all_deals_list_by_city as $deals){

	$symbol = CURRENCY_SYMBOL; 
?>
	
	<?php if(($deals->enddate >=time())&&($deals->purchase_count < $deals->maximum_deals_limit)) { ?>

	<?php  if(($i!=1) && $i <= 3) { ?>
	


                                                    <td style=" width: 314px; border:  1px solid #ccc; padding: 20px;">
                                                        <table cellpadding="0" cellspacing="0" border="0">
                                                            
                                                            <tr>

						    <?php  if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1'.'.png')){ ?>
								<td ><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>"><img  width="315px" height="214px" src="<?php echo PATH.'images/deals/220_160/'.$deals->deal_key.'_1'.'.png';?>" alt="<?php echo $this->Lang['PRODUCTS']; ?>" title="<?php echo $deals->deal_title;?>" style="border:none;" /></a></td> 
								<?php } else {?>
								<td ><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" alt="<?php echo $this->Lang['PRODUCTS']; ?>" title="<?php echo $deals->deal_title;?>" style="border:none;"  width="315px" height="214px" /></a></td> 
								<?php } ?>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr>
                                                                            <td style="font:  bold 15px arial; color: #fff; width: 243px; background: #000; padding: 6px; margin: 0px;"><?php echo $deals->purchase_count;?> bought</td>
                                                                            <td style="font:  bold 18px arial;  text-align: center; background: #000; width: 71px;color: #fff; padding: 0px; margin: 0px; "><?php echo $symbol.$deals->deal_value;?></td>

                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr>
                                                                            <td style="font:  normal 12px/18px arial; color: #333;margin: 0px;padding: 4px 0 6px;">
										<p><?php echo $deals->deal_title; ?></p>
                                                                              <?php echo substr($deals->deal_description,0,300).'..'; ?> 
                                                                            </td>


                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr style="height:5px"><td></td></tr>
                                                                        <tr>
                                                                        
                                                     
                                                                            <td  style="font:  bold 15px arial; color: #333; padding-right: 120px; margin: 0px; width: 105px; text-decoration: line-through;"><?php echo $symbol.$deals->deal_price;?></td>
                                                                            <td><a href="<?php echo PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';?>" title="View This Deals"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/view2.png" border="0" alt="View This Deals" /></a></td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                  </td>


<?php  }$i++; }  } ?>
                                                    <td width="7"></td>

                                                </tr>


                                            </table>
                                        </td>

                                        <td width="7"></td>
                                    </tr>

                                    <tr>
                                        <td width="8"></td>
                                        <td style=" vertical-align: top; text-align: right; padding-bottom: 10px; padding-top: 6px;">
                                            <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/aero.png" border="0" alt="" />
                                            <a href="<?php echo PATH; ?>today-deals.html" title="VIEW ALL DAILY DEALS" style=" padding: 0px; margin: 0px;font: normal 12px arial;  color: #1e85bd; text-decoration: none;"> VIEW ALL DAILY DEALS</a>
                                        </td>
                                        <td width="7"></td>
                                    </tr>


                                    <tr>
                                        <td width="8"></td>

                                        <td style=" vertical-align: top;    padding-bottom: 7px; border-top: 1px solid #CCCCCC; font: bold 18px/35px arial; color: #333;">PRODUCTS</td>
                                        <td width="7"></td>
                                    </tr>

                                    <tr>
                                        <td width="8"></td>
                                        <td>
                                            <table>
                                                <tr>

                                                    
                                                   	 <?php 
	$j=1; 	
	foreach($this->all_products_list_by_city  as $products){
	$symbol = CURRENCY_SYMBOL; ?>
	<?php  if(($products->purchase_count < $products->user_limit_quantity)) { ?>

                                                    <td style=" padding: 10px; margin: 0px; width: 156px;">
                                                        <table  cellpadding="0" cellspacing="0" border="0">
                                                            <tr>
                                                                <td style=" width: 156px; border: 1px solid #ccc;">
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr>


							<?php  if(file_exists(DOCROOT.'images/products/290_215/'.$products->deal_key.'_1'.'.png')){ ?>
								<td ><img src="<?php echo PATH.'images/products/290_215/'.$products->deal_key.'_1'.'.png';?>" alt="<?php echo $this->Lang['PRODUCT_IMG']; ?>" title="<?php echo $products->deal_title; ?>" style="border:none;" /></td>
								<?php } else {?>
								<td ><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_products_list.png" alt="<?php echo $this->Lang['PRODUCT_IMG']; ?>" title="<?php echo $products->deal_title; ?>" style="border:none;" width="167px" height="217px" /></td>
								<?php } ?>
                                                                        </tr>


                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font:  12px arial; color: #999; padding:2px 0px; margin: 0px;"> <?php echo $products->category_name; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font: bold  12px arial; color: #3399cc; padding: 0px; margin: 0px;"> <?php echo substr($products->deal_title,0,50).'..'; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font: bold  12px arial; color: #3399cc; padding: 0px; margin: 0px;">
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr>
                                                                            <td style=" font: bold  12px arial; color: #333; padding: 0px; margin: 0px;">Price :</td>
                                                                            <td style=" font: bold  12px arial; color: red; padding: 2px 0px; margin: 0px;"><?php echo $symbol." ".$products->deal_value; ?></td>
                                                                        </tr>
                                                                    </table>
                                                                </td>


                                                            </tr>
                                                            <tr>
                                                                <td style=" font:  12px arial; color: #999; padding: 10px 0px; margin: 0px;">
                                                                    <a href="<?php echo PATH.'product/'.$products->deal_key.'/'.$products->url_title.'.html';?>" title="VIEW DETIAL"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/view3.png" border="0" alt="VIEW DETIAL" /></a>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
<?php } } ?>

                                                </tr>
                                                <tr style="height:5px"><td></td></tr>

                                            </table>

                                        </td>
                                        <td width="7"></td>
                                    </tr>
                                    <tr>
                                        <td width="8"></td>
                                        <td style=" vertical-align: top; text-align: right; padding-bottom: 10px; padding-top: 6px;">
                                            <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/aero.png" border="0" alt="" />
                                            <a href="<?php echo PATH; ?>products.html" title="VIEW ALL PRODUCTS" style=" padding: 0px; margin: 0px;font: normal 12px arial;  color: #1e85bd; text-decoration: none;">VIEW ALL PRODUCTS</a>
                                        </td>
                                        <td width="7"></td>
                                    </tr>


                                    <tr>
                                        <td width="8"></td>

                                        <td style=" vertical-align: top;    padding-bottom: 7px; border-top: 1px solid #CCCCCC; font: bold 18px/35px arial; color: #333;">AUCTIONS</td>
                                        <td width="7"></td>
                                    </tr>

                                    <tr>
                                        <td width="8"></td>
                                        <td>
                                            <table>
                                                <tr>

                                                  	 <?php 
	
	foreach($this->all_auction_list_by_city as $auction){
	$symbol = CURRENCY_SYMBOL; ?>
                                                    <td style=" padding: 10px; margin: 0px; width: 156px;">
                                                        <table  cellpadding="0" cellspacing="0" border="0">
                                                            <tr>
                                                                <td style=" width: 156px; border:  1px solid #ccc;">
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr>


					    <?php  if(file_exists(DOCROOT.'images/auction/220_160/'.$auction->deal_key.'_1'.'.png')){ ?>
								<td ><a href="<?php echo PATH.'auction/'.$auction->deal_key.'/'.$auction->url_title.'.html';?>"><img  src="<?php echo PATH.'images/auction/220_160/'.$auction->deal_key.'_1'.'.png';?>" alt="<?php echo $this->Lang['PRODUCTS']; ?>" title="<?php echo $auction->deal_title;?>" style="border:none;" /></a></td> 
								<?php } else {?>
								<td ><a href="<?php echo PATH.'auction/'.$auction->deal_key.'/'.$auction->url_title.'.html';?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/noimage_deals_list.png" alt="<?php echo $this->Lang['PRODUCTS']; ?>" title="<?php echo $auction->deal_title;?>" style="border:none;"  width="165px" height="110px" /></a></td> 
								<?php } ?>
                                                                        </tr>


                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font:  12px arial; color: #999; padding:2px 0px; margin: 0px;"> <?php echo $products->category_name; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font: bold  12px arial; color: #3399cc; padding: 0px; margin: 0px;"><?php echo substr($auction->deal_title,0,45).'..';?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font: bold  12px arial; color: #3399cc; padding: 0px; margin: 0px;">
                                                                    <table  cellpadding="0" cellspacing="0" border="0">
                                                                        <tr>
                                                                            <td style=" font: bold  12px arial; color: #333; padding: 0px; margin: 0px;">Starting Bid :</td>
                                                                            <td style=" font: bold  12px arial; color: red; padding: 2px 0px; margin: 0px;"><?php echo $symbol." ".$auction->deal_value; ?></td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style=" font:  12px arial; color: #999; padding: 10px 0px; margin: 0px;">
                                                                    <a href="<?php echo PATH.'auction/'.$auction->deal_key.'/'.$auction->url_title.'.html';?>" title="VIEW DETIAL"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/view3.png" border="0" alt="VIEW DETIAL" /></a>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>

<?php } ?>

                                                </tr>
                                                <tr style="height:5px"><td></td></tr>

                                            </table>

                                        </td>
                                        <td width="7"></td>
                                    </tr>
                                    <tr>
                                        <td width="8"></td>
                                        <td style=" vertical-align: top; text-align: right; padding-bottom: 10px; padding-top: 6px;">
                                            <img src="<?php echo PATH;?>themes/<?php echo THEME_NAME;?>/images/aero.png" border="0" alt="" />
                                            <a href="<?php echo PATH;?>auction.html" title="VIEW ALL PRODUCTS" style=" padding: 0px; margin: 0px;font: normal 12px arial;  color: #1e85bd; text-decoration: none;">VIEW ALL AUCTIONS</a>
                                        </td>
                                        <td width="7"></td>
                                    </tr>



                                </table>
                            </td>
                        </tr>


            <tr>
                <td>
                    <p  style="width:660px; margin:0px; padding: 21px 0 0 0px; font: normal 12px/21px arial; color:#333; text-align:center;">You are receiving this message because you signed up with the email address <a style="font:normal 12px arial; color:#007bd9" href="#" title="kumar@gmail.com"><?php echo $this->email; ?></a>
Please add <a style="font:normal 12px arial; color:#007bd9" href="#" title="mail@unicommerce.com ">mail@unicommerce.com </a>to your safe senders list so your WagJag messages don't end up in your 
Junk box.
                    </p>
                </td>
            </tr>
            <tr style="height:20px"><td></td></tr>
            <tr>
                <td>
                    <p style=" font:  normal 13px arial; color: #0066cc; text-align: center; padding:0; margin:0;">  <a  style=" color: #0066cc;"href="<?php echo PATH ;?>privacy-policy.php" title="Privacy Police">Privacy Policy</a></p>
                </td>
            </tr>
            <tr style="height:20px;"><td></td></tr>

            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0">
                        <tr style="height:14px;"><td></td></tr>

                    </table>
                </td>
            </tr>
        
                  
                   
        </table>


      
        
        </tr>
</td>
            </table>
    </body>
</html>


