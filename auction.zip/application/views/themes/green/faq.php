<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

                </div>
            </div>
        </div>
        <!--end-->




        <div class="contianer_outer1">
            <div class="contianer_inner">

<div class="bread_crumb">
                        <ul>
                            <li><p><a href="<?php echo PATH;?>" title="<?php echo $this->Lang['HOME1']; ?>"><?php echo $this->Lang["HOME1"]; ?></a></p></li>
                            <li><p><?php echo $this->Lang['FAQ']; ?></p></li>
                        </ul>
                    </div>
                <div class="contianer">

                    <!--content start-->
                    <div class="content_abouts">
                        <div class="content_abou_common">
                            <div class="contact_form_new">

                                <div class="faq_container">

                                    <div class="faq_section1">
										<h1 class="txt_upp"><?php echo $this->Lang['FAQ']; ?></h1>
                                      
                                    </div>

                                    <div class="faq_section1">
										<?php foreach($this->faq as $faq){ ?><h2><?php echo $faq->question; ?></h2><p><a><?php echo $faq->answer; ?></a></p><?php 	} ?>
                                       
                                      
                                    </div>

                                   
                                    <div class="faq_space">&nbsp;</div>
                                </div>
                            </div>
                            <div class="pro_tit_pagenation_1 mt20">
                                 <div class="pagenation">
				                     <?php echo $this->pagination; ?>
		                         </div>
		                    </div>	
                        </div>  
                    </div>
                    <!--end-->
                </div>
            </div>
        </div>

