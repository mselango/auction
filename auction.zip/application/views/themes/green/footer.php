<?php  if(($this->uri->last_segment()=="near-map.html")||($this->uri->last_segment()=="nearmap.html")) { ?> 

<div class="footer_outer footer_full_common">
            <div class="footer_inner">
                <div class="footer">
                    <div class="service_content full_width_footer">
                       
                        <ul>
                            <li> <a href="<?php echo PATH?>about-us.html" title="<?php echo $this->Lang['ABT']; ?>"><?php echo $this->Lang["ABT"]; ?></a></li>
                            <li class="top_mar">|</li>
                            <li><a href="<?php echo PATH?>contactus.html" title="<?php echo $this->Lang['CONTACT_US']; ?>"><?php echo $this->Lang["CONTACT_US"]; ?></a></li>
                            <li class="top_mar">|</li>
			    <?php if($this->faq_setting){ ?>
                            <li><a href="<?php echo PATH?>faq.html" title="<?php echo $this->Lang['FAQ']; ?>"><?php echo $this->Lang['FAQ']; ?></a></li>
                                                        <li class="top_mar">|</li>
			    <?php } ?>
			<?php if($this->blog_setting) { ?>
                            <li><a href="<?php echo PATH?>blog" title="<?php echo $this->Lang['BLOG']; ?>"><?php echo $this->Lang["BLOG"]; ?></a></li>
                                                        <li class="top_mar">|</li>
			<?php } ?>
			 <?php foreach($this->get_all_cms_title as $d){ ?>
                            <li> <a href="<?php echo PATH.$d->cms_url.'.php'?>" title="<?php echo $d->cms_title; ?>"><?php echo $d->cms_title;?></a></li>
                             <li class="top_mar">|</li>
                                                      

			    <?php } ?>
                        </ul>

                    </div>  
					<?php /*
                    <div class="service_content">
                        <p>Our Policies</p>
                        <ul>
                            <li><a href="#" title="Cancellations and Returns">Cancellations and Returns</a></li>
                            <li><a href="#" title="Shipping">Shipping</a></li>
                            <li><a href="#" title="Payments">Payments</a></li>
                            <li><a href="#" title="Ordering and Tracking">Ordering and Tracking</a></li>

                        </ul>                                
                    </div> 
						*/?>

                    <div class="social_ican full_width_footer2 ">
                        <p>Join Us on :</p>
                        <ul>


			                <?php if(FB_PAGE){?>
                <li><a class="facebook1" href="<?php echo FB_PAGE; ?>"  target="blank" title="<?php echo $this->Lang['FB']; ?>">&nbsp;</a></li>
                <?php }if(TWITTER_PAGE){?> 
                <li><a class="twitter1" href="<?php echo TWITTER_PAGE; ?>" target="blank" title="<?php echo $this->Lang['TW']; ?>">&nbsp;</a></li>
                <?php }if(LINKEDIN_PAGE){?> 
                <li><a class="linke_in" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="<?php echo $this->Lang['LINK']; ?>">&nbsp;</a></li>
                <?php }if(YOUTUBE_URL){?> 
                <li><a class="youtube" href="<?php echo YOUTUBE_URL; ?>" target="blank" title="You &nbsp;Tube">&nbsp;</a></li>
                <?php }if($this->city_id){?> 
                <?php  foreach($this->all_city_list as $CX){if($this->city_id == $CX->city_id){ ?>
                <li><a class="rss_1" href="<?php echo PATH.'deals/rss/'.$this->city_id.'/'.$CX->city_url;?>" target="blank" title="">&nbsp;</a></li>
				 
		     <?php }} }?>
			  <?php /* <li><a class="gooican" href="<?php echo YOUTUBE_URL; ?>" target="blank" title="google">&nbsp;</a></li> */ ?>
                        </ul>
                    </div> 
                    <div class="cridit_cards full_width_footer3">
                     
                        <ul>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/paypal.png" alt="paypal"/>&nbsp;</a></li>
                            <li><a><img  src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/visa.png" alt="visa"/>&nbsp;</a></li>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/mastercard.png" alt="mastercard"/>&nbsp;</a></li>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/discover.png" alt="discover"/>&nbsp;</a></li>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/rayal.png" alt="rayal"/>&nbsp;</a></li>

                        </ul>
                         <div class="cridit_cards1">
                        <label> Copyright &COPY; All rights reserved</label>
                                            </div>
                   
                  
 </div> 
                   

                </div>
            </div>
    <?php echo ""; ?>

        </div>

<?php } else { ?>
<div class="footer_outer">
            <div class="footer_inner">
                <div class="footer">
                    <div class="service_content">
                        <p>Service</p>
                        <ul>
                            <li> <a href="<?php echo PATH?>about-us.html" title="<?php echo $this->Lang['ABT']; ?>"><?php echo $this->Lang["ABT"]; ?></a></li>
                            <li><a href="<?php echo PATH?>contactus.html" title="<?php echo $this->Lang['CONTACT_US']; ?>"><?php echo $this->Lang["CONTACT_US"]; ?></a></li>

			    <?php if($this->faq_setting){ ?>
                            <li><a href="<?php echo PATH?>faq.html" title="<?php echo $this->Lang['FAQ']; ?>"><?php echo $this->Lang['FAQ']; ?></a></li>
			    <?php } ?>
			<?php if($this->blog_setting) { ?>
                            <li><a href="<?php echo PATH?>blog" title="<?php echo $this->Lang['BLOG']; ?>"><?php echo $this->Lang["BLOG"]; ?></a></li>
			<?php } ?>
			 <?php foreach($this->get_all_cms_title as $d){ ?>
                            <li> <a href="<?php echo PATH.$d->cms_url.'.php'?>" title="<?php echo $d->cms_title; ?>"><?php echo $d->cms_title;?></a></li>

			    <?php } ?>
                        </ul>

                    </div>  
					<?php /*
                    <div class="service_content">
                        <p>Our Policies</p>
                        <ul>
                            <li><a href="#" title="Cancellations and Returns">Cancellations and Returns</a></li>
                            <li><a href="#" title="Shipping">Shipping</a></li>
                            <li><a href="#" title="Payments">Payments</a></li>
                            <li><a href="#" title="Ordering and Tracking">Ordering and Tracking</a></li>

                        </ul>                                
                    </div> 
						*/?>

                    <div class="social_ican">
                        <p>Join Us on</p>
                        <ul>


			                <?php if(FB_PAGE){?>
                <li><a class="facebook1" href="<?php echo FB_PAGE; ?>"  target="blank" title="<?php echo $this->Lang['FB']; ?>">Facebook</a></li>
                <?php }if(TWITTER_PAGE){?> 
                <li><a class="twitter1" href="<?php echo TWITTER_PAGE; ?>" target="blank" title="<?php echo $this->Lang['TW']; ?>">Twitter</a></li>
                <?php }if(LINKEDIN_PAGE){?> 
                <li><a class="linke_in" href="<?php echo LINKEDIN_PAGE; ?>" target="blank" title="<?php echo $this->Lang['LINK']; ?>">Linked In</a></li>
                <?php }if(YOUTUBE_URL){?> 
                <li><a class="youtube" href="<?php echo YOUTUBE_URL; ?>" target="blank" title="You &nbsp;Tube">You Tube</a></li>
                <?php }if($this->city_id){?> 
                <?php  foreach($this->all_city_list as $CX){if($this->city_id == $CX->city_id){ ?>
                <li><a class="rss_1" href="<?php echo PATH.'deals/rss/'.$this->city_id.'/'.$CX->city_url;?>" target="blank" title="">Rss</a></li>
				 
		     <?php }} }?>
			  <?php /* <li><a class="gooican" href="<?php echo YOUTUBE_URL; ?>" target="blank" title="google">Google+</a></li> */ ?>
                        </ul>
                    </div> 
                    <div class="cridit_cards">
                        <p>Payment Methods</p>
                        <ul>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/paypal.png" alt="paypal"/>&nbsp;</a></li>
                            <li><a><img  src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/visa.png" alt="visa"/>&nbsp;</a></li>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/mastercard.png" alt="mastercard"/>&nbsp;</a></li>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/discover.png" alt="discover"/>&nbsp;</a></li>
                            <li><a><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/rayal.png" alt="rayal"/>&nbsp;</a></li>

                        </ul>
                   
                  
 </div> 
                    <div class="cridit_cards">
                        <label> Copyright &COPY; All rights reserved</label>
                                            </div>

                </div>
            </div>
        </div>


<?php } ?>
