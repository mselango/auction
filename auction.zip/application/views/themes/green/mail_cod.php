<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" /> 
        <title></title>
    </head>
    <body>
        <table cellspacing="0" cellpadding="0" border="0" width="700" style=" background:#fff; width:700px; ">
            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0" style=" width:600px; margin:0 0 0 50px;">
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0" >

                                    <tr>				
                                        <td style=" width:544px;margin:0px; padding:0px; height:2px;">
                                            <div style="width:116px; margin:0px; padding:0px;  height:2px;">&nbsp;</div>
                                        </td>

                                    </tr>

                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table cellspacing="0" cellpadding="0" border="0">
                                    <tr style="height:16px;"><td></td></tr>
                                    <tr>

                                        <td style="margin:0px; padding:0px;">
											
                                            <a href="<?php echo PATH; ?>" title="<?php ?>"><img src="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/images/logo.png"" border="0" alt="" /></a>
                                        </td>

                                    </tr>
                                    <tr style="height:12px;"><td></td></tr>
                                </table>
                            </td>
                        </tr>
                         <tr style="height:20px;"><td></td></tr>
                        <tr>
                            <td>
								
                                <table cellspacing="0" cellpadding="0"  style="width:600px;    border: 1px solid #ECE9E4; background:#fff;">
                                    <tr style="height:7px;"><td></td></tr>
                                    <tr>
                                        <td width="12px"></td>
                                        <td style="  font:normal 18px arial; color:#1986bb;">
											
                                        </td>

                                    </tr>
                                    <tr style="height:7px;"><td></td></tr>
                                    <tr style="height:10"><td></td></tr>
                                    <tr>
                                        <td width="15"></td>
                                        <td style="width:600px; font:bold 12px/25px arial; color:#666;">
											
										
											Your order for <span style="font:bold 12px/25px arial; color:#1E90FF;"><?php echo $this->deal_title;?> </span>has been <span style="font:bold 12px/25px arial; color:#1E90FF;"><?php echo $this->order_status;?> </span>by admin.
											
										</td>

                                    </tr>
                                  
                                
                                    <tr style="height:20px;"><td></td></tr>

                                    <tr>
                                        <td width="15"></td>
                                        <td style="font:normal 12px/25px arial; color:#000000;">
                                            Thanks,
                                        </td>
                                    </tr>
                                    <tr style="height:2px;"><td></td></tr>
                                    <tr>
                                        <td width="15"></td>
                                        <td style="font:normal 12px arial; color:#000000;">
                                            <?php echo SITENAME; ?> Team
                                        </td>
                                    </tr>
                                    <tr style=" height:5px;"><td></td></tr>
                                    <tr>
                                        <td width="8"></td>
                                        <td>
                                            <a href="<?php echo PATH; ?>" title="<?php echo SITENAME; ?>" style="font:normal 12px arial; color:#000000; text-decoration:none;"><?php echo PATH; ?></a>
                                        </td>
                                    </tr>
                                    <tr style="height:30px;"><td></td></tr>


                                </table>
                                
                            
                            </td>
                        </tr>
               

            <tr>
                <td>
                    <p  style="width:600px; margin:0px; padding: 21px 0 0 0px; font: normal 12px arial; color:#666; text-align:center;">
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <table cellspacing="0" cellpadding="0" border="0">
                        <tr style="height:14px;"><td></td></tr>

                    </table>
                </td>
            </tr>
        </table>
                </td>
            </tr>
        </table>



    </body>
</html>
