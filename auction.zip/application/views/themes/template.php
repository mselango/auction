<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<?php 
if(THEME_NAME == "mobile"){ ?>
<!DOCTYPE html>
<?php } else{?>
<!DOCTYPE html>
<?php }?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta property="og:image" content="<?php echo $this->template->metaimage; ?>"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> <?php echo $this->template->title; ?> </title>
<meta name="description" content="<?php echo $this->template->description; ?>" />
<meta name="keywords" content="<?php echo $this->template->keywords; ?>" />
<link rel="shortcut icon" href="<?php echo PATH; ?>themes/<?php echo THEME_NAME; ?>/images/favicon.png" type="image/x-icon" />

<?php  if($this->city_id){foreach($this->all_city_list as $CX){if($this->city_id == $CX->city_id){ ?>

        <link rel="alternate" type="application/atom+xml" title="<?php echo ucfirst($CX->city_name); ?> deals" href="<?php echo PATH.'deals/rss/'.$this->city_id.'/'.$CX->city_url;?>"  />
        
<?php } } } ?>
<?php 
	echo $this->template->style; 
	echo $this->template->javascript;
?>
<!--[if IE 7]>

        <link rel="stylesheet" href="<?php echo PATH;?>themes/<?php echo THEME_NAME; ?>/css/ie7-and-down.css" />
        
<![endif]-->
<head> 



</head>
<body >
	<?php  echo new View("themes/".THEME_NAME."/header"); ?>
	<div class="mt10" style="display:none;" id="citylist">
<ul>

<?php 
$a = ''; 
foreach($this->all_city_list as $city){?>
					<li <?php if($a!=$city->country_name){ ?>  style="clear:both; color:#E14948;float:left;" <?php }?> > <?php if($a!=$city->country_name){  $a = $city->country_name; echo ucfirst($city->country_name);  } else {?> <p>&nbsp;</p> <?php } ?>  <a  onclick="return changecity('<?php echo $city->city_id; ?>','<?php echo $city->city_url; ?>');" ><?php echo ucfirst($city->city_name); ?>  </a></li>
<?php } ?>

</ul>
					

 </div >
        <?php if(!empty($this->response)){  ?>
        
        <div  id="messagedisplay">            
            <div class="session_wrap">
	            <div class="session_container">
		            <div class="success_session">
			            <p><span ><?php echo $this->response; ?>.</span></p>
			            <div class="close_session_2">
				        <a class="closestatus cur" title="Close"  onclick="return closeerr();" >&nbsp;</a>
			            </div>
		            </div>
	            </div>
            </div>
        </div>
        <?php } ?>
        
        <?php  if(!empty($this->error_response)){  ?>
        
        <div id="error_messagedisplay">  
            <div class="session_wrap">
	            <div class="session_container">
		            <div class="failure_session">
			            <p ><span><?php echo $this->Lang['ERROR']; ?>!&nbsp;</span> <?php echo $this->error_response; ?></p>
			            <div class="close_session">
				        <a  title="<?php echo $this->Lang['CLOSE']; ?>" title="Close" onclick="return closeerr('err');" > &nbsp;</a>
			            </div>
		            </div>
	            </div>
             </div>
        </div>
         
      <?php }?>
	  <?php  echo $this->template->content;	?>
	  <?php	echo new View("themes/".THEME_NAME."/footer"); 
	  //echo ANALYTICS_CODE; 
	?>    
 
</body>
</html>
