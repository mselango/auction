<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form method="get" class="admin_form">
            <table class="list_table1 fl clr">
                <?php 
	            if(isset($this->search_key)){
		            $s = $this->search_key;
	            }?>
                <tr> <td><label><?php echo $this->Lang["NAME"]; ?> :</label></td>
                <td><input type = "text" name = "name" <?php if(isset($s->name)){?> value="<?php echo $s->name; ?>"<?php } ?>/></td>

                <td><label><?php echo $this->Lang["EMAIL_F"]; ?> :</label></td>
                <td><input type = "text" name = "email" <?php if(isset($s->email)){?> value="<?php echo $s->email; ?>"<?php } ?>/></td>
                <tr>
                <td><label><?php echo $this->Lang["CITY"]; ?> :</label></td>
               
                <td><select name ="city">
                <?php if(isset($s->city)){ foreach($this->city_list as $c){ if($s->city == $c->city_id){ ?>
                <option value="<?php echo $c->city_id; ?>"><?php echo ucfirst($c->city_name); }}}?></option>
                <option value=""><?php echo $this->Lang["SEL_CITY"]; ?></option>
                <?php foreach($this->city_list as $c){ ?>
                <option value="<?php echo $c->city_id; ?>"><?php echo ucfirst($c->city_name); ?></option>  
                <?php }?>
                </select></td>
		<?php  if($this->uri->last_segment() == 'merchant.html'){?>
		<?php if(count($this->users_list) > 0){ ?>
		<a href="<?php echo PATH.'admin/merchant.html?id='.$this->Lang['SEARCH'].'&name='.$this->input->get('name').'&city='.$this->input->get('city').'&email='.$this->input->get('email'); ?>" title="<?php echo $this->Lang['EXP_MER']; ?>"><span style="float:right;text-decoration: underline;"><img src="<?php echo PATH ?>images/csv.png" class="image" alt="Export Deals In CSV Format"/></span></a>

		<?php } }?>
                               
                <td></td><td></td>
                <td><input type="submit" value="<?php echo $this->Lang['SEARCH']; ?>" class="fl"/></td>
            </tr>
        </table>
        </form>
    
    <?php if(count($this->users_list)>0){?>
        <table class="list_table fl clr mt15">
        	<tr>
        	<th align="left" ><?php echo $this->Lang['S_NO']; ?></th>
            	<th align="left" ><div class="arrow"><a href="<?php echo $this->sort_url;?>param=name&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By  Name" ><?php echo $this->Lang["NAME"]; ?></a></div></th>
            	<th align="left" ><div class="arrow"><a href="<?php echo $this->sort_url;?>param=email&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By  Email" ><?php echo $this->Lang["EMAIL_F"]; ?></a></div></th>

            	<th align="left" ><div class="arrow1"><a href="<?php echo $this->sort_url;?>param=store&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By Storename" ><?php echo $this->Lang["STORE_NAME"]; ?></a></div></th>

            	<th align="left" ><div class="arrow1"><a href="<?php echo $this->sort_url;?>param=city&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By City" ><?php echo $this->Lang["CITY"]; ?></a></div></th>               
                <th align="left" ><?php echo $this->Lang["ADD_BRANCH_SHOP"]; ?></th>
                <th align="left" ><?php echo $this->Lang["MAN_BRANCH_SHOP"]; ?></th>
                <th align="left" ><?php echo $this->Lang["EDIT"]; ?></th>
                <th align="left" ><?php echo $this->Lang["B_UNB"]; ?></th>
				<?php /*<th align="left" ><?php echo 'Rating'; ?></th> */ ?>
            </tr>
            <?php $i=0; $first_item = $this->pagination->current_first_item;
                foreach($this->users_list as $u){?>
                <tr>    
                        <td align="left"><?php echo $i+$first_item; ?></td>
                        <td align="left"><a href="<?php echo PATH; ?>admin/merchant-details/<?php echo base64_encode($u->user_id); ?>.html"><?php echo ucfirst($u->firstname); ?></a></td>
                        <td align="left"><?php echo $u->email; ?></td>
                        <td align="left"><?php echo $u->store_name;?></td>		
                        <td align="left"><?php foreach($this->city_list as $c){ if($c->city_id == $u->city_id){ echo ucfirst($c->city_name);}  }?></td>
                        
                                       
                     <td align="center">
                     <?php if($u->user_status =="1"){?> 
                    	<a <?php if($u->user_status =="1"){?> href="<?php echo PATH.'admin/add-merchant-shop/'.$u->user_id;?>.html"  <?php } ?>   ><img src="<?php echo PATH."images/add_branch.png";?>" title="<?php echo $this->Lang['ADD_STR_BR']; ?>"/></a>
                    	<?php } else { ?>
                    	<img src="<?php echo PATH."images/Block_icon.png";?>" title="<?php echo $this->Lang['MERCHANT_BLO']; ?>"/>
                    	<?php } ?>
                        </td>

                        
                        <td align="center">
                    	<a href="<?php echo PATH.'admin/merchant-shop/'.$u->user_id;?>.html" ><img src="<?php echo PATH.'images/manage_branch.png';?>" title="<?php echo $this->Lang['MANG_STORE']; ?>"/>
                    	<?php $j = 0; foreach($this->getstoreslist as $c){ if($c->merchant_id == $u->user_id){ $j++; } } echo "(".$j.")  Shops"; ?> </a> 
                        </td>
                        
                        <td align="left">
                    	<a href="<?php echo PATH.'admin/edit-merchant/'.$u->user_id;?>.html" class="editicon" title="<?php echo $this->Lang['EDIT_MERCHANT']; ?>"></a>
                        </td>
                    <td>
                    	<?php if($u->user_status == 1){?>
                    	<a onclick="return blockunblockmerchant('<?php echo $u->user_id; ?>','<?php echo base64_encode($u->email); ?>','block');" class="blockicon" title="<?php echo $this->Lang['BLO_MERCHANT']; ?>"></a>
                        <?php } else{  ?>
                        <a onclick="return blockunblockmerchant('<?php echo $u->user_id; ?>','<?php echo base64_encode($u->email); ?>','unblock');" class="unblockicon" title="<?php echo $this->Lang['UNBLO_MERCHANT']; ?>"></a>

                        <?php } ?>
                 	<?php /*   <td>
				 <input type="text" size="5px" id="rating-<?php echo $u->user_id; ?>" maxlength="3" name="rating" onkeyup="return rating(this.value,'<?php echo PATH; ?>',<?php echo $u->user_id; ?>);" value="<?php echo $u->rating; ?>"> */ ?>
					</td>
                    
                </tr>
            <?php $i++;} ?>   
        </table>
    <?php } else{?><p class="nodata"><?php echo $this->Lang["NO_DATA"]; ?></p><?php }?>
	
    <?php echo $this->pagination; ?>
</div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
<?php /* <script>
function rating(rate,path,merchant_id)
{ 
	if(rate!='' && path!='' && merchant_id !=''){
		var filter = /^[0-9-+]+$/;
		if(filter.test(rate)==true){
		var url = path+'admin_merchant/shop_rating/'+merchant_id+'/'+rate;
		$.post(url,function(check){ 


				if(check!=1){ 
					alert('Two ratings are same please check');
					$("#rating-"+merchant_id).css('border','1px solid red');
					var val = check.split(',');
					$("#rating-"+merchant_id).val(rate);
					$("#rating-"+val[0]).val(val[1]);
					return true;
				}
				else{
					 $("#rating-"+merchant_id).val(rate);
					 $("#rating-"+merchant_id).css('border','');
					return true;
				}
			});
		}
		else{
			$("#rating-"+merchant_id).css('border','1px solid red');
			return false;
		}

	}
	else return false;
}
</script> */ ?>
