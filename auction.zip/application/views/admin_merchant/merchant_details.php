<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a>
  <p><?php echo $this->template->title; ?></p>
</div>
<div class="cont_container mt15 mt10">
<div class="content_top">
  <div class="top_left"></div>
  <div class="top_center"></div>
  <div class="top_rgt"></div>
</div>
<div class="content_middle">
  <div class="mergent_det">
    <fieldset>
    <legend><?php echo $this->Lang["MERCHANT_DEL"]; ?></legend>
    <table class="list_table fl clr show_details_table">
      <?php foreach($this->merchant_details as $d){			
			
			?>
      <tr>
        <th valign="top" align="left" width="20%"><?php echo $this->Lang["FIRST_NAME"]; ?></th>
        <th valign="top">:</th>
        <td align="left"><?php echo $d->firstname; ?></td>
      </tr>
      <tr>
        <th valign="top" align="left" width="20%"><?php echo $this->Lang["LAST_NAME"]; ?></th>
        <th valign="top">:</th>
        <td align="left"><?php echo $d->lastname; ?></td>
      </tr>
      <tr>
        <th valign="top" align="left" width="20%"><?php echo $this->Lang["EMAIL"]; ?></th>
        <th valign="top">:</th>
        <td align="left"><?php echo $d->email; ?></td>
      </tr>
      <tr>
        <th valign="top" align="left"><?php echo $this->Lang["MOBILE"]; ?></th>
        <th valign="top">:</th>
        <td align="left"><?php echo $d->phone_number;?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["ADDRES"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $d->address1.','.$d->address2; ?></td>
      </tr>
      <tr>
        <th align="left"><?php echo $this->Lang["PAYMENT_ACC"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $d->payment_account_id; ?></td>
      </tr>
	 <tr>
        <th align="left">Commision</th>
        <th>:</th>
        <td align="left"><?php echo $d->merchant_commission; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["CITY"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $d->city_name; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["COUNTRY"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $d->country_name; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["MERCHANT_STATUS"]; ?></th>
        <th>:</th>
        <td align="left"><?php if($d->user_status == 1){ echo "Active"; }else{ echo "Bolcked"; } ?></td>
      </tr>
      <?php } ?>
    </table>
    </fieldset>
  </div>
  <div class="mergent_det2">
    
     <?php foreach($this->store_details as $c){ ?>
    <fieldset>
      
    <legend>
    <?php echo $this->Lang["SHOP_DET"]; ?>
    </legend>
  
    <table class="list_table fl clr show_details_table">
   
      <tr>
        <th align="left" valign="top" width="20%" ><?php echo $this->Lang["SHOP_NAME"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->store_name; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["SHOP_ADDR1"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->address1; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["SHOP_ADDR2"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->address2; ?></td>
      </tr>
	<tr>
        <th align="left" >Phone Number</th>
        <th>:</th>
        <td align="left"><?php echo $c->phone_number; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["COUNTRY"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->country_name; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["CITY"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->city_name; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["SHOP_LATI"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->latitude; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["SHOP_LONG"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->longitude; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["SHOP_WEB"]; ?></th>
        <th>:</th>
        <td align="left"><?php echo $c->website; ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["MERCHANT_STATUS"]; ?></th>
        <th>:</th>
        <td align="left"><?php if($c->store_status == 1){ echo $this->Lang['ACTIVE'];  }else{ echo $this->Lang['BLOCKED']; } ?></td>
      </tr>
      <tr>
        <th align="left" ><?php echo $this->Lang["SHOP_TYPE"]; ?></th>
        <th>:</th>
        <td><?php if($c->store_type == 1){ echo $this->Lang['MAIN']; } else{ echo $this->Lang['BRANCH']; } ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
    
    
     </fieldset>
      <?php } ?>
  </div>
 
  <table class="list_table fl clr show_details_table">
    <tr>
      <td colspan="3"><a href="javascript:history.back();" class="back_btn"><?php echo $this->Lang["BACK"]; ?></a></td>
    </tr>
  </table> </div>
  <div class="content_bottom">
    <div class="bot_left"></div>
    <div class="bot_center"></div>
    <div class="bot_rgt"></div>
 
</div>
</div>
