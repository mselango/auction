<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>


 <head>
  

 <link rel="stylesheet" type="text/css" href="<?php echo PATH; ?>css/map/demo.css"/>

	<!-- Dependencies: JQuery and GMaps API should be loaded first -->
	
	<script src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>

	<!-- CSS and JS for our code -->
	<link rel="stylesheet" type="text/css" href="<?php echo PATH; ?>css/map/jquery-gmaps-latlon-picker.css"/>
	<script src="<?php echo PATH; ?>js/map/jquery-gmaps-latlon-picker.js"></script>
      
    <script>
  
   $(document).ready(function(){					   		   
	    //Close Popups and Fade Layer
	    //Fade in the fade layer 
	    $('a#close8').live('click', function() { //When clicking on the close or fade layer...
		    $('#popup6').css({'display' : 'none'});
			    $('.popup_block5').css({'display' : 'none'});
			    $('#fade').css({'display' : 'none'});
	      	
		    return false;
	    });		
    });
	function show_popup()
    {
	$('.popup_block5').css({'display' : 'block'});
	
	
    }

</script>

</head>
<div class="gllpLatlonPicker">
<div class="bread_crumb"><a href="<?php echo PATH.'admin.html'; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10" >
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
    
    <?php /* <div id="popup6" class="popup_block5">
	  
        <div class="login1">
          <div class="log_in_top1">
            <div class="share_top_lft">
              <div class="share_top_rgt">
                <div class="share_top_mid"> </div>
              </div>
            </div>
          </div>
          <div class="log_middle">
            <div class="con_mid_lft">
              <div class="con_mid_rgt">
                <div class="con_mid_mid">
					
                  </div>                
                  
                </div>
              </div>
            </div>
          </div>
          <div class="log_bot">
            <div class="con_bot_lft_r">
              <div class="con_bot_rgt_r">
                <div class="con_bot_mid_r"> </div>
              </div>
            </div>
          </div>
       
        </div>
 */ ?>  
    
            <form method="post"  class="admin_form" enctype="multipart/form-data">
    		<div class="mergent_det">
            <fieldset>
            <legend><?php echo $this->Lang["MERCHANT_ACC"]; ?></legend>

                <table>
                
                         <tr>
                                <td><label><?php echo $this->Lang["FIRST_NAME"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="firstname" maxlength="32"  value="<?php if(!isset($this->form_error['firstname']) && isset($this->userPost['firstname'])){echo $this->userPost['firstname'];}?>"/>
                                <em><?php if(isset($this->form_error['firstname'])){ echo $this->form_error["firstname"]; }?></em>
                                </td>
                        </tr>
                        
                        <tr>
                                <td><label><?php echo $this->Lang["LAST_NAME"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="lastname"  maxlength="32" value="<?php if(!isset($this->form_error['lastname']) && isset($this->userPost['lastname'])){echo $this->userPost['lastname'];}?>"/>
                                <em><?php if(isset($this->form_error['lastname'])){ echo $this->form_error["lastname"]; }?></em>
                                </td>
                        </tr>
                        
                        <tr>
                                <td><label><?php echo $this->Lang["EMAIL_F"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="email" value="<?php if(!isset($this->form_error['email']) && isset($this->userPost['email'])){echo $this->userPost['email'];}?>"/>
                                <em><?php if(isset($this->form_error['email'])){ echo $this->form_error["email"]; }?></em>
                                </td>
                        </tr>

                         <?php /*<tr>
                                <td><label><?php echo $this->Lang["RE_PASSWORD"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="password" name="cpassword" maxlength="16"/>
                                <em><?php if(isset($this->form_error['cpassword'])){ echo $this->form_error["cpassword"]; }?></em>
                                </td>
                        </tr>  */ ?>
                        
                        <tr>
                                <td><label><?php echo $this->Lang["PHONE"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>

                                <td><input type="text" name="mr_mobile"  value="<?php if(!isset($this->form_error['mr_mobile1']) && isset($this->userPost['mr_mobile1'])){echo $this->userPost['mr_mobile1'];}?>"/>
                                <em><?php if(isset($this->form_error['mr_mobile'])){ echo $this->form_error["mr_mobile"]; }?></em>
                                </td>
                        </tr>
                         <tr>
                                <td><label><?php echo $this->Lang["ADDR1"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="mr_address1" value="<?php if(isset($this->userPost['mr_address1'])){echo $this->userPost['mr_address1'];}?>"/>
                                <em><?php if(isset($this->form_error['mr_address1'])){ echo $this->form_error["mr_address1"]; }?></em>
                                </td>
                        </tr>
                        <tr>
                                <td><label><?php echo $this->Lang["ADDR2"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="mr_address2" value="<?php if(isset($this->userPost['mr_address2'])){echo $this->userPost['mr_address2'];}?>"/>
                                <em><?php if(isset($this->form_error['mr_address2'])){ echo $this->form_error["mr_address2"]; }?></em>
                                </td>
                        </tr> 
                        <tr>
                                <td><label><?php echo $this->Lang["PAYMENT_ACC"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="payment_acc" value="<?php if(!isset($this->form_error['payment_acc']) && isset($this->userPost['payment_acc'])){echo $this->userPost['payment_acc'];}?>"/>

                                <em><?php if(isset($this->form_error['payment_acc'])){ echo $this->form_error["payment_acc"]; }?></em>
                                </td>
                        </tr>  
                       </table>
            
                       </fieldset>
                       </div>
                       
                       <div class="mergent_det2">
                       <fieldset>
                       <legend><?php echo $this->Lang["STORE_DETAILS"]; ?></legend>
     
                     <table>
                       
                       
                         <tr>
                                <td width="110px;"><label><?php echo $this->Lang["STORE_NAME"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="storename" maxlength="32"  value="<?php if(!isset($this->form_error['storename']) && isset($this->userPost['storename'])){echo $this->userPost['storename'];}?>"/>
                                <em><?php if(isset($this->form_error['storename'])){ echo $this->form_error["storename"]; }?></em>
                                </td>
                        </tr>
                        
                        <tr>
                                <td><label><?php echo $this->Lang["PHONE"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="mobile" maxlength="15"  value="<?php if(!isset($this->form_error['mobile']) && isset($this->userPost['mobile'])){echo $this->userPost['mobile'];}?>"/>
                                <em><?php if(isset($this->form_error['mobile'])){ echo $this->form_error["mobile"]; }?></em>
                                </td>
                        </tr>
                         <tr>
                                <td><label><?php echo $this->Lang["ADDR1"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="address1" value="<?php if(isset($this->userPost['address1'])){echo $this->userPost['address1'];}?>"/>
                                <em><?php if(isset($this->form_error['address1'])){ echo $this->form_error["address1"]; }?></em>
                                </td>
                        </tr>
                        <tr>
                                <td><label><?php echo $this->Lang["ADDR2"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="address2" value="<?php if(isset($this->userPost['address2'])){echo $this->userPost['address2'];}?>"/>
                                <em><?php if(isset($this->form_error['address2'])){ echo $this->form_error["address2"]; }?></em>
                                </td>
                        </tr>                     
                       
                        <tr>
                                <td><label><?php echo $this->Lang["SEL_COUNTRY"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td>
                                <select name="country" onchange="return city_change_merchant(this.value);">
                                <option value=""><?php echo $this->Lang["SEL_COUNTRY"]; ?></option>
                                <?php foreach($this->country_list as $d){ ?>
                                <option value="<?php echo $d->country_id ?>" <?php if(!isset($this->form_error['country']) && isset($_POST['country'])){ if($_POST['country'] == $d->country_id){ ?> selected <?php } } ?>><?php echo $d->country_name; ?></option>
                                <?php } ?>
                                </select>
                                <em><?php if(isset($this->form_error["country"])){ echo $this->form_error["country"]; }?></em>
                                </td>
                        </tr>

                        <tr id="CitySD">
                                <td><label><?php echo $this->Lang["SEL_CITY"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td>
                               <?php if(!isset($this->form_error['city']) && isset($_POST['city'])){ ?>
				<select name="city">
				<?php foreach($this->city_list as $s){ ?>
				<?php if($s->city_id == $_POST['city']){ ?>
			                <option value="<?php echo $s->city_id; ?>" <?php if(isset($_POST['city'])){ if($_POST['city'] == $s->city_id){ ?> selected <?php } } ?>><?php echo $s->city_name; ?></option>
				<?php } } ?>
		                </select>
			<?php } else{ ?>
		                <select name="city">
		                <option value=""> <?php echo $this->Lang["CITY_FIRST"]; ?></option>
		                </select>
                        <?php } ?>
                                <em><?php if(isset($this->form_error["city"])){ echo $this->form_error["city"]; }?></em>
                                </td>
                        </tr> 
                        
                        <tr>
                                <td><label><?php echo $this->Lang["ZIP_CODE"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="zipcode" maxlength="10" value="<?php if(!isset($this->form_error['zipcode']) && isset($this->userPost['zipcode'])){echo $this->userPost['zipcode'];}?>"/>
                                <em><?php if(isset($this->form_error['zipcode'])){ echo $this->form_error["zipcode"]; }?></em>
                                </td>
                        </tr>
                        
                        <tr>
                                <td><label><?php echo $this->Lang["META_KEY"]; ?></label></td>
                                <td><label>:</label></td>
                                <td>
                                <textarea name="meta_keywords"><?php if(!isset($this->form_error["meta_keywords"])&&isset($this->userPost["meta_keywords"])){ echo $this->userPost["meta_keywords"]; }?></textarea>
                                <em><?php if(isset($this->form_error["meta_keywords"])){ echo $this->form_error["meta_keywords"]; }?></em>
                                </td>
                        </tr>

                        <tr>
                                <td><label><?php echo $this->Lang["META_DESC"]; ?></label></td>
                                <td><label>:</label></td>
                                <td>
                                <textarea name="meta_description"><?php if(!isset($this->form_error["meta_description"])&&isset($this->userPost["meta_description"])){ echo $this->userPost["meta_description"]; }?></textarea>




                                <em><?php if(isset($this->form_error["meta_description"])){ echo $this->form_error["meta_description"]; }?></em>
                                </td>
                        </tr>
                        
                         <tr>
                                <td><label><?php echo $this->Lang["WEBSITE"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="website" value="<?php if(!isset($this->form_error['website']) && isset($this->userPost['website'])){echo $this->userPost['website'];}?>"/>
                                <em><?php if(isset($this->form_error['website'])){ echo $this->form_error["website"]; }?></em>
                                </td>
                    </tr>
                   
                 
		
                    <tr>
						
						<tr>
                        <td colspan="3">
                       
                        <form name="share" method="post" action="<?php echo PATH; ?>welcome/share_offers">
              
                   
                    <input type="text" class="gllpSearchField">
		            <input type="button" class="gllpSearchButton" value="search">
		            <br/><br/>
		            <div class="gllpMap" >Google Maps</div>
		           
                   
		            </form>
                       
                        </td>
                        </tr>  
						
						
                    <td><label><?php echo $this->Lang["LATITUDE"]; ?><span>*</span></label></td>
                    <td><label>:</label></td>
                    <td>
                    <input type="text" onclick="show_popup();" name="latitude" class="gllpLatitude" readonly value="<?php if(!isset($this->form_error['latitude']) && isset($this->userPost['latitude'])){echo $this->userPost['latitude'];}?>"/>
                    <em><?php if(isset($this->form_error['latitude'])){ echo $this->form_error["latitude"]; }?></em>
                    </td>
                    </tr>
                    <tr>
                    <td><label><?php echo $this->Lang["LONGITUDE"]; ?><span>*</span></label></td>
                    <td><label>:</label></td>
                    <td>
                    <input type="text" name="longitude" class="gllpLongitude" readonly value="<?php if(!isset($this->form_error['longitude']) && isset($this->userPost['longitude'])){echo $this->userPost['longitude'];}?>"/>
                    <em><?php if(isset($this->form_error['longitude'])){ echo $this->form_error["longitude"]; }?></em>
                    <input type="hidden" class="gllpZoom" value="3"/>
		            <input type="hidden" class="gllpUpdateButton" value="update map">
                    </td>
                    </tr>
                
                       
			            <tr>
                                <td><label><?php echo $this->Lang["COMMISION"]; ?><span>*</span></label></td>
                                <td><label>:</label></td>
                                <td><input type="text" name="commission" value="<?php if(!isset($this->form_error['commission']) && isset($this->userPost['commission'])){echo $this->userPost['commission'];}?>"/>
				                <span class="pbl1">%</span>
                                <em><?php if(isset($this->form_error['commission'])){ echo $this->form_error["commission"]; }?></em>
                              
                         </td>
			
                        </tr>
                        <tr>
                                <td><label><?php echo $this->Lang["STORES_IMG"]; ?></label></td>
                                <td><label>:</label></td>
                                <td>
                                <input type="file" name="image" />
                                <em><?php if(isset($this->form_error["image"])){ echo $this->form_error["image"]; }?></em>
                                </td>
                        </tr> 
                                         
                     
                        <tr>
                                <td></td>
                                <td></td>
                                <td><input type="submit" value="<?php echo $this->Lang['SUBMIT']; ?>" /><input type="button" value="<?php echo $this->Lang['RESET']; ?>" onclick="javascript:window.location='<?php echo PATH; ?>admin/add-merchant.html'"/></td>
                        </tr>
                </table>
                
        </form>
        </div>
        
        
        
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div></div>
