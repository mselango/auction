<?php defined('SYSPATH') OR die("No direct access allowed."); ?>
<script type="text/javascript"> 
 $(document).ready(function(){
 	$("#ui-datepicker-div").hide();
 	$("#check2").click(function(){ 	
        var textVal = $(".txtChar").val();
        if(textVal == "") {
            alert('Fill this field');
            return false;
        }
        if(textVal == 0) {
            alert('The Quantity should not be zero');
            return false;
        }
        var selectsize = $(".selectsize").val();
        if(selectsize == "") {
            alert('Please fill all mandatory fields');
            return false;
        }
        if($('input[type=checkbox]:checked').length == 0){
            alert("Please select minimum one size checkbox");
            return false;
        }
    })
 });
function toggle() {
	var ele = document.getElementById("toggleText");
	var text = document.getElementById("displayText");
	if(ele.style.display == "none") {
    		ele.style.display = "block";
    		text.style.display = "none";
  	}
	else {
		ele.style.display = "none";
		text.style.display = "block";
	}
} 

        $(document).ready(function() {
	       $('#toggleText').change(function() {
               var count=$(this).val();
               $.post("<?php echo PATH;?>merchant/addmore_color?count="+count,{
                       }, function(response){ 
                               $("#city_display").append(response);
                       });
               });
          });
</script>

<script language="javascript"> 
function toggle() {
	var ele = document.getElementById("SizeText");
	var text = document.getElementById("displayText");
	if(ele.style.display == "none") {
    		ele.style.display = "block";
    		text.style.display = "none";
  	}
	else {
		ele.style.display = "none";
		text.style.display = "block";
	}
} 

        $(document).ready(function() {
	       $('#SizeText').change(function() {
               var count=$(this).val();
               $.post("<?php echo PATH;?>merchant/addmore_size?count="+count,{
                       }, function(response){ 
                               $("#size_display").append(response);
                       });
               });
          });
</script>
<SCRIPT language="Javascript">
      
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode        
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
            
         return true;
          
      }
      
      
      
   </SCRIPT>
<script type="text/javascript" src="<?php echo PATH ?>js/multiimage.js"></script>
<div class="bread_crumb"><a href="<?php echo PATH."merchant.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
<div class="chart_2 fl">
    <ul>
    <li  id="userdate" class=" selected fl"> 
      <div class="tab1"></div>
      <div class="tab2" ><a  onclick="return User_date();" id="userdate">PRODUCT DETAILS</a></div>
      <div class="tab3"></div>
    </li>
        
    <li class=" fl" id="reflist">
      <div class="tab1"></div>
      <div class="tab2" ><a onclick="return User_ref();"  id="reflist">PRODUCT IMAGE</a></div>
      <div class="tab3"></div>
    </li>    
    <li class=" fl" id="useryear">
      <div class="tab1"></div>
      <div class="tab2" ><a onclick="return User_year();"  id="useryear">SHIPPING / COLOR </a></div>
      <div class="tab3"></div>
    </li>
    <li class=" fl" id="usermonth">
      <div class="tab1"></div>
      <div class="tab2" ><a onclick="return User_month();"  id="usermonth">SEO FEATURE</a></div>
      <div class="tab3"></div>
    </li>

  </ul>
</div> 
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form action="" method="post" class="admin_form" enctype="multipart/form-data" id="addFormId">
         <div class="mergent_det2 user_date">
            <table>
           
                <tr>
                    <td><label><?php echo $this->Lang["PRODUCT_TITLE"]; ?></label> <span>*</span></td>
		   
                    <td><label>:</label></td>
                    <td>
                    	<input type="text" name="title" value="<?php if(!isset($this->form_error["title"])&&isset($this->userPost["title"])){ echo $this->userPost["title"]; }?>" />
                      	<em><?php if(isset($this->form_error["title"])){ echo $this->form_error["title"]; }?></em>
                   	</td>
                </tr>
                
                 <tr>
                    <td><label><?php echo $this->Lang["CATEGORY"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                    	<select name="category" onchange="merchant_change_category(this.value);">
                        	<option value=""><?php echo $this->Lang['SEL_CATEGORY']; ?></option>
							<?php foreach($this->category_list as $main){ if($main->product == 1 ) { ?>
                                    <option value="<?php echo $main->category_id?>" <option value="<?php echo $main->category_id?>" <?php if(!isset($this->form_error['category']) && isset($_POST['category'])){  if($_POST['category'] == $main->category_id){ ?>selected<?php } } ?>><?php echo ucfirst($main->category_name); ?></option>    
                            <?php } } ?>
                    	</select>
                    	<em><?php if(isset($this->form_error["category"])){ echo $this->form_error["category"]; }?></em>
					</td>
                </tr>
                     
                <tr id="category">
                    <td><label><?php echo $this->Lang['SEL_SUB_CAT']; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <?php if(!isset($this->form_error['category']) && isset($_POST['category'])){ ?>
                        <select name="sub_category[]" multiple="multiple">

			<?php foreach($this->sub_category_list as $s){ ?>
				<?php if($s->main_category_id == $_POST['category']){ ?>
			                <option value="<?php echo $s->category_id; ?>" <?php if(isset($_POST['sub_category'])){ if($_POST['sub_category'] == $s->category_id){ ?> selected <?php } } ?>><?php echo $s->category_name; ?></option>
				<?php } } ?>
		                </select>
			<?php } else{ ?>
		                <select name="sub_category">
		                <option value=""><?php echo $this->Lang['SEL_CAT_FIRST']; ?></option>
		                </select>
                        <?php } ?>
                        <em><?php if(isset($this->form_error["sub_category"])){ echo $this->form_error["sub_category"]; }?></em>
					</td>
		
                </tr> 
                 <tr>
                    <td>
                        <input type="hidden" name="deal_type" value="2" />
                    </td>
                </tr>

                <tr>
                    <td><label><?php echo $this->Lang["PRICE"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <input type="text" name="price" maxlength="8" value="<?php if(!isset($this->form_error["price"])&&isset($this->userPost["price"])){ echo $this->userPost["price"]; }?>" />
                        <em><?php if(isset($this->form_error["price"])){ echo $this->form_error["price"]; }?></em>
                    </td>
                </tr>
                
                <tr>
                    <td><label><?php echo $this->Lang["DEALVALUE"]; ?></label><span>*</span></td>
		
                    <td><label>:</label></td>
                    <td>
                        <input type="text" name="deal_value" maxlength="8" value="<?php if(!isset($this->form_error["deal_value"])&&isset($this->userPost["deal_value"])){ echo $this->userPost["deal_value"]; }?>" />
                        <em><?php if(isset($this->form_error["deal_value"])){ echo $this->form_error["deal_value"]; }?></em>
                    </td>
                </tr>

           	<tr>
                    <td><label><?php echo $this->Lang["DESC"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                    <textarea name="description" ><?php if(!isset($this->form_error["description"])&&isset($this->userPost["description"])){ echo $this->userPost["description"]; }?></textarea>
                        <em><?php if(isset($this->form_error["description"])){ echo $this->form_error["description"]; }?></em>
                    </td>
                </tr>
            
                     
                <tr id="shop">
                    <td><label><?php echo $this->Lang["SEL_SHOP"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <select name="stores">
							<?php foreach($this->shop_list as $c){ ?>
								<option value="<?php echo $c->store_id; ?>"><?php echo $c->store_name; ?></option>
							<?php } ?>
                        </select>
                        <em><?php if(isset($this->form_error["stores"])){ echo $this->form_error["stores"]; }?></em>
					</td>
		
                        </tr> 
                
                        <input type="hidden" onchange="return checkedsizeadd(this)" name="size_val" value="1">
                        
                         <tr >
                    <td><label>Your Select Size / Quantity</label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                                <span id="size_display"></span>
                        
                    </td>
                    
                </tr>     
                    
                <tr>
                    <td><label>Product Size</label><span>*</span></td>
                    <td><label>:</label></td>
                                
                    <td>
 
                        <select name="size_tag[]" id="SizeText" class="selectsize">
			              <option value="">Select Size</option>
			            <?php foreach($this->product_size as $size){
			            ?>
			            <option value="<?php echo $size->size_id; ?>" ><?php echo $size->size_name; ?></option>
			            <?php 
			            } ?>
			            </select>
			            <em><?php if(isset($this->form_error["size_tag[]"])){ echo $this->form_error["size_tag[]"]; }?></em>
                    </td>
                </tr>
                       
                            
                
                </table>
                </div>   		
			  
			  <div class="mergent_det2 user_month">
			  <fieldset>
    		<legend><?php echo "PRODUCTS SEO DETAILS" ?></legend>
			  <table>
                <tr>
                    <td><label><?php echo $this->Lang["META_KEY"]; ?></label></td>
                    <td><label>:</label></td>
                    <td>
                        <textarea name="meta_keywords"><?php if(!isset($this->form_error["meta_keywords"])&&isset($this->userPost["meta_keywords"])){ echo $this->userPost["meta_keywords"]; }?></textarea>
                        <em><?php if(isset($this->form_error["meta_keywords"])){ echo $this->form_error["meta_keywords"]; }?></em>
                    </td>
                </tr>
                
                <tr>
                    <td><label><?php echo $this->Lang["META_DESC"]; ?></label></td>
                    <td><label>:</label></td>
                    <td>
                        <textarea name="meta_description"><?php if(!isset($this->form_error["meta_description"])&&isset($this->userPost["meta_description"])){ echo $this->userPost["meta_description"]; }?></textarea>
                        <em><?php if(isset($this->form_error["meta_description"])){ echo $this->form_error["meta_description"]; }?></em>
                    </td>
                </tr>
                </table>
                </fieldset>
                </div>   
                
                
                <div class="mergent_det2 user_ref">
			    <fieldset>
    		<legend><?php echo "PRODUCTS IMAGES DETAILS" ?></legend>
			  <table>

		 		<tr>
                    <td><label>Auto post to facebook  </label></td>
                    <td><label>:</label></td>
                    <td>


		 <input type="radio" name="autopost" <?php if($this->session->get("facebook_status")==1) {?> checked <?php } ?>  value="1" > Yes <input type="radio" name="autopost" value="2"> No
			</td>
                </tr>

                <tr>
                    <td><label><?php echo $this->Lang["PRODUCT_IMG"]; ?></label></td>
                    <td><label>:</label></td>
                                
                    <td>
                        <div class = "inputs">
                        <input type="file" name="image[]"  id="first" onchange="return validateFileExtension(this)" /></div>
                        <input type="button" id="add" value="<?php echo $this->Lang['MRE_IMG']; ?>" >
                        <input type="button" id="remove" value="<?php echo $this->Lang['RMV']; ?>" >
                        <em><?php if(isset($this->form_error["image"])){ echo $this->form_error["image"]; }?></em>
                        <label>Image upload size <?php echo '500'; ?> X <?php echo '800'; ?> </label>
                    </td>
                </tr>
                </table>
                </fieldset>
                </div> 		  
			    
			  
			  <div class="mergent_det2 user_year">
			  
			  <fieldset>
    		<legend><?php echo "SHIPPING DETAILS" ?></legend>
			  <table>
			  
                 
                <tr id="shipping">
                    <td><label>Shipping Amount</label></td>
                    <td><label>:</label></td>
                    <td>
                         <input type="text" name="shipping_amount" maxlength="18" value="<?php if(!isset($this->form_error["shipping_amount"])&&isset($this->userPost["shipping_amount"])){ echo $this->userPost["shipping_amount"]; }?>" />
                        <em><?php if(isset($this->form_error["shipping_amount"])){ echo $this->form_error["shipping_amount"]; }?></em>
					</td>
                </tr> 
			  </table>
			  </fieldset>
			  <fieldset>
    		<legend><?php echo "PRODUCTS COLOR DETAILS" ?></legend>
			  <table>
                <tr>
                    <td><label>Add Color Field</label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <input type="radio" onchange="return checkedcolorremove(this)" name="color_val" value="0" checked>No<br>
                        <input type="radio" onchange="return checkedcoloradd(this)" name="color_val" value="1">Yes
                    </td>
                 </tr>
                 
                 <tr class="addcolor">
                    <td><label>Your Select Color</label></td>
                    <td><label>:</label></td>
                    <td>
                                <span id="city_display"> </span>
                        
                    </td>
                    
                </tr>
                 
                 <tr class="addcolor">
                    <td><label>Product Color</label></td>
                    <td><label>:</label></td>
                                
                    <td>
                        
                        <select name="city_tag[]" id="toggleText" >
			              <option value="">Select city</option>
			            <?php foreach($this->color_code as $CityL){
			            ?>
			            <option value="<?php echo $CityL->id; ?>" style='color:#<?php echo $CityL->color_code; ?>'; ><?php echo $CityL->color_name; ?></option>
			            <?php 
			            } ?>
			            </select>
                    </td>
                </tr>
                
                </table>
                           </fieldset>
                           
                           
                </div>
                
                <?php /*
                <tr class="addcolor">
                    <td><label>Product Color</label></td>
                    <td><label>:</label></td>
                                
                    <td>
                        <div class = "inputs_text">
                        <input type="text" name="color[]"  id="firsttext" onchange="return validateFileExtensiontext(this)" /></div>
                        <input type="button" id="addtext" value="Add color" >
                        <input type="button" id="removetext" value="<?php echo $this->Lang['RMV']; ?>" >
                        <em><?php if(isset($this->form_error["image"])){ echo $this->form_error["image"]; }?></em>
                    </td>
                </tr>
                    */ ?>
                

                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="<?php echo $this->Lang['SUBMIT']; ?>"  id="check2"/><input type="button" value="<?php echo $this->Lang['RESET']; ?>" onclick="javascript:window.location='<?php echo PATH; ?>merchant/add-products.html'"/></td>
                </tr>
           
        </form>
        
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
