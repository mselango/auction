<?php defined('SYSPATH') OR die("No direct access allowed."); ?>
<div class="bread_crumb"><a href="<?php echo PATH."merchant.html"; ?>" title="Home"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form action="" method="post" class="admin_form" enctype="multipart/form-data">
            <table>
                <tr>
                    <td><label><?php echo $this->Lang["CODE"]; ?></label> <span>*</span></td>
		   
                    <td><label>:</label></td>
                    <td>
                    	<input type="text" name="code" value="<?php if(!isset($this->form_error['code'])&&isset($this->userPost['code'])){ echo $this->userPost['code']; }?>" />
                      	<em><?php if(isset($this->form_error['code'])){ echo $this->form_error['code']; }?></em>
                   	</td>
                </tr>
                
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="<?php echo $this->Lang['SUBMIT']; ?>" /><input type="button" value="<?php echo $this->Lang['RESET']; ?>" onclick="javascript:window.location='<?php echo PATH; ?>merchant/couopn_code.html'"/></td>
                </tr>
            </table>
        </form>
        
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
  
         <table class="list_table fl clr mt20">
	
 		       <?php if(isset($this->deal_list)){ 
                        foreach($this->deal_list as $u){?>
                        
                        <th style=" float:left;  text-align:center; background:none;">
			<?php if ($u->coupon_code_status== 1){ 
									echo "<div style='padding-bottom:10px;'>"." <th style='float:left; width:100px; text-align:center; background:none;   margin: 0px 0 0 263px; border:none;
   
    position: absolute; width:200px;'><font color='green'>".$this->Lang['COUPON_AVIL']."</font></th>"."</div>";  ?>
									<?php } else { 
									echo "<div style='padding-bottom:10px;'>"."<th style='float:left; width:100px; text-align:center; background:none;   margin: 0px 0 0 263px; border:none;
   
    position: absolute; width:200px;'><font color='red'>".$this->Lang['COUPON_ALREADY']."</font></th>"."</div>";  ?>
<?php }?>
			</th>
			
			<tr> 
			<th align="left" width="10%"><?php echo $this->Lang["DEAL_IMG"]; ?></th> 
			<th align="left" width="15%"><?php echo $this->Lang["DEALS_NAME"]; ?></th>
			<th align="left" width="12%"><?php echo $this->Lang["PRICE"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></th>
			<th align="left" width="15%"><?php echo $this->Lang["DEALVALUE"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></th>
			<th align="left" width="15%"><?php echo $this->Lang["SAVINGS"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></th>
		        <th align="left" width="20%"><?php echo $this->Lang["COUPON_CODE"]; ?></th>
			 <th align="left" width="20%">Manage</th>
			
                        </tr>
                        <td align="left">
                       
                        <?php if(file_exists(DOCROOT.'images/deals/220_160/'.$u->deal_key.'_1.png')) { ?>
                        
	                <img border="0" src= "<?php echo PATH.'images/deals/220_160/'.$u->deal_key.'_1'.'.png';?>" alt="" width="80" />
	                
	                <?php } else { ?>
	                
	                <img border="0" src= "<?php echo PATH.'themes/'.THEME_NAME.'/images/noimage_products_list.png';?>" alt="" width="80" />
	                <?php } ?>
                       
                       </td>
                        <td align="left"><?php echo $u->deal_title; ?></td>
		        <td align="left"><?php echo $u->deal_price; ?></td>
		        <td align="left"><?php echo $u->deal_value; ?></td>
         	        <td align="left"><?php echo $u->deal_savings; ?></td>
		        <td align="left"><?php echo $u->coupon_code; ?></td>
	                <td><a onclick="return close_deal('<?php echo $u->deal_id; ?>','<?php echo $u->coupon_code; ?>','close');"<?php if($u->coupon_code_status == 1){  ?>  class="close" <?php }else { }?> ></a></td>
         	     <?php  } }?>
               
         </table>
