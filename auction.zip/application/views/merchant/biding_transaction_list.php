<?php defined('SYSPATH') OR die("No direct access allowed."); ?>

<?php if(count($this->transaction_auction_list) > 0){ ?>
        <table class="list_table fl clr mt20">
        	<tr>
			<th align="left" ><?php echo $this->Lang["S_NO"]; ?></span></th>
			<?php if($this->uri->segment(2) != "view-auction"){  ?>
			<th align="left" ><div class="arrow"><a href="<?php echo $this->sort_url;?>param=username&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By  Name" ><?php echo $this->Lang["USERS"]; ?></a></div></th>
			
			<th align="left" ><div class="arrow1"><a href="<?php echo $this->sort_url;?>param=title&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By  Deal Title" >Auction Title</a></div></th>
			
			<th align="left" ><div class="arrow3"><a href="<?php echo $this->sort_url;?>param=bidamount&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By  Bid Amount" >Biding Price<?php echo '('.CURRENCY_SYMBOL.')';?></a></div></th>
			<th align="left" ><div class="arrow3"><a href="<?php echo $this->sort_url;?>param=shipping_fee&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By  Shipping Fee" >Shipping Fee<?php echo '('.CURRENCY_SYMBOL.')';?></a></div></th>
			<?php } else { ?>	
			<th align="left"> <?php echo $this->Lang["USERS"]; ?> </th> 			
			<th align="left"> Auction Title </th>
			<th align="left"> Biding Price<?php echo '('.CURRENCY_SYMBOL.')';?> </th>
			<th align="left"> Shipping Fee<?php echo '('.CURRENCY_SYMBOL.')';?> </th>
			<?php } ?>
			<th align="left" > Pay Amount<?php echo '('.CURRENCY_SYMBOL.')';?> </th>
			<?php if(($this->uri->segment(2) == "view-auction")||($this->uri->segment(2) == "view-auction")||($this->uri->last_segment() == "all-transaction.html")||($this->uri->segment(2) == "view-user")||($this->uri->segment(2) == "all-transaction")){  ?>				
            <th align="left" ><?php echo $this->Lang["STATUS"]; ?></th>	
			<?php  } ?>		
			<th align="left" ><?php echo $this->Lang["TRANS_DATE"]; ?></th>
			<th align="left" ><?php echo $this->Lang["TRANS_TYPE"]; ?></th>
                </tr>
           <?php $i = 0;  if($this->uri->segment(2) == "view-auction") {  $first_item = 1; } else {  $first_item = $this->pagination->current_first_item; }
                
            $tot_quan = count($this->transaction_auction_list); 
			$tot_amount = "";
			$tot_commission = "";
			$biding_amount = "";
			$shipping_amount = "";
			
			foreach($this->transaction_auction_list as $u){?>
                <tr> 
         	    <td align="center"><?php echo $i+$first_item; ?></span></td>	
         	   <?php if($this->uri->segment(2) != "view-user"){  ?>
		    <td align="left"><?php echo ucfirst($u->firstname); ?></td>
		    <?php } ?>
		    <?php if($this->uri->segment(2) != "view-auction"){  ?>
		   
		   <td align="left"><a href="<?php echo PATH.'merchant/view-auction/'.$u->deal_key.'/'.$u->deal_id.'.html';?>" title="<?php echo $u->deal_title; ?>"><?php echo $u->deal_title; ?></a></td>
		    <?php } else { ?>	
			<td align="left" > <?php echo $u->deal_title; ?> </td>
			<?php } ?>
		    <td align="center"><?php echo $u->bid_amount; ?></td>
		    <?php $biding_amount +=$u->bid_amount; ?>
		    <td align="center"><?php echo $u->shipping_amount; ?></td>
		    <?php $shipping_amount +=$u->shipping_amount; ?>
		    <td align="center"><?php echo $u->amount; ?></td>
		    <?php $tot_amount +=$u->amount; ?>
			<?php if(($this->uri->segment(2) == "view-auction")||($this->uri->segment(2) == "view-auction")||($this->uri->last_segment() == "all-transaction.html")||($this->uri->segment(2) == "view-user")||($this->uri->segment(2) == "all-transaction")){  ?>
		    <td ><span class="align">
		    <?php if($u->payment_status=="SuccessWithWarning"){ echo '<span class="clor">'. $this->Lang["SUCCESS"] .'</span>'; } ?>
		    <?php if($u->payment_status=="Completed"){ echo '<span class="clor3">'. $this->Lang["COMPLETED"] .'</span>'; } ?>
		    <?php if($u->payment_status=="Success"){ echo '<span class="clor">'. $this->Lang["SUCCESS"] .'</span>'; } ?>
		    <?php if($u->payment_status=="Pending"){ echo '<span class="clor4">'.$this->Lang["PENDING"].'</span>'; } ?>
		    
		    </span></td>
			<?php } ?>
             <td align="left"><?php echo date('d-M-Y h:i:s',$u->transaction_date); ?></td>
                    
                    <td ><span class="align">
		    <?php if($u->type=="1"){ echo '<span class="clor2">'. $this->Lang["PAYPAL_CREDIT"] .'</span>'; } ?>
		    <?php if($u->type=="2"){ echo '<span class="clor2">'. $this->Lang["PAYPAL"] .'</span>'; } ?>
		    <?php if($u->type=="3"){ echo '<span class="clor2">'. $this->Lang["REF_PAYMENT"] .'</span>'; } ?>
		    <?php if($u->type=="4"){ echo '<span class="clor2">'. "Authorize.net(".$u->transaction_type.")" .'</span>'; } ?>
		    </span></td>
                </tr>
            <?php  $i++;} ?> 
        </table> 
        
        <table class="list_table fl clr mt20">
            
           <th align="left" >
           <fieldset>
    		<legend><?php echo $this->Lang["PAYMENT_DETAILS"]; ?></legend>
         <div class="value_total_in">
           
           <div class="value_amount"><p align="left"> Total Biding Count</p> <b>:</b><span align="center"><?php echo $tot_quan; ?></span></div>
            <div class="value_amount"><p align="left"><?php echo $this->Lang["TOT_PURC_AMOUNT"]; ?> </p><b>:</b><span align="center"> <?php echo CURRENCY_SYMBOL.$tot_amount; ?> </span></div>
            <?php if($this->user_type != 3){  ?>
             <div class="value_amount"><p align="left">Total Biding Price  </p><b>:</b><span align="center"><?php echo CURRENCY_SYMBOL.$biding_amount; ?></span></div>
             <?php } ?>
            
             <div class="value_amount"><p align="left">Total Shipping Fees </p><b>:</b><span align="center"> <?php echo CURRENCY_SYMBOL.($shipping_amount); ?> </span></div> 
           
             </th>       
             
            </div> 
           </fieldset>
            </table>
  <?php } else{?><p class="nodata">No Auction Products Found</p><?php }?>
