<?php defined('SYSPATH') OR die("No direct access allowed."); ?>
    <script type="text/javascript"> 
    $(document).ready(function(){
        $("#yourFormId").submit(function() {
        var textVal = $(".txtChar").val();
        if(textVal == "") {
            alert('Fill this field');
            return false;
        }
		 if(textVal == 0) {
            alert('The Quantity should not be zero');
            return false;
        }
    });

    $("#ui-datepicker-div").hide();
        $("#check2").click(function(){
            if($('input[type=checkbox]:checked').length == 0){
                alert("Please select minimum one size checkbox");
                return false;
            }
        })
    });
    </script>
    <SCRIPT language="Javascript">
          function isNumberKey(evt)
          {
             var charCode = (evt.which) ? evt.which : event.keyCode        
             if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
                
             return true;
              
          }
    </SCRIPT>
     <style>
#fade { background: #000; position: fixed; left: 0; top: 0; width: 100%; height: 100%; opacity: 0.5; z-index: 9999; }
.popup{ float: left;position: fixed; width:40%;  z-index: 99999; background: white; border-color:red;clear:both;top:200px; left:580px;  padding: 0px; }

</style>
<script type="text/javascript" src="<?php echo PATH ?>js/multiimage.js"></script>

<div class="bread_crumb"><a href="<?php echo PATH."merchant.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10">
<div class="chart_2 fl">
    <ul>
    <li  id="userdate" class=" selected fl"> 
      <div class="tab1"></div>
      <div class="tab2" ><a  onclick="return User_date();" id="userdate">PRODUCT DETAILS</a></div>
      <div class="tab3"></div>
    </li>
    
    <li class=" fl" id="reflist">
      <div class="tab1"></div>
      <div class="tab2" ><a onclick="return User_ref();"  id="reflist">PRODUCT IMAGE</a></div>
      <div class="tab3"></div>
    </li>
      
    <li class=" fl" id="useryear">
      <div class="tab1"></div>
      <div class="tab2" ><a onclick="return User_year();"  id="useryear">SHIPPING / COLOR / SIZE</a></div>
      <div class="tab3"></div>
    </li>
     <li class=" fl" id="usermonth">
      <div class="tab1"></div>
      <div class="tab2" ><a onclick="return User_month();"  id="usermonth">SEO FEATURE</a></div>
      <div class="tab3"></div>
    </li>

  </ul>
</div> 
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form action="" method="post" class="admin_form" enctype="multipart/form-data" id="yourFormId" >
        <?php foreach($this->product as $u){?>
            <div class="mergent_det2 user_date">
            <table>
                <tr>
                    <td><label><?php echo $this->Lang["PRODUCT_TITLE"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                    	<input type="text" name="title" value="<?php echo $u->deal_title; ?>" />
                      	<em><?php if(isset($this->form_error["title"])){ echo $this->form_error["title"]; }?></em>
                   	</td>
                </tr>              
                <tr>
                    <td><label><?php echo $this->Lang["CATEGORY"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                    	<select name="category" onchange="return merchant_change_category(this.value);">
                        	<option value=""><?php echo $this->Lang['SEL_CATEGORY']; ?></option>
							<?php foreach($this->category_list as $main){ if($main->product == 1 ) { ?>
                                    <option value="<?php echo $main->category_id?>" <option value="<?php echo $main->category_id?>" <?php if($main->category_id == $u->category_id){ ?>selected<?php } ?>><?php echo ucfirst($main->category_name); ?></option>    
                            <?php } } ?>
                    	</select>
                    	<em><?php if(isset($this->form_error["category"])){ echo $this->form_error["category"]; }?></em>
					</td>
                </tr>
                     
                <tr id="category">
                    <td><label><?php echo $this->Lang['SEL_SUB_CAT']; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td >
				 
                        <select name="sub_category[]" multiple="multiple" >
			<?php $cat_ids = explode(',',$u->sub_category_id); foreach($this->sub_category_list as $d){ if($u->category_id == $d->main_category_id) { ?>
			                <option value="<?php echo $d->category_id; ?>" <?php foreach($cat_ids as $ci){ if($d->category_id == $ci){ ?> selected <?php } } ?> > <?php echo $d->category_name; ?></option>
				<?php } }  ?>
		                </select>
			
                        <em><?php if(isset($this->form_error["sub_category"])){ echo $this->form_error["sub_category"]; }?></em>
					</td>
		
                </tr>  
                
                <tr> 
                  <td>
                      <input type="hidden" name="deal_type" value="2" <?php if($u->deal_type == 2){ ?>checked="checked" <?php } ?>/> 
                    </td>
                </tr>
                           
                <tr>
                    <td><label><?php echo $this->Lang["PRICE"]; ?> </label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <input type="text" name="price" maxlength="8" value="<?php echo $u->deal_price; ?>" />
                        <em><?php if(isset($this->form_error["price"])){ echo $this->form_error["price"]; }?></em>
                    </td>
                </tr>
                
		<tr>
                    <td><label><?php echo $this->Lang["DEALVALUE"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <input type="text" name="deal_value" maxlength="8" value="<?php echo $u->deal_value; ?>" />
                        <em><?php if(isset($this->form_error["deal_value"])){ echo $this->form_error["deal_value"]; }?></em>
                    </td>
                </tr>
		<tr>
                    <td><label><?php echo $this->Lang["DESC"]; ?></label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                       <textarea name="description" ><?php echo $u->deal_description;?></textarea>
			 <em><?php if(isset($this->form_error["description"])){ echo $this->form_error["description"]; }?></em>
                    </td>
                </tr> 
				<tr id="shop">
                    <td><label><?php echo $this->Lang["SEL_SHOP"]; ?><span>*</span></label></td>
                    <td><label>:</label></td>
                    <td>
                        <select name="stores">
			<?php foreach($this->shop_list as $d){ ?>
				<option value=<?php echo $d->store_id; ?> <?php if($u->shop_id==$d->store_id) { ?> selected="selected" <?php  } ?>><?php echo $d->store_name; ?></option>
			<?php }  ?> 
                        </select>
                        <em><?php if(isset($this->form_error["stores"])){ echo $this->form_error["stores"]; }?></em>
					</td>
                 </tr> 
                <input type="hidden" onchange="return checkedsizeadd(this)" name="size_val" value="1" >
                 <tr>
                    <td><label>Your Select Size / Quantity</label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                    <?php if(count($this->selectproduct_size)>0) { ?>
                         <span id="size_display"> </span>
                        <?php 
                            foreach($this->selectproduct_size as $c){
                            echo "<span style='width:3px;padding:3px;'>  Select size = ".ucfirst($c->size_name)." <input type='checkbox' name='size[]' checked='checked' value='".$c->size_id."'></span> <br> <span style='width:3px;padding:3px;'><input type='text' name='size_quantity[]'  value='".$c->quantity."' class='txtChar' onkeypress='return isNumberKey(event)'></span> <br> ";
                        } } else { ?>
                        <span id="size_display" > </span>
                        <?php }?>
                    </td>
                </tr>
                    <script language="javascript"> 
                    function toggle() {
                        var ele = document.getElementById("SizeText");
                        var text = document.getElementById("displayText");
                            if(ele.style.display == "none") {
                                ele.style.display = "block";
                                text.style.display = "none";
                            }
                            else {
                                ele.style.display = "none";
                                text.style.display = "block";
                            }
                    } 

                    $(document).ready(function() {
                        $('#SizeText').change(function() {
                            var count=$(this).val();
                            $.post("<?php echo PATH;?>merchant/editmore_size?count="+count+"&deal="+<?php echo $u->deal_id; ?>,{
                            }, function(response){ 
                            $("#size_display").append(response);
                            });
                        });
                    });
                    </script>
                      <?php if(count($this->product_size)>0) { ?>
                        <td><label>Product Size</label><span>*</span></td>
                        <td><label>:</label></td>
                        <td >
                        <?php $user_city=""; foreach($this->selectproduct_size as $city1){
			                $user_city .= $city1->size_id.",";
			            }
			            $city_Tags=explode(",", substr($user_city, 0, -1));
			            ?>
                        <select name="Size_tag[]" id="SizeText">			  
			            <option value="">Select Size</option>
			            <?php $i=1;
			            foreach($this->product_size as $CityL){
	 		              if(!in_array($CityL->size_id, $city_Tags)){
			            ?>
			            <option  value="<?php echo $CityL->size_id; ?>"><?php echo ucfirst($CityL->size_name); ?> </option> 
			            <?php  }
			            } ?>
			            </select>
			            </td>
                    </tr>
                    <?php 
                    } else {?>
                    <tr >
                    <td><label>Product Size</label></td>
                    <td><label>:</label></td>
                    <td>
                        <select name="city_size[]" id="SizeText" >
			            <option value="">Select Size</option>
			            <?php foreach($this->selectproduct_size as $CityL){ ?>
			            <option value="<?php echo $CityL->size_id; ?>"><?php echo ucfirst($CityL->size_name); ?></option>
			            <?php } ?>
			            </select>
                    </td>
                </tr>
                <?php } ?>
             </table>                          
          </div> 
			  <div class="mergent_det2 user_month">
			  <fieldset>
    		<legend><?php echo "PRODUCTS SEO DETAILS" ?></legend>
			  <table>
                
                
                <tr>
                    <td><label><?php echo $this->Lang["META_KEY"]; ?></label></td>
                    <td><label>:</label></td>
                    <td>
                        <textarea name="meta_keywords"><?php echo $u->meta_keywords; ?></textarea>
                        <em><?php if(isset($this->form_error["meta_keywords"])){ echo $this->form_error["meta_keywords"]; }?></em>
                    </td>
                </tr>
                
                 <tr>
                    <td><label><?php echo $this->Lang["META_DESC"]; ?></label></td>
                    <td><label>:</label></td>
                    <td>
                        <textarea name="meta_description"><?php echo $u->meta_description; ?></textarea>
                        <em><?php if(isset($this->form_error["meta_description"])){ echo $this->form_error["meta_description"]; }?></em>
                    </td>
                </tr>
                
                 </table>
                 <fieldset>
                </div> 
                <div class="mergent_det2 user_ref">                
			  <fieldset>
    		<legend><?php echo "PRODUCTS IMAGES DETAILS" ?></legend>
			  <table>
                                
                <tr>
                
                    <td><label><?php echo $this->Lang["PRODUCT_IMG"]; ?></label></td>
                    <td><label>:</label></td>
                    <td>
                        <div class = "inputs">
				<?php /*<input type="file" name="image[]"  id="first" onchange="return validateFileExtension(this)" /></div>
                        <input type="button" id="add" value="<?php echo $this->Lang['MRE_IMG']; ?>" >
                        <input type="button" id="remove" value="<?php echo $this->Lang['RMV']; ?>" > */ ?>
                        <em><?php if(isset($this->form_error["image"])){ echo $this->form_error["image"]; }?></em>
                        <label>Image upload size <?php echo '500'; ?> X <?php echo '800'; ?> </label>
                    </td>
                </tr>

                <tr>
                <td></td>
                <td></td>
               <?php /* $con=0; 
                        for($i=1; $i<=5; $i++){ 
                                if(file_exists(DOCROOT.'images/deals/466_347/'.$u->deal_key.'_'.$i.'.png')) { 
                                        $con=$con+1; 
                                } 
                         } */ ?>
                
               
                <?php for($i=1; $i<=5; $i++){ ?>
                <td style="float:left;">
					<div class="merchant_store_img_edit">
							<div class="popup">
							<div class = "inputs">
								
								<input type="file" name="image[]"  class="first" id="first<?php echo '_'.$i;?>" onchange="return validateFileExtension1(this)"  /></div>
								<input type="button" id="remove<?php echo '_'.$i;?>" value="<?php echo "CANCEL"; ?>" >
								<input type="button" id="upload<?php echo '_'.$i;?>" value="<?php echo "ADD"; ?>" onchange="return validateFileExtension1(this)">
								
							</div>
							<a id="show-panel<?php echo '_'.$i;?>" style="cursor:pointer;"  href="javascript:;" >Edit</a> 
							<?php  if(file_exists(DOCROOT.'images/products/466_347/'.$u->deal_key.'_'.$i.'.png'))  { ?>
							<span>|</span>
							
							<a href="<?php echo PATH; ?>delete-deal-images.html?type=<?php echo "products"; ?>&id=<?php echo $u->deal_id; ?>&img=<?php echo base64_encode($u->deal_key.'_'.$i);?>&deal_key=<?php echo $u->deal_key; ?>" onclick="return confirm('Are you sure you want to delete?')">Delete</a>
							<?php } ?>
						</div>
                <?php  if(file_exists(DOCROOT.'images/products/466_347/'.$u->deal_key.'_'.$i.'.png'))  { ?>
                        <img id="del<?php echo '_'.$i;?>" border="0" src= "<?php echo PATH.'images/products/466_347/'.$u->deal_key.'_'.$i.'.png';?>" alt="" width="100" />
                <?php } else {  ?>
						<img style="float:left;"border="0" src= "<?php echo PATH.'/images/no-images.png';?>" alt="" width="100" height="125" />
                <?php } ?>   
                  <p id="img_name<?php echo '_'.$i; ?>"></p>
				<script>
$(document).ready(function(){
       $('#first<?php echo '_'.$i;?>').hide();
       $('#remove<?php echo '_'.$i;?>').hide();
       $('.popup').hide();
       $('#upload<?php echo '_'.$i;?>').hide();
       var i = $('inputs').size() + 0;
       
        
    $("#show-panel<?php echo '_'.$i;?>").click(function() { 
		$('#first<?php echo '_'.$i;?>').show();
		$('.popup').show();
        $('#remove<?php echo '_'.$i;?>').show();
        $('#upload<?php echo '_'.$i;?>').show();
        $('body').append('<div id="fade"></div>'); //Add the fade layer to bottom of the body tag.
		$('#fade').css({'filter' : 'alpha(opacity=100)'}).fadeIn();
		$('#fade').css({'visibility' : 'visible'});
        
        
        if(i != 4)  {
			
		i++;
        if(i == 4)  {
                $('#add').hide();
        }
        }else{ $('#add').hide(); } 
    });
    
    $('#remove<?php echo '_'.$i;?>').click(function() {
        if(i > 0) { 
			$('#first<?php echo '_'.$i;?>').val('');
        $('#first<?php echo '_'.$i;?>').hide();
        $('#upload<?php echo '_'.$i;?>').hide();
         $('.popup').hide();
         
         
		$('#fade').css({'filter' : 'alpha(opacity=100)'}).fadeOut();
		$('#fade').css({'visibility' : 'invisibe'});
        i--;
        if(i==0)
        { 
		$('#first<?php echo '_'.$i;?>').val('');
        $('#remove<?php echo '_'.$i;?>').hide();
        $('#upload<?php echo '_'.$i;?>').hide();
         $('.popup').hide();
         
        }
        }else if(i == 0){
        alert('No more to remove');
        i = 1;
        return false;
        }
    });
         
    $("#upload<?php echo '_'.$i;?>").click(function() { 
		if($('#first<?php echo '_'.$i;?>').val()=='') {
			alert("Please add some Image file");
			
		} else {
			$('#first<?php echo '_'.$i;?>').hide();
        $('#remove<?php echo '_'.$i;?>').hide();
        $('#first<?php echo '_'.$i;?>').val();
        $('#img_name<?php echo '_'.$i; ?>').html($('#first<?php echo '_'.$i;?>').val());
         $('#upload<?php echo '_'.$i;?>').hide();
        $('#fade').css({'filter' : 'alpha(opacity=100)'}).fadeOut();
		$('#fade').css({'visibility' : 'invisibe'});
        
		}
		
       
    });
    

});
</script></td>
                <?php } ?>
                </tr> 
                
                 </table>
                 <fieldset>
                </div>   	  
			    
			  
			  <div class="mergent_det2 user_year">
			  <fieldset>
    		<legend><?php echo "SHIPPING DETAILS" ?></legend>
			  <table>
			  
                 
                 <tr id="shipping" >
                    <td><label>Shipping Amount</label></td>
                    <td><label>:</label></td>
                    <td>
                        <input type="text" name="shipping_amount" maxlength="18" value="<?php echo $u->shipping_amount; ?>" />
                        <em><?php if(isset($this->form_error["shipping_amount"])){ echo $this->form_error["shipping_amount"]; }?></em>
					</td>
                </tr> 
			  
			   </table>
                           </fieldset>
			  
			  <fieldset>
    		<legend><?php echo "PRODUCTS COLOR DETAILS" ?></legend>
			  <table>
                
                <tr>
                    <td><label>Add Color Field</label><span>*</span></td>
                    <td><label>:</label></td>
                    <td>
                        <input type="radio" onchange="return checkedcolorremove(this)" name="color_val" value="0" <?php if($u->color==0){ ?> checked <?php } ?>>No<br>
                        <input type="radio" onchange="return checkedcoloradd(this)" name="color_val" value="1" <?php if($u->color==1){ ?> checked <?php } ?>>Yes
                    </td>
                 </tr>
                
                <tr>
                    <td><label>Your Select Color</label></td>
                    <td><label>:</label></td>
                    <td>
                     <?php if(count($this->product_color)>0) { ?>
                         <span id="city_display"> </span>
                        <?php 
                            foreach($this->product_color as $color){
                            echo "<span style='width:3px;padding:3px;border:3px solid #$color->color_name;'><input type='checkbox' name='color[]' checked='checked' value='".$color->color_name."'>".ucfirst($color->color_code_name)."</span> ";
                        } } else { ?>
                        <span id="city_display"> </span>
                        <?php }?>
                    </td>
                    
                </tr>
                <script language="javascript"> 
                function toggle() {
                var ele = document.getElementById("toggleText");
                var text = document.getElementById("displayText");
                if(ele.style.display == "none") {
                ele.style.display = "block";
                text.style.display = "none";
                }
                else {
                ele.style.display = "none";
                text.style.display = "block";
                }
                } 

                $(document).ready(function() {
                $('#toggleText').change(function() {
                var count=$(this).val();
                $.post("<?php echo PATH;?>merchant/editmore_color?count="+count+"&deal="+<?php echo $u->deal_id; ?>,{
                }, function(response){ 
                $("#city_display").append(response);
                });
                });
                });
                </script>
                
                    <?php if(count($this->product_color)>0) { ?>
                    
                    <tr>
                        <td><label>Product Color</label></td>
                        <td><label>:</label></td>
                        <td >
                        
                        
                        
                        <?php $user_city=""; foreach($this->product_color as $city1){
			                $user_city .= $city1->color_code_id.",";
	 		                
			            }
			            $city_Tags=explode(",", substr($user_city, 0, -1));
			            ?>
                        <select name="city_tag[]" id="toggleText">			  
			            <option value="">Select Color</option>
			            <?php $i=1;
			            
			            foreach($this->color_code as $CityL){
			            	
	 		              if(!in_array($CityL->id, $city_Tags)){
			            	
			            ?>
			            <option  value="<?php echo $CityL->id; ?>" style='color:#<?php echo $CityL->color_code; ?>';><?php echo ucfirst($CityL->color_name); ?> </option>
			            <?php  }
			            } ?>
			            </select>
			            </td>
                    </tr>
                    <?php 
                    } else {?>
                    
                    <tr>
                    <td><label>Product Color</label></td>
                    <td><label>:</label></td>
                                
                    <td>
                        <select name="city_tag[]" id="toggleText" >
			              <option value="">Select city</option>
			            <?php foreach($this->color_code as $CityL){
			            ?>
			            <option value="<?php echo $CityL->id; ?>"><?php echo ucfirst($CityL->color_code); ?></option>
			            <?php 
			            } ?>
			            </select>
                    </td>
                </tr>
                    
                    <?php } ?>
                    
                    
                    </table>
                           </fieldset>
                         
                </div>      
               <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="<?php echo $this->Lang['SUBMIT']; ?>"  id="check2"/><input type="button" value="<?php echo $this->Lang['CANCEL']; ?>" onclick='window.location.href="<?php echo PATH?>merchant/manage-products.html"'/></td>
                </tr><?php }?>
        </form>
        
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
