<?php defined('SYSPATH') OR die("No direct access allowed."); ?>

<div class="bread_crumb"><a href="<?php echo PATH."admin.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a>
<?php if(isset($s->title)){?>
<a href="<?php echo PATH.$this->url; ?>" title="<?php echo $this->template->title; ?>">&nbsp;<?php echo $this->template->title; ?>&nbsp;<span class="fwn">&#155;&#155;</span>
<?php } else{ ?>
<p><?php echo $this->template->title; ?></p>
<?php } ?></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
	<form method="get" class="admin_form" action=""> 
		<?php if(count($this->transaction_list)>0){?>

	<a style="float:right;text-decoration: underline; cursor: pointer;position:relative; z-index:2;" href="<?php echo $this->sort_url.'id='.$this->Lang['SEARCH'].'&name='.$this->input->get('name'); ?>" title="Export Deal Transactions In CSV Format"><img src="<?php echo PATH ?>images/csv.png" class="image" alt="Export Deal Transactions In CSV Format"/></a>
	<?php }  ?>	  
	 <table class="list_table1 fl clr">
                <?php 
	            if(isset($this->search_key)){
		           
	            }?>
		    <td><input type = "text" name = "name" <?php if(isset($this->search_key)){?> value="<?php echo $this->search_key; ?>"<?php } ?>/>
		    <input type="submit" value="<?php echo $this->Lang['SEARCH']; ?>" class="fl"/>
		    </td>
		    <td><label><?php echo "Transaction Type"; ?></label></td>
		        <td><label>:</label></td> 
		        <td>
		        
		         <select onchange="window.open(this.options[this.selectedIndex].value,'_top')">
		        
		         <option value="<?php echo PATH.'merchant/all-transaction.html';?>" <?php if($this->uri->last_segment() == "all-transaction.html"){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["ALL_TRAN"]; ?></option>
		         
		        <option value="<?php echo PATH.'merchant/success-transaction.html';?>" <?php if(($this->uri->last_segment() == "success-transaction.html")||($this->uri->segment(2) == "success-transaction")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["SUCC_TRAN"]; ?></option>
		        
		        <option value="<?php echo PATH.'merchant/completed-transaction.html';?>" <?php if(($this->uri->last_segment() == "completed-transaction.html")||($this->uri->segment(2) == "completed-transaction")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["COMP_TRAN"]; ?></option>
		        
		        <option value="<?php echo PATH.'merchant/failed-transaction.html';?>" <?php if(($this->uri->last_segment() == "failed-transaction.html")||($this->uri->segment(2) == "failed-transaction")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["FAI_TRAN"]; ?></option>
		        
		        <option value="<?php echo PATH.'merchant/hold-transaction.html';?>" <?php if(($this->uri->last_segment() == "hold-transaction.html")||($this->uri->segment(2) == "hold-transaction")){  ?>  selected="selected" <?php }  ?>><?php echo $this->Lang["HOLD_TRAN"]; ?></option>
		        	         
		        </select>
		        </td>
		    <td></td>
 
        </table>
       ( <label><?php echo $this->Lang["SEARCH_TRAN"]; ?></label>)  
        </form>
	<?php echo new View("merchant/transaction_list"); ?>
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>
 <span class="pagination"> <?php echo $this->pagination; ?> </span>
