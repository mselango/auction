<?php defined('SYSPATH') OR die("No direct access allowed."); ?>
<div class="bread_crumb"><a href="<?php echo PATH."merchant.html"; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a>
<?php if(isset($s->title)){?>
<a href="<?php echo PATH.$this->url; ?>" title="<?php echo $this->template->title; ?>">&nbsp;<?php echo $this->template->title; ?>&nbsp;<span class="fwn">&#155;&#155;</span></a><p><?php echo $this->Lang["SEARCH"]; ?></p>
<?php } else{ ?>
<p><?php echo $this->template->title; ?></p>
<?php } ?></div>
<div class="cont_container mt15 mt10">
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
    
     <form method="get" class="admin_form fl" action="<?php echo PATH.$this->url;?>">

		<?php  if(($this->uri->last_segment() == 'manage-products.html') || ($this->uri->segment(3))){
			
		  if(count($this->all_product_list) > 0){ ?>
		<a class="fr" style="float:right;text-decoration: underline; cursor: pointer;position:relative; z-index:2;" href="<?php echo PATH.'merchant/manage-products.html?id='.$this->Lang['SEARCH'].'&name='.$this->input->get('name').'&city='.$this->input->get('city'); ?>" title="<?php echo $this->Lang['EXP_PRO']; ?>"><img src="<?php echo PATH ?>images/csv.png" class="image" alt="<?php echo $this->Lang['EXP_PRO']; ?>"/></a>

		<?php } } ?>

		
            <table class="list_table1 fl clr">
                <?php 
	            if(isset($this->search_key)){
		            $s = $this->search_key; 
	            }?>
		<td><label><?php echo $this->Lang["SEARCH_DEALS"]; ?></label></td>
		<td><label>:</label></td>
                <tr>
		<td><label><?php echo $this->Lang["CITY_NAME"]; ?></label></td>
                <td><label>:</label></td>
                <td><select name ="city">
                <?php if(isset($s->city)){ foreach($this->city_list as $c){ if($s->city == $c->city_id){ ?>
                <option value="<?php echo $c->city_id; ?>"><?php echo ucfirst($c->city_name); }}}?></option>
                <option value=""><?php echo $this->Lang["SEL_CITY"]; ?></option>
                <?php foreach($this->city_list as $c){ ?>
                <option value="<?php echo $c->city_id; ?>"><?php echo ucfirst($c->city_name); ?></option>  
                <?php }?>


                </select></td>
		<td><label><?php echo $this->Lang["NAME"]; ?></label></td>
                <td><label>:</label></td>
                <td><input type = "text"  name = "name" <?php if(isset($s->name)){?> value="<?php echo $s->name; ?>"<?php } ?>/></td>
		<td></td>

                <td><input type="submit" value="<?php echo $this->Lang['SEARCH']; ?>" class="fl"/></td>
            </tr>
            <tr>
            <td></td><td></td><td></td><td></td><td></td><td>
            <label><?php echo $this->Lang['PRODUCT_NAME']; ?>, <?php echo $this->Lang['STORE_NAME']; ?></label>
            </td>
            </tr>
        </table>
        </form>
        <?php if(count($this->all_product_list) > 0){ ?>
        <table class="list_table fl clr mt20">
        	<tr>
			<th align="left" width="5"><?php echo $this->Lang['S_NO']; ?></th>
			<th align="left" width="20%"><div class="arrow"><a href="<?php echo $this->sort_url;?>param=name&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By Products Name" ><?php echo $this->Lang["PRODUCT_NAME"]; ?></a></div></th>
			<th align="left" width="12%"><div class="arrow1"><a href="<?php echo $this->sort_url;?>param=city&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By City" ><?php echo $this->Lang["CITY"]; ?></a></div></th>			
			<th align="left" width="12%"><div class="arrow2"><a href="<?php echo $this->sort_url;?>param=store&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By Store Name" ><?php echo $this->Lang["STORE_NAME"]; ?></a></div></th>
			<th align="left" width="12%"><div class="arrow3"><a href="<?php echo $this->sort_url;?>param=price&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By Price" ><?php echo $this->Lang["PRICE"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></a></div></th>
			<th align="left" width="15%"><div class="arrow4"><a href="<?php echo $this->sort_url;?>param=value&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By Product Value" ><?php echo $this->Lang["DEALVALUE"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></a></div></th>
			<th align="left" width="15%"><div class="arrow5"><a href="<?php echo $this->sort_url;?>param=savings&sort=<?php if($this->input->get('sort')=='DESC'){ echo 'ASC'; }else{ echo 'DESC'; } ?>" title="Sort By Product Savings" ><?php echo $this->Lang["SAVINGS"]; ?><?php echo '('.CURRENCY_SYMBOL.')';?></a></div></th>
			<th align="left" width="15%"><?php echo $this->Lang["PRODUCT_IMG"]; ?></th> 
			<th align="left" width="5%"><?php echo $this->Lang["EDIT"]; ?></th>
			<th align="left" width="5%"><?php echo 'Preview'; ?></th>
			<?php /* if(($this->uri->last_segment() == 'manage-products.html')||($this->uri->segment(2) == 'manage-products.html')){ ?> 
			<th align="left" width="5%"><?php echo $this->Lang["B_UNB"]; ?></th>
			<?php } */ ?>
			<th align="left" width="10%"><?php echo $this->Lang["PRODUCT_DET"]; ?></th>
               </tr>
            
                <?php $i=0; 
			$first_item = $this->pagination->current_first_item;
			foreach($this->all_product_list as $u){?>
                <tr>    
                     <td align="left"><?php echo $i + $first_item ; ?></td>
                     <td align="left"><?php echo $u->deal_title; ?></td>
                     <td align="left"><?php echo $u->city_name; ?></td>
                     <td align="left"><?php echo $u->store_name; ?></td>
		     <td align="left"><?php echo $u->deal_price; ?></td>
		     <td align="left"><?php echo $u->deal_value; ?></td>
         	     <td align="left"><?php echo $u->deal_savings; ?></td>
         	     <?php  if(file_exists(DOCROOT.'images/products/290_215/'.$u->deal_key.'_1'.'.png'))       
	             { ?>
                    <td align="left"><img border="0" src= "<?php echo PATH.'images/products/290_215/'.$u->deal_key.'_1'.'.png';?>" alt="" width="80" /></td>
                     <?php } else { ?>
                         <td><img border="0" src= "<?php echo PATH.'/images/no-images.png';?>" alt="" width="80" /></td>
                        <?php } ?>
                 
                    <td align="left">
                    <a href="<?php echo PATH.'merchant/edit-products/'.$u->deal_id.'/'.$u->deal_key.'.html';?>" class="editicon" title="<?php echo $this->Lang['EDIT_PRODUCT']; ?>"></a>
                    </td>
					<td align="left">
                    <a href="<?php echo PATH.'product/'.$u->deal_key.'/'.$u->url_title.'/merchant.html';?>" class="previewicon" title="<?php echo 'Preview'; ?>" target="_blank"></a>
                    </td>
                    <?php /* if(($this->uri->last_segment() == 'manage-products.html')||($this->uri->segment(2) == 'manage-products.html')){ ?> 
                    <td align="left">
                    <?php if($u->deal_status == 1){?>
                    <a onclick="return blockunblockmproduct('<?php echo $u->deal_id; ?>','<?php echo $u->deal_key; ?>','block');" class="blockicon" title="<?php echo $this->Lang['BLOCK']; ?>"></a>
                    <?php } else{  ?>
                    <a onclick="return blockunblockmproduct('<?php echo $u->deal_id; ?>','<?php echo $u->deal_key; ?>', 'unblock');" class="unblockicon" title="<?php echo $this->Lang['UNBLOCK']; ?>"></a>
                    <?php } ?>
                    </td>
                  <?php } */ ?>
                    <td align="left"><a href="<?php echo PATH.'merchant/view-products/'.$u->deal_key.'/'.$u->deal_id.'.html';?>"><?php echo $this->Lang["VIEW_DET"]; ?></a></td>
                </tr>
            <?php $i++;} ?>   
        </table> 
        <p><?php echo $this->pagination; ?></p>
       <?php } else{ ?>
       	<p class="nodata"><?php echo $this->Lang["NO_PRODUCTS"]; ?></p>
       <?php } ?>
        
    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
</div>

