<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
&#8377;
<div class="bread_crumb"><a href="<?php echo PATH.'merchant.html'; ?>" title="<?php echo $this->Lang['HOME']; ?>"><?php echo $this->Lang["HOME"]; ?> <span class="fwn">&#155;&#155;</span></a><p><?php echo $this->template->title; ?></p></div>
<div class="cont_container mt15 mt10" >
    <div class="content_top"><div class="top_left"></div><div class="top_center"></div><div class="top_rgt"></div></div>
    <div class="content_middle">
        <form method="get" class="admin_form" >
            <table class="list_table1 fl clr">
	 <?php if(count($this->shipping_list)>0){?>

	<a style="float:right;text-decoration: underline; cursor: pointer;position:relative; z-index:2;" href="<?php echo PATH.'merchant/shipping-delivery.html?id='.$this->Lang['SEARCH'].'&search='.$this->input->get('search'); ?>" title="<?php echo $this->Lang['EXP_PRO']; ?>"><img src="<?php echo PATH ?>images/csv.png" class="image" alt="<?php echo $this->Lang['EXP_PRO']; ?>"/></a>
	<?php } ?>
                <?php 
	            if(isset($this->search_key)){
		            $s = $this->search_key;
	            }?>
                

			 <tr>
				<td><label><?php echo $this->Lang['SEARCH']; ?></label></td>
                <td><label>:</label></td>
                <td><input type = "text" name ="search" <?php if(isset($s->name)){?> value="<?php echo $s->search; ?>"<?php } ?>/><input type="submit" value="<?php echo $this->Lang['SEARCH']; ?>" class="fl"/ style="padding:4px; margin: 2px 0 0 6px; height:25px;"></td>
	
                <td></td>
            </tr>
            <tr>
            <td></td><td></td><td>
           	 <label><?php echo $this->Lang['NAME'].",".$this->Lang['EMAIL'].",".'Coupon Code'; ?></label>
            </td>
            </tr>
        </table>
        </form>
    
    <?php if(count($this->shipping_list)>0){?>
        <table class="list_table fl clr mt15">
        	<tr>
        	<th align="left" ><?php echo $this->Lang['S_NO']; ?></th>
        	<th align="left" >Products <?php echo $this->Lang['NAME']; ?></th>
			<th align="left" ><?php echo $this->Lang['NAME']; ?></th>
           	<th align="left" ><?php echo $this->Lang['EMAIL']; ?></th>
			<th align="left" >Date</th>
			<?php /*<th align="left" ><?php echo $this->Lang['PH_NUM']; ?></th> **/?> 
			<th align="left" ><?php echo $this->Lang['ADDRES']; ?></th>
        	<th align="left" >Details</th>
			<th align="left" ><?php echo $this->Lang['DELIVERY_STA']; ?></th>
			
		<?php /*<th align="left" ><?php echo $this->Lang["DELETE"]; ?></th> */ ?>
                
            </tr>
            <?php $i=0; $first_item = $this->pagination->current_first_item;

                foreach($this->shipping_list as $u){?>
                <tr>    
                        <td align="left"><?php echo $i+$first_item; ?></td>
                        <td align="left"><a href="<?php echo PATH.'merchant/view-products/'.$u->deal_key.'/'.$u->product_id1.'.html';?>"><?php echo $u->deal_title; ?></a></td>
                    	<td align="left"><?php echo $u->firstname; ?></td>

                        <td align="left"><?php echo $u->email; ?></td>	
						<td align="left"><?php echo date('d-M-Y h:i:s',$u->shipping_date); ?></td>	
                  
     			<?php /* <td width=12 align="left"><?php echo $u->phone; ?></td> **/?>
			
			<td align="left"><?php echo $u->adderss1.",".$u->address2; ?></td>
			
			<td align="left"><center><a id="details-panel<?php echo $u->shipping_id; ?>" title="<?php echo $this->Lang['SEND_MAIL']; ?>"  href="javascript:;" ><img src="<?php echo PATH;?>images/details_view.gif"><input type="hidden" name="email1" id="mail" value="<?php echo $u->email; ?>"></center></a>
			
			
            
			<div class="popup_show1" id="lightboxdetails-panel<?php echo $u->shipping_id; ?>" style="display:none;"  >
			<div id="divToPrint<?php echo $u->shipping_id; ?>"   class="divToPrintval" >
			<div class="rejected_shipping" id="details-close<?php echo $u->shipping_id; ?>" ></div>
			<div class="printer_shipping blink" onclick="PrintDiv('<?php echo $u->shipping_id; ?>');" ></div>
			
			<script type="text/javascript">     
        function PrintDiv(val) {    
           var divid = 'divToPrint'+val;
           var divToPrint = document.getElementById(divid);          
           var popupWin = window.open('', '_blank', 'width=600,height=500');
           $('.print_div').hide();
            popupWin.document.open();
            popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
            popupWin.document.close();
            $('.print_div').show();
                }
     </script> 
                <div class="display" style="width:666px; margin: 15px auto;"> 
		        
						<div style="width:99%;">
							<div class="HeadLogo" style="float:left; width: 35%;">
								<img style="border: medium none;" src="<?php echo PATH; ?>/themes/<?php echo THEME_NAME; ?>/images/logo.png" height="20"><br>
								<span style="color:#666666; font-size: 11px; line-height: 1.3em;">  

									<?php echo $u->store_name ; ?>,<br>
									<?php echo $u->addr1.','.$u->addr2 ; ?>,<br>
									<?php echo $u->city_name.'-'.$u->zipcode; ?>.<br>
									Phone: <?php echo $u->str_phone; ?><br>
								</span>
							</div>
							<div style="float:left; width: 20%; text-align:center;">
								<strong style="font-size: 15px; font-weight:bold; font-family: Arial;">TAX INVOICE <br>
									</strong>
							</div>
							<div style="float:right; margin-right: 5px;text-align:center;">
								<div style="font-weight: bold; font-size: 15px; float:left; margin: 60px 10px 0 0;"></div>
								
							   <div style="clear:both;"></div>
							</div>
							<div style="clear:both;"></div>
						</div>
		        
					<hr style="border: 1px solid black; padding:0; margin: 20px 0 0 0; width: 99%;">
		        
						<div style="margin-top: 20px; width:99%;">
							<div style="float:left; margin-top: 20px;"></div>
								<div style="float:left; width: 40%; font-size:12px; border-right: 1px dotted #666666; margin-left: 10px;">
										<strong style="font-size: 15px; margin:0; padding:0;">CASH ON DELIVERY</strong><br><br><br>
										<strong style="font-size: 15px; margin:0; padding:0;">Amount to be Paid: <?php echo CURRENCY_SYMBOL.$u->amount; ?></strong><br>
										<span class="caption">(inclusive of all charges)</span><br><br>
										<strong style="font-size: 15px; margin:0; padding:0;">Coupon No. : <?php echo $u->coupon_code; ?></strong><br>
											Order Date: <?php echo date("d-M-Y h:i:s A",$u->transaction_date); ?><br><br>
			   
								</div>
								<div style="float:left; width: 50%; margin-left: 20px;">
										 <strong style="font-size: 15px; font-weight:bold;">Shipping Address</strong>
										<br><br>
										<strong style="font-size: 15px; font-weight:bold;"><?php echo ucfirst($u->name); ?> </strong><br>
										<?php echo $u->saddr1."<br />".$u->saddr2; ?>,<br>
										<?php echo $u->city_name . '-' . $u->postal_code; ?><br>
										<?php echo $u->country; ?><br>
										<strong style="font-size: 15px; font-weight:bold;">Phone: <?php echo $u->phone; ?> </strong>
								</div>
							<div style="clear:both;"></div>
						</div>
					
					<hr style="border: 1px dotted black; padding:0; margin: 20px 0 0 0; width: 99%;">
		        
						<div style="margin-top: 50px; text-align:center;">
							<strong style="font-size: 15px; font-weight:bold; font-family: Arial;">Invoice Details</strong><br>
							<b>Note:</b> This shipment contains following items<br><br>
						</div>
					<table cellpadding="0" cellspacing="0" width="99%">
						<tbody><tr>
							<td><hr style="border: 1px solid black;"></td>
						</tr>
						<tr>
							<td>
								<table class="printtable" cellpadding="0" cellspacing="0" width="99%">
										<tbody>
											<tr>
												<td colspan="7"><b>1. <?php echo $u->deal_title; ?></b></td>
											</tr>
											<tr>
												<td colspan="7">&nbsp;</td>

											</tr>
										
											<tr>
												<td width="10%">&nbsp;</td>
												<td width="13%" align="center">Color</td>
												<td width="13%" align="center">Size</td>
												<td width="13%" align="center">Quantity</td>
												<td width="13%" align="center">Unit Price</td>
												<td width="13%" align="center">Original Price</td>
												<td width="13%" align="right">Sub Total</td>
											</tr>
										<tr><td>&nbsp;</td><td colspan="6"><hr style="border:1px dotted #AAAAAA;"></td></tr>
										<tr>
											<td width="16%">&nbsp;</td>
																
												<?php if($u->product_color !=0 ) { foreach($this->product_color as $pro){ ?>
												<?php if($u->product_color == $pro->id){ ?>                   
												<td align="center">
												<?php echo ucfirst($pro->color_name); ?></td>
												<?php } } } else { ?><td align="center">-</td> <?php } ?>
												
												 <?php if($u->product_size != 0 ){ foreach($this->product_size as $size){ ?>
												<?php if($u->product_size == $size->size_id){ ?>                 
												<td align="center">
												<?php echo $size->size_name; ?></td>
												<?php } } } else { ?><td align="center">-</td> <?php } ?>
											<td align="center"><?php echo $u->quantity; ?></td>
											<td align="center"><?php echo CURRENCY_SYMBOL.$u->deal_price; ?></td>
											<td align="center"><?php echo CURRENCY_SYMBOL.$u->deal_value; ?></td>
											<td align="right"><?php echo CURRENCY_SYMBOL.$u->deal_value * $u->quantity; ?></td>
										</tr>
										<tr><td colspan="7">&nbsp;</td></tr>
										 
									</tbody>
								</table>
							</td>
						</tr>
						<tr>
							<td><hr style="border: 1px solid black;"></td>
						</tr>
					</tbody></table>
						<div style="clear:both;"></div>
						<div style="width:99%;  line-height: 2em; text-align:left; page-break-before: auto;">
							<div style="float:left; width: 55%">&nbsp;</div>
							<div style="float:left; width: 27%; text-align:left;">Shipment Value</div>
							<div style="float:left; width: 18%; text-align:right;"><b><?php echo CURRENCY_SYMBOL.$u->deal_value * $u->quantity; ?></b></div>
							<div style="clear:both;"></div>
					    	        	    
							<div style="float:left; width: 55%">&nbsp;</div>
							<div style="float:left; width: 27%; text-align:left;">Shipping</div>
							<div style="float:left; width: 18%; text-align:right;"><b><?php if($u->shipping != 0 ) echo $u->shipping; else echo '-'; ?> </b></div>
							<div style="clear:both;"></div>
							
							<div style="float:left; width: 55%">&nbsp;</div>
							<div style="float:left; width: 27%; text-align:left;">Tax</div>
							<div style="float:left; width: 18%; text-align:right;"><b><?php if($u->tax_amount != 0 ) echo CURRENCY_SYMBOL.$u->tax_amount; else echo '-'; ?> </b></div>
							<div style="clear:both;"></div>
							<div style="float:left; width: 55%; margin-top: 10px;">&nbsp;</div>
							<div style="float:left; width: 45%; margin-top: 10px;">
								<div style="padding: 10px 0px; border-top: solid 0.15em; border-bottom: 0.15em solid;">
									<div style="width:50%; float:left;">Amount to be paid</div>
									<div style="text-align:right; float:right; width:50%;">
										<strong style="font-size: 17px;"><?php echo CURRENCY_SYMBOL.(($u->deal_value * $u->quantity) + ($u->shipping) + ($u->tax_amount)); ?></strong>
									</div>
									<div style="clear:both;"></div>
								</div>
							</div>
							<div style="clear:both"></div>
						</div>
		
						<div style="clear:both"></div>
		    	        <div style="height: 30px;">&nbsp;</div>
						<div style="clear:both;"></div>
		        
						<div style="position: relative; bottom: 2px;">
							<div style="text-align:left; margin-top: 30px; padding: 0;">
								If you have any questions, feel free to call customer care at <b><?php echo $u->str_phone; ?></b> or website <b><?php echo $u->website; ?></b>                
							</div>
				              
						</div>
					</div>
				</div>
                
	    </div>
			</div>
			
			
			</td>
			
			 
     
		<script>
$(document).ready(function(){


$('a#show-panel<?php echo $u->shipping_id; ?>').click(function(){ 
$('#lightbox-panel<?php echo $u->shipping_id; ?>').show();
})

$('a#details-panel<?php echo $u->shipping_id; ?>').click(function(){ 
$('#lightboxdetails-panel<?php echo $u->shipping_id; ?>').show();
$('.divToPrintval').show();
})

$('#details-close<?php echo $u->shipping_id; ?>').click(function(){ 
$('#lightboxdetails-panel<?php echo $u->shipping_id; ?>').hide();
})

$('#details-cancel<?php echo $u->shipping_id; ?>').click(function(){ 
$('#lightbox-panel<?php echo $u->shipping_id; ?>').hide();
})


$('#cancel').click(function(){ 
$('#em').text(''); 

})

});

</script>
	
                        <td align="center">
                    <?php if($u->delivery_status == 0 && $u->type!=5){ ?> <a id="show-panel<?php echo $u->shipping_id; ?>" title="<?php echo $this->Lang['SEND_MAIL']; ?>"  href="javascript:;"><img src="<?php echo PATH;?>images/mail.png"><input type="hidden" name="email1" id="mail" value="<?php echo $u->email; ?>"></a><?php } else if ($u->type==5) { echo "COD"; } else { echo $this->Lang['DELIVERED']; } ?>   
				
		<div class="popup_show" id="lightbox-panel<?php echo $u->shipping_id; ?>" style="display:none;">
	<form method="post"  class="admin_form" id="form">
                <table>
			
                        <tr>
                            <td><label><?php echo $this->Lang['EMAIL']; ?></label></td>
                            <td><label>:</label></td>
		            <td><input type="text" name="email" value="<?php echo $u->email; ?> " readonly >
				<input type="hidden" name="id" value = "<?php echo $u->shipping_id; ?>" >
                            </td>
                        </tr>
			
			<tr>
                            <td><label><?php echo $this->Lang['ADDRES']; ?></label></td>
                            <td><label>:</label></td>
		            <td><?php echo $u->adderss1.",".$u->address2; ?>,<?php echo $u->city_name; ?>,<?php echo $u->country; ?></td>
			  
                        </tr>
		
			
                        <tr>
                            <td><label><?php echo $this->Lang['MSGG']; ?></label></td>
                            <td><label>:</label></td>
		            <td><textarea class="TextArea" name="message" id="msg" cols=15 rows=10 / ></textarea>
			    </td>
                        </tr> 
                        <tr> 
                             <td></td>
                             <td></td>
                             <td><input type="submit" value="<?php echo $this->Lang['SEND']; ?>" id="submit<?php echo $u->shipping_id; ?>"> <input type="reset" value="<?php echo $this->Lang['CANCEL']; ?>" id="details-cancel<?php echo $u->shipping_id; ?>"  />
			     </td>
                        </tr>
                </table>
        </form>
	</div>
		
					
                    </td>
	<? /* <td>
                    	<a onclick="return deletesubcontact('<?php echo $u->shipping_id; ?>')" class="deleteicon" title="Delete" ></a>
                    </td>  */ ?>
                    
                </tr>
            <?php $i++;} ?>   
        </table>
<?php } else{?><p class="nodata"><?php echo $this->Lang["NO_DATA"]; ?></p><?php }?>
     <?php echo $this->pagination; ?>    </div>
    <div class="content_bottom"><div class="bot_left"></div><div class="bot_center"></div><div class="bot_rgt"></div></div>
 
</div>


