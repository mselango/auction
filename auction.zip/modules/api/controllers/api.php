<?php defined('SYSPATH') OR die('No direct access allowed.');
class Api_Controller extends Layout_Controller
{
	const ALLOW_PRODUCTION = FALSE;
	public function __construct()
	{
		parent::__construct();
		$this->api = new Api_Model;		
		
		foreach($this->generalSettings as $s){

			$this->Api_Username = $s->paypal_account_id;
			$this->Api_Password = $s->paypal_api_password;
			$this->Api_Signature = $s->paypal_api_signature;

			$this->Api_Username = "nandhu_1337947987_biz_api1.gmail.com";
			$this->Api_Password = "1337948040";
			$this->Api_Signature = "A0YqGlJEML24al4qg2LnV2U.g2ThAfXD37NEiWIVcgjl1pxlygg-XaVs";

			$this->Live_Mode = $s->paypal_payment_mode;
			$this->API_Endpoint = "https://api-3t.sandbox.paypal.com/nvp";
			$this->Paypal_Url = "https://www.sandbox.paypal.com/webscr&cmd=_express-checkout&token=";

			if($this->Live_Mode == 1){
				$this->API_Endpoint = "https://api-3t.paypal.com/nvp";
				$this->Paypal_Url = "https://www.paypal.com/webscr&cmd=_express-checkout&token=";
			}			
		}
		$this->Api_Version = "76.0";
		$this->Api_Subject = $this->AUTH_token = $this->AUTH_signature = $this->AUTH_timestamp = '';
	}


    /** DoDirectPayment - Credit Card  **/

	public function product_dodirectpayment()
	{
	    if($_POST){
            $get_deal_id = $this->input->post("deal_id");
            $deal_id = explode(",", $get_deal_id );
            $get_deal_qty = $this->input->post("deal_qty");
            $deal_qty = explode(",", $get_deal_qty);
            $userid = $this->input->post("userid");
            $total_product_amount = $this->input->post("total_product_amount");
                if((count($deal_id))==(count($deal_qty))) {
                    $this->userPost = $this->input->post();
                    $total_amount="";
                    $total_qty="";
                    $product_title="";
                    $produ_qty="";
                    $referral_amount="";
                        for($i=0; $i<count($deal_id); $i++) {
                            $this->deals_payment_deatils = $this->api->get_product_payment_details($deal_id[$i]);	
                                foreach($this->deals_payment_deatils as $UL){
                                    $purchase_qty = $UL->purchase_count;
                                    $deal_title = $UL->deal_title;
                                    $deal_key  = $UL->deal_key;
                                    $url_title = $UL->url_title;
                                    $deal_value = $UL->deal_value;
                                    $product_amount = $UL->deal_value*$deal_qty[$i];
                                }			        
                            $total_amount +=$product_amount;
                            $total_qty += $deal_qty[$i]; 
                            $product_title .=$deal_title.",";	
                            $produ_qty .=$deal_qty[$i].",";	 
                        }
                    if($total_product_amount==$total_amount){
                        $pay_amount=$total_amount; 
                        $post = arr::to_object($this->input->post());
                        $paymentType = "Sale";
                        $captured = 0;				
                        $creditCardNumber = urlencode($post->creditCardNumber);
                        $cvv2Number = urlencode($post->cvv2Number);
                        $expDateMonth =urlencode( $post->expDateMonth);
                        $padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);
                        $expDateYear =urlencode( $post->expDateYear);
                        $firstName =urlencode( $post->firstName);
                        $lastName =urlencode( $post->firstName);			
                        $address1 = urlencode($post->address1);
                        $city = urlencode($post->city);
                        $state =urlencode($post->state);
                        $zip = urlencode($post->zip);
                        $country_code = "US";
                        $currencyCode = "USD";
                        $nvpstr ="&PAYMENTACTION=$paymentType&AMT=$pay_amount&ACCT=$creditCardNumber&EXPDATE=".$padDateMonth.$expDateYear."&CVV2=$cvv2Number&FIRSTNAME=$firstName&LASTNAME=$lastName&STREET=$address1&CITY=$city&STATE=$state&ZIP=$zip&COUNTRYCODE=$country_code&CURRENCYCODE=$currencyCode";
                        $this->result = arr::to_object($this->hash_call("doDirectPayment", $nvpstr));
                        $ack = strtoupper($this->result->ACK);
                            if($ack == 'SUCCESS' || $ack == 'SUCCESSWITHWARNING'){
                            
                                for($i=0; $i<count($deal_id); $i++) {
                                $this->deals_payment_deatils = $this->api->get_product_payment_details($deal_id[$i]);	
                                    foreach($this->deals_payment_deatils as $UL) {
                                        $purchase_qty = $UL->purchase_count;
                                        $deal_title = $UL->deal_title;
                                        $deal_value = $UL->deal_value;
                                        $merchant_id = $UL->merchant_id;
                                    }			        
                                $deal_amount=$deal_value*$deal_qty[$i];
                                $transaction = $this->api->insert_product_transaction_details($this->result, $deal_id[$i], $country_code, $firstName, $lastName, $referral_amount, $deal_qty[$i], 1, $captured, $purchase_qty, arr::to_object($this->userPost),$merchant_id,$userid);	
                                $status = $this->do_product_transaction($captured, $deal_id[$i],$deal_qty[$i],$transaction,$userid);
                                }
                                
                                $R = $this->result;
                                $response = array("response" => array("Transaction_Time" => $R->TIMESTAMP,"Transaction_id" =>$R->TRANSACTIONID,"Transaction_Status" => $R->ACK,"Transaction_amount" => $R->AMT ,"Currency_code" => $R->CURRENCYCODE, "httpCode" => 200, "Message" => "Payment successfully transaction", 'currency_symbol' => CURRENCY_SYMBOL));
                                echo json_encode($response);	
                                exit;		

                            } else {
                            
                        $response = array("response" => array("httpCode" => 401 , "Message" => "Problem in paypal.Please try again sometimes..." ));
                        echo json_encode($response);
                        exit;	
                        	
                        }

                    } else {
                    
                    $response = array("response" => array("httpCode" => 401 , "Message" => "Invalid payment amount" ));
                    echo json_encode($response);
                    exit;
                    
                    }

                } else {
                
                    $response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
                    echo json_encode($response);
                    exit;
                    
                }
            } else {	
            
                $response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
                echo json_encode($response);
                exit;		
                
            }
	}
		
	/** DOCAPTURED PAYMENT, UPDATED AMOUNT TO REFERED USERS, POST PURCHASE DEALS TO FACEBOOK WALL and SEND MAIL **/

	public function do_product_transaction($captured = "", $deal_id = "", $qty = "",$transaction = "",$userid = "")
	{
		$user_details = $this->api->get_purchased_user_details($userid);
		foreach($user_details as $U){
			if($U->referred_user_id && $U->deal_bought_count == $qty){
				$update_reff_amount = $this->api->update_referral_amount($U->referred_user_id);
			}
			$deals_details = $this->api->get_product_details_share($deal_id);
			if($U->facebook_update == 1){				
				foreach($deals_details as $D){
					$dealURL = PATH."deals/".$D->deal_key.'/'.$D->url_title.".html";
					$message = "I have purchased the deal...".$D->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $U->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg);
				}
			}  
			
			/** Send Purchase details to user Email **/
			foreach($deals_details as $D){
			    $deal_title = $D->deal_title;
			    $deal_amount = $D->deal_value;
			}
                $from = CONTACT_EMAIL;
                $this->transaction_mail = array("deal_title" => $deal_title, "item_qty" => $qty ,"total" => ($deal_amount * $qty) ,"amount"=> ($deal_amount * $qty),"value" =>$deal_amount);
                $this->result_mail = arr::to_object($this->transaction_mail);
                /* Mail template */
                $message = new View("themes/".THEME_NAME."/payment_mail_product");
                email::sendgrid($from,$U->email, "Thanks for buying from ". SITENAME ,$message); 
		}
		return;
	}
    /** DoDirectPayment - Credit Card  **/

	public function dodirectpayment()
	{
		if($_POST){
		    $userid = $this->input->post("userid");
			$deal_id = $this->input->post("deal_id");
			$deal_key = $this->input->post("deal_key");
			$referral_amount = $this->input->post("referral_amount");
			$item_qty = $this->input->post("QTY");
			$this->deals_payment_deatils = $this->api->get_deals_payment_details($deal_id, $deal_key);

			if(count($this->deals_payment_deatils) == 0){			
			    $response = array("response" => array("httpCode" => 401 , "Message" => "Page not found !" ));
				echo json_encode($response);
				exit;
			}
			$this->referral_balance_deatils = $this->api->get_user_referral_balance_details($userid);
			$this->get_user_limit_details = $this->api->get_user_limit_details($deal_id,$userid);
			
			foreach($this->deals_payment_deatils as $UL){
				$purchase_qty = $UL->purchase_count;
				$max_user_limit = $UL->user_limit_quantity;
				$min_deals_limit = $UL->minimum_deals_limit;
				$merchant_id = $UL->merchant_id;
			}
			
			if($referral_amount > $this->referral_balance_deatils ){
			    $response = array("response" => array("httpCode" => 401 , "Message" => "Invalid referral amount" ));
				echo json_encode($response);
				exit;
			}

			if(($this->get_user_limit_details + $item_qty) > $max_user_limit){			
			    $response = array("response" => array("httpCode" => 401 , "Message" => "Maximum purchase limit reached" ));
				echo json_encode($response);
				exit;				
			}
			
			$post = new Validation($_POST);
			$post = Validation::factory($_POST)
			                ->add_rules('firstName','required')
			                ->add_rules('address1','required')
			                ->add_rules('creditCardNumber','required')
			                ->add_rules('city','required')
			                ->add_rules('state','required')
			                ->add_rules('zip','required')
			                ->add_rules('cvv2Number','required')
			                ->add_rules('amount','required')
			                ->add_rules('friend_name','required')
			                ->add_rules('friend_email','required');
			if($post->validate()){
				$post = arr::to_object($this->input->post());
				if(($purchase_qty + $item_qty) >= $min_deals_limit){
					    $paymentType = "Sale";
					    $captured = 0;
				    } else {
					    $paymentType = "Authorization";
					    $captured = 1;
				}
				$creditCardNumber = urlencode($post->creditCardNumber);
				$cvv2Number = urlencode($post->cvv2Number);
				$expDateMonth =urlencode( $post->expDateMonth);
				$padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);
				$expDateYear =urlencode( $post->expDateYear);			
				$firstName =urlencode( $post->firstName);
				$lastName =urlencode( $post->firstName);			
				$address1 = urlencode($post->address1);
				$city = urlencode($post->city);
				$state =urlencode($post->state);
				$zip = urlencode($post->zip);
				$country_code = "US";
				$amount = urlencode($post->amount);
				$currencyCode = "USD";			
				$friend_gift =$post->friend_gift;
				$friendName =$post->friend_name;
				$friendEmail =$post->friend_email;
			
				$nvpstr ="&PAYMENTACTION=$paymentType&AMT=$amount&ACCT=$creditCardNumber&EXPDATE=".$padDateMonth.$expDateYear."&CVV2=$cvv2Number&FIRSTNAME=$firstName&LASTNAME=$lastName&STREET=$address1&CITY=$city&STATE=$state&ZIP=$zip&COUNTRYCODE=$country_code&CURRENCYCODE=$currencyCode";

				$this->result = arr::to_object($this->hash_call("doDirectPayment", $nvpstr));
				$ack = strtoupper($this->result->ACK);

				if($ack == 'SUCCESS' || $ack == 'SUCCESSWITHWARNING'){
					$transaction = $this->api->insert_transaction_details($this->result, $deal_id, $country_code, $firstName, $lastName, $referral_amount, $item_qty, 1, $captured, $purchase_qty, $friend_gift, $friendName, $friendEmail,$merchant_id,$userid);
					$status = $this->do_captured_transaction($captured, $deal_id, $item_qty, $userid);
					$mail_status = $this->payment_mail_function($captured, $deal_id, $transaction);
					
					$R = $this->result;
					$response = array("response" => array("Transaction_Time" => $R->TIMESTAMP,"Transaction_id" =>$R->TRANSACTIONID,"Transaction_Status" => $R->ACK,"Transaction_amount" => $R->AMT ,"Currency_code" => $R->CURRENCYCODE, "httpCode" => 200, "Message" => "Payment successfully transaction", 'currency_symbol' => CURRENCY_SYMBOL));
				    echo json_encode($response);	
				    exit;				    
				}
				else{
				    $response = array("response" => array("httpCode" => 401 , "Message" => "Problem in paypal.Please Try again sometimes..." ));
				    echo json_encode($response);
				    exit;		
				}
			}
			else{
				$response = array("response" => array("httpCode" => 400 , "Message" => "Required data missing" ));
				echo json_encode($response);
				exit;
			}
		}
		else{	
			$response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
		    echo json_encode($response);
		    exit;		
		}
	}
	
	/** DOCAPTURED PAYMENT, UPDATED AMOUNT TO REFERED USERS, POST PURCHASE DEALS TO FACEBOOK WALL and SENT MAIL **/

	private function do_captured_transaction($captured = "", $deal_id = "", $qty = "", $userid = "")
	{
		if($captured == 0){
			$captured_list = $this->api->payment_authorization_list($deal_id);
			foreach($captured_list as $C){
				$nvpStr = "&AUTHORIZATIONID=".$C->transaction_id."&AMT=".$C->amount."&COMPLETETYPE=Complete";
				$result = arr::to_object($this->hash_call("DoCapture", $nvpStr));
				if($result->ACK = "Success" ){
				        $status = $this->api->update_captured_transaction($result, $C->id);
				}
			}			
		}
        $user_details = $this->api->get_purchased_user_details($userid);
		foreach($user_details as $U){
			if($U->referred_user_id && $U->deal_bought_count == $qty){
				$update_reff_amount = $this->api->update_referral_amount($U->referred_user_id);
			}
			if($U->facebook_update == 1){
				$deals_details = $this->api->get_deals_details($deal_id);
				foreach($deals_details as $D){
					$dealURL = PATH."deals/".$D->deal_key.'/'.$D->url_title.".html";
					$message = "I have purchased the deal...".$D->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $U->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg );
				}
			}
		}
		return;
	}
	
	/** Send Purchase details to user Email **/
	
	private function payment_mail_function( $captured = "", $deal_id = "", $transaction_id = "")
	{
		$from = NOREPLY_EMAIL;
		$transaction_details = $this->api->get_all_deal_captured_transaction($deal_id, $transaction_id, $captured);	
		foreach($transaction_details as $TD){		
		
		        $friend_details = $this->api->get_friend_transaction_details($deal_id, $TD->id);	
		        
                $friend_email = $friend_details->current()->friend_email;
                $friend_name = $friend_details->current()->friend_name;
        
			$this->result_mail = arr::to_object(array("deal_title" => $TD->deal_title, "item_qty" => $TD->quantity ,"total" => $TD->amount + $TD->referral_amount,"ref_amount"=> $TD->referral_amount, "amount"=> $TD->amount ,"friend_name" => $friend_name,"value" =>$TD->deal_value));
			    $subject = "Thanks for buying from ". SITENAME;			
			    if($friend_email != "xxxyyy@zzz.com"){
			            $friend_message = new View("themes/".THEME_NAME."/friend_buyit_mail");
			    } else {
			            $message = new View("themes/".THEME_NAME."/payment_mail");
			    }
			
			if($captured == 0){
				$transaction_coupon_details = $this->api->get_all_deal_captured_coupon($deal_id, $TD->user_id, $TD->order_date);
				$coupon_array = array();
				foreach($transaction_coupon_details as $coupon_details){
					$coupon_array[] = $coupon_details->coupon_code;	
				}				
				pdf::pdf_created($coupon_array);
				$file=array();
				for($i=0; $i < count($coupon_array); $i++){
					array_push($file, "images/pdf/Voucher".$i.".pdf");
				}				
				if($friend_email != "xxxyyy@zzz.com"){
				    $status = email::sendgrid_attach($friend_email, "You Got Coupon Gift from your Friend", $friend_message, $file);
				} else {
				    $status = email::sendgrid_attach($TD->email, $subject, $message, $file);
				}
				$transaction_coupon_update = $this->api->update_transaction_coupon_status($transaction_id,$TD->user_id);
				for($i=0; $i < count($coupon_array); $i++){
					unlink("images/pdf/Voucher".$i.".pdf");
				}
			}
			else{
		        if($friend_email != "xxxyyy@zzz.com"){
		                email::sendgrid($from, $friend_email, "You Got Coupon Gift from your Friend" ,$friend_message);
		        } else {			        
		                email::sendgrid($from,$TD->email, $subject, $message);
		        }
			}
		}		
		return;
	}
	
	/** Hash Call **/
	
	private function hash_call($methodName, $nvpStr)
	{
	        
		$nvpheader = $this->nvpHeader();
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->API_Endpoint);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);

		if($this->AUTH_token && $this->AUTH_signature && $this->AUTH_timestamp){
			$headers_array[] = "X-PP-AUTHORIZATION: ".$nvpheader;
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
			curl_setopt($ch, CURLOPT_HEADER, false);
		}
		else {
			$nvpStr = $nvpheader.$nvpStr;
		}
		
		if(strlen(str_replace('VERSION=', '', strtoupper($nvpStr))) == strlen($nvpStr)) {
			$nvpStr = "&VERSION=" . $this->Api_Version . $nvpStr;	
		}
               
		$nvpreq = "METHOD=".urlencode($methodName).$nvpStr;
				

		curl_setopt($ch,CURLOPT_POSTFIELDS,$nvpreq);
		$response = curl_exec($ch);
		$nvpResArray = $this->deformatNVP($response);
		if(curl_errno($ch)) { 
			$_SESSION['curl_error_no']=curl_errno($ch) ;
			$_SESSION['curl_error_msg']=curl_error($ch);
		} else {
			curl_close($ch);
		}

		return $nvpResArray;
	}

	/** NVP Header **/

	public function nvpHeader()
	{
		$nvpHeaderStr = "";
		if($this->Api_Username && $this->Api_Password && $this->Api_Signature && $this->Api_Subject) {
			$nvpHeaderStr = "&PWD=".urlencode($this->Api_Password)."&USER=".urlencode($this->Api_Username)."&SIGNATURE=".urlencode($this->Api_Signature)."&SUBJECT=".urlencode($this->Api_Subject);
		}
		elseif($this->Api_Username && $this->Api_Password && $this->Api_Signature) {
			$nvpHeaderStr = "&PWD=".urlencode($this->Api_Password)."&USER=".urlencode($this->Api_Username)."&SIGNATURE=".urlencode($this->Api_Signature);
		}
		elseif ($this->AUTH_token && $this->AUTH_signature && $this->AUTH_timestamp) {
			$nvpHeaderStr = $this->formAutorization($this->AUTH_token,$this->AUTH_signature,$this->AUTH_timestamp);
		}
		elseif($this->Api_Subject) {
			$nvpHeaderStr = "&SUBJECT=".urlencode($this->Api_Subject);
		}
		return $nvpHeaderStr;
	}
	
	/** form Autorization**/

	private function formAutorization($auth_token,$auth_signature,$auth_timestamp)
	{
		$authString="token=".$auth_token.",signature=".$auth_signature.",timestamp=".$auth_timestamp ;
		return $authString;
	}

	/** Format Response Data  **/

	private function deformatNVP($nvpstr)
	{
		$intial = 0;
		$nvpArray = array();

		while(strlen($nvpstr)){
			$keypos= strpos($nvpstr,'=');
			$valuepos = strpos($nvpstr,'&') ? strpos($nvpstr,'&'): strlen($nvpstr);

			$keyval=substr($nvpstr,$intial,$keypos);
			$valval=substr($nvpstr,$keypos+1,$valuepos-$keypos-1);

			$nvpArray[urldecode($keyval)] =urldecode( $valval);
			$nvpstr=substr($nvpstr,$valuepos+1,strlen($nvpstr));
		}
		return $nvpArray;
	}
	
	
	/** USER LOGIN **/
	
	public function login()
	{
		/*if($_POST){ */
			$post = $this->input->post();
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$status = $this->api->login($email, $password);
			if($status >= 1){
				$response = array("response" => array("user_id" => $status,"email" => $email,"httpCode" => 200,"Message" => "Successfully logged in"));
				echo json_encode($response);	
			}
			else if($status == -2){

				$response = array("response" => array("httpCode" => 401 , "Message" => "User is banned" ));
				echo json_encode($response);
			}
			else{
				$response = array("response" => array("httpCode" => 401 , "Message" => "Incorrect login details" ));
				echo json_encode($response);
			 }
			exit;
		/*} */
		$response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
		echo json_encode($response);
		exit;
	}

	/* USER REGISTRATION **/

	public function registration()
	{
		if($_POST){
			$post = new Validation($_POST);
			$post = Validation::factory($_POST)
						->add_rules('firstname','required')
						->add_rules('email','required')
						->add_rules('password','required')
						->add_rules('city_id','required');
			if($post->validate()){
                              
				if(!valid::email($this->input->post("email"))){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Invalid email" ));
					echo json_encode($response);
					exit;
				}
				if(strlen($this->input->post("password")) < 7){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Password should be minimum 6 chars" ));
					echo json_encode($response);
					exit;	
				}

				$status = $this->api->registration(arr::to_object($this->input->post()));

				if($status > 0){
					$response = array("response" => array("user_id" => $status, "email" => $post->email, "httpCode" => 200,"Message" => "Successfully user registered"));				
				}
				elseif($status == -1){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Users already exist" ));
				}
				elseif($status == -2){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Invalid city ID" ));

				}
				else{
					$response = array("response" => array("httpCode" => 401 , "Message" => "Error in user registration" ));
				}
				echo json_encode($response);exit;
				

			}
			else{
				$response = array("response" => array("httpCode" => 400 , "Message" => "Required data missing" ));
				echo json_encode($response);
				exit;
			}			
	
		}
		$response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
		echo json_encode($response);
		exit;
	}
	
	
	/** GET USER PROFILE DATA **/

	public function user_profile_data($user_id = "")
	{
		$data = $this->api->get_user_profile_data($user_id);
		if(count($data) > 0){
			foreach($data as $R){
			    if(file_exists(DOCROOT.'images/user/150_115/'.$user_id.'.png')){
					$user_image_path = PATH.'images/user/150_115/'.$user_id.'.png';
				}else{
					$user_image_path = PATH.'images/user/150_115/profileimg.png';
				}
				$response = array("response" => array("user_id" => $user_id, "email" => $R->email, "firstname" => $R->firstname, "lastname" => $R->lastname, "address1" => $R->address1, "address2" => $R->address2, "city_name" => $R->city_name,  "phone" => $R->phone_number, "user_image" => $user_image_path,  "httpCode" => 200));
				echo json_encode($response);
				exit;
			}
			
		}
		$response = array("response" => array("httpCode" => 401 , "Message" => "Invalid user" ));
		echo json_encode($response);
		exit;
		
	}
	
	/* EDIT PROFILE **/

	public function edit_profile()
	{
		if($_POST){
				    
			$post = new Validation($_POST);
			$userid = $this->input->post('userid');
			if($userid){
			$post = Validation::factory($_POST)
			            ->add_rules('userid','required')
						->add_rules('city_id','required');
			if($post->validate()){
                
				$status = $this->api->edit_profile(arr::to_object($this->input->post()));

				if($status > 0){
					$response = array("response" => array("httpCode" => 200,"Message" => "Successfully user profile updated"));				
				}
				elseif($status == -1){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Users not found" ));
				}
				else{
					$response = array("response" => array("httpCode" => 401 , "Message" => "Error in user profile update" ));
				}
				echo json_encode($response);
				exit;			

			}
			else{
				$response = array("response" => array("httpCode" => 400 , "Message" => "Required data missing" ));
				echo json_encode($response);
				exit;
			}			
	
		}		
		else{
				$response = array("response" => array("httpCode" => 400 , "Message" => "Login to edit profile" ));
				echo json_encode($response);
				exit;
			}		
		}
		$response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
		echo json_encode($response);
		exit;
	}
	
	/*  FORGOT PASSWORD **/

	public function forgot_password()
	{
		//if($_POST){		
		    $emailid = $this->input->post('emailid');
		    						                     
				$status = $this->api->forgot_password($emailid);

				if($status > 0){
					$response = array("response" => array("user_id" => $status, "email" => $emailid, "httpCode" => 200,"Message" => "Successfully your password changed please check your mail"));				
				}
				elseif($status == -1){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Users not found" ));
				}
				else{
					$response = array("response" => array("httpCode" => 401 , "Message" => "Error in user forgot password" ));
				}
				echo json_encode($response);
				exit;
	
		//}
		$response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
		echo json_encode($response);
		exit;
	}

	/* USER CHANGE PASSWORD **/

	public function change_password()
	{
		if($_POST){

			$post = new Validation($_POST);
			
			$post = Validation::factory($_POST)
						->add_rules('user_id','required')
						->add_rules('old_password','required')
						->add_rules('new_password','required');
			if($post->validate()){
                              
				if(strlen($this->input->post("new_password")) < 7){
					$response = array("response" => array("httpCode" => 401 , "Message" => "New password should be minimum 6 chars" ));
					echo json_encode($response);
					exit;	
				}
				if($this->input->post("old_password") == $this->input->post("new_password")){
					$response = array("response" => array("httpCode" => 401 , "Message" => "Current password and new password shouldn't be same" ));
					echo json_encode($response);
					exit;	
				}
				$status = $this->api->changepassword(arr::to_object($this->input->post()));
				if($status == 1){
					$response = array("response" => array("httpCode" => 200,"Message" => "Password changed successfully"));				
				}
				else{
					$response = array("response" => array("httpCode" => 401, "Message" => "The User id or current password doesn't match"));	
				}
				echo json_encode($response);
				exit;	

			}
			else{
				$response = array("response" => array("httpCode" => 400 , "Message" => "Required data missing" ));
				echo json_encode($response);
				exit;
			}	
		}   
		$response = array("response" => array("httpCode" => 400 , "Message" => "Invalid method type" ));
		echo json_encode($response);
		exit;
	}
	
	/** CITY LIST **/
	
	public function city_list()
	{
		$data = $this->api->get_city_list();
		if(count($data) > 0){
			foreach($data as $city){
				$response[] = array("city_list" => array("city_id" => $city->city_id, "country_id" => $city->country_id,"country_name" => $city->country_name, "city_name" => $city->city_name, "city_url" => $city->city_url));
			}
			$city_response["citylist"] = $response;
			echo json_encode($city_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No cities available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	/** CATEGORY LIST **/
	
	public function category_list()
	{
		$data = $this->api->get_category_list();
		if(count($data) > 0){
			foreach($data as $category){
				$response[] = array("category_list" => array("category_id" => $category->category_id, "category_name" => $category->category_name, "category_url_title" => $category->category_url));
			}
			$category_response["categorylist"] = $response;
			echo json_encode($category_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No categories available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	/** TODAY'S DEALS **/
	
	public function deals_listing($city_url = "", $search = "")
	{
		$data = $this->api->get_today_deals($city_url, $search);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/deals/220_160/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("dealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "deal_key" => $deals->deal_key,"description" => strip_tags($deals->deal_description), "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings, "store_name" => $deals->store_name,"startdate" => date('d-m-Y H:i:s', $deals->startdate),  "enddate" => date('d-m-Y H:i:s', $deals->enddate), "deal_category" => $deals->category_name, "latitude" => $deals->latitude, "longitude" => $deals->longitude, "image_url" => $image_path, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$today_deals_response["deallist"] = $response;
			echo json_encode($today_deals_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deals available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	
	/** TODAY'S DEALS **/
	
	public function deals_category_listing($category_id = "")
	{
		$data = $this->api->get_category_deals($category_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/deals/220_160/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("dealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "deal_key" => $deals->deal_key,"description" => strip_tags($deals->deal_description), "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings, "store_name" => $deals->store_name,"startdate" => date('d-m-Y H:i:s', $deals->startdate),  "enddate" => date('d-m-Y H:i:s', $deals->enddate), "deal_category" => $deals->category_name, "latitude" => $deals->latitude, "longitude" => $deals->longitude, "image_url" => $image_path,"city_name" => $deals->city_name,"city_id" => $deals->city_id, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$today_deals_response["dealcategorylist"] = $response;
			echo json_encode($today_deals_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deals available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	
	/** TODAY'S DEAL **/
	
	public function today_deals($city_url = "")
	{
		$data = $this->api->get_today_deal_details($city_url);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/deals/220_160/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("deal_details" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "image_url" => $image_path, "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings, "category" => $deals->category_name, "description" => strip_tags($deals->deal_description), "fineprints" => strip_tags($deals->fineprints), "highlights" => strip_tags($deals->highlights), "terms_conditions" => strip_tags($deals->terms_conditions), "purchase_count" => $deals->purchase_count, "startdate" => date('d-m-Y H:i:s', $deals->startdate),  "enddate" => date('d-m-Y H:i:s', $deals->enddate),"store_name" => $deals->store_name, "store_address" => $deals->address1.','.$deals->address2, "city_id" => $deals->city_id, "store_city_name" => $deals->city_name,  "store_phone_number" => $deals->phone, "store_website" => $deals->website, "store_latitude" => $deals->latitude, "store_longitude" => $deals->longitude, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$deal_detail_response["dealdetail"] = $response;
			echo json_encode($deal_detail_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deal available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	/** DEAL DETAILS **/
	
	public function deal_details($deal_id = "", $deal_key = "")
	{
		$data = $this->api->get_deal_details($deal_id,$deal_key);
		if(count($data) > 0){
			foreach($data as $deals){			
			    $con=0; 
                for($i=1; $i<=10; $i++){ 
                    if(file_exists(DOCROOT.'images/deals/466_347/'.$deals->deal_key.'_'.$i.'.png')) { 
                        $con=$con+1; 
                    } 
                 }
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
				        $image_path ="";
				        
				    for($i=1; $i<=$con; $i++){ 
					        $image_path .= PATH.'images/deals/466_347/'.$deals->deal_key.'_'.$i.'.png'.',';
					    }
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				
				
				if(file_exists(DOCROOT.'images/merchant/290_215/'.$deals->merchant_id.'_'.$deals->store_id.'.png')){
					$img_path = PATH.'images/merchant/290_215/'.$deals->merchant_id.'_'.$deals->store_id.'.png';
				}else{
					$img_path = PATH.'images/no-images.png';
				}
				$social_share = PATH.'deals/'.$deals->deal_key.'/'.$deals->url_title.'.html';
								
				$response[] = array("deal_details" => array("deal_id" => $deals->deal_id, "deal_key" => $deals->deal_key, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "image_url" => $image_path, "store_id" => $deals->store_id, "store_image_url" => $img_path,"deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings, "category" => $deals->category_name, "category_id" => $deals->category_id,"description" => strip_tags($deals->deal_description), "fineprints" => strip_tags($deals->fineprints), "highlights" => strip_tags($deals->highlights), "terms_conditions" => strip_tags($deals->terms_conditions), "purchase_count" => $deals->purchase_count, "startdate" => date('Y-m-d H:i:s', $deals->startdate),  "enddate" => date('Y-m-d H:i:s', $deals->enddate), "current_time" => date('Y-m-d H:i:s', time()), "store_name" => $deals->store_name, "store_address" => $deals->address1.','.$deals->address2, "city_id" => $deals->city_id, "store_city_name" => $deals->city_name,  "store_phone_number" => $deals->phone, "store_website" => $deals->website, "store_latitude" => $deals->latitude, "store_longitude" => $deals->longitude, "social_share" => $social_share, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$deal_detail_response["dealdetail"] = $response;
			echo json_encode($deal_detail_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deal available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	/** STORE LIST **/
	
	public function store_list($search="")
	{
		$data = $this->api->get_store_list($search);
		if(count($data) > 0){
			foreach($data as $stores){
				$store_type = "";
				if($stores->store_type == 1){
					$store_type = "Main Store";
				}else{
					$store_type = "Branch";
				}
				if(file_exists(DOCROOT.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png')){
					$img_path = PATH.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png';
				}else{
					$img_path = PATH.'images/no-images.png';
				}
				$response[] = array("store_list" => array("store_id" => $stores->store_id, "store_name" => $stores->store_name, "store_key" => $stores->store_key, "store_url_title" => $stores->store_url_title, "address1" => $stores->address1, "address2" => $stores->address2, "city_id" => $stores->city_id, "city_name" => $stores->city_name, "phone_number" => $stores->phone_number, "website" => $stores->website, "latitude" => $stores->latitude, "longitude" => $stores->longitude,  "store_type" => $store_type, "store_image" => $img_path));
			}
			$store_response["storelist"] = $response;
			echo json_encode($store_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No stores available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	
	/** STORE DETAIL **/
	
	public function store_detail($store_id = "")
	{
		$data = $this->api->get_store_detail($store_id);
		if(count($data) > 0){
			foreach($data as $stores){
				$store_type = "";
				if($stores->store_type == 1){
					$store_type = "Main Store";
				}else{
					$store_type = "Branch";
				}
				if(file_exists(DOCROOT.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png')){
					$img_path = PATH.'images/merchant/290_215/'.$stores->merchant_id.'_'.$stores->store_id.'.png';
				}else{
					$img_path = PATH.'images/no-images.png';
				}
				$response[] = array("store_detail" => array("store_id" => $stores->store_id, "store_name" => $stores->store_name, "store_key" => $stores->store_key, "store_url_title" => $stores->store_url_title, "address1" => $stores->address1, "address2" => $stores->address2, "city_id" => $stores->city_id, "city_name" => $stores->city_name, "phone_number" => $stores->phone_number, "website" => $stores->website, "latitude" => $stores->latitude, "longitude" => $stores->longitude,  "store_type" => $store_type, "store_image" => $img_path));
			}
			$store_response["storedetails"] = $response;
			echo json_encode($store_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No stores available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	/** SIMILAR DEALS BY STORES **/
	
	public function similar_deals_by_store($store_id = "")
	{
		$data = $this->api->get_similar_deals_stores($store_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/deals/220_160/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("similardealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "deal_key" => $deals->deal_key, "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "startdate" => date('d-m-Y H:i:s', $deals->startdate),  "enddate" => date('d-m-Y H:i:s', $deals->enddate),"deal_savings" => $deals->deal_savings, "store_name" => $deals->store_name, "deal_category" => $deals->category_name, "image_url" => $image_path, "deal_description" => strip_tags($deals->deal_description),'currency_symbol' => CURRENCY_SYMBOL));
			}
			$today_deals_response["similardeallist"] = $response;
			echo json_encode($today_deals_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deals available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	
	/** SIMILAR DEALS BY DEALS **/
	
	public function similar_deals_by_deals($deal_id = "", $category_id = "", $city_id ="")
	{
	    
		$data = $this->api->get_similar_deals_by_deals($deal_id, $category_id, $city_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/deals/220_160/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("similardealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "deal_key" => $deals->deal_key, "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "startdate" => date('d-m-Y H:i:s', $deals->startdate),  "enddate" => date('d-m-Y H:i:s', $deals->enddate),"deal_savings" => $deals->deal_savings, "store_name" => $deals->store_name, "deal_category" => $deals->category_name, "image_url" => $image_path, "deal_description" => strip_tags($deals->deal_description), 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$today_deals_response["similardeallistdeals"] = $response;
			echo json_encode($today_deals_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deals available" ));
			echo json_encode($response);
			exit;
		}
	}

	/** SIMILAR PRODUCT BY STORES **/
	
	public function similar_product_by_products($deal_id = "", $category_id = "", $city_id ="")
	{
		$data = $this->api->get_similar_product_by_products($deal_id, $category_id, $city_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/products/290_215/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/products/290_215/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}   
				$response[] = array("similarproductlist" => array("product_id" => $deals->deal_id, "product_title" => $deals->deal_title, "product_url_title" => $deals->url_title, "product_key" => $deals->deal_key, "product_price" => $deals->deal_price, "product_value" => $deals->deal_value, "product_discount" => round($deals->deal_percentage), "product_savings" => $deals->deal_savings, "store_name" => $deals->store_name, "product_category" => $deals->category_name, "image_url" => $image_path, "product_description" => strip_tags($deals->deal_description), "terms_conditions" => $deals->terms_conditions, 'currency_symbol' => CURRENCY_SYMBOL,"user_limit_quantity" => $deals->user_limit_quantity,"purchase_count" => $deals->purchase_count));
			}
			$today_deals_response["similarproductlistproducts"] = $response;
			echo json_encode($today_deals_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No product available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	
	/** SIMILAR PRODUCT BY PRODUCTS **/
	
	public function similar_product_by_store($store_id = "")
	{
		$data = $this->api->get_similar_product_stores($store_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/products/290_215/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/products/290_215/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				
				$response[] = array("similarproductlist" => array("product_id" => $deals->deal_id, "product_title" => $deals->deal_title, "product_url_title" => $deals->url_title, "product_key" => $deals->deal_key, "product_price" => $deals->deal_price, "product_value" => $deals->deal_value, "product_discount" => round($deals->deal_percentage), "product_savings" => $deals->deal_savings, "store_name" => $deals->store_name, "product_category" => $deals->category_name, "image_url" => $image_path, "product_description" => strip_tags($deals->deal_description), "terms_conditions" => $deals->terms_conditions, 'currency_symbol' => CURRENCY_SYMBOL,"user_limit_quantity" => $deals->user_limit_quantity,"purchase_count" => $deals->purchase_count));
			}
			$today_deals_response["similarproductliststore"] = $response;
			echo json_encode($today_deals_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No product available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	/** PRODUCTS LISTING **/
	
	public function product_listing($city_url = "",$search = "")
	{
		$data = $this->api->get_today_product($city_url, $search);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/products/290_215/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/products/290_215/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("dealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "deal_key" => $deals->deal_key,"description" => strip_tags($deals->deal_description), "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings,"purchase_count" => $deals->purchase_count,"user_limit_quantity" => $deals->user_limit_quantity, "store_name" => $deals->store_name, "deal_category" => $deals->category_name,"latitude" => $deals->latitude, "longitude" => $deals->longitude, "image_url" => $image_path, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$today_deals_response["productlist"] = $response;
			echo json_encode($today_deals_response);

			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No product available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	/** PRODUCT DETAILS **/
	
	public function product_details($deal_id = "", $deal_key = "")
	{
		$data = $this->api->get_product_details($deal_id,$deal_key);
		if(count($data) > 0){
			foreach($data as $deals){			
			    $con=0; 
                for($i=1; $i<=10; $i++){ 
                    if(file_exists(DOCROOT.'images/products/466_347/'.$deals->deal_key.'_'.$i.'.png')) { 
                        $con=$con+1; 
                    } 
                 }
				if(file_exists(DOCROOT.'images/products/290_215/'.$deals->deal_key.'_1.png')){
				        $image_path ="";
				        
				    for($i=1; $i<=$con; $i++){ 
					        $image_path .= PATH.'images/products/466_347/'.$deals->deal_key.'_'.$i.'.png'.',';
					    }
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				
				
				if(file_exists(DOCROOT.'images/merchant/290_215/'.$deals->merchant_id.'_'.$deals->store_id.'.png')){
					$img_path = PATH.'images/merchant/290_215/'.$deals->merchant_id.'_'.$deals->store_id.'.png';
				}else{
					$img_path = PATH.'images/no-images.png';
				}
				$social_share = PATH.'product/'.$deals->deal_key.'/'.$deals->url_title.'.html';
				$response[] = array("product_details" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "image_url" => $image_path, "store_id" => $deals->store_id, "store_image_url" => $img_path,"deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings, "category" => $deals->category_name,"user_limit_quantity" => $deals->user_limit_quantity, "category_id" => $deals->category_id,"description" => strip_tags($deals->deal_description),  "purchase_count" => $deals->purchase_count,  "store_name" => $deals->store_name, "store_address" => $deals->address1.','.$deals->address2, "city_id" => $deals->city_id, "store_city_name" => $deals->city_name,  "store_phone_number" => $deals->phone, "store_website" => $deals->website, "store_latitude" => $deals->latitude, "store_longitude" => $deals->longitude, "social_share" => $social_share, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$deal_detail_response["productdetail"] = $response;
			echo json_encode($deal_detail_response);
			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No product available" ));
			echo json_encode($response);
			exit;
		}
		
	}
	
	
	/** PRODUCTS CATEGORY LISTING **/
	
	public function products_category_listing($category_id = "")
	{
		$data = $this->api->get_category_product($category_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/products/290_215/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/products/290_215/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("dealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title, "deal_url_title" => $deals->url_title, "deal_key" => $deals->deal_key,"description" => strip_tags($deals->deal_description), "deal_price" => $deals->deal_price, "deal_value" => $deals->deal_value, "deal_discount" => round($deals->deal_percentage), "deal_savings" => $deals->deal_savings,"purchase_count" => $deals->purchase_count,"user_limit_quantity" => $deals->user_limit_quantity, "store_name" => $deals->store_name, "deal_category" => $deals->category_name,"latitude" => $deals->latitude, "longitude" => $deals->longitude, "image_url" => $image_path,"city_name" => $deals->city_name,"city_id" => $deals->city_id, 'currency_symbol' => CURRENCY_SYMBOL));
			}
			$today_deals_response["productcategorylist"] = $response;
			echo json_encode($today_deals_response);

			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No product available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	
	/** DEALS COUPONS LISTING **/
	
	public function deals_coupons_listing($user_id = "")
	{
		$data = $this->api->get_deals_coupons_list($user_id);
		if(count($data) > 0){
			foreach($data as $deals){
				if(file_exists(DOCROOT.'images/deals/220_160/'.$deals->deal_key.'_1.png')){
					$image_path = PATH.'images/deals/220_160/'.$deals->deal_key.'_1.png';
				}else{
					$image_path = PATH.'images/no-images.png';
				}
				$response[] = array("dealslist" => array("deal_id" => $deals->deal_id, "deal_title" => $deals->deal_title,"description" => strip_tags($deals->deal_description), "expiry_date" => date('d-m-Y', $deals->expirydate),"purchase_date" => date('d-m-Y', $deals->transaction_date), "coupon_code" => $deals->coupon_code,"coupon_status" => $deals->coupon_code_status, "store_name" => $deals->store_name, "image_url" => $image_path,"store_id" => $deals->store_id));
			}
			$today_deals_response["dealscouponslist"] = $response;
			echo json_encode($today_deals_response);

			exit;
		}else{
			$response = array("response" => array("httpCode" => 401 , "Message" => "No deals coupons available" ));
			echo json_encode($response);
			exit;
		}
	}
	
	/** GET DEALS USING GEO **/
	
	public function geo_products($latitude = "",$longitude = "")
	{
			    $data = file_get_contents("http://maps.googleapis.com/maps/api/geocode/json?latlng=".$latitude.",".$longitude."&sensor=false"); 
			              
			        $address = json_decode($data);
			        $addr = "";
			        $i = 0;
			        foreach($address->results[3] as $i => $val)
			        {
			               
			            if(count($val) > 1){
			                foreach($val as $city){
			                    if(isset($city->long_name)){
			                        $addr .= $city->long_name.',';
			                    }
			                }
			             }
			         }
			        if(!$addr){
    			        $addr = $address->results[0]->formatted_address;
    			    }
			        $city = explode(',',$addr);
			        //print_r($addr);exit;
			        if(count($city) > 2){
			            foreach($city as $c){
			                $city_url = $this->api->get_city_id(strtolower($c));
			                if($city_url){
			                    $this->product_listing($city_url);
			                }
			              }
			        }			     
			    $response = array("response" => array("httpCode" => 401 , "Message" => "No product available" ));
			    echo json_encode($response);
			    exit;
	}	
	
	/** GET DEALS USING GEO **/
	
	public function geo_deals($latitude = "",$longitude = "")
	{
			    $data = file_get_contents("http://maps.googleapis.com/maps/api/geocode/json?latlng=".$latitude.",".$longitude."&sensor=false"); 
			              
			        $address = json_decode($data);
			        $addr = "";
			        $i = 0;
			        foreach($address->results[3] as $i => $val)
			        {
			               
			            if(count($val) > 1){
			                foreach($val as $city){
			                    if(isset($city->long_name)){
			                        $addr .= $city->long_name.',';
			                    }
			                }
			             }
			         }
			        if(!$addr){
    			        $addr = $address->results[0]->formatted_address;
    			    }
			        $city = explode(',',$addr);
			        //print_r($addr);exit;
			        if(count($city) > 2){
			            foreach($city as $c){
			                $city_url = $this->api->get_city_id(strtolower($c));
			                if($city_url){
			                    $this->deals_listing($city_url);
			                }
			              }
			        }			     
			    $response = array("response" => array("httpCode" => 401 , "Message" => "No deals available" ));
			    echo json_encode($response);
			    exit;
	}
	
	
	/** GET DEALS USING GEO **/
	
	public function search_listing($keyword = "", $searchvalue = "")
	{
        if($keyword=="deal"){
                $this->deals_listing("",$searchvalue);
        } elseif($keyword=="product"){
                $this->product_listing("",$searchvalue);
        } elseif($keyword=="store"){
                $this->store_list($searchvalue);
        } else {
                $response = array("response" => array("httpCode" => 401 , "Message" => "Keyword not found" ));
	            echo json_encode($response);
	            exit;
        }
	}

	/** INVALID REQUEST  **/

	public function __call($method, $arguments)
	{
		$response = array("response" => array("httpCode" => 404 , "Message" => "Request URL found" ));
		json_encode($response);
		exit;
	}

}

