<?php defined('SYSPATH') or die('No direct script access.');
class Api_Model extends Model
{
	public function __construct()
	{	
		parent::__construct();
		$this->db = new Database();
	}
	
	
	/** GET DEALS PAYMENT DETAILS  **/
	
	public function get_deals_payment_details($deal_id = "", $deal_key = "")
	{
		$result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where deal_type = 1  and deal_status = 1 and category.category_status = 1 and  store_status = 1 and deal_key = '$deal_key'  and deals.deal_id = '$deal_id' and enddate > 'time()'");
	        return $result;
	}
	
	/** GET USER REFERRAL BALANCE DETAILS **/
	
	public function get_user_referral_balance_details($userid = "")
	{
		$result = $this->db->select("user_referral_balance")->from("users")
				   ->where(array("user_id" => $userid))
				   ->get();
		if(count($result)){
			return $result->current()->user_referral_balance;
		}
		return 0;
	}
	
	/** GET USER LIMIT **/
	
	public function get_user_limit_details($deal_id = "",$userid = "")
	{
		$result = $this->db->count_records("transaction_mapping", array( "deal_id" => $deal_id, "user_id" => $userid));	            
                return $result;
	}
	
	
	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CREDIT CARD PAYMENT **/

	public function insert_product_transaction_details($R = "", $deal_id = "", $country_code = "", $firstName = "", $lastName = "", $ref_amount = 0, $qty = 1, $type = 1, $captured = 0, $purchase_qty = "" ,$post = "",$merchant_id = "",$userid = "")
	{
	
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission;     
		$result = $this->db->insert("transaction",array("user_id" => $userid , "deal_id" => $deal_id, "country_code" => $country_code, "currency_code" => $R->CURRENCYCODE, "transaction_date" => strtotime($R->TIMESTAMP), "correlation_id" => $R->CORRELATIONID, "acknowledgement" => $R->ACK, "firstname" => $firstName, "lastname" => $lastName, "transaction_id" => $R->TRANSACTIONID, "order_date" => time(), "amount" => $R->AMT, "referral_amount" => $ref_amount, "payment_status" => $R->ACK, "quantity" => $qty, "type" => $type, "captured" => $captured,'deal_merchant_commission' => $commission_amount));
		$trans_ID = $result->insert_id();

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("deal_id" => $deal_id , "user_id" => $userid, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time()));
		}
		
		$this->db->insert("shipping_info", array("transaction_id" => $trans_ID , "user_id" => $userid, "adderss1" => $post->shipping_adderss1 , "address2" => $post->shipping_address2, "city" => $post->shipping_city ,"state" => $post->shipping_state ,"country" => $post->shipping_country, "shipping_date" => time()));

		 $purchase_count_total = $purchase_qty + $qty;
	     $result_deal = $this->db->update("deals", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
	     $this->db->query("update users set merchant_account_balance = merchant_account_balance + $R->AMT where user_type = 1");
		

		return $trans_ID;
	}
	
	
	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CREDIT CARD PAYMENT **/

	public function insert_transaction_details($R = "", $deal_id = "", $country_code = "", $firstName = "", $lastName = "", $ref_amount = 0, $qty = 1, $type = 1, $captured = 0, $purchase_qty = "" ,$friend_gift = "",$friendName = "",$friendEmail = "",$merchant_id = "",$userid = "")
	{
	
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission; 

		$payment_status = "Pending";
		if($captured == 0){
			$payment_status = "Completed";
		}
		
		$result = $this->db->insert("transaction",array("user_id" => $userid , "deal_id" => $deal_id, "country_code" => $country_code, "currency_code" => $R->CURRENCYCODE, "transaction_date" => strtotime($R->TIMESTAMP), "correlation_id" => $R->CORRELATIONID, "acknowledgement" => $R->ACK, "firstname" => $firstName, "lastname" => $lastName, "transaction_id" => $R->TRANSACTIONID, "order_date" => time(), "amount" => $R->AMT, "referral_amount" => $ref_amount, "payment_status" => $payment_status, "quantity" => $qty, "type" => $type, "captured" => $captured,"friend_gift_status" => $friend_gift, 'deal_merchant_commission' => $commission_amount));

		$trans_ID = $result->insert_id();

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("deal_id" => $deal_id , "user_id" => $userid, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" =>$friendName, "friend_email" => $friendEmail ));
			
		}

		 $purchase_count_total = $purchase_qty + $qty;
	         $result_deal = $this->db->update("deals", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
		 $this->db->query("update users set user_referral_balance = user_referral_balance - $ref_amount, deal_bought_count = deal_bought_count + $qty where user_id = $userid");
		 $this->db->query("update users set merchant_account_balance = merchant_account_balance + $R->AMT where user_type = 1");

		return $trans_ID;
	}
	
	
	/** GET AUTHORIZATION PAYMENT LIST FROM TRANSACTION LIST  **/

	public function payment_authorization_list( $deal_id = "")
	{
		$result = $this->db->from("transaction")->where(array("deal_id" => $deal_id, "captured" => 1))->get();
		return $result;
	}
	
	/** UPDATE THE CAPTURED TRANSACTION **/

	public function update_captured_transaction($C = "", $id = "")
	{
		$contition = array("captured_transaction_id" => $C->TRANSACTIONID , "captured_date" => strtotime($C->TIMESTAMP) , "captured_correlation_id" => $C->CORRELATIONID, "captured_ack" => $C->ACK, "captured_payment_type" => $C->PAYMENTTYPE , "captured_payment_status" => $C->PAYMENTSTATUS, "captured_pending_reason" => $C->PENDINGREASON);	
		if($C->PAYMENTSTATUS == "Completed"){			
			$contition = array("captured_transaction_id" => $C->TRANSACTIONID , "captured_date" => strtotime($C->TIMESTAMP) , "captured_correlation_id" => $C->CORRELATIONID, "captured_ack" => $C->ACK, "captured_payment_type" => $C->PAYMENTTYPE , "captured_payment_status" => $C->PAYMENTSTATUS, "captured_pending_reason" => $C->PENDINGREASON, "captured" => 0, "payment_status" => "Completed");
		}
		$result = $this->db->update("transaction", $contition , array("id" => $id));
		return;
	}

	/** GET ALL CAPTURED TRANSACTION LIST **/

	public function get_all_deal_captured_transaction($deal_id = "", $transaction_id = "", $captured = "")
	{
		if($captured  == 0){
			$cont = array("transaction.deal_id" => $deal_id, "captured" => 0, "coupon_mail_sent" => 0);
		}
		else{
			$cont = array("transaction.id" => $transaction_id);
		}
		$result = $this->db->select("users.email", "transaction.id", "deal_title","deal_value", "transaction.quantity", "transaction.amount", "transaction.referral_amount", "transaction.user_id", "transaction.order_date")
					->from("transaction")
					->join("deals", "deals.deal_id", "transaction.deal_id")
					->join("users", "users.user_id", "transaction.user_id")
					->where($cont)
					->get();
		return $result;
	}
	
	
	/** GET PURCHASED USERID **/

	public function get_purchased_user_details($userid = "")
	{
		$result = $this->db->from("users")->where(array("user_id" => $userid))->get();
		return $result;
	}
	
	/** UPDATE AMOUNT TO REFERED USER **/

	public function update_referral_amount($ref_user_id = "")
	{
		$referral_amount = REFERRAL_AMOUNT;
		
		$this->db->query("update users set user_referral_balance = user_referral_balance+$referral_amount where user_id = $ref_user_id");
		return;
	}
	
	/** *GET DEALS DETAILS */

	public function get_deals_details($deal_id = "")
	{
		$result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where deal_type = 1 and deal_status = 1 and category.category_status = 1 and  store_status = 1 and deals.deal_id = '$deal_id'");
	        return $result;
	}
	/** *GET DEALS DETAILS */

	public function get_product_details_share($deal_id = "")
	{
		$result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where deal_type = 2 and deal_status = 1 and category.category_status = 1 and  store_status = 1 and deals.deal_id = '$deal_id'");
	        return $result;
	}

    /** GET FRIEND DETAILS **/

	public function get_friend_transaction_details($deal_id = "", $transaction_id = "")
	{
	        $result = $this->db->select("transaction_mapping.friend_name", "transaction_mapping.friend_email")
					->from("transaction_mapping")
					->where(array("transaction_id" => $transaction_id, "deal_id" => $deal_id))
					->get();
		return $result;
	
	}
	
	/** GET COUPON DETAILS **/

	public function get_all_deal_captured_coupon($deal_id = "", $user_id = "", $order_date = "")
	{
		     $result = $this->db->select("coupon_code")->from("transaction_mapping")
		                        ->join("transaction", "transaction.id", "transaction_mapping.transaction_id")
					->where(array("transaction_mapping.deal_id" => $deal_id, "coupon_code_status" => 1, "transaction_mapping.user_id" => $user_id, "transaction_mapping.transaction_date" => $order_date, "transaction.coupon_mail_sent" => 0))
					->get();
		        return $result;
	}
	
	/** UPDATE TRANSACTION COUPON STATUS  **/
	
	public function update_transaction_coupon_status($transaction_id = "", $user_id = "")
	{
	                $result = $this->db->update("transaction", array("coupon_mail_sent" => 1), array("transaction.id" => $transaction_id, "transaction.user_id" => $user_id)); 
	}
	
	/** USER LOGIN **/

	public function login($email = "",$password = "")
	{
		$result = $this->db->from("users")->where(array("email" => $email, "password" =>  md5($password)))->get();
		if(count($result) == 1){
			if($result->current()->user_status == 1){
			        return $result->current()->user_id;
			}
			else if($result->current()->user_status == 0){
			        return -2;
			}
		} 
		return -1;
	}

	/** USER REGISTRATION **/

	public function registration($post = array())
	{
		$result = $this->db->count_records('users', array('email' => $post->email));
		if($result == 0){
			$citycount = $this->db->count_records('city', array('city_id' => $post->city_id));
			if($citycount == 0){
				return -2;
			}

			$status = $this->db->insert("users",array("firstname" => $post->firstname, "email" => $post->email, "password" => md5($post->password), "city_id" => $post->city_id));
			return $status->insert_id();

		}
		return -1;
	}
	
	/** EDIT PROFILE **/

	public function edit_profile($post = array())
	{
		$result = $this->db->count_records('users', array('user_id' => $post->userid));
		    if($result){	
		       $status =  $this->db->update("users",array("firstname" => $post->firstname, "lastname" => $post->lastname, "address1" => $post->address1, "address2" => $post->address2, "phone_number" => $post->phone, "city_id" => $post->city_id), array('user_id' => $post->userid));
			    return 1;
		    }
		return -1;
	}
	
	
	/** FORGOT PASSWORD **/

	public function forgot_password($emailid)
	{
		$result = $this->db->count_records('users', array('email' => $emailid));
		if($result){		
		        $password = text::random($type = 'alnum', $length = 10);
		        $this->db->update("users",array("password" => md5($password) ), array('email' => $emailid));	
			    if($emailid){
			        $from = CONTACT_EMAIL;
				    $message = ucfirst($emailid).",";

				    $message .= "<p>Your Password  reset </p><p>Email : ".$emailid."<p/><p>Password : ".$password."<p/><br /> <p>Thanks,</p>";    
				    email::sendgrid($from, $emailid, SITENAME  ,$message);
			    }
			return 1;
		}
		return -1;
	}

	/** CHANGE PASSWORD **/

	public function changepassword($post = array())
	{
		$citycount = $this->db->update('users', array("password" => md5($post->new_password) ), array('user_id' => $post->user_id, "password" => md5($post->old_password)));
		if(count($citycount) == 1){
			return 1;
		}
		return -1;
	}

	
	/** USER PROFILE DATA ( PARAMETER USER ID ) **/

	public function get_user_profile_data($user_id = "")
	{
		$result = $this->db->select("firstname", "lastname", "email", "address1", "address2", "city_name", "users.country_id", "phone_number")->from("users")->join('city', 'city.city_id','users.city_id')->where(array("user_id" => $user_id ))->get();
		return $result;
	}
	
	/** CITY LIST **/
	
	public function get_city_list()
	{
		$result = $this->db->from('city')->join('country', 'country.country_id','city.country_id')
										 ->where(array('city_status' => 1))
										 ->orderby("city_name", "ASC")
										 ->get();
		return $result;
	}
	
	/** CATEGORY LIST **/
	
	public function get_category_list()
	{
		$result = $this->db->from("category")->where(array("category_status" => 1))->orderby("category_name", "ASC")->get();
		return $result;
	}
	
	/** DEALS LIST **/
	
	public function get_today_deals($city_url, $search)
	{
	    
	     $conditions = " deal_type = 1 and enddate > 'time()' and deal_status = 1 and category.category_status = 1 and  store_status = 1 ";
	    if($search){
			$conditions .= " and (deal_title like '%".mysql_escape_string($search)."%'";
			$conditions .= " or deal_description like '%".mysql_escape_string($search)."%')";
		}
		 if($city_url){
		    $conditions .= "and city.city_url = '$city_url'";
		 }
		
		$query = "select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id join city on city.city_id=stores.city_id where $conditions order by deal_id DESC ";
		$result = $this->db->query($query);
		return $result;
	}
	
	/** DEALS LIST **/
	
	public function get_category_deals($category_id)
	{
		$result = $this->db->from("deals")->join("category", "category.category_id", "deals.category_id")
                                          ->join("stores", "stores.store_id", "deals.shop_id")
                                          ->join("city", "city.city_id", "stores.city_id")
										  ->where(array("deal_type" => 1, "deal_status" => 1, "enddate >" => time(),"deals.category_id" => $category_id, "category.category_status" => 1, "store_status" => 1, "city_status" => 1))
                                          ->orderby("deal_id", "DESC")
										  ->get();
		return $result;
	}
	
	/** TODAY DEAL **/
	
	public function get_today_deal_details($city_url = "")
	{
		$result = $this->db->from("deals")->join("category", "category.category_id", "deals.category_id")
                                          ->join("stores", "stores.store_id", "deals.shop_id")
                                          ->join("city", "city.city_id", "stores.city_id")
										  ->where(array("city.city_url" => $city_url, "deal_type" => 1, "deal_status" => 1, "enddate >" => time(), "category.category_status" => 1, "store_status" => 1, "city_status" => 1))
                                          ->orderby("deal_id", "DESC")
										  ->limit(1)
										  ->get();
		return $result;
	}
	
	/** DEAL DETAILS **/
	
	public function get_deal_details($deal_id = "", $deal_key = "")
	{
		$result = $this->db->select("*", "stores.phone_number as phone")
						   ->from("deals")
						   ->join("stores", "stores.store_id", "deals.shop_id")
			               ->join("city", "city.city_id", "stores.city_id")
			               //->join("country", "country.country_id", "stores.country_id")
					       //->join("users", "users.user_id", "deals.merchant_id")
					       ->join("category", "category.category_id", "deals.category_id")
			               ->where(array("deal_key" => $deal_key, "deal_id" => $deal_id, "deal_type" => 1, "deal_status" => 1, "category.category_status" => 1, "store_status" => 1))
	 	                   ->get();
		return $result;
	}
	
	/** STORE LIST **/
	
	public function get_store_list($search = "")
	{
	
	    $conditions = " stores.store_status = 1 ";
	    if($search){
			$conditions .= " and store_name like '%".mysql_escape_string($search)."%'";
		}				
		$query = "select * from stores join city on city.city_id=stores.city_id where $conditions ";
		$result = $this->db->query($query);
		return $result;
		
		
	}
	
	/** STORE DETAILS **/
	
	public function get_store_detail($store_id = "")
	{
	    
		$result = $this->db->from("stores")
										   ->join("city", "city.city_id", "stores.city_id")
										   ->where(array("store_id" => $store_id))
										   ->get();
		return $result;
	}
	
	/** GET SIMILAR DEALS BY STORES **/
	
	public function get_similar_deals_stores($store_id = "")
	{
		$result = $this->db->from("deals")->join("category", "category.category_id", "deals.category_id")
                                          ->join("stores", "stores.store_id", "deals.shop_id")
                                          ->join("city", "city.city_id", "stores.city_id")
										  ->where(array("stores.store_id" => $store_id, "deal_type" => 1, "deal_status" => 1, "enddate >" => time(), "category.category_status" => 1, "store_status" => 1, "city_status" => 1))
                                          ->orderby("deal_id", "DESC")
										  ->get();
		return $result;
	}
	
	
	/** GET SIMILAR DEALS BY STORES **/
	
	public function get_similar_deals_by_deals($deal_id = "", $category_id = "", $city_id = "")
	{
	
		$result = $this->db->select("*","stores.phone_number as phone")->from("deals")
	                        ->where(array("deal_id <>" => $deal_id, "deal_type" => 1, "deals.category_id" =>$category_id, "stores.city_id" => $city_id, "enddate >" => time(),"deal_status" => 1, "category.category_status" => 1, "store_status" => 1))
			                ->join("stores","stores.store_id","deals.shop_id")
				            ->join("category","category.category_id","deals.category_id")
				            ->orderby("deal_id", "DESC")
 	                        ->get();
                return $result;
	}
	
	
	/** GET SIMILAR PRODUCT BY PRODUCTS **/
	
	public function get_similar_product_by_products($deal_id = "", $category_id = "", $city_id = "")
	{
	
		    $result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where deal_type = 2 and purchase_count < user_limit_quantity and deal_status = 1 and category.category_status = 1 and  store_status = 1 and deal_id <> '$deal_id'  and stores.city_id = '$city_id' and deals.category_id =  '$category_id'   order by deal_id DESC ");
	        return $result;
	}
	
	/** GET SIMILAR PRODUCT BY PRODUCTS **/
	
	public function get_today_product($city_url = "",$search = "")
	{ 
	
	    $conditions = " deal_type = 2 and deal_status = 1 and category.category_status = 1 and  store_status = 1 ";
	    if($search){
			$conditions .= " and (deal_title like '%".mysql_escape_string($search)."%'";
			$conditions .= " or deal_description like '%".mysql_escape_string($search)."%')";
		}
		 if($city_url){
		    $conditions .= "and city.city_url = '$city_url'";
		 }
		
		$query = "select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id join city on city.city_id=stores.city_id where $conditions order by deal_id DESC ";
		$result = $this->db->query($query);
		return $result;
			    
	}
	
	public function get_category_product($category_id = "")
	{ 
	
	        $result = $this->db->from("deals")->join("category", "category.category_id", "deals.category_id")
                                          ->join("stores", "stores.store_id", "deals.shop_id")
                                          ->join("city", "city.city_id", "stores.city_id")
										  ->where(array("deal_type" => 2, "deal_status" => 1, "deals.category_id" => $category_id, "category.category_status" => 1, "store_status" => 1, "city_status" => 1))
                                          ->orderby("deal_id", "DESC")
										  ->get();
		            return $result;		    
	}
	
	/** GET SIMILAR PRODUCT BY STORES **/
	
	public function get_similar_product_stores($store_id = "")
	{
		$result = $this->db->from("deals")->join("category", "category.category_id", "deals.category_id")
                                          ->join("stores", "stores.store_id", "deals.shop_id")
                                          ->join("city", "city.city_id", "stores.city_id")
										  ->where(array("stores.store_id" => $store_id, "deal_type" => 2, "deal_status" => 1, "category.category_status" => 1, "store_status" => 1, "city_status" => 1, "purchase_count !=" => "deals.user_limit_quantity"))
                                          ->orderby("deal_id", "DESC")
										  ->get();
		return $result;
	}
	
	
	/**GET DELAS COUPONS LIST**/

	public function get_deals_coupons_list($user_id = "")
	{
		$result = $this->db->from("transaction")
                    ->where(array("deal_type"=>1,"transaction.user_id" => $user_id,"transaction_mapping.user_id" => $user_id))
                    ->join("deals","deals.deal_id","transaction.deal_id")
                    ->join("transaction_mapping","transaction_mapping.transaction_id","transaction.id")
                    ->join("stores","stores.store_id","deals.shop_id")
                    ->orderby("transaction.transaction_date","DESC")
                    ->get();
		return $result;	
	}
	
	/** VIEW PRODUCTS **/
	
	public function get_product_details($deal_id = "", $deal_key = "")
	{
	        $result = $this->db->select("*","stores.phone_number as phone")->from("deals")
	                        ->where(array("deal_id" => $deal_id, "deal_key" => $deal_key,"deal_type" => 2,"deal_status" => 1, "category.category_status" => 1, "store_status" => 1))
			                ->join("stores","stores.store_id","deals.shop_id")
	                        ->join("city","city.city_id","stores.city_id")
	                        ->join("country","country.country_id","stores.country_id")
				            ->join("users","users.user_id","deals.merchant_id")
				            ->join("category","category.category_id","deals.category_id")
 	                        ->get();
                return $result;
	}
	
	/** GET CITY ID FOR CITY NAME **/
	
	public function get_city_id($city_name = "")
	{
		$city_url = url::title($city_name);
		$query = "select city_id from city where city_url like '%$city_url%'";
		$result = $this->db->query($query);
		if(count($result) > 0)
		{
			return $city_url;
		}
		return 0;
	}
	
	/** GET PRODUCT PAYMENT DETAILS  **/
	
	public function get_product_payment_details($deal_id = "")
	{
		$result = $this->db->query("select * from deals  join category on category.category_id=deals.category_id where deal_type = 2  and deal_status = 1 and category.category_status = 1 and deal_id = '$deal_id' ");
	        return $result;

	}
	
}	
