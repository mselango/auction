<?php defined('SYSPATH') OR die('No direct access allowed.');
class Cash_on_delivery_Controller extends Layout_Controller
{
	const ALLOW_PRODUCTION = FALSE;
	public function __construct()
	{
		parent::__construct();
		$this->cash = new Cash_on_delivery_Model;
		$this->deals = new Auction_Model();
		  $this->template->style .= html::stylesheet(array(PATH.'themes/'.THEME_NAME.'/css/style.css'));
	}
		
	/** CASH ON DELIVERY  **/

	public function cash_delivery()
	{
		 $product_size = "1";    
        $product_size = "1"; 
		foreach($_SESSION as $key=>$value) 
        { 
            if(($key=='product_cart_id'.$value)){
            $item_qty = $this->input->post($key);
            $deal_id = $_SESSION[$key]; 
                foreach($_SESSION as $key=>$value) 
                {
                    if(($key=='product_size_qty'.$deal_id)){
                        $product_size = $value;
                    }
                    if(($key=='product_quantity_qty'.$deal_id)){
                        $product_quantity = $value;
                    }
                    
                }                
                $this->product_size_details = $this->cash->product_size_details($deal_id, $product_size);	
                $dbquantity=$this->product_size_details->current()->quantity;
   
                if($dbquantity < $item_qty){
                    $this->session->set('product_quantity_qty'.$deal_id,$dbquantity);
                    common::message(-1, "Check your product quantity");
                    url::redirect(PATH."cart.html");
                }
            }
        }  

		if($_POST){ 

			$referral_amount = $this->input->post("p_referral_amount");
		        $this->userPost = $this->input->post();
				$product_color="";
				$paymentType = "COD";
				$captured = 0;
				$total_amount="";
		        $total_qty="";
		        $product_title="";
		        $produ_qty="";
		        $total_shipping="";
		        foreach($_SESSION as $key=>$value) 
                {                     
                    if(($key=='product_cart_id'.$value)){
						$product_color = 0; 
                        $product_size = 0;                    
                    $deal_id = $_SESSION[$key];
                    $item_qty = $this->input->post($key);	
                    $this->session->set('product_cart_qty'.$deal_id,$item_qty);
                    $amount = $this->input->post("amount");
			        $this->deals_payment_deatils = $this->cash->get_product_payment_details($deal_id);			
			        if(count($this->deals_payment_deatils) == 0){
                        unset($_SESSION[$key]);
                        $this->session->delete('product_cart_qty'.$value);                                     
                        $this->session->delete("count"); 
				        common::message(-1, $this->Lang["PAGE_NOT"]);
				        url::redirect(PATH."products.html");
			        }
			        foreach($this->deals_payment_deatils as $UL){
			            $purchase_qty = $UL->purchase_count;
				        $deal_title = $UL->deal_title;
				        $deal_key  = $UL->deal_key;
				        $url_title = $UL->url_title;
				        $deal_value = $UL->deal_value;
				        $product_amount = $UL->deal_value*$item_qty;
						$merchant_id = $UL->merchant_id;
						$product_shipping = $UL->shipping_amount;
			        }

					 if($this->shipping_setting  == 1){
			        $shipping_amount = 0;
			        }  elseif($this->shipping_setting  == 2){
			        $total_flateshipping = FLAT_SHIPPING_AMOUNT;
			        $total_count = $this->session->get("count");
			        $shipping_amount = number_format((float)($total_flateshipping/$total_count), 2, '.', '');
			        } elseif($this->shipping_setting  == 3){
			        $shipping_amount =$product_shipping;
			        } elseif($this->shipping_setting  == 4){
			        $shipping_amount =$product_shipping*$item_qty;
			        }		        
			       	        
			        $taxdeal_amount=($deal_value*$item_qty)+$shipping_amount;
			        $tax_amount = ((TAX_PRECENTAGE_VALUE/100)*$taxdeal_amount);
					foreach($_SESSION as $key=>$value) 
                    {
                    if(($key=='product_size_qty'.$deal_id)){
                        $product_size = $value;
                    }
                    if(($key=='product_color_qty'.$deal_id)){
                        $product_color = $value;
                    }
                   
                    }	
					
					
						$transaction = $this->cash->insert_cash_delivery_transaction_details($deal_id, $referral_amount, $item_qty, 5, $captured, $purchase_qty,$paymentType,$product_amount,$merchant_id,$product_size,$product_color,$tax_amount,$shipping_amount, arr::to_object($this->userPost));
	
				   $status = $this->do_captured_transaction($captured, $deal_id,$item_qty,$transaction);	
			                         		        
			       }                                   
	            }

				url::redirect(PATH."payment_product/cart_payment_paypal.html");	
				
			        
			}
	}


	public function deal_cash_delivery()
	{
		if($_POST){
			$deal_id = $this->input->post("deal_id");
			$deal_key = $this->input->post("deal_key");
			$referral_amount = $this->input->post("p_referral_amount");
			$item_qty = $this->input->post("P_QTY");
			$this->paypal = new Paypal_Model;
			$this->deals_payment_deatils = $this->paypal->get_deals_payment_details($deal_id, $deal_key);

			if(count($this->deals_payment_deatils) == 0){
				common::message(-1, $this->Lang["PAGE_NOT"]);
				url::redirect(PATH);
			}
			$this->referral_balance_deatils = $this->paypal->get_user_referral_balance_details();
			$this->get_user_limit_details = $this->paypal->get_user_limit_details($deal_id);
			$this->get_user_limit_count = $this->paypal->get_user_limit_details($deal_id);
			$this->user_referral_balance = $this->paypal->get_user_referral_balance_details();
			
			foreach($this->deals_payment_deatils as $UL){
				$purchase_qty = $UL->purchase_count;
				$max_user_limit = $UL->user_limit_quantity;
				$min_deals_limit = $UL->minimum_deals_limit;
				$merchant_id = $UL->merchant_id;
			}
			
			if($referral_amount > $this->referral_balance_deatils ){
				common::message(-1,$this->Lang["INVALID_REF_AMONT"]);
				url::redirect(PATH);
			}

			if(($this->get_user_limit_details + $item_qty) > $max_user_limit){
				common::message(-1, $this->Lang["MAX_PURCH_LIMIT"]);
				url::redirect(PATH);
			}
			if(($purchase_qty + $item_qty) >= $min_deals_limit){
					    $captured = 0;
				    } else {
					   
					    $captured = 2;
				}	
				$paymentType = "COD";
							$post = Validation::factory($_POST)
			                ->add_rules('shipping_name','required','chars[a-zA-Z_ -.,%\']')
			                ->add_rules('address','required')
			               ->add_rules('country','required')
			                ->add_rules('postal_code','required')
			                ->add_rules('phone','required')
			                ->add_rules('email','required')
			                
			                ->add_rules('state','required');
			               
			if($post->validate()){	
							
				$sname =$this->input->post('shipping_name');
				$email =$this->input->post('email');
				$address = $this->input->post('address');
				//$address = $this->input->post('address');
				$city = $this->input->post('city');
				$country = $this->input->post('country');
				$state =$this->input->post('state');
				$zip = $this->input->post('postal_code');
				$phone = $this->input->post('phone');
				$country_code = COUNTRY_CODE;
				$amount = $this->input->post('amount');
				$fb_id = $this->input->post('fb_id');
				$currencyCode = CURRENCY_CODE;			
				$friend_gift =$this->input->post('friend_gift');
				$friendName =$this->input->post('friend_name');
				$friendEmail =$this->input->post('friend_email');
			
				$transaction=$this->cash->insert_deal_cod_details($sname,$email,$phone,$address,$city,$state,$country,$zip,$deal_id,$amount,$item_qty,$fb_id);
					//$transaction = $this->cash->insert_transaction_details($deal_id, $country_code,$currencyCode, $firstName, $lastName, $referral_amount,$amount, $item_qty, 5, $captured, $purchase_qty, $friend_gift, $friendName, $friendEmail,$merchant_id,$address1,$address2,$city,$country,$state,$zip,$phone);
					//$status = $this->do_captured_deal_transaction($captured, $deal_id, $item_qty);
				//	$mail_status = $this->payment_mail_function($captured, $deal_id, $transaction);
					// $this->transaction_result = array("TIMESTAMP" => date('m/d/Y h:i:s a', time()), "ACK" => "Success" ,"AMT"=> $amount,"CURRENCYCODE" =>$currencyCode);
					//$this->result = arr::to_object($this->transaction_result);
				//	$this->session->set('payment_result', $this->result);
				//	url::redirect(PATH.'transaction.html');
				
			common::message(1, "Your Order has been submitted for admin approval");
			url::redirect(PATH);
				
		}
		else
		{
			$this->deal_cod=1;
			$this->form_error = error::_error($post->errors());
		$this->template->content = new View("themes/".THEME_NAME."/payment");
				
		}
	}
		else{	
			common::message(-1, $this->Lang["PAGE_NOT"]);
			url::redirect(PATH);		
		}
	}
	
	
		public function auction_cash_delivery()
	{

		if($_POST){ 	
			$deal_id = $this->input->post("deal_id"); 
			$merchant_id = $this->input->post("merchant_id"); 
			$bid_id = $this->input->post("bid_id"); 
			$deal_key = $this->input->post("deal_key"); 
		    $url_title = $this->input->post("url_title");   
			$referral_amount = 0;
			$item_qty = $this->input->post("P_QTY");
			$amount = $this->input->post("amount");			
			$deal_value = $this->input->post("deal_value");
			$shipping_amount = $this->input->post("shipping_amount");
			$tax_amount = 0;			

		    $tot_amount = $amount+$shipping_amount;
			$paymentType = "Sale";
			$captured = 0;
			
			$sname = $this->input->post("shipping_name");			
			$address = $this->input->post("address");
			$email = $this->input->post("email");
			$state = $this->input->post("state");
			$city = $this->input->post("city");
			$country = $this->input->post("country");
			$zip = $this->input->post("postal_code");
			$phone = $this->input->post("phone");
			$fb_id = $this->input->post("fb_id");
			
			$this->deals_payment_deatils = $this->deals->get_payment_auction_details($deal_id);	
				$this->current_bid_value = $amount;
		//$this->bid_id = base64_decode($bid_id);
		$this->bid_id = $bid_id;
		//$this->auction_user = base64_decode($user_id);
		$this->auction_user = $this->UserID;
		
		
				$post = Validation::factory($_POST)
			                ->add_rules('shipping_name','required','chars[a-zA-Z_ -.,%\']')
			                ->add_rules('address','required')
			               ->add_rules('country','required')
			                ->add_rules('postal_code','required')
			                ->add_rules('phone','required')
			                ->add_rules('email','required')
			                
			                ->add_rules('state','required');
			            
			               
			if($post->validate()){	
							
				$sname =$this->input->post('shipping_name');
				$email =$this->input->post('email');
				$address = $this->input->post('address');
				//$address = $this->input->post('address');
				$city = $this->input->post('city');
				$country = $this->input->post('country');
				$state =$this->input->post('state');
				$zip = $this->input->post('postal_code');
				$phone = $this->input->post('phone');
				$country_code = COUNTRY_CODE;
				$amount = $this->input->post('amount');
				$fb_id = $this->input->post('fb_id');
				$currencyCode = CURRENCY_CODE;			
				$friend_gift =$this->input->post('friend_gift');
				$friendName =$this->input->post('friend_name');
				$friendEmail =$this->input->post('friend_email');
			$transaction=$this->cash->insert_auction_cod_details($sname,$email,$phone,$address,$city,$state,$country,$zip,$deal_id,$amount,$item_qty,$fb_id);
					//$transaction = $this->cash->insert_transaction_details($deal_id, $country_code,$currencyCode, $firstName, $lastName, $referral_amount,$amount, $item_qty, 5, $captured, $purchase_qty, $friend_gift, $friendName, $friendEmail,$merchant_id,$address1,$address2,$city,$country,$state,$zip,$phone);
					//$status = $this->do_captured_deal_transaction($captured, $deal_id, $item_qty);
				//	$mail_status = $this->payment_mail_function($captured, $deal_id, $transaction);
					// $this->transaction_result = array("TIMESTAMP" => date('m/d/Y h:i:s a', time()), "ACK" => "Success" ,"AMT"=> $amount,"CURRENCYCODE" =>$currencyCode);
					//$this->result = arr::to_object($this->transaction_result);
				//	$this->session->set('payment_result', $this->result);
				//	url::redirect(PATH.'transaction.html');
				
			common::message(1, "Your Order has been submitted for admin approval");
			url::redirect(PATH);   
		}
		else
		{
			//$this->paypal_setting=0;
			$this->auction_cod=1;
			$this->form_error = error::_error($post->errors());
		
			$this->template->content = new View("themes/".THEME_NAME."/auction/auction_payment1");
		}
			 
			
		}
		else{	
			common::message(-1, $this->Lang["PAGE_NOT"]);		
		}
		//url::redirect(PATH);
	}


	/** DOCAPTURED PAYMENT, UPDATED AMOUNT TO REFERED USERS, POST PURCHASE DEALS TO FACEBOOK WALL and SEND MAIL **/

	public function do_captured_transaction($captured = "", $deal_id = "", $qty = "",$transaction = "")
	{
		$user_details = $this->cash->get_purchased_user_details();
		foreach($user_details as $U){
			if($U->referred_user_id && $U->deal_bought_count == $qty){
				$update_reff_amount = $this->cash->update_referral_amount($U->referred_user_id);
			}
			$deals_details = $this->cash->get_deals_details($deal_id);
			if($U->facebook_update == 1){				
				foreach($deals_details as $D){
					$dealURL = PATH."deals/".$D->deal_key.'/'.$D->url_title.".html";
					$message = "I have purchased the deal...".$D->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $U->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg);
				}
			}  
			
			/** Send Purchase details to user Email **/
			foreach($deals_details as $D){
			    $deal_title = $D->deal_title;
			    $deal_amount = $D->deal_value;
			}
			
			$friend_details = $this->cash->get_friend_transaction_details($deal_id, $transaction);
            $friend_email = $friend_details->current()->friend_email;
            $friend_name = $friend_details->current()->friend_name;
            if($friend_email != "xxxyyy@zzz.com"){
                $from = CONTACT_EMAIL;
                $this->transaction_mail =array("deal_title" => $deal_title, "item_qty" => $qty ,"total" => ($deal_amount * $qty) ,"amount"=> ($deal_amount * $qty),"ref_amount"=> "0","value" =>$deal_amount,"friend_name" => $friend_name,"value" =>$deal_amount);
                $this->result_mail = arr::to_object($this->transaction_mail);
                $friend_message = new View("themes/".THEME_NAME."/friend_buyit_mail");           
                email::sendgrid($from, $friend_email, "You Got Product Gift from your Friend" ,$friend_message);         
            
            } else {
                $from = CONTACT_EMAIL;
				$this->products_list = $this->cash->get_products_coupons_list($transaction,$deal_id);
				$this->product_size = $this->cash->get_shipping_product_size();
				$this->product_color = $this->cash->get_shipping_product_color();
                $message = new View("themes/".THEME_NAME."/payment_mail_product");
                email::sendgrid($from,$U->email, "Thanks for buying from ". SITENAME ,$message);            
            }
			
		}
		return;
	}

}
