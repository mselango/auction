<?php defined('SYSPATH') OR die('No direct access allowed.');
class Creditcard_paypal_Controller extends Layout_Controller
{
	const ALLOW_PRODUCTION = FALSE;
	public function __construct()
	{
		parent::__construct();
		$this->paypal = new Paypal_Model;
		$this->creditcard_paypal_pay = new Creditcard_paypal_Model;
		foreach($this->generalSettings as $s){
			$this->Api_Username = $s->paypal_account_id;
			$this->Api_Password = $s->paypal_api_password;
			$this->Api_Signature = $s->paypal_api_signature;

			$this->Live_Mode = $s->paypal_payment_mode;
			$this->API_Endpoint = "https://api-3t.sandbox.paypal.com/nvp";
			$this->Paypal_Url = "https://www.sandbox.paypal.com/webscr&cmd=_express-checkout&token=";

			if($this->Live_Mode == 1){
				$this->API_Endpoint = "https://api-3t.paypal.com/nvp";
				$this->Paypal_Url = "https://www.paypal.com/webscr&cmd=_express-checkout&token=";
			}	
		}
		$this->Api_Version = "76.0";
		$this->Api_Subject = $this->AUTH_token = $this->AUTH_signature = $this->AUTH_timestamp = '';
	}

	/** DoDirectPayment - Credit Card  **/

	public function dodirectpayment()
	{
	
	    $product_size = "1";    
	    foreach($_SESSION as $key=>$value) 
        { 
            if(($key=='product_cart_id'.$value)){
            $item_qty = $this->input->post($key);
            $deal_id = $_SESSION[$key]; 
                foreach($_SESSION as $key=>$value) 
                {
                    if(($key=='product_size_qty'.$deal_id)){
                        $product_size = $value;
                    }
                    if(($key=='product_quantity_qty'.$deal_id)){
                        $product_quantity = $value;
                    }
                    
                }                
                $this->product_size_details = $this->creditcard_paypal_pay->product_size_details($deal_id, $product_size);	
                $dbquantity=$this->product_size_details->current()->quantity;
   
                if($dbquantity < $item_qty){
                    $this->session->set('product_quantity_qty'.$deal_id,$dbquantity);
                    common::message(-1, "Check your product quantity");
                    url::redirect(PATH."cart.html");
                }
            }
        }  
        
		if($_POST){     

			    $referral_amount = $this->input->post("p_referral_amount");
		        $this->userPost = $this->input->post();
		        $total_amount="";
		        $total_qty="";
		        $product_title="";
		        $produ_qty="";
		        $total_shipping="";
		        $product_shipping = "";
		        foreach($_SESSION as $key=>$value) 
                {                     
                    if(($key=='product_cart_id'.$value)){                    
                    $deal_id = $_SESSION[$key];
                    $item_qty = $this->input->post($key);	
                    $this->session->set('product_cart_qty'.$deal_id,$item_qty);
                    $amount = $this->input->post("amount");
			        $this->deals_payment_deatils = $this->creditcard_paypal_pay->get_product_payment_details($deal_id);			
			        if(count($this->deals_payment_deatils) == 0){
                        unset($_SESSION[$key]);
                        $this->session->delete('product_cart_qty'.$value);                                     
                        $this->session->delete("count"); 
				        common::message(-1, $this->Lang["PAGE_NOT"]);
				        url::redirect(PATH."products.html");
			        }
			        foreach($this->deals_payment_deatils as $UL){
			            $purchase_qty = $UL->purchase_count;
				        $deal_title = $UL->deal_title;
				        $deal_key  = $UL->deal_key;
				        $url_title = $UL->url_title;
				        $deal_value = $UL->deal_value;
				        $product_amount = $UL->deal_value*$item_qty;
				        $shipping_amount = $UL->shipping_amount;
			        }	
			        
			        if($this->shipping_setting  == 1){
			        $total_shipping += 0;
			        }  elseif($this->shipping_setting  == 2){
			        $total_shipping = FLAT_SHIPPING_AMOUNT;
			        } elseif($this->shipping_setting  == 3){
			        $total_shipping +=$shipping_amount;
			        } elseif($this->shipping_setting  == 4){
			        $total_shipping +=$shipping_amount*$item_qty;
			        }     		        
			        $total_amount +=$product_amount;
			        $total_qty += $item_qty; 
			        $product_title .=$deal_title.",";	
			        $produ_qty .=$item_qty.",";		                        		        
			       }   
			                                  
	            }		            
	            $total_tax = (TAX_PRECENTAGE_VALUE/100)*($total_amount+$total_shipping);
                $pay_amount = $total_amount+$total_shipping+$total_tax;
                  
				$post = arr::to_object($this->input->post());
					$paymentType = "Sale";
					$captured = 0;
				
				$creditCardNumber = urlencode($post->creditCardNumber);
				$cvv2Number = urlencode($post->cvv2Number);
				$expDateMonth =urlencode( $post->expDateMonth);
				$padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);
				$expDateYear =urlencode( $post->expDateYear);
				$firstName =urlencode( $post->firstName);
				$lastName =urlencode( $post->firstName);			
				$address1 = urlencode($post->address1);
				$city = urlencode($post->city);
				$state =urlencode($post->state);
				$zip = urlencode($post->zip);
				$country_code = COUNTRY_CODE;
				$amount = urlencode($post->amount);
				$currencyCode = CURRENCY_CODE;
				
				$friend_gift =$post->friend_gift;
				$friendName =$post->friend_name;
				$friendEmail =$post->friend_email;
				$product_size="";
				$product_color="";
				
				$nvpstr ="&PAYMENTACTION=$paymentType&AMT=$pay_amount&ACCT=$creditCardNumber&EXPDATE=".$padDateMonth.$expDateYear."&CVV2=$cvv2Number&FIRSTNAME=$firstName&LASTNAME=$lastName&STREET=$address1&CITY=$city&STATE=$state&ZIP=$zip&COUNTRYCODE=$country_code&CURRENCYCODE=$currencyCode";
				$this->result = arr::to_object($this->hash_call("doDirectPayment", $nvpstr));
				$ack = strtoupper($this->result->ACK);
				if($ack == 'SUCCESS' || $ack == 'SUCCESSWITHWARNING'){				
				foreach($_SESSION as $key=>$value) 
                { 
                    if(($key=='product_cart_id'.$value)){
                    $product_color = 0; 
                    $product_size = 0;
                    $qty = $this->session->get('product_cart_qty'.$value);
                    $deal_id = $_SESSION[$key];                    
                    $this->deals_payment_deatils = $this->creditcard_paypal_pay->get_product_payment_details($deal_id);
			        foreach($this->deals_payment_deatils as $UL){
			            $purchase_qty = $UL->purchase_count;
			            $deal_value = $UL->deal_value;
			            $merchant_id = $UL->merchant_id;
			            $product_shipping = $UL->shipping_amount;
			            $deal_title = $UL->deal_title;
			        }
			        	
			        if($this->shipping_setting  == 1){
			        $shipping_amount = 0;
			        }  elseif($this->shipping_setting  == 2){
			        $total_flateshipping = FLAT_SHIPPING_AMOUNT;
			        $total_count = $this->session->get("count");
			        $shipping_amount = number_format((float)($total_flateshipping/$total_count), 2, '.', '');
			        } elseif($this->shipping_setting  == 3){
			        $shipping_amount =$product_shipping;
			        } elseif($this->shipping_setting  == 4){
			        $shipping_amount =$product_shipping*$qty;
			        }		        
			       	        
			        $taxdeal_amount=($deal_value*$qty)+$shipping_amount;
			        $tax_amount = ((TAX_PRECENTAGE_VALUE/100)*$taxdeal_amount);
			        
			        
			        foreach($_SESSION as $key=>$value) 
                    {
                    if(($key=='product_size_qty'.$deal_id)){
                        $product_size = $value;
                    }
                    if(($key=='product_color_qty'.$deal_id)){
                        $product_color = $value;
                    }
                   
                    }			        
			        $deal_amount=$deal_value*$qty;
			        
			        $transaction = $this->creditcard_paypal_pay->insert_transaction_details($this->result, $deal_id, $country_code, $firstName, $lastName, $referral_amount, $qty, 1, $captured, $purchase_qty, arr::to_object($this->userPost),$merchant_id,$friend_gift, $friendName, $friendEmail, $product_size,$product_color,$tax_amount,$shipping_amount,$deal_amount);
	
			        $status = $this->do_captured_transaction($captured, $deal_id,$qty,$transaction);	
			        
			        }
				}
					url::redirect(PATH."payment_product/cart_payment_paypal.html");	
				} else {
				
					common::message(-1, $this->Lang["PROB_PAYPAL"]);  
					url::redirect(PATH."cart.html");	
				}
		}
		else{	
					common::message(-1, $this->Lang["PAGE_NOT"]);
            url::redirect(PATH."payment_product/problem_payment_paypal.html");
		}
	}

	/** Paypal Payment - Express check out **/
	public function expresscheckout()
	{       
	    $product_size = "1"; 
	    foreach($_SESSION as $key=>$value) 
        { 
            if(($key=='product_cart_id'.$value)){
            $item_qty = $this->input->post($key);
            $deal_id = $_SESSION[$key]; 
                foreach($_SESSION as $key=>$value) 
                {
                    if(($key=='product_size_qty'.$deal_id)){
                        $product_size = $value;
                    }
                    if(($key=='product_quantity_qty'.$deal_id)){
                        $product_quantity = $value;
                    }
                    
                }                
                $this->product_size_details = $this->creditcard_paypal_pay->product_size_details($deal_id, $product_size);	
                $dbquantity=$this->product_size_details->current()->quantity;
   
                if($dbquantity < $item_qty){
                    $this->session->set('product_quantity_qty'.$deal_id,$dbquantity);
                    common::message(-1, "Check your product quantity");
                    url::redirect(PATH."cart.html");
                }
            }
        }  
        
		 if($_POST){
		        $referral_amount = $this->input->post("p_referral_amount");
		        $this->userPost = $this->input->post();
		        $total_amount="";
		        $total_qty="";
		        $product_title="";
		        $produ_qty="";
		        $pay="";
		        $total_shipping="";
		        $i=0;
		        foreach($_SESSION as $key=>$value) 
                {                     
                    if(($key=='product_cart_id'.$value)){ 
                    $deal_id = $_SESSION[$key];                   
                    $item_qty = $this->input->post($key);	
                    $this->session->set('product_cart_qty'.$deal_id,$item_qty);
                    $amount = $this->input->post("amount");
			        $this->deals_payment_deatils = $this->creditcard_paypal_pay->get_product_payment_details($deal_id);			
			        if(count($this->deals_payment_deatils) == 0){
                        unset($_SESSION[$key]);
                        $this->session->delete('product_cart_qty'.$value);                                     
                        $this->session->delete("count"); 
				        common::message(-1, $this->Lang["PAGE_NOT"]);
				        url::redirect(PATH."products.html");
			        }
			        foreach($this->deals_payment_deatils as $UL){
			            $purchase_qty = $UL->purchase_count;
				        $deal_title = $UL->deal_title;
				        $deal_key  = $UL->deal_key;
				        $url_title = $UL->url_title;
				        $deal_value = $UL->deal_value;
				        $shipping_amount = $UL->shipping_amount;
				        $product_amount = $UL->deal_value*$item_qty;
			        }
			        $total_amount +=$product_amount;
			        if($this->shipping_setting  == 1){
			        $total_shipping += 0;
			        }  elseif($this->shipping_setting  == 2){
			        $total_shipping = FLAT_SHIPPING_AMOUNT;
			        } elseif($this->shipping_setting  == 3){
			        $total_shipping +=$shipping_amount;
			        } elseif($this->shipping_setting  == 4){
			        $total_shipping +=$shipping_amount*$item_qty;
			        }
			        
			        $total_qty += $item_qty; 
			        $product_title .=$deal_title.",";	
			        $produ_qty .=$item_qty.",";		        
			        
			        $pay .="&L_PAYMENTREQUEST_0_NAME$i=".preg_replace("/[^a-zA-Z0-9_ %\[\]\.\(\)%-]/s", '', $deal_title)."&L_PAYMENTREQUEST_0_NUMBER$i=".$deal_key."&L_PAYMENTREQUEST_0_AMT$i=".$deal_value."&L_PAYMENTREQUEST_0_QTY$i=".$item_qty."&LOGOIMG=".PATH.'themes/'.THEME_NAME.'/images/logo.png';
			        
			        $i++;              		        
			       }                                   
	            } 
	            $total_tax = (TAX_PRECENTAGE_VALUE/100)*($total_amount+$total_shipping);
                $total_shipping_amount = $total_amount+$total_shipping+$total_tax;
                $to_pay ="&PAYMENTREQUEST_0_SHIPPINGAMT=".$total_shipping."&PAYMENTREQUEST_0_TAXAMT=".$total_tax."&PAYMENTREQUEST_0_ITEMAMT=".$total_amount."&PAYMENTREQUEST_0_AMT=".$total_shipping_amount;
     
		        $friend_name = $this->input->post("friend_name");
			    $friend_email = $this->input->post("friend_email");
			    $friend_gift_status = $this->input->post("friend_gift");
			    $userPost_status = arr::to_object($this->userPost);
		        $captured =0;
		        $deal_custom_details = $deal_id."--".$referral_amount."--".$total_qty."--".$purchase_qty."--".$captured."--".$friend_name."--".$friend_email."--".$friend_gift_status;
		        $returnURL = urlencode(PATH."creditcard_paypal/authorize/".$deal_id."/".$friend_name."/".$friend_email."/".$friend_gift_status."/".$userPost_status->adderss1."/".$userPost_status->address2."/".$userPost_status->state."/".$userPost_status->city."/".$userPost_status->country."/".$userPost_status->shipping_name."/".$userPost_status->postal_code."/".$userPost_status->phone."/");
		        $cancelURL = urlencode(PATH."cart_checkout.html");
		        $currencyCodeType = CURRENCY_CODE;
		        $paymentType = "Sale";
		       $nvpstr="&METHOD=".'SetExpressCheckout'."&RETURNURL=".$returnURL."&CANCELURL=".$cancelURL."&PAYMENTREQUEST_0_PAYMENTACTION=".$paymentType.$pay.$to_pay."&PAYMENTREQUEST_0_CURRENCYCODE=".$currencyCodeType;

      			$resArray = $this->hash_call("SetExpressCheckout",$nvpstr);

		        $ack = strtoupper($resArray["ACK"]);			       
	            if($ack == "SUCCESS" || $ack == 'SUCCESSWITHWARNING'){
		            $this->session->set("IS_authorize", 1);
		            url::redirect($this->Paypal_Url.urldecode($resArray["TOKEN"]));
	            }
	            else{
		            common::message(-1, $this->Lang["PLES_TRY_SOMETIMES"]); 
		            url::redirect(PATH."cart.html");  
	            }                   
                
                $this->referral_amount_payment_deatils = $this->creditcard_paypal_pay->products_referral_amount_payment_deatils($referral_amount);
                common::message(1, $this->Lang["THANK_FOR_PURCH"]);
                url::redirect(PATH."payment_product/cart_payment_paypal.html");
	       }
	       else{
	                	
			common::message(-1, $this->Lang["PAGE_NOT"]);		
		}
		url::redirect(PATH."payment_product/problem_payment_paypal.html");	
	}
	
	/** Redirect After paypal authorize (Success) **/

	public function authorize($deal_id = "", $friend_name= "",$friend_email = "", $friend_gift_status = "", $adderss1= "", $adderss2 = "", $state = "", $city= "",$country = "", $shipping_name = "", $postal_code= "",$phone = "")
	{	
		$status = $this->session->get("IS_authorize");
		if($status == 1){
			$this->session->delete("IS_authorize");
			$token =urlencode($_REQUEST['token']);
			$nvpstr="&TOKEN=".$token;

			$Response = $this->hash_call("GetExpressCheckoutDetails", $nvpstr);
			
			$ack = strtoupper($Response["ACK"]);
			if($ack == 'SUCCESS' || $ack == 'SUCCESSWITHWARNING'){

				$Response = arr::to_object($Response);

				$paymentType = "Sale";
				$captured = "0";
				$qty="";
				$product_size="";
				$product_color="";
				$referral_amount="";
				$shipping_amount = 0;
				$tax_amount = "";
				$currencyCodeType = CURRENCY_CODE;
				
				$nvpstr ="&TOKEN=".$Response->TOKEN."&PAYERID=".$Response->PAYERID."&CURRENCYCODE=".$currencyCodeType."&PAYMENTACTION=".$paymentType."&AMT=".$Response->AMT;
				$result = arr::to_object($this->hash_call("DoExpressCheckoutPayment",$nvpstr));
				$ack = strtoupper($result->ACK);


				if($ack == 'SUCCESS' || $ack == 'SUCCESSWITHWARNING'){		
				
				foreach($_SESSION as $key=>$value) 
                { 
                    if(($key=='product_cart_id'.$value)){
                    $product_color = 0; 
                    $product_size = 0;
                    $qty = $this->session->get('product_cart_qty'.$value);
                    $deal_id = $_SESSION[$key]; 
                    foreach($_SESSION as $key=>$value) 
                    {
                        if(($key=='product_size_qty'.$deal_id)){
                            $product_size = $value;
                        }
                        if(($key=='product_color_qty'.$deal_id)){
                            $product_color = $value;
                        }                   
                    }
                 
                    $this->deals_payment_deatils = $this->creditcard_paypal_pay->get_product_payment_details($deal_id);	
                    foreach($this->deals_payment_deatils as $UL){
			            $purchase_qty = $UL->purchase_count;
			            $deal_value = $UL->deal_value;
			            $merchant_id = $UL->merchant_id;
			            $product_shipping = $UL->shipping_amount;
			        }	
			        if($this->shipping_setting  == 1){
			        $shipping_amount = 0;
			        }  elseif($this->shipping_setting  == 2){
			        $total_flateshipping = FLAT_SHIPPING_AMOUNT;
			        $total_count = $this->session->get("count");
			        $shipping_amount = number_format((float)($total_flateshipping/$total_count), 2, '.', '');
			        } elseif($this->shipping_setting  == 3){
			        $shipping_amount =$product_shipping;
			        } elseif($this->shipping_setting  == 4){
			        $shipping_amount =$product_shipping*$qty;
			        }		        
			        $deal_amount=$deal_value*$qty;
			        $taxdeal_amount=($deal_value*$qty)+$shipping_amount;
			        $tax_amount = ((TAX_PRECENTAGE_VALUE/100)*$taxdeal_amount);
					$transaction = $this->creditcard_paypal_pay->insert_paypal_transaction_details($result, $Response, 2, $deal_id, $referral_amount, $qty, $purchase_qty, $captured, $paymentType,$deal_amount,$merchant_id,$friend_name, $friend_email, $friend_gift_status, $adderss1, $adderss2, $state, $city, $country, $product_size,$product_color,$shipping_name,$postal_code,$phone,$tax_amount,$shipping_amount);
					$status = $this->do_captured_transaction($captured, $deal_id, $qty,$transaction);
					} 
				}
				  url::redirect(PATH."payment_product/cart_payment_paypal.html");	
				
				}
				
				else {
					common::message(-1, $this->Lang["PROB_PAYPAL"]);	
				}		
			} 
			else {
				common::message(-1, $this->Lang["PROB_PAYPAL"]);
			}
		}
		else{	
			common::message(-1, $this->Lang["PAGE_NOT"]);
					
		}
		url::redirect(PATH."payment_product/problem_payment_paypal.html");	
	}

	/** DOCAPTURED PAYMENT, UPDATED AMOUNT TO REFERED USERS, POST PURCHASE DEALS TO FACEBOOK WALL and SEND MAIL **/

	public function do_captured_transaction($captured = "", $deal_id = "", $qty = "",$transaction = "")
	{
		$user_details = $this->paypal->get_purchased_user_details();
		foreach($user_details as $U){
			if($U->referred_user_id && $U->deal_bought_count == $qty){
				$update_reff_amount = $this->creditcard_paypal_pay->update_referral_amount($U->referred_user_id);
			}
			$deals_details = $this->creditcard_paypal_pay->get_deals_details($deal_id);
			if($U->facebook_update == 1){				
				foreach($deals_details as $D){
					$dealURL = PATH."deals/".$D->deal_key.'/'.$D->url_title.".html";
					$message = "I have purchased the deal...".$D->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $U->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg);
				}
			}  
			
			/** Send Purchase details to user Email **/
			foreach($deals_details as $D){
			    $deal_title = $D->deal_title;
			    $deal_amount = $D->deal_value;
			}
			
			$friend_details = $this->creditcard_paypal_pay->get_friend_transaction_details($deal_id, $transaction);
            $friend_email = $friend_details->current()->friend_email;
            $friend_name = $friend_details->current()->friend_name;
            if($friend_email != "xxxyyy@zzz.com"){
                $from = CONTACT_EMAIL;
                $this->transaction_mail =array("deal_title" => $deal_title, "item_qty" => $qty ,"total" => ($deal_amount * $qty) ,"amount"=> ($deal_amount * $qty),"ref_amount"=> "0","value" =>$deal_amount,"friend_name" => $friend_name,"value" =>$deal_amount);
                $this->result_mail = arr::to_object($this->transaction_mail);
                $friend_message = new View("themes/".THEME_NAME."/friend_buyit_mail");  
		if(EMAIL_TYPE==2) {        
                email::smtp($from, $friend_email, "You Got Product Gift from your Friend" ,$friend_message); 
		}else {
		 email::sendgrid($from, $friend_email, "You Got Product Gift from your Friend" ,$friend_message); 

		}        
            
            } else {
                $from = CONTACT_EMAIL;
				$this->products_list = $this->creditcard_paypal_pay->get_products_coupons_list($transaction,$deal_id);
				$this->product_size = $this->creditcard_paypal_pay->get_shipping_product_size();
				$this->product_color = $this->creditcard_paypal_pay->get_shipping_product_color();
                // $this->transaction_mail = array("deal_title" => $deal_title, "item_qty" => $qty ,"total" => ($deal_amount * $qty) ,"amount"=> ($deal_amount * $qty),"value" =>$deal_amount);
                // $this->result_mail = arr::to_object($this->transaction_mail);
                /* Mail template */
                $message = new View("themes/".THEME_NAME."/payment_mail_product");
		if(EMAIL_TYPE==2) {   	
                email::smtp($from,$U->email, "Thanks for buying from ". SITENAME ,$message);  
		}else{
		 email::sendgrid($from,$U->email, "Thanks for buying from ". SITENAME ,$message);  
		}          
            }
			
		}
		return;
	}
	
	private function hash_call($methodName, $nvpStr)
	{
		$nvpheader = $this->nvpHeader(); 
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->API_Endpoint);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);

		if($this->AUTH_token && $this->AUTH_signature && $this->AUTH_timestamp){
			$headers_array[] = "X-PP-AUTHORIZATION: ".$nvpheader;
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
			curl_setopt($ch, CURLOPT_HEADER, false);
		}
		else {
			$nvpStr = $nvpheader.$nvpStr;
		}
		
		if(strlen(str_replace('VERSION=', '', strtoupper($nvpStr))) == strlen($nvpStr)) {
			$nvpStr = "&VERSION=" . $this->Api_Version . $nvpStr;	
		}

		$nvpreq = "METHOD=".urlencode($methodName).$nvpStr;

		curl_setopt($ch,CURLOPT_POSTFIELDS,$nvpreq);
		$response = curl_exec($ch);

		$nvpResArray = $this->deformatNVP($response);
		if(curl_errno($ch)) { 
			$_SESSION['curl_error_no']=curl_errno($ch) ;
			$_SESSION['curl_error_msg']=curl_error($ch);
		} else {
			curl_close($ch);
		}

		return $nvpResArray;
	}

	/** NVP Header **/

	public function nvpHeader()
	{
		$nvpHeaderStr = "";
		if($this->Api_Username && $this->Api_Password && $this->Api_Signature && $this->Api_Subject) {
			$nvpHeaderStr = "&PWD=".urlencode($this->Api_Password)."&USER=".urlencode($this->Api_Username)."&SIGNATURE=".urlencode($this->Api_Signature)."&SUBJECT=".urlencode($this->Api_Subject);
		}
		elseif($this->Api_Username && $this->Api_Password && $this->Api_Signature) {
			$nvpHeaderStr = "&PWD=".urlencode($this->Api_Password)."&USER=".urlencode($this->Api_Username)."&SIGNATURE=".urlencode($this->Api_Signature);
		}
		elseif ($this->AUTH_token && $this->AUTH_signature && $this->AUTH_timestamp) {
			$nvpHeaderStr = $this->formAutorization($this->AUTH_token,$this->AUTH_signature,$this->AUTH_timestamp);
		}
		elseif($this->Api_Subject) {
			$nvpHeaderStr = "&SUBJECT=".urlencode($this->Api_Subject);
		}
		return $nvpHeaderStr;
	}
	
	/** form Autorization**/

	private function formAutorization($auth_token,$auth_signature,$auth_timestamp)
	{
		$authString="token=".$auth_token.",signature=".$auth_signature.",timestamp=".$auth_timestamp ;
		return $authString;
	}

	/** Format Response Data  **/

	private function deformatNVP($nvpstr)
	{
		$intial = 0;
		$nvpArray = array();

		while(strlen($nvpstr)){
			$keypos= strpos($nvpstr,'=');
			$valuepos = strpos($nvpstr,'&') ? strpos($nvpstr,'&'): strlen($nvpstr);

			$keyval=substr($nvpstr,$intial,$keypos);
			$valval=substr($nvpstr,$keypos+1,$valuepos-$keypos-1);

			$nvpArray[urldecode($keyval)] =urldecode( $valval);
			$nvpstr=substr($nvpstr,$valuepos+1,strlen($nvpstr));
		}
		return $nvpArray;
	}
		
	/** PAYMENT STATS AFTER PAYMENT PROCESS COMPLETE **/
		
	public function success()
	{
	    $this->result = $this->session->get('payment_result');
		if(!$this->result){
		
             url::redirect(PATH."merchant/problem_payment_paypal.html");	
		}
	        $this->session->delete('payment_result');
		$this->template->content = new View("themes/".THEME_NAME."/success_payment");
	}	
}
