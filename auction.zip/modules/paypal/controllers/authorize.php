<?php defined('SYSPATH') OR die('No direct access allowed.');
class Authorize_Controller extends Layout_Controller
{
	const ALLOW_PRODUCTION = FALSE;
	public function __construct()
	{
		parent::__construct();
		$this->authorize = new Authorize_Model;
        $this->template->style .= html::stylesheet(array(PATH.'themes/'.THEME_NAME.'/css/style.css'));
        $this->session = Session::instance();	
		$this->UserID = $this->session->get("UserID");
		$this->UserEmail = $this->session->get("UserEmail");  
		foreach($this->generalSettings as $s){
		    $this->Live_Mode = $s->paypal_payment_mode;
		    require_once APPPATH.'vendor/authorize.net/AuthorizeNet.php'; 
	        define("AUTHORIZENET_API_LOGIN_ID", $s->authorizenet_api_id);
	        define("AUTHORIZENET_TRANSACTION_KEY", $s->authorizenet_transaction_key);
	        define("AUTHORIZENET_SANDBOX", true);
			if($this->Live_Mode == 1){
				define("AUTHORIZENET_SANDBOX", false);
			}
		}
	}    
    
    /** DoDirectPayment - Credit Card  **/

	public function productpayment()
	{
	    $product_size = "1"; 
	    foreach($_SESSION as $key=>$value) 
        { 
            if(($key=='product_cart_id'.$value)){
            $item_qty = $this->input->post($key);
            $deal_id = $_SESSION[$key]; 
                foreach($_SESSION as $key=>$value) 
                {
                    if(($key=='product_size_qty'.$deal_id)){
                        $product_size = $value;
                    }
                    if(($key=='product_quantity_qty'.$deal_id)){
                        $product_quantity = $value;
                    }
                    
                }                
                $this->product_size_details = $this->authorize->product_size_details($deal_id, $product_size);	
                $dbquantity=$this->product_size_details->current()->quantity;
   
                if($dbquantity < $item_qty){
                    $this->session->set('product_quantity_qty'.$deal_id,$dbquantity);
                    common::message(-1, "Check your product quantity");
                    url::redirect(PATH."cart.html");
                }
            }
        }  
        
		if($_POST){     
			$referral_amount = $this->input->post("p_referral_amount");
		        $this->userPost = $this->input->post();
		        $total_amount="";
		        $total_qty="";
		        $product_title="";
		        $produ_qty="";
		        $total_shipping="";
		         $product_shipping = "";
		        foreach($_SESSION as $key=>$value) 
                {                     
                    if(($key=='product_cart_id'.$value)){                    
                    $deal_id = $_SESSION[$key];
                    $item_qty = $this->input->post($key);	
                    $this->session->set('product_cart_qty'.$deal_id,$item_qty);
                    $amount = $this->input->post("amount");
			        $this->deals_payment_deatils = $this->authorize->get_product_payment_details($deal_id);			
			        if(count($this->deals_payment_deatils) == 0){
                        unset($_SESSION[$key]);
                        $this->session->delete('product_cart_qty'.$value);                                     
                        $this->session->delete("count"); 
				        common::message(-1, $this->Lang["PAGE_NOT"]);
				        url::redirect(PATH."products.html");
			        }
			        foreach($this->deals_payment_deatils as $UL){
			            $purchase_qty = $UL->purchase_count;
				        $deal_title = $UL->deal_title;
				        $deal_key  = $UL->deal_key;
				        $url_title = $UL->url_title;
				        $deal_value = $UL->deal_value;
				        $product_amount = $UL->deal_value*$item_qty;
				        $shipping_amount = $UL->shipping_amount;
			        }	
			        
			        if($this->shipping_setting  == 1){
			        $total_shipping += 0;
			        }  elseif($this->shipping_setting  == 2){
			        $total_shipping = FLAT_SHIPPING_AMOUNT;
			        } elseif($this->shipping_setting  == 3){
			        $total_shipping +=$shipping_amount;
			        } elseif($this->shipping_setting  == 4){
			        $total_shipping +=$shipping_amount*$item_qty;
			        }
			        		        
			        $total_amount +=$product_amount;
			        $total_qty += $item_qty; 
			        $product_title .=$deal_title.",";	
			        $produ_qty .=$item_qty.",";		                        		        
			       }                                   
	            }      
	            $total_tax = (TAX_PRECENTAGE_VALUE/100)*($total_amount+$total_shipping);
                $pay_amount = $total_amount+$total_shipping+$total_tax;  
                    
                $post = arr::to_object($this->input->post());
                
                // authorize
                $sale = new AuthorizeNetAIM;                
                $sale->cust_id = $this->UserID;
                $paymentType = "Sale";
				$captured = 0;
				
			    $shipping_info                     = (object) array();
                $shipping_info->ship_to_first_name = urlencode($post->shipping_name); 
                $shipping_info->ship_to_last_name  = urlencode($post->shipping_last_name);
                $shipping_info->ship_to_address    = urlencode($post->shipping_adderss1." , ".$post->shipping_address2); 
                $shipping_info->ship_to_state      = urlencode($post->shipping_state);
                $shipping_info->ship_to_zip        = urlencode($post->shipping_postal_code); 
                $shipping_info->ship_to_country    = urlencode($post->shipping_country);                 
                
                $customer                          = (object) array();
                $customer->first_name              = urlencode($post->firstName);
                $customer->last_name               = urlencode($post->firstName);
                $customer->address                 = urlencode($post->address1);
                $customer->city                    = urlencode($post->city);
                $customer->state                   = urlencode($post->state);
                $customer->zip                     = urlencode($post->zip);
                $customer->email                   = $this->UserEmail;
                $customer->country                 = urlencode($post->country);
                $customer->phone                   = urlencode($post->phone); 
                 
                $sale->amount                      = urlencode($pay_amount);
                $sale->tax                         = urlencode($total_tax);
                $sale->card_num                    = urlencode($post->creditCardNumber);
                $sale->card_code                   = urlencode($post->cvv2Number);
                $sale->exp_date                    = urlencode($post->expDateMonth)."/".urlencode($post->expDateYear);
                $sale->invoice_num                 = substr(time(), 0, 6);
                $sale->description                 = $product_title;
                $sale->setFields($shipping_info);
                $sale->setFields($customer);
                $response = $sale->authorizeOnly(); 
                    
                $friend_gift =$post->friend_gift;
			    $friendName =$post->friend_name;
			    $friendEmail =$post->friend_email;
			    $country_code = COUNTRY_CODE;
			    $currencyCode = CURRENCY_CODE;
			    $product_size="";
			    $product_color="";
			    $pay_amount = $pay_amount;
                    if ($response->approved) {		
                        $transaction_id = $response->transaction_id;
                        $responseheader = array('Order_Status'=>$response->response_reason_text,'Invoice_Number'=>$response->invoice_number,'Authorization_Code'=>$response->authorization_code,'Credit_card'=>$response->card_type,'Billing_Address'=>$response->address);                 
                        foreach($_SESSION as $key=>$value) 
                        { 
                            if(($key=='product_cart_id'.$value)){
                                $product_color = 0;
                                $product_size = 0;
                                $qty = $this->session->get('product_cart_qty'.$value);
                                $deal_id = $_SESSION[$key];                    
                                $this->deals_payment_deatils = $this->authorize->get_product_payment_details($deal_id);	
                                foreach($this->deals_payment_deatils as $UL){
                                    $purchase_qty = $UL->purchase_count;
                                    $deal_title = $UL->deal_title;
                                    $deal_value = $UL->deal_value;
                                    $product_shipping = $UL->shipping_amount;
                                    $merchant_id = $UL->merchant_id;
                                }                                
                                if($this->shipping_setting  == 1){
		                        $shipping_amount = 0;
		                        }  elseif($this->shipping_setting  == 2){
		                        $total_flateshipping = FLAT_SHIPPING_AMOUNT;
		                        $total_count = $this->session->get("count");
		                        $shipping_amount = number_format((float)($total_flateshipping/$total_count), 2, '.', '');
		                        } elseif($this->shipping_setting  == 3){
		                        $shipping_amount =$product_shipping;
		                        } elseif($this->shipping_setting  == 4){
		                        $shipping_amount =$product_shipping*$qty;
		                        }		        
		                       	        
		                        $taxdeal_amount=($deal_value*$qty)+$shipping_amount;
		                        $tax_amount = ((TAX_PRECENTAGE_VALUE/100)*$taxdeal_amount);

		                        foreach($_SESSION as $key=>$value) 
                                {
                                    if(($key=='product_size_qty'.$deal_id)){
                                        $product_size = $value;
                                    }
                                    if(($key=='product_color_qty'.$deal_id)){
                                        $product_color = $value;
                                    }                               
                                }				        
                                $deal_amount=$deal_value*$qty;
                                $transaction = $this->authorize->insert_product_transaction_details($responseheader, $deal_amount,$deal_id, $transaction_id,$country_code, $currencyCode,$post->firstName, $post->firstName, $referral_amount, $qty, 1, $captured, $purchase_qty, $friend_gift, $friendName, $friendEmail,$merchant_id,arr::to_object($this->userPost), $product_size,$product_color,$tax_amount,$shipping_amount);
                            
                            $status = $this->do_captured_product_transaction($captured, $deal_id,$qty,$transaction);
                            }
                        }
                        $capture = new AuthorizeNetAIM;
		                $capture->amount = $pay_amount;
			            $capture->trans_id = $transaction_id;
			            $response = $capture->priorAuthCapture();			
				        if ($response->approved) {
		                    $now_transaction_id=$response->transaction_id;
		                    $now_authorization_code=$response->authorization_code;
		                    $status = $this->authorize->update_captured_transaction($now_transaction_id,$now_authorization_code, $transaction);
				        } else {
				            $status = $this->authorize->update_captured_transaction_failed($transaction);				
				        }					
                        url::redirect(PATH."payment_product/cart_payment_paypal.html");
                    }   else {
                    $responseheader = array('Error'=>$response->response_reason_text,'Error code'=>$response->response_reason_code,'Authorization Code'=>'Not Authorized','Credit card'=>$response->card_type,'Billing Address'=>$response->address);
                    common::message(-1, $response->response_reason_text);
                    url::redirect(PATH);
                    }        

		}
		else{	
			common::message(-1, $this->Lang["PAGE_NOT"]);
            url::redirect(PATH."payment_product/problem_payment_paypal.html");
		}
	}
	

	/** DoDirectPayment - Credit Card  **/

	public function auctionpayment()
	{
        
		if($_POST){  
				$referral_amount = 0;
				$auction_amount = $this->input->post("amount");	  
				$deal_id = $this->input->post("deal_id"); 
				$qty = $this->input->post("P_QTY");  
				$merchant_id = $this->input->post("merchant_id");
				$bid_id = $this->input->post("bid_id"); 
				$shipping_amount = $this->input->post("shipping_amount");
				$tax_amount = 0;	        
                $pay_amount = $auction_amount+$shipping_amount+$tax_amount;  
                $product_title = $this->input->post("auction_title");	    
    
                $post = arr::to_object($this->input->post());
                
                // authorize
                $sale = new AuthorizeNetAIM;                
                $sale->cust_id = $this->UserID;
                $paymentType = "Sale";
				$captured = 0;
				$purchase_qty = $qty;

			    $shipping_info                     = (object) array();
                $shipping_info->ship_to_first_name = urlencode($post->shipping_name); 
                $shipping_info->ship_to_last_name  = urlencode($post->shipping_last_name);
                $shipping_info->ship_to_address    = urlencode($post->shipping_adderss1." , ".$post->shipping_address2); 
                $shipping_info->ship_to_state      = urlencode($post->shipping_state);
                $shipping_info->ship_to_zip        = urlencode($post->shipping_postal_code); 
                $shipping_info->ship_to_country    = urlencode($post->shipping_country);                 
                
                $customer                          = (object) array();
                $customer->first_name              = urlencode($post->firstName);
                $customer->last_name               = urlencode($post->firstName);
                $customer->address                 = urlencode($post->address1);
                $customer->city                    = urlencode($post->city);
                $customer->state                   = urlencode($post->state);
                $customer->zip                     = urlencode($post->zip);
                $customer->email                   = $this->UserEmail;
                $customer->country                 = urlencode($post->country);
                $customer->phone                   = urlencode($post->phone); 
                 
                $sale->amount                      = urlencode($pay_amount);
                $sale->tax                         = urlencode($tax_amount);
                $sale->card_num                    = urlencode($post->creditCardNumber);
                $sale->card_code                   = urlencode($post->cvv2Number);
                $sale->exp_date                    = urlencode($post->expDateMonth)."/".urlencode($post->expDateYear);
                $sale->invoice_num                 = substr(time(), 0, 6);
                $sale->description                 = $product_title;
                $sale->setFields($shipping_info);
                $sale->setFields($customer);

                $response = $sale->authorizeOnly(); 
                // Authorize from Authorize.net if respose is approved the payment process not error showend
                    
               
			    $country_code = COUNTRY_CODE;
			    $currencyCode = CURRENCY_CODE;
			    
			    $pay_amount = $pay_amount;
                    if ($response->approved) {		
                        $transaction_id = $response->transaction_id;
                        $responseheader = array('Order_Status'=>$response->response_reason_text,'Invoice_Number'=>$response->invoice_number,'Authorization_Code'=>$response->authorization_code,'Credit_card'=>$response->card_type,'Billing_Address'=>$response->address);                 
                       
                            $transaction = $this->authorize->insert_auction_transaction_details($responseheader, $pay_amount,$deal_id, $transaction_id,$country_code, $currencyCode,$post->firstName, $post->firstName, $referral_amount, $qty, 4, $captured, $purchase_qty, $merchant_id,$post,$tax_amount,$shipping_amount,$auction_amount,$bid_id);
                            
                             $status = $this->payment_auction_mail_function($deal_id,$transaction);
                   
                        
                        $capture = new AuthorizeNetAIM;
		                $capture->amount = $pay_amount;
			            $capture->trans_id = $transaction_id;
			            $response = $capture->priorAuthCapture();			
				        if ($response->approved) {
		                    $now_transaction_id=$response->transaction_id;
		                    $now_authorization_code=$response->authorization_code;
		                    $status = $this->authorize->update_captured_transaction($now_transaction_id,$now_authorization_code, $transaction);
				        } else {
				            $status = $this->authorize->update_captured_transaction_failed($transaction);				
				          }	
						
                        url::redirect(PATH."payment_product/cart_payment_paypal.html");

                    }   else {
                    $responseheader = array('Error'=>$response->response_reason_text,'Error code'=>$response->response_reason_code,'Authorization Code'=>'Not Authorized','Credit card'=>$response->card_type,'Billing Address'=>$response->address);
                    common::message(-1, $response->response_reason_text);
                    url::redirect(PATH);
                    }        

		}
		else{	
			common::message(-1, $this->Lang["PAGE_NOT"]);
            url::redirect(PATH."payment_product/problem_payment_paypal.html");
		}
	}

	/** DoDirectPayment - Credit Card  **/

	public function dodirectpayment()
	{
	        if($_POST){
			$deal_id = $this->input->post("deal_id");
			$deal_key = $this->input->post("deal_key");
			$referral_amount = $this->input->post("p_referral_amount");
			$item_qty = $this->input->post("P_QTY");
			$this->deals_payment_deatils = $this->authorize->get_deals_payment_details($deal_id, $deal_key);
			if(count($this->deals_payment_deatils) == 0){
				common::message(-1, $this->Lang["PAGE_NOT"]);
				url::redirect(PATH);
			}
			$this->referral_balance_deatils = $this->authorize->get_user_referral_balance_details();
			$this->get_user_limit_details = $this->authorize->get_user_limit_details($deal_id);
			$this->get_user_limit_count = $this->authorize->get_user_limit_details($deal_id);
			$this->user_referral_balance = $this->authorize->get_user_referral_balance_details();
			
			foreach($this->deals_payment_deatils as $UL){
				$purchase_qty = $UL->purchase_count;
				$deal_title = $UL->deal_title;
				$max_user_limit = $UL->user_limit_quantity;
				$min_deals_limit = $UL->minimum_deals_limit;
				$merchant_id = $UL->merchant_id;
			}
			if($referral_amount > $this->referral_balance_deatils ){
				common::message(-1,$this->Lang["INVALID_REF_AMONT"]);
				url::redirect(PATH);
			}
			if(($this->get_user_limit_details + $item_qty) > $max_user_limit){
				common::message(-1, $this->Lang["MAX_PURCH_LIMIT"]);
				url::redirect(PATH);
			}
			$post = new Validation($_POST);
			$post = Validation::factory($_POST)
				            ->add_rules('firstName','required','chars[a-zA-Z_ -.,%\']')
				            ->add_rules('address1','required')
				            ->add_rules('creditCardNumber','required')
				            ->add_rules('city','required')
				            ->add_rules('state','required')
				            ->add_rules('country','required')
				            ->add_rules('zip','required')
				            ->add_rules('cvv2Number','required')
				            ->add_rules('deal_value','required')
				            ->add_rules('amount','required')
				            ->add_rules('friend_name','required')
				            ->add_rules('friend_email','required');
			if($post->validate()){
				$post = arr::to_object($this->input->post());
                $sale = new AuthorizeNetAIM;
                // authorize
                $sale->cust_id = $this->UserID;
                if($post->amount != 0) 
                {                
                    if(($purchase_qty + $item_qty) >= $min_deals_limit){
			            $captured = 0;
		            }else{
			            $captured = 1;
		            }				                         
                    $sale->amount = urlencode($post->amount);
                    $sale->card_num = urlencode($post->creditCardNumber);
                    $sale->card_code = urlencode($post->cvv2Number);
                    $sale->exp_date = urlencode($post->expDateMonth)."/".urlencode($post->expDateYear);
                    $sale->first_name = urlencode($post->firstName);
                    $sale->last_name = urlencode($post->firstName);
                    $sale->address = urlencode($post->address1);
                    $sale->city = urlencode($post->city);
                    $sale->state = urlencode($post->state);
                    $sale->zip = urlencode($post->zip);         
                    $sale->phone = urlencode($post->phone);              
                    $sale->country = urlencode($post->country);
                    $sale->email = $this->UserEmail;
                    $sale->invoice_num = substr(time(), 0, 6);
                    $sale->description = $deal_title;
                    $response = $sale->authorizeOnly(); 
                    $friend_gift =$post->friend_gift;
				    $friendName =$post->friend_name;
				    $friendEmail =$post->friend_email;
				    $country_code = COUNTRY_CODE;
				    $currencyCode = CURRENCY_CODE;
				    $pay_amount = $post->amount;
				    if ($response->approved) {		
                        $transaction_id = $response->transaction_id;
                        $responseheader = array('Order_Status'=>$response->response_reason_text,'Invoice_Number'=>$response->invoice_number,'Authorization_Code'=>$response->authorization_code,'Credit_card'=>$response->card_type,'Billing_Address'=>$response->address);                           
                        $transaction = $this->authorize->insert_transaction_details($responseheader, $pay_amount,$deal_id, $transaction_id,$country_code, $currencyCode,$post->firstName, $post->firstName, $referral_amount, $item_qty, 1, $captured, $purchase_qty, $friend_gift, $friendName, $friendEmail,$merchant_id);
                        $status = $this->do_captured_transaction($captured, $deal_id, $item_qty);
                        $mail_status = $this->payment_mail_function($captured, $deal_id, $transaction);                            
                        $this->result = arr::to_object(array('TIMESTAMP'=> date('d/m/Y h:i:s A', time()),'ACK'=>"Success",'AMT'=>$pay_amount,'CURRENCYCODE'=>$currencyCode));
                        $this->session->set('payment_result', $this->result);
                        url::redirect(PATH.'transaction.html');	
                    } else {
                        $responseheader = array('Error'=>$response->response_reason_text,'Error code'=>$response->response_reason_code,'Authorization Code'=>'Not Authorized','Credit card'=>$response->card_type,'Billing Address'=>$response->address);
                        common::message(-1, $response->response_reason_text);
                        url::redirect(PATH);
                    }
                }				
			}
			else{
				$this->form_error = error::_error($post->errors());
				$this->template->content = new View("themes/".THEME_NAME."/payment");
			}
		}
		else{	
			common::message(-1, $this->Lang["PAGE_NOT"]);
			url::redirect(PATH);		
		}
	}
	
	/** DOCAPTURED PAYMENT, UPDATED AMOUNT TO REFERED USERS, POST PURCHASE DEALS TO FACEBOOK WALL and SENT MAIL **/

	private function do_captured_transaction($captured = "", $deal_id = "", $qty = "")
	{
		if($captured == 0){
			$captured_list = $this->authorize->payment_authorization_list($deal_id);
			$capture = new AuthorizeNetAIM;
			foreach($captured_list as $C){
			    $capture->amount = $C->amount;
				$capture->trans_id = $C->transaction_id;
				$response = $capture->priorAuthCapture();			
				if ($response->approved) {
		            $now_transaction_id=$response->transaction_id;
		            $now_authorization_code=$response->authorization_code;
		            $status = $this->authorize->update_captured_transaction($now_transaction_id,$now_authorization_code, $C->id);
				} else {
				    $status = $this->authorize->update_captured_transaction_failed($C->id);				
				}
			}	
			
			$captured_mail_list = $this->authorize->payment_authorization_mail_list($deal_id);
			foreach($captured_mail_list as $mail){			
			    $friend_details = $this->authorize->get_friend_transaction_details($deal_id, $mail->id);			        
                $friend_email = $friend_details->current()->friend_email;
                $friend_name = $friend_details->current()->friend_name;        
			    $this->result_mail = arr::to_object(array("deal_title" => $mail->deal_title, "item_qty" => $mail->quantity ,"total" => $mail->amount + $mail->referral_amount,"ref_amount"=> $mail->referral_amount, "amount"=> $mail->amount ,"friend_name" => $friend_name,"value" =>$mail->deal_value));
			    $subject = "Thanks for buying from coupon ". SITENAME;			
			    if($friend_email != "xxxyyy@zzz.com"){
			            $friend_message = new View("themes/".THEME_NAME."/friend_buyit_mail");
			    } else {
			            $message = new View("themes/".THEME_NAME."/payment_mail");
			    }			    
				$transaction_coupon_details = $this->authorize->get_all_deal_captured_coupon($deal_id, $mail->user_id, $mail->order_date);
				$coupon_array = array();
				foreach($transaction_coupon_details as $coupon_details){
					$coupon_array[] = $coupon_details->coupon_code;	
				}				
				pdf::pdf_created($coupon_array);
				$file=array();
				for($i=0; $i < count($coupon_array); $i++){
					array_push($file, "images/pdf/Voucher".$i.".pdf");
				}				
				if($friend_email != "xxxyyy@zzz.com"){
				    $status = email::sendgrid_attach($friend_email, "You Got Coupon Gift from your Friend", $friend_message, $file);
				} else {
				    $status = email::sendgrid_attach($mail->email, $subject, $message, $file);
				} 	
				
				$transaction_coupon_update = $this->authorize->update_transaction_coupon_status($deal_id,$mail->user_id);
				for($i=0; $i < count($coupon_array); $i++){
					unlink("images/pdf/Voucher".$i.".pdf");
				}
			}	
		}
        $user_details = $this->authorize->get_purchased_user_details();
		foreach($user_details as $U){
			if($U->referred_user_id && $U->deal_bought_count == $qty){
				$update_reff_amount = $this->authorize->update_referral_amount($U->referred_user_id);
			}
			if($U->facebook_update == 1){
				$deals_details = $this->authorize->get_deals_details($deal_id);
				foreach($deals_details as $D){
					$dealURL = PATH."deals/".$D->deal_key.'/'.$D->url_title.".html";
					$message = "I have purchased the deal...".$D->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $U->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg );
				}
			}
		}
		return;
	}
	
	
	/** DOCAPTURED PAYMENT, UPDATED AMOUNT TO REFERED USERS, POST PURCHASE DEALS TO FACEBOOK WALL and SEND MAIL **/

	public function do_captured_product_transaction($captured = "", $deal_id = "", $qty = "",$transaction = "")
	{
	
	    $user_details = $this->authorize->get_purchased_user_details();
		foreach($user_details as $U){
			if($U->referred_user_id && $U->deal_bought_count == $qty){
				$update_reff_amount = $this->authorize->update_referral_amount($U->referred_user_id);
			}
			$deals_details = $this->authorize->get_product_details($deal_id);
			if($U->facebook_update == 1){				
				foreach($deals_details as $D){
					$dealURL = PATH."deals/".$D->deal_key.'/'.$D->url_title.".html";
					$message = "I have purchased the deal...".$D->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $U->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg);
				}
			}  
			
			/** Send Purchase details to user Email **/
			foreach($deals_details as $D){
			    $deal_title = $D->deal_title;
			    $deal_amount = $D->deal_value;
			}
			
			$friend_details = $this->authorize->get_friend_transaction_product_details($deal_id, $transaction);
            $friend_email = $friend_details->current()->friend_email;
            $friend_name = $friend_details->current()->friend_name;
            if($friend_email != "xxxyyy@zzz.com"){
                $from = CONTACT_EMAIL;
                $this->transaction_mail =array("deal_title" => $deal_title, "item_qty" => $qty ,"total" => ($deal_amount * $qty) ,"amount"=> ($deal_amount * $qty),"ref_amount"=> "0","value" =>$deal_amount,"friend_name" => $friend_name,"value" =>$deal_amount);
                $this->result_mail = arr::to_object($this->transaction_mail);
                $friend_message = new View("themes/".THEME_NAME."/friend_buyit_mail");
		if(EMAIL_TYPE==2){           
                email::smtp($from, $friend_email, "You Got Product Gift from your Friend" ,$friend_message);   
		}else{
		 email::sendgrid($from, $friend_email, "You Got Product Gift from your Friend" ,$friend_message); 

		}      
            
            } else {
                $from = CONTACT_EMAIL;
				$this->products_list = $this->authorize->get_products_coupons_list($transaction,$deal_id);
				$this->product_size = $this->authorize->get_shipping_product_size();
				$this->product_color = $this->authorize->get_shipping_product_color();
                // $this->transaction_mail = array("deal_title" => $deal_title, "item_qty" => $qty ,"total" => ($deal_amount * $qty) ,"amount"=> ($deal_amount * $qty),"value" =>$deal_amount);
                //$this->result_mail = arr::to_object($this->transaction_mail);
                /* Mail template */
                $message = new View("themes/".THEME_NAME."/payment_mail_product");
		if(EMAIL_TYPE==2){ 	
                email::smtp($from,$U->email, "Thanks for buying from ". SITENAME ,$message);  
		}else{
		 email::sendgrid($from,$U->email, "Thanks for buying from ". SITENAME ,$message); 
		}          
            }
			
		}
		return;
		
	}
	
	/** Send Purchase details to user Email **/
	
	private function payment_mail_function( $captured = "", $deal_id = "", $transaction_id = "")
	{
		$from = NOREPLY_EMAIL;
		$transaction_details = $this->authorize->get_all_deal_captured_transaction($deal_id, $transaction_id, $captured);	
		foreach($transaction_details as $TD){		
		        $friend_details = $this->authorize->get_friend_transaction_details($deal_id, $transaction_id);	
                $friend_email = $friend_details->current()->friend_email;
                $friend_name = $friend_details->current()->friend_name;
                        
			$this->result_mail = arr::to_object(array("deal_title" => $TD->deal_title, "item_qty" => $TD->quantity ,"total" => $TD->amount + $TD->referral_amount,"ref_amount"=> $TD->referral_amount, "amount"=> $TD->amount ,"friend_name" => $friend_name,"value" =>$TD->deal_value));
			$subject = "Thanks for buying from ". SITENAME;			
			if($friend_email != "xxxyyy@zzz.com"){
			        $friend_message = new View("themes/".THEME_NAME."/friend_buyit_mail");
			} else {
			        $message = new View("themes/".THEME_NAME."/payment_mail");

			}
	        if($friend_email != "xxxyyy@zzz.com"){
			if(EMAIL_TYPE==2){
	                email::smtp($from, $friend_email, "You Got Coupon Gift from your Friend" ,$friend_message);
			}else{
			email::sendgrid($from, $friend_email, "You Got Coupon Gift from your Friend" ,$friend_message);
			}
	        } else {
			if(EMAIL_TYPE==2){		        
	                email::smtp($from,$TD->email, $subject, $message);
			}else{
			email::sendgrid($from,$TD->email, $subject, $message);
			}
	        }			
		}		
		return;
	}
	
	/** Send Purchase details to user Email **/
	
	private function payment_auction_mail_function($deal_id = "", $transaction_id = "")
	{
		$this->auction_details = $this->authorize->get_auction_mail_data($deal_id,$transaction_id);
		$message = new View("themes/".THEME_NAME."/auction/auction_payment_mail"); 
		foreach ($this->auction_details as $row) {
			if($row->facebook_update == 1){				
					$dealURL = PATH."deals/".$row->deal_key.'/'.$row->url_title.".html";
					$message = "I have purchased the deal...".$row->deal_title." ".$dealURL." limited offer hurry up!";
					$post_arg = array("access_token" => $row->fb_session_key, "message" => $message, "id" => $U->fb_user_id, "method" => "post");
					common::fb_curl_function("https://graph.facebook.com/feed", "POST", $post_arg );
			}
			$from = NOREPLY_EMAIL;
			$subject = "Thanks for buying from ". SITENAME;
			if(EMAIL_TYPE==2){
                email::smtp($from,$row->email, $subject, $message);
		    }
		    else{
		        email::sendgrid($from,$row->email, $subject, $message);
		    }
 		}
		return;
	}
	
	/** PAYMENT STATS AFTER PAYMENT PROCESS COMPLETE **/

	public function success()
	{
	    $this->result = $this->session->get('payment_result');
		if(!$this->result){
			url::redirect(PATH);
		}
	    $this->session->delete('payment_result');
		$this->template->content = new View("themes/".THEME_NAME."/success_payment");
	}

}

