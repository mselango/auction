<?php defined('SYSPATH') or die('No direct script access.');
class Cash_on_delivery_Model extends Model
{
	public function __construct()
	{	
		parent::__construct();
		$this->db = new Database();
		$this->session = Session::instance();	
		$this->UserID = $this->session->get("UserID");
	}

	/** GET PRODUCT PAYMENT DETAILS  **/
	
	public function insert_deal_cod_details($sname,$email,$phone,$address,$city,$state,$country,$pin,$deal_id,$amount,$qty,$fb_id)
	{
			$result = $this->db->insert("deal_cod",array("user_id" => $this->UserID , "deal_id" => $deal_id,"email" => $email, "shipping_name" => $sname, "amount" => $amount, "status" => 'Pending', "quantity" => $qty,"datetime" =>time(),"city" => $city ,"address" => $address ,"state" => $state ,"country" => $country,"phone" => $phone,"pin" => $pin,"fb_id" => $fb_id));
			//print_r($result);exit;
			
			return ;
		
	}
	
		public function insert_auction_cod_details($sname,$email,$phone,$address,$city,$state,$country,$pin,$deal_id,$amount,$qty,$fb_id)
	{
			$result = $this->db->insert("auction_cod",array("user_id" => $this->UserID , "auction_id" => $deal_id,"email" => $email, "shipping_name" => $sname, "amount" => $amount, "status" => 'Pending', "quantity" => $qty,"datetime" =>time(),"city" => $city ,"address" => $address ,"state" => $state ,"country" => $country,"phone" => $phone,"pin" => $pin,"fb_id" => $fb_id));
			//print_r($result);exit;
			return ;
		
	}
	
	
	public function get_product_payment_details($deal_id = "")
	{
		$result = $this->db->query("select * from product  join category on category.category_id=product.category_id where deal_status = 1 and category.category_status = 1 and deal_id = $deal_id ");
	        return $result;

	}

	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CASH ON DELIVERY **/

	public function insert_cash_delivery_transaction_details($deal_id = "", $referral_amount = "", $qty = "",$type ="", $captured = "",$purchase_qty = "",$paymentType = "",$product_amount = "",$merchant_id = "",$product_size = "",$product_color = "",$tax_amount = "",$shipping_amount = "",$post)
	{
	
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission; 
	    
		$result = $this->db->insert("transaction",array("user_id" => $this->UserID , "product_id" => $deal_id, "firstname" => $post->shipping_name, "lastname" => $post->shipping_name, "order_date" => time(), "amount" => $product_amount, "payment_status" => 'Pending', "pending_reason" => 'Cash on delivery', "referral_amount" => $referral_amount,"transaction_type" => $paymentType, "quantity" => $qty, "type" => $type, "captured" => $captured,"transaction_date" =>time(),'deal_merchant_commission' => $commission_amount,"friend_gift_status" => $post->friend_gift,"product_size" => $product_size, "product_color"=>$product_color,"shipping_amount"=>$shipping_amount, "tax_amount"=>$tax_amount));

		$trans_ID = $result->insert_id();
		
		$this->db->insert("shipping_info", array("transaction_id" => $trans_ID , "user_id" => $this->UserID, "adderss1" => $post->adderss1 , "address2" => $post->address2, "city" => $post->city ,"state" => $post->state ,"country" => $post->country,"name" => $post->shipping_name ,"postal_code" => $post->postal_code ,"phone" => $post->phone,"shipping_type" =>1,"shipping_date" => time()));

		//for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("product_id" => $deal_id , "user_id" => $this->UserID, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" =>$post->friend_name, "friend_email" => $post->friend_email,"product_size" => $product_size, "product_color"=>$product_color));
		//}

		$purchase_count_total = $purchase_qty + $qty;
	    $result_deal = $this->db->update("product", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
		 $this->db->query("update product_size set quantity = quantity - $qty where deal_id = $deal_id and size_id = $product_size");
		return $trans_ID;

	}
	
	/** GET PURCHASED USERID **/

	public function get_purchased_user_details()
	{
		$result = $this->db->from("users")->where(array("user_id" => $this->UserID))->get();
		return $result;
	}
	
	/** UPDATE AMOUNT TO REFERED USER **/

	public function update_referral_amount($ref_user_id = "")
	{
		$referral_amount = REFERRAL_AMOUNT;
		
		$this->db->query("update users set user_referral_balance = user_referral_balance+$referral_amount where user_id = $ref_user_id");
		return;
	}

	/** GET DEALS DETAILS **/

	public function get_deals_details($deal_id = "")
	{
		$result = $this->db->query("select * from product  join stores on stores.store_id=product.shop_id join category on category.category_id=product.category_id where deal_status = 1 and category.category_status = 1 and  store_status = 1 and product.deal_id = $deal_id");
	        return $result;
	}
	
	/** GET FRIEND DETAILS **/

	public function get_friend_transaction_details($deal_id = "", $transaction_id = "")
	{
	        $result = $this->db->select("transaction_mapping.friend_name", "transaction_mapping.friend_email")
					->from("transaction_mapping")
					->where(array("transaction_id" => $transaction_id, "product_id" => $deal_id))
					->get();
		return $result;
	
	}

	/** GET PRODUCT SIZE **/
	
	public function product_size_details($deal_id = "", $size_id = "")
	{
		$result = $this->db->from("product_size")
				->where(array("deal_id" => $deal_id,"size_id" => $size_id))
		     		->get();
		return $result;
	}


	/**GET PRODUCTS LIST**/

	public function get_products_coupons_list($transaction = "",$deal_id = "")
	{

		$result = $this->db->select('*','shipping_info.adderss1 as saddr1','shipping_info.address2 as saddr2','users.phone_number','transaction.id as trans_id','stores.address1 as addr1','stores.address2 as addr2','stores.phone_number as str_phone','transaction.shipping_amount as shipping')->from("shipping_info")
                    ->where(array("shipping_type"=>1,"shipping_info.user_id" => $this->UserID,"transaction.id" =>$transaction,"transaction.product_id" =>$deal_id))
                    ->join("users","users.user_id","shipping_info.user_id") 					
                    ->join("transaction","transaction.id","shipping_info.transaction_id")  
					->join("product","product.deal_id","transaction.product_id") 
					->join("stores","stores.store_id","product.shop_id") 
					->join("city","city.city_id","shipping_info.city")             
                    ->orderby("shipping_id","DESC")

                    ->get(); 
		return $result;	
                
	}

	public function get_shipping_product_color()
	{
		$result = $this->db->from("color_code")->get();
		return $result;
	}
	
	public function get_shipping_product_size()
	{
		$result = $this->db->from("size")->get();
		return $result;
	}

}
