<?php defined('SYSPATH') or die('No direct script access.');
class Authorize_Model extends Model
{
	public function __construct()
	{	
		parent::__construct();
		$this->db = new Database();
		$this->session = Session::instance();	
		$this->UserID = $this->session->get("UserID");
	}
	
	/** GET DEALS PAYMENT DETAILS  **/
	
	public function get_deals_payment_details($deal_id = "", $deal_key = "")
	{
		$result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where deal_status = 1 and category.category_status = 1 and  store_status = 1 and deal_key = '$deal_key'  and deals.deal_id = '$deal_id' and enddate > 'time()'");
	        return $result;
	}
	
	/** *GET DEALS DETAILS */

	public function get_deals_details($deal_id = "")
	{
		$result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where  deal_status = 1 and category.category_status = 1 and  store_status = 1 and deals.deal_id = '$deal_id'");
	        return $result;
	}
	
	/** *GET PRODUCT DETAILS */

	public function get_product_details($deal_id = "")
	{
		$result = $this->db->query("select * from product  join stores on stores.store_id=product.shop_id join category on category.category_id=product.category_id where  deal_status = 1 and category.category_status = 1 and  store_status = 1 and product.deal_id = '$deal_id'");
	        return $result;
	}
	
	/** GET USER LIMIT **/
	
	public function get_user_limit_details($deal_id = "")
	{
		$result = $this->db->count_records("transaction_mapping", array( "deal_id" => $deal_id, "user_id" => $this->UserID));	            
                return $result;
	}
	
	/** GET USER REFERRAL BALANCE DETAILS **/
	
	public function get_user_referral_balance_details()
	{
		$result = $this->db->select("user_referral_balance")->from("users")
				   ->where(array("user_id" => $this->UserID))
				   ->get();
		if(count($result)){
			return $result->current()->user_referral_balance;
		}
		return 0;
	}

	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CREDIT CARD PAYMENT **/

	public function insert_transaction_details($R = "", $pay_amount = "" , $deal_id = "", $transaction_id = "", $country_code = "",$currencyCode = "", $firstName = "", $lastName = "", $ref_amount = 0, $qty = 1, $type = 4, $captured = 0, $purchase_qty = "" ,$friend_gift = "",$friendName = "",$friendEmail = "",$merchant_id = "")
	{
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission; 

		$payment_status = "Pending";
		if($captured == 0){
			$payment_status = "Completed";
		}
				
		$result = $this->db->insert("transaction",array("user_id" => $this->UserID , "deal_id" => $deal_id, "country_code" => $country_code, "currency_code" => $currencyCode, "transaction_date" => time(), "correlation_id" => $R['Authorization_Code'], "acknowledgement" => "Success", "firstname" => $firstName, "lastname" => $lastName, "transaction_id" => $transaction_id, "order_date" => time(), "amount" => $pay_amount, "referral_amount" => $ref_amount, "transaction_type" =>  $R['Credit_card'], "payment_status" => $payment_status, "quantity" => $qty, "type" => "4", "captured" => $captured,"friend_gift_status" => $friend_gift, 'deal_merchant_commission' => $commission_amount));

		$trans_ID = $result->insert_id();

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("deal_id" => $deal_id , "user_id" => $this->UserID, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" =>$friendName, "friend_email" => $friendEmail ));			
		}

		 $purchase_count_total = $purchase_qty + $qty;
	     $result_deal = $this->db->update("deals", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
		 $this->db->query("update users set user_referral_balance = user_referral_balance - $ref_amount, deal_bought_count = deal_bought_count + $qty where user_id = $this->UserID");
		 $this->db->query("update users set merchant_account_balance = merchant_account_balance + $pay_amount where user_type = 1");

		return $trans_ID;
	}
	
	
	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CREDIT CARD PAYMENT **/

	public function insert_product_transaction_details($R = "", $pay_amount = "", $deal_id = "", $transaction_id = "", $country_code = "",$currencyCode = "", $firstName = "", $lastName = "", $ref_amount = 0, $qty = 1, $type = 4, $captured = 0, $purchase_qty = "" ,$friend_gift = "",$friendName = "",$friendEmail = "",$merchant_id = "", $post = "", $product_size  = "",$product_color = "",$tax_amount = "" ,$shipping_amount = "")
	{
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission;

		$payment_status = "Pending";
		if($captured == 0){
			$payment_status = "Completed";
		}
				
		$result = $this->db->insert("transaction",array("user_id" => $this->UserID , "product_id" => $deal_id, "country_code" => $country_code, "currency_code" => $currencyCode, "transaction_date" => time(), "correlation_id" => $R['Authorization_Code'], "acknowledgement" => "Success", "firstname" => $firstName, "lastname" => $lastName, "transaction_id" => $transaction_id, "order_date" => time(), "amount" => $pay_amount, "referral_amount" => $ref_amount, "transaction_type" =>  $R['Credit_card'], "payment_status" => $payment_status, "quantity" => $qty, "type" => "4", "captured" => $captured,"friend_gift_status" => $friend_gift, 'deal_merchant_commission' => $commission_amount,"product_size" => $product_size, "product_color"=>$product_color,"shipping_amount"=>$shipping_amount, "tax_amount"=>$tax_amount));

		$trans_ID = $result->insert_id();

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("product_id" => $deal_id , "user_id" => $this->UserID, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" =>$friendName, "friend_email" => $friendEmail,"product_size" => $product_size, "product_color"=>$product_color ));			
		}

		 $purchase_count_total = $purchase_qty + $qty;		
		 $this->db->insert("shipping_info", array("transaction_id" => $trans_ID , "user_id" => $this->UserID, "adderss1" => $post->shipping_adderss1 , "address2" => $post->shipping_address2, "city" => $post->shipping_city ,"state" => $post->shipping_state ,"country" => $post->shipping_country,"name" => $post->shipping_name ,"postal_code" => $post->shipping_postal_code ,"phone" => $post->shipping_phone, "shipping_date" => time()));

         $total_pay_amount = ($pay_amount + $shipping_amount + $tax_amount); 
		 $commission=(($pay_amount)*($commission_amount/100));
         $merchantcommission = $total_pay_amount - $commission ; 
         $this->db->query("update users set merchant_account_balance = merchant_account_balance + $merchantcommission where user_type = 3 and user_id = $merchant_id ");
         
		$purchase_count_total = $purchase_qty + $qty;
	    $result_deal = $this->db->update("product", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
		$this->db->query("update users set merchant_account_balance = merchant_account_balance + $pay_amount where user_type = 1");
		$this->db->query("update product_size set quantity = quantity - $qty where deal_id = $deal_id and size_id = $product_size");

		return $trans_ID;
	}

	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CREDIT CARD PAYMENT FOR AUCTION **/

	public function insert_auction_transaction_details($R = "", $pay_amount = "", $deal_id = "", $transaction_id = "", $country_code = "",$currencyCode = "", $firstName = "", $lastName = "", $ref_amount = 0, $qty = 1, $type = 4, $captured = 0, $purchase_qty = "" ,$merchant_id = "", $post = "",$tax_amount = "" ,$shipping_amount = "",$auction_amount = 0,$bid_id = 0)
	{
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission; 

		$payment_status = "Pending";
		if($captured == 0){
			$payment_status = "Completed";
		}
				
		$result = $this->db->insert("transaction",array("user_id" => $this->UserID , "auction_id" => $deal_id, "country_code" => $country_code, "currency_code" => $currencyCode, "transaction_date" => time(), "correlation_id" => $R['Authorization_Code'], "acknowledgement" => "Success", "firstname" => $firstName, "lastname" => $lastName, "transaction_id" => $transaction_id, "order_date" => time(), "amount" => $pay_amount,"bid_amount" =>$auction_amount, "referral_amount" => $ref_amount, "transaction_type" =>  $R['Credit_card'], "payment_status" => $payment_status, "quantity" => $qty, "type" => 4, "captured" => $captured, 'deal_merchant_commission' => $commission_amount,"shipping_amount"=>$shipping_amount, "tax_amount"=>$tax_amount));

		$trans_ID = $result->insert_id();

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("auction_id" => $deal_id , "user_id" => $this->UserID, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" => 'xxxyyy', "friend_email" => 'xxxyyy@zzz.com'));			
		}


		 $total_pay_amount = ($pay_amount + $shipping_amount + $tax_amount); 
		 $commission=(($pay_amount)*($commission_amount/100));
         $merchantcommission = $total_pay_amount - $commission ; 
         $this->db->query("update users set merchant_account_balance = merchant_account_balance + $merchantcommission where user_type = 3 and user_id = $merchant_id ");

		// $purchase_count_total = $purchase_qty + $qty;     

		$this->db->insert("shipping_info", array("transaction_id" => $trans_ID , "user_id" => $this->UserID, "adderss1" => $post->shipping_adderss1 , "address2" => $post->shipping_address2, "city" => $post->shipping_city ,"state" => $post->shipping_state ,"country" => $post->shipping_country,"name" => $post->shipping_name ,"postal_code" => $post->shipping_postal_code ,"phone" => $post->shipping_phone,"shipping_type" => 2, "shipping_date" => time()));

		//$purchase_count_total = $purchase_qty + $qty;
	   // $result_deal = $this->db->update("deals", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
		$this->db->query("update users set merchant_account_balance = merchant_account_balance + $pay_amount where user_type = 1");

		 $this->db->update("bidding",array("winning_status" => 2),array("bid_id" =>$bid_id,"user_id" =>$this->UserID,"auction_id" =>$deal_id));	
		//$this->db->query("update product_size set quantity = quantity - $qty where deal_id = $deal_id and size_id = $product_size");

		return $trans_ID;
	}

	/** GET AUCTION MAIL DATA   **/

	public function get_auction_mail_data($deal_id = "",$transaction_id = "")
	{

		$result = $this->db->select("shipping_info.*,auction.deal_title,deal_price,transaction.bid_amount,transaction.quantity,transaction.shipping_amount,transaction.tax_amount,transaction.transaction_date,store_name,stores.address1 as addr1,stores.address2 as addr2,city_name,stores.zipcode,stores.phone_number as str_phone,transaction.shipping_amount as shipping,shipping_info.adderss1 as saddr1,shipping_info.address2 as saddr2,shipping_info.phone,stores.website,shipping_info.name,shipping_info.country,auction.deal_key,auction.deal_value,auction.url_title,users.fb_session_key,users.fb_user_id,users.email,users.facebook_update")->from("shipping_info")->join("transaction","transaction.id","shipping_info.transaction_id")->join("auction","auction.deal_id","transaction.auction_id")->join("stores","stores.store_id","auction.shop_id")->join("city","city.city_id","shipping_info.city")->join("users","users.user_id","shipping_info.user_id")->where(array("users.user_id" => $this->UserID,"transaction.id" =>$transaction_id,"auction.deal_id" => $deal_id))->get();
			
		return $result;
	}
		
	/** UPDATE AMOUNT TO REFERED USER **/

	public function update_referral_amount($ref_user_id = "")
	{
		$referral_amount = REFERRAL_AMOUNT;
		
		$this->db->query("update users set user_referral_balance = user_referral_balance+$referral_amount where user_id = $ref_user_id");
		return;
	}

	/** GET PURCHASED USERID **/

	public function get_purchased_user_details()
	{
		$result = $this->db->from("users")->where(array("user_id" => $this->UserID))->get();
		return $result;
	}/** GET AUTHORIZATION PAYMENT LIST FROM TRANSACTION LIST  **/

	public function payment_authorization_mail_list($deal_id = "")
	{
	    $cont = array("transaction.deal_id" => $deal_id, "captured" => 0, "coupon_mail_sent" => 0,"deals.deal_type" => 1);
		$result = $this->db->select("users.email", "transaction.id", "deal_title","deal_value", "transaction.quantity", "transaction.amount", "transaction.referral_amount", "transaction.user_id", "transaction.order_date")
					->from("transaction")
					->join("deals", "deals.deal_id", "transaction.deal_id")
					->join("users", "users.user_id", "transaction.user_id")
					->where($cont)
					->get();
		return $result;
	}
	

	/** GET AUTHORIZATION PAYMENT LIST FROM TRANSACTION LIST  **/

	public function payment_authorization_list( $deal_id = "")
	{
		$result = $this->db->from("transaction")->where(array("deal_id" => $deal_id, "captured" => 1))->get();
		return $result;
	}
	
	/** UPDATE THE CAPTURED TRANSACTION **/

	public function update_captured_transaction($now_transaction_id = "", $now_authorization_code = "", $id = "")
	{
		 $contition = array("captured_transaction_id" => $now_transaction_id , "captured_date" => time() , "captured_correlation_id" => $now_authorization_code, "captured_ack" => "Success",  "captured_payment_status" => "Completed", "captured_pending_reason" => "None", "captured" => 0, "payment_status" => "Completed");
		
		$result = $this->db->update("transaction", $contition , array("id" => $id));
		return;
	}
	
	/** UPDATE THE CAPTURED TRANSACTION FAILED **/

	public function update_captured_transaction_failed($id = "")
	{
		 $contition = array("captured_date" => time() , "captured_ack" => "Failed",  "captured_payment_status" => "Failed", "captured_pending_reason" => "None", "captured" => 0, "payment_status" => "Failed", "acknowledgement"=>"Failed");
		
		$result = $this->db->update("transaction", $contition , array("id" => $id));
		return;
	}

	/** GET ALL CAPTURED TRANSACTION LIST **/

	public function get_all_deal_captured_transaction($deal_id = "", $transaction_id = "", $captured = "")
	{
		if($captured  == 0){
			$cont = array("transaction.deal_id" => $deal_id, "captured" => 0, "coupon_mail_sent" => 0);
		}
		else{
			$cont = array("transaction.id" => $transaction_id);
		}
		$result = $this->db->select("users.email", "transaction.id", "deal_title","deal_value", "transaction.quantity", "transaction.amount", "transaction.referral_amount", "transaction.user_id", "transaction.order_date")
					->from("transaction")
					->join("deals", "deals.deal_id", "transaction.deal_id")
					->join("users", "users.user_id", "transaction.user_id")
					->where($cont)
					->get();
		return $result;
	}

	/** GET COUPON DETAILS **/

	public function get_all_deal_captured_coupon($deal_id = "", $user_id = "", $order_date = "")
	{
		     $result = $this->db->select("coupon_code")->from("transaction_mapping")
		                        ->join("transaction", "transaction.id", "transaction_mapping.transaction_id")
					->where(array("transaction_mapping.deal_id" => $deal_id, "coupon_code_status" => 1, "transaction_mapping.user_id" => $user_id, "transaction_mapping.transaction_date" => $order_date, "transaction.coupon_mail_sent" => 0))
					->get();
		        return $result;
	}
	
	/** UPDATE TRANSACTION COUPON STATUS  **/
	
	public function update_transaction_coupon_status($transaction_id = "", $user_id = "")
	{
	                $result = $this->db->update("transaction", array("coupon_mail_sent" => 1), array("transaction.id" => $transaction_id, "transaction.user_id" => $user_id)); 
	}
	
	/** GET FRIEND DETAILS **/

	public function get_friend_transaction_details($deal_id = "", $transaction_id = "")
	{
	        $result = $this->db->select("transaction_mapping.friend_name", "transaction_mapping.friend_email")
					->from("transaction_mapping")
					->where(array("transaction_id" => $transaction_id, "deal_id" => $deal_id))
					->get();
		return $result;
	
	}
	
	/** GET FRIEND DETAILS **/

	public function get_friend_transaction_product_details($deal_id = "", $transaction_id = "")
	{
	        $result = $this->db->select("transaction_mapping.friend_name", "transaction_mapping.friend_email")
					->from("transaction_mapping")
					->where(array("transaction_id" => $transaction_id, "product_id" => $deal_id))
					->get();
		return $result;
	
	}
	
	/** GET PRODUCT PAYMENT DETAILS  **/
	
	public function get_product_payment_details($deal_id = "")
	{
		$result = $this->db->query("select * from product  join category on category.category_id=product.category_id where  deal_status = 1 and category.category_status = 1 and deal_id = '$deal_id' ");
	        return $result;

	}
	
	/** GET PRODUCT SIZE **/
	
	public function product_size_details($deal_id = "", $size_id = "")
	{
		$result = $this->db->from("product_size")
				->where(array("deal_id" => $deal_id,"size_id" => $size_id))
		     		->get();
		return $result;
	}
	
	
	/**GET PRODUCTS LIST**/

	public function get_products_coupons_list($transaction = "",$deal_id = "")
	{

		$result = $this->db->select('*','shipping_info.adderss1 as saddr1','shipping_info.address2 as saddr2','users.phone_number','transaction.id as trans_id','stores.address1 as addr1','stores.address2 as addr2','stores.phone_number as str_phone','transaction.shipping_amount as shipping')->from("shipping_info")
                    ->where(array("shipping_type"=>1,"shipping_info.user_id" => $this->UserID,"transaction.id" =>$transaction,"transaction.product_id" =>$deal_id))
                    ->join("users","users.user_id","shipping_info.user_id") 					
                    ->join("transaction","transaction.id","shipping_info.transaction_id")  
					->join("product","product.deal_id","transaction.product_id") 
					->join("stores","stores.store_id","product.shop_id") 
					->join("city","city.city_id","shipping_info.city")             
                    ->orderby("shipping_id","DESC")

                    ->get(); 
		return $result;	
                
	}

	public function get_shipping_product_color()
	{
		$result = $this->db->from("color_code")->get();
		return $result;
	}
	
	public function get_shipping_product_size()
	{
		$result = $this->db->from("size")->get();
		return $result;
	}
	
}	
