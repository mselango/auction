<?php defined('SYSPATH') or die('No direct script access.');
class Creditcard_paypal_Model extends Model
{
	public function __construct()
	{	
		parent::__construct();
		$this->db = new Database();
		$this->session = Session::instance();	
		$this->UserID = $this->session->get("UserID");
	}
	
	/** GET DEALS PAYMENT DETAILS  **/
	
	public function get_deals_payment_details($deal_id = "", $deal_key = "")
	{
		$result = $this->db->query("select * from deals  join stores on stores.store_id=deals.shop_id join category on category.category_id=deals.category_id where deal_type = 1  and deal_status = 1 and category.category_status = 1 and  store_status = 1 and deal_key = '$deal_key'  and deals.deal_id = '$deal_id' and enddate > 'time()'");
	        return $result;
	}
	
		
	/** GET USER LIMIT **/
	
	public function get_user_limit_details($deal_id = "")
	{
		$result = $this->db->count_records("transaction_mapping", array( "product_id" => $deal_id, "user_id" => $this->UserID));	            
                return $result;
	}
	
	/** GET USER REFERRAL BALANCE DETAILS **/
	
	public function get_user_referral_balance_details()
	{
		$result = $this->db->select("user_referral_balance")->from("users")
				   ->where(array("user_id" => $this->UserID))
				   ->get();
		if(count($result)){
			return $result->current()->user_referral_balance;
		}
		return 0;
	}

	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - CREDIT CARD PAYMENT **/

	public function insert_transaction_details($R = "", $deal_id = "", $country_code = "", $firstName = "", $lastName = "", $ref_amount = 0, $qty = 1, $type = 1, $captured = 0, $purchase_qty = "" ,$post = "",$merchant_id = "",$friend_gift = "",$friendName = "",$friendEmail = "",$product_size = "",$product_color = "",$tax_amount = "" ,$shipping_amount = "", $deal_amount = "")
	{
	
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission;     
		$result = $this->db->insert("transaction",array("user_id" => $this->UserID , "product_id" => $deal_id, "country_code" => $country_code, "currency_code" => $R->CURRENCYCODE, "transaction_date" => strtotime($R->TIMESTAMP), "correlation_id" => $R->CORRELATIONID, "acknowledgement" => $R->ACK, "firstname" => $firstName, "lastname" => $lastName, "transaction_id" => $R->TRANSACTIONID, "order_date" => time(), "amount" => $deal_amount , "referral_amount" => $ref_amount, "payment_status" => $R->ACK, "quantity" => $qty, "type" => $type, "captured" => $captured,'deal_merchant_commission' => $commission_amount,"friend_gift_status" => $friend_gift,"product_size" => $product_size, "product_color"=>$product_color,"shipping_amount"=>$shipping_amount, "tax_amount"=>$tax_amount));
		$trans_ID = $result->insert_id();

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("product_id" => $deal_id , "user_id" => $this->UserID, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" =>$friendName, "friend_email" => $friendEmail,"product_size" => $product_size, "product_color"=>$product_color));
		}
		
		$this->db->insert("shipping_info", array("transaction_id" => $trans_ID , "user_id" => $this->UserID, "adderss1" => $post->shipping_adderss1 , "address2" => $post->shipping_address2, "city" => $post->shipping_city ,"state" => $post->shipping_state ,"country" => $post->shipping_country,"name" => $post->shipping_name ,"postal_code" => $post->shipping_postal_code ,"phone" => $post->shipping_phone, "shipping_date" => time()));
		
		 $total_pay_amount = ($deal_amount + $shipping_amount + $tax_amount); 
		 $commission=(($deal_amount)*($commission_amount/100));
         $merchantcommission = $total_pay_amount - $commission ; 
         $this->db->query("update users set merchant_account_balance = merchant_account_balance + $merchantcommission where user_type = 3 and user_id = $merchant_id ");
           
		 $purchase_count_total = $purchase_qty + $qty;
	     $result_deal = $this->db->update("product", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
	     $this->db->query("update users set merchant_account_balance = merchant_account_balance + $total_pay_amount where user_type = 1");	     
	     $this->db->query("update product_size set quantity = quantity - $qty where deal_id = $deal_id and size_id = $product_size");		

		return $trans_ID;
	}

	/** INSERT TRANSACTION DETAILS TO TRANSACTION TABLE - PAYPAL EXPRESS CHECK OUT **/

	public function insert_paypal_transaction_details($R = "", $payer="", $type = "",$deal_id = "", $referral_amount = "", $qty = "", $purchase_qty = "", $captured = "",$paymentType = "",$deal_amount = "",$merchant_id = "",$friend_name= "",$friend_email = "", $friend_gift_status = "",$adderss1= "",$adderss2 = "", $state = "",$city= "",$country = "",$product_size = "",$product_color = "", $shipping_name = "", $postal_code= "",$phone = "",$tax_amount = "",$shipping_amount = "")
	{
	
	    $merchant_commission = $this->db->select("merchant_commission")->from("users")->where(array("user_id" => $merchant_id))->get();
		$commission_amount=$merchant_commission->current()->merchant_commission; 
	    if($R->ACK = "SUCCESSWITHWARNING"){
			$R->ACK = "Success";
		}

		$result = $this->db->insert("transaction",array("user_id" => $this->UserID , "product_id" => $deal_id, "payer_id" => $payer->PAYERID , "payer_status" => $payer->PAYERSTATUS, "paypal_email" => $payer->EMAIL ,"country_code" => $payer->COUNTRYCODE, "currency_code" => $R->CURRENCYCODE, "transaction_date" => strtotime($R->TIMESTAMP), "correlation_id" => $R->CORRELATIONID, "transaction_id" => $R->TRANSACTIONID, "transaction_type" =>  $R->TRANSACTIONTYPE, "payment_type" => $paymentType, "acknowledgement" => $R->ACK, "firstname" => $payer->FIRSTNAME, "lastname" => $payer->LASTNAME, "order_date" => time(), "amount" => $deal_amount, "payment_status" => $R->PAYMENTSTATUS, "pending_reason" => $R->PENDINGREASON, "reason_code" => $R->REASONCODE , "referral_amount" => $referral_amount, "quantity" => $qty, "type" => $type, "captured" => $captured,'deal_merchant_commission' => $commission_amount,"friend_gift_status" => $friend_gift_status,"product_size" => $product_size, "product_color"=>$product_color,"shipping_amount"=>$shipping_amount, "tax_amount"=>$tax_amount));

		$trans_ID = $result->insert_id();
		
		$this->db->insert("shipping_info", array("transaction_id" => $trans_ID , "user_id" => $this->UserID, "adderss1" => $adderss1 , "address2" => $adderss2, "city" => $city ,"state" => $state ,"country" => $country,"name" => $shipping_name ,"postal_code" => $postal_code ,"phone" => $phone, "shipping_date" => time()));

		for($q=1; $q <= $qty; $q++){
			$coupon_code = text::random($type = 'alnum', $length = 8);
			$this->db->insert("transaction_mapping", array("product_id" => $deal_id , "user_id" => $this->UserID, "transaction_id" => $trans_ID , "coupon_code" => $coupon_code , "coupon_code_status" => 1,"transaction_date"=>time(),"friend_name" =>$friend_name, "friend_email" => $friend_email,"product_size" => $product_size, "product_color"=>$product_color));
		}

         $total_pay_amount = ($deal_amount + $shipping_amount + $tax_amount); 
		 $commission=(($deal_amount)*($commission_amount/100));
         $merchantcommission = $total_pay_amount - $commission ; 
         $this->db->query("update users set merchant_account_balance = merchant_account_balance + $merchantcommission where user_type = 3 and user_id = $merchant_id ");
         
		$purchase_count_total = $purchase_qty + $qty;
	    $result_deal = $this->db->update("product", array("purchase_count" => $purchase_count_total), array("deal_id" => $deal_id)); 
		$this->db->query("update users set merchant_account_balance = merchant_account_balance + $deal_amount where user_type = 1");
		$this->db->query("update product_size set quantity = quantity - $qty where deal_id = $deal_id and size_id = $product_size");

		return $trans_ID;

	}

	
	/** UPDATE AMOUNT TO REFERED USER **/

	public function update_referral_amount($ref_user_id = "")
	{
		$referral_amount = REFERRAL_AMOUNT;
		
		$this->db->query("update users set user_referral_balance = user_referral_balance+$referral_amount where user_id = $ref_user_id");
		return;
	}

	/** GET PURCHASED USERID **/

	public function get_purchased_user_details()
	{
		$result = $this->db->from("users")->where(array("user_id" => $this->UserID))->get();
		return $result;
	}

	/** GET AUTHORIZATION PAYMENT LIST FROM TRANSACTION LIST  **/

	public function payment_authorization_list( $deal_id = "")
	{
		$result = $this->db->from("transaction")->where(array("product_id" => $deal_id, "captured" => 1))->get();
		return $result;
	}
	
	/** UPDATE THE CAPTURED TRANSACTION **/

	public function update_captured_transaction($C = "", $id = "")
	{
		$contition = array("captured_transaction_id" => $C->TRANSACTIONID , "captured_date" => strtotime($C->TIMESTAMP) , "captured_correlation_id" => $C->CORRELATIONID, "captured_ack" => $C->ACK, "captured_payment_type" => $C->PAYMENTTYPE , "captured_payment_status" => $C->PAYMENTSTATUS, "captured_pending_reason" => $C->PENDINGREASON);	
		if($C->PAYMENTSTATUS == "Completed"){			
			$contition = array("captured_transaction_id" => $C->TRANSACTIONID , "captured_date" => strtotime($C->TIMESTAMP) , "captured_correlation_id" => $C->CORRELATIONID, "captured_ack" => $C->ACK, "captured_payment_type" => $C->PAYMENTTYPE , "captured_payment_status" => $C->PAYMENTSTATUS, "captured_pending_reason" => $C->PENDINGREASON, "captured" => 0);
		}
	
		$result = $this->db->update("transaction", $contition , array("id" => $id));
		return;
	}


    /** GET PRODUCT PAYMENT DETAILS  **/
	
	public function get_product_payment_details($deal_id = "")
	{
		$result = $this->db->query("select * from product  join category on category.category_id=product.category_id where deal_status = 1 and category.category_status = 1 and deal_id = '$deal_id' ");
	        return $result;

	}

	
	/** REFERRAL AMOUNT UPDATE **/
	
	public function products_referral_amount_payment_deatils($referral_amount="")
	{
	   if($referral_amount) {
		$this->db->query("update users set user_referral_balance = user_referral_balance - $referral_amount  where user_id = $this->UserID");
		
		} 
	}
	
	
	/** GET DEALS DETAILS **/

	public function get_deals_details($deal_id = "")
	{
		$result = $this->db->query("select * from product  join stores on stores.store_id=product.shop_id join category on category.category_id=product.category_id where deal_type = 2 and deal_status = 1 and category.category_status = 1 and  store_status = 1 and product.deal_id = '$deal_id'");
	    return $result;
	}
	
	/** GET USERS FULL DETAILS **/
	
	public function get_user_details()
	{
		$result = $this->db->from("users")->where(array("user_id" => $this->UserID))->get();
		return $result;
	}
	
	/** GET FRIEND DETAILS **/

	public function get_friend_transaction_details($deal_id = "", $transaction_id = "")
	{
	        $result = $this->db->select("transaction_mapping.friend_name", "transaction_mapping.friend_email")
					->from("transaction_mapping")
					->where(array("transaction_id" => $transaction_id, "product_id" => $deal_id))
					->get();
		return $result;
	
	}
	
	/** GET PRODUCT SIZE **/
	
	public function product_size_details($deal_id = "", $size_id = "")
	{
		$result = $this->db->from("product_size")
				->where(array("deal_id" => $deal_id,"size_id" => $size_id))
		     		->get();
		return $result;
	}
	
	/**GET PRODUCTS LIST**/

	public function get_products_coupons_list($transaction = "",$deal_id = "")
	{

		$result = $this->db->select('*','shipping_info.adderss1 as saddr1','shipping_info.address2 as saddr2','users.phone_number','transaction.id as trans_id','stores.address1 as addr1','stores.address2 as addr2','stores.phone_number as str_phone','transaction.shipping_amount as shipping')->from("shipping_info")
                    ->where(array("shipping_type"=>1,"shipping_info.user_id" => $this->UserID,"transaction.id" =>$transaction,"transaction.product_id" =>$deal_id))
                    ->join("users","users.user_id","shipping_info.user_id") 					
                    ->join("transaction","transaction.id","shipping_info.transaction_id")  
					->join("product","product.deal_id","transaction.product_id") 
					->join("stores","stores.store_id","product.shop_id") 
					->join("city","city.city_id","shipping_info.city")             
                    ->orderby("shipping_id","DESC")

                    ->get(); 
		return $result;	
                
	}

	public function get_shipping_product_color()
	{
		$result = $this->db->from("color_code")->get();
		return $result;
	}
	
	public function get_shipping_product_size()
	{
		$result = $this->db->from("size")->get();
		return $result;
	}
}	
	
	 
