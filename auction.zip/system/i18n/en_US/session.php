<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'The session_name, %s, is invalid. It must contain only alphanumeric characters and underscores. Also at least one letter must be present.',
);